/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.api.enums;

public final class ItemType
extends Enum<ItemType> {
    public static final /* enum */ ItemType MUSHROOM_STEW;
    public static final /* enum */ ItemType BOWL;
    public static final /* enum */ ItemType FLINT_AND_STEEL;
    public static final /* enum */ ItemType LAVA_BUCKET;
    public static final /* enum */ ItemType WRITABLE_BOOK;
    public static final /* enum */ ItemType WATER_BUCKET;
    public static final /* enum */ ItemType COMMAND_BLOCK_MINECART;
    public static final /* enum */ ItemType POTION_ITEM;
    public static final /* enum */ ItemType SKULL;
    public static final /* enum */ ItemType ARMOR_STAND;
    private static final /* synthetic */ ItemType[] $VALUES;

    static {
        ItemType[] itemTypeArray = new ItemType[10];
        ItemType[] itemTypeArray2 = itemTypeArray;
        itemTypeArray[0] = MUSHROOM_STEW = new ItemType();
        itemTypeArray[1] = BOWL = new ItemType();
        itemTypeArray[2] = FLINT_AND_STEEL = new ItemType();
        itemTypeArray[3] = LAVA_BUCKET = new ItemType();
        itemTypeArray[4] = WRITABLE_BOOK = new ItemType();
        itemTypeArray[5] = WATER_BUCKET = new ItemType();
        itemTypeArray[6] = COMMAND_BLOCK_MINECART = new ItemType();
        itemTypeArray[7] = POTION_ITEM = new ItemType();
        itemTypeArray[8] = SKULL = new ItemType();
        itemTypeArray[9] = ARMOR_STAND = new ItemType();
        $VALUES = itemTypeArray;
    }

    public static ItemType[] values() {
        return (ItemType[])$VALUES.clone();
    }

    public static ItemType valueOf(String string) {
        return Enum.valueOf(ItemType.class, string);
    }
}

