/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.features.command.shortcuts;

import net.ccbluex.liquidbounce.features.command.shortcuts.Token;

public final class StatementEnd
extends Token {
}

