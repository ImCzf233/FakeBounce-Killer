/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.event;

public class Event {
}

