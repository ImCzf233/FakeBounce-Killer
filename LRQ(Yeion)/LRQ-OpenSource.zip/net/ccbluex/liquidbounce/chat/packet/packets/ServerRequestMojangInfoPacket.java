/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.chat.packet.packets;

import net.ccbluex.liquidbounce.chat.packet.packets.Packet;

public final class ServerRequestMojangInfoPacket
implements Packet {
}

