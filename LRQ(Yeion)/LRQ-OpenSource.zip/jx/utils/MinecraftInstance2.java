/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package jx.utils;

import net.minecraft.client.Minecraft;

public class MinecraftInstance2 {
    public static final Minecraft mc = Minecraft.func_71410_x();
}

