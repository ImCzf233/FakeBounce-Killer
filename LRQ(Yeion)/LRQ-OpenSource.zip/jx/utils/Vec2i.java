/*
 * Decompiled with CFR 0.152.
 */
package jx.utils;

public class Vec2i {
    int x;
    int y;

    public Vec2i(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }
}

