/*
 * Copyright (c) 2010, 2013, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

if (!this.JFX_BASE_CLASSES) {
    load("fx:base.js")
}

LOAD_FX_CLASSES(JFX_CONTROLS_CLASSES);
