Open-Source by ImCzf#0064.
重生之我是3282600743然後魔改Pride開圈。