package me.utils.fluxfont;

class FluxFont$IntObject {
    public int width;
    public int height;
    public int storedX;
    public int storedY;

    private FluxFont$IntObject() {
    }
}
