package net.ccbluex.liquidbounce.chat.packet.packets;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.chat.packet.packets.Packet;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\n\n\b\u000020B¢¨"}, d2={"Lnet/ccbluex/liquidbounce/chat/packet/packets/ServerRequestJWTPacket;", "Lnet/ccbluex/liquidbounce/chat/packet/packets/Packet;", "()V", "Pride"})
public final class ServerRequestJWTPacket
implements Packet {
}
