package net.ccbluex.liquidbounce.event;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.event.Event;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\n\n\b\u000020B¢¨"}, d2={"Lnet/ccbluex/liquidbounce/event/UpdateEvent;", "Lnet/ccbluex/liquidbounce/event/Event;", "()V", "Pride"})
public final class UpdateEvent
extends Event {
}
