package net.ccbluex.liquidbounce.features.module.modules.render;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.ccbluex.liquidbounce.value.ListValue;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\n\n\u0000\n\b\n\n\b\b\u000020B\b¢R0¢\b\n\u0000\bR0¢\b\n\u0000\b\b¨\t"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/AttackEffects$Companion;", "", "()V", "atksound", "Lnet/ccbluex/liquidbounce/value/ListValue;", "getAtksound", "()Lnet/ccbluex/liquidbounce/value/ListValue;", "mode", "getMode", "Pride"})
public static final class AttackEffects$Companion {
    @NotNull
    public final ListValue getAtksound() {
        return atksound;
    }

    @NotNull
    public final ListValue getMode() {
        return mode;
    }

    private AttackEffects$Companion() {
    }

    public AttackEffects$Companion(DefaultConstructorMarker $constructor_marker) {
        this();
    }
}
