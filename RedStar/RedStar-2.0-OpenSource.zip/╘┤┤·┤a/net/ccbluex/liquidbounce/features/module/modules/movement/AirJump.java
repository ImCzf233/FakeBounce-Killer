package net.ccbluex.liquidbounce.features.module.modules.movement;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;

@ModuleInfo(name="AirJump", description="Allows you to jump in the mid air", category=ModuleCategory.MOVEMENT)
@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\n\n\b\b\u000020B¢¨"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/movement/AirJump;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "Pride"})
public final class AirJump
extends Module {
}
