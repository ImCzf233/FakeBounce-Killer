package net.ccbluex.liquidbounce.features.module.modules.combat;

import kotlin.Metadata;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\n\n\u0000\n\b\n\b\n\b\b\u000020B\b¢R$08@X¢\n\u0000\b\b\"\b\b\t¨\n"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/combat/KillAura2$Companion;", "", "()V", "killCounts", "", "killCounts$annotations", "getKillCounts", "()I", "setKillCounts", "(I)V", "Pride"})
public static final class KillAura2$Companion {
    @JvmStatic
    public static void killCounts$annotations() {
    }

    public final int getKillCounts() {
        return killCounts;
    }

    public final void setKillCounts(int n) {
        killCounts = n;
    }

    private KillAura2$Companion() {
    }

    public KillAura2$Companion(DefaultConstructorMarker $constructor_marker) {
        this();
    }
}
