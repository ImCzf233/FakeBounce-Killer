package net.ccbluex.liquidbounce.features.module.modules.render;

import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.ccbluex.liquidbounce.value.ListValue;
import org.jetbrains.annotations.NotNull;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\n\n\u0000\n\b\n\n\u0000\n\n\b\b\u000020B\b¢R08X¢\n\u0000R0¢\b\n\u0000\b\b¨\t"}, d2={"Lnet/ccbluex/liquidbounce/features/module/modules/render/HUD$Companion;", "", "()V", "Hotbarblur", "Lnet/ccbluex/liquidbounce/value/BoolValue;", "shadowValue", "Lnet/ccbluex/liquidbounce/value/ListValue;", "getShadowValue", "()Lnet/ccbluex/liquidbounce/value/ListValue;", "Pride"})
public static final class HUD$Companion {
    @NotNull
    public final ListValue getShadowValue() {
        return shadowValue;
    }

    private HUD$Companion() {
    }

    public HUD$Companion(DefaultConstructorMarker $constructor_marker) {
        this();
    }
}
