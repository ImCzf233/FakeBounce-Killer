package net.ccbluex.liquidbounce.features.command.shortcuts;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.features.command.shortcuts.Token;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\f\n\n\n\b\u000020B¢¨"}, d2={"Lnet/ccbluex/liquidbounce/features/command/shortcuts/StatementEnd;", "Lnet/ccbluex/liquidbounce/features/command/shortcuts/Token;", "()V", "Pride"})
public final class StatementEnd
extends Token {
}
