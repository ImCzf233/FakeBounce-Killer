package net.ccbluex.liquidbounce.api.minecraft.client.entity.player;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.api.minecraft.client.entity.player.IEntityPlayer;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=1, d1={"\u0000\n\n\n\n\u0000\bf\u000020¨"}, d2={"Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/player/IEntityOtherPlayerMP;", "Lnet/ccbluex/liquidbounce/api/minecraft/client/entity/player/IEntityPlayer;", "Pride"})
public interface IEntityOtherPlayerMP
extends IEntityPlayer {
}
