/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package net.ccbluex.liquidbounce.injection.backend;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.api.enums.BlockType;
import net.ccbluex.liquidbounce.api.enums.EnchantmentType;
import net.ccbluex.liquidbounce.api.enums.EnumFacingType;
import net.ccbluex.liquidbounce.api.enums.ItemType;
import net.ccbluex.liquidbounce.api.enums.MaterialType;
import net.ccbluex.liquidbounce.api.enums.StatType;
import net.ccbluex.liquidbounce.api.enums.WDefaultVertexFormats;
import net.ccbluex.liquidbounce.api.minecraft.network.play.client.ICPacketUseEntity;
import net.ccbluex.liquidbounce.api.minecraft.potion.PotionType;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=3)
public final class ClassProviderImpl$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;
    public static final /* synthetic */ int[] $EnumSwitchMapping$1;
    public static final /* synthetic */ int[] $EnumSwitchMapping$2;
    public static final /* synthetic */ int[] $EnumSwitchMapping$3;
    public static final /* synthetic */ int[] $EnumSwitchMapping$4;
    public static final /* synthetic */ int[] $EnumSwitchMapping$5;
    public static final /* synthetic */ int[] $EnumSwitchMapping$6;
    public static final /* synthetic */ int[] $EnumSwitchMapping$7;
    public static final /* synthetic */ int[] $EnumSwitchMapping$8;

    static {
        $EnumSwitchMapping$0 = new int[ICPacketUseEntity.WAction.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$0[ICPacketUseEntity.WAction.INTERACT.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$0[ICPacketUseEntity.WAction.ATTACK.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$0[ICPacketUseEntity.WAction.INTERACT_AT.ordinal()] = 3;
        $EnumSwitchMapping$1 = new int[PotionType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.HEAL.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.REGENERATION.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.BLINDNESS.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.MOVE_SPEED.ordinal()] = 4;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.HUNGER.ordinal()] = 5;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.DIG_SLOWDOWN.ordinal()] = 6;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.CONFUSION.ordinal()] = 7;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.WEAKNESS.ordinal()] = 8;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.MOVE_SLOWDOWN.ordinal()] = 9;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.HARM.ordinal()] = 10;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.WITHER.ordinal()] = 11;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.POISON.ordinal()] = 12;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.NIGHT_VISION.ordinal()] = 13;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$1[PotionType.JUMP.ordinal()] = 14;
        $EnumSwitchMapping$2 = new int[EnumFacingType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.DOWN.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.UP.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.NORTH.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.SOUTH.ordinal()] = 4;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.WEST.ordinal()] = 5;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$2[EnumFacingType.EAST.ordinal()] = 6;
        $EnumSwitchMapping$3 = new int[BlockType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.ENCHANTING_TABLE.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.CHEST.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.ENDER_CHEST.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.TRAPPED_CHEST.ordinal()] = 4;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.ANVIL.ordinal()] = 5;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.SAND.ordinal()] = 6;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.WEB.ordinal()] = 7;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.TORCH.ordinal()] = 8;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.CRAFTING_TABLE.ordinal()] = 9;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.FURNACE.ordinal()] = 10;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.WATERLILY.ordinal()] = 11;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.DISPENSER.ordinal()] = 12;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.STONE_PRESSURE_PLATE.ordinal()] = 13;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.WODDEN_PRESSURE_PLATE.ordinal()] = 14;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.TNT.ordinal()] = 15;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.STANDING_BANNER.ordinal()] = 16;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.WALL_BANNER.ordinal()] = 17;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.REDSTONE_TORCH.ordinal()] = 18;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.NOTEBLOCK.ordinal()] = 19;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.DROPPER.ordinal()] = 20;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.SNOW_LAYER.ordinal()] = 21;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.AIR.ordinal()] = 22;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.ICE_PACKED.ordinal()] = 23;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.ICE.ordinal()] = 24;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.WATER.ordinal()] = 25;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.BARRIER.ordinal()] = 26;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.FLOWING_WATER.ordinal()] = 27;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.COAL_ORE.ordinal()] = 28;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.IRON_ORE.ordinal()] = 29;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.GOLD_ORE.ordinal()] = 30;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.REDSTONE_ORE.ordinal()] = 31;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.LAPIS_ORE.ordinal()] = 32;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.DIAMOND_ORE.ordinal()] = 33;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.EMERALD_ORE.ordinal()] = 34;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.QUARTZ_ORE.ordinal()] = 35;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.CLAY.ordinal()] = 36;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.GLOWSTONE.ordinal()] = 37;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.LADDER.ordinal()] = 38;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.COAL_BLOCK.ordinal()] = 39;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.IRON_BLOCK.ordinal()] = 40;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.GOLD_BLOCK.ordinal()] = 41;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.DIAMOND_BLOCK.ordinal()] = 42;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.EMERALD_BLOCK.ordinal()] = 43;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.REDSTONE_BLOCK.ordinal()] = 44;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.LAPIS_BLOCK.ordinal()] = 45;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.FIRE.ordinal()] = 46;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.MOSSY_COBBLESTONE.ordinal()] = 47;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.MOB_SPAWNER.ordinal()] = 48;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.END_PORTAL_FRAME.ordinal()] = 49;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.BOOKSHELF.ordinal()] = 50;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.COMMAND_BLOCK.ordinal()] = 51;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.LAVA.ordinal()] = 52;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.FLOWING_LAVA.ordinal()] = 53;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.LIT_FURNACE.ordinal()] = 54;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.DRAGON_EGG.ordinal()] = 55;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.BROWN_MUSHROOM_BLOCK.ordinal()] = 56;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.RED_MUSHROOM_BLOCK.ordinal()] = 57;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$3[BlockType.FARMLAND.ordinal()] = 58;
        $EnumSwitchMapping$4 = new int[MaterialType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$4[MaterialType.AIR.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$4[MaterialType.WATER.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$4[MaterialType.LAVA.ordinal()] = 3;
        $EnumSwitchMapping$5 = new int[StatType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$5[StatType.JUMP_STAT.ordinal()] = 1;
        $EnumSwitchMapping$6 = new int[ItemType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.MUSHROOM_STEW.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.BOWL.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.FLINT_AND_STEEL.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.LAVA_BUCKET.ordinal()] = 4;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.WRITABLE_BOOK.ordinal()] = 5;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.WATER_BUCKET.ordinal()] = 6;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.COMMAND_BLOCK_MINECART.ordinal()] = 7;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.POTION_ITEM.ordinal()] = 8;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.SKULL.ordinal()] = 9;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$6[ItemType.ARMOR_STAND.ordinal()] = 10;
        $EnumSwitchMapping$7 = new int[EnchantmentType.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.SHARPNESS.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.POWER.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.PROTECTION.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.FEATHER_FALLING.ordinal()] = 4;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.PROJECTILE_PROTECTION.ordinal()] = 5;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.THORNS.ordinal()] = 6;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.FIRE_PROTECTION.ordinal()] = 7;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.RESPIRATION.ordinal()] = 8;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.AQUA_AFFINITY.ordinal()] = 9;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.BLAST_PROTECTION.ordinal()] = 10;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$7[EnchantmentType.UNBREAKING.ordinal()] = 11;
        $EnumSwitchMapping$8 = new int[WDefaultVertexFormats.values().length];
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$8[WDefaultVertexFormats.POSITION.ordinal()] = 1;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$8[WDefaultVertexFormats.POSITION_TEX.ordinal()] = 2;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$8[WDefaultVertexFormats.POSITION_COLOR.ordinal()] = 3;
        ClassProviderImpl$WhenMappings.$EnumSwitchMapping$8[WDefaultVertexFormats.POSITION_TEX_COLOR.ordinal()] = 4;
    }
}

