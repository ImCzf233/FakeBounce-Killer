/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Metadata
 */
package net.ccbluex.liquidbounce.features.module.modules.render;

import kotlin.Metadata;
import net.ccbluex.liquidbounce.features.module.modules.render.JelloTabGui;

@Metadata(mv={1, 1, 16}, bv={1, 0, 3}, k=3)
public final class JelloTabGui$WhenMappings {
    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

    static {
        $EnumSwitchMapping$0 = new int[JelloTabGui.Action.values().length];
        JelloTabGui$WhenMappings.$EnumSwitchMapping$0[JelloTabGui.Action.UP.ordinal()] = 1;
        JelloTabGui$WhenMappings.$EnumSwitchMapping$0[JelloTabGui.Action.DOWN.ordinal()] = 2;
        JelloTabGui$WhenMappings.$EnumSwitchMapping$0[JelloTabGui.Action.LEFT.ordinal()] = 3;
        JelloTabGui$WhenMappings.$EnumSwitchMapping$0[JelloTabGui.Action.RIGHT.ordinal()] = 4;
        JelloTabGui$WhenMappings.$EnumSwitchMapping$0[JelloTabGui.Action.TOGGLE.ordinal()] = 5;
    }
}

