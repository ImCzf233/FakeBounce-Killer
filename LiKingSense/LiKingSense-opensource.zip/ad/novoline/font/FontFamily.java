/*
 * Decompiled with CFR 0.152.
 */
package ad.novoline.font;

import ad.novoline.font.FontRenderer;
import ad.novoline.font.FontType;

public interface FontFamily {
    public FontRenderer ofSize(int var1);

    public FontType font();
}

