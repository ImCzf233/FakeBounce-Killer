/*
 * Decompiled with CFR 0.152.
 */
package ad.novoline.font;

public enum ThemeType {
    ARRAYLIST,
    LOGO,
    FLAT_COLOR,
    GENERAL;

}

