/*
 * Decompiled with CFR 0.152.
 */
package ad.tenacity.notifications;

public enum NotificationType {
    SUCCESS,
    DISABLE,
    INFO,
    WARNING;

}

