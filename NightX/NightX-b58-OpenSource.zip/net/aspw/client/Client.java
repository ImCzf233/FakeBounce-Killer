/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.ResourceLocation
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client;

import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.config.FileConfig;
import net.aspw.client.config.FileManager;
import net.aspw.client.event.ClientShutdownEvent;
import net.aspw.client.event.EventManager;
import net.aspw.client.features.api.ClientSpoof;
import net.aspw.client.features.api.DiscordRPC;
import net.aspw.client.features.api.EnchantItems;
import net.aspw.client.features.api.MacroManager;
import net.aspw.client.features.api.ModItems;
import net.aspw.client.features.api.StackItems;
import net.aspw.client.features.command.CommandManager;
import net.aspw.client.features.module.ModuleManager;
import net.aspw.client.util.ClassUtils;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.InventoryHelper;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.SessionUtils;
import net.aspw.client.util.misc.sound.TipSoundManager;
import net.aspw.client.visual.client.clickgui.dropdown.ClickGui;
import net.aspw.client.visual.font.Fonts;
import net.aspw.client.visual.hud.HUD;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public final class Client {
    public static final Client INSTANCE = new Client();
    public static final String CLIENT_BEST = "NightX";
    public static final String CLIENT_FOLDER = "NightX-Reborn";
    public static final String CLIENT_VERSION = "Release B58";
    public static final String CLIENT_CREATOR = "As_pw";
    public static final String CLIENT_DISCORD = "discord.gg/SGBccUXFK";
    public static final String CLIENT_AUTH = "x6fops9jxw";
    public static final String CLIENT_FONTS = "jldpbehytt";
    public static final String CLIENT_CHAT = "\u00a7c\u00a7l>> \u00a7r";
    private static boolean isStarting;
    public static ModuleManager moduleManager;
    public static CommandManager commandManager;
    public static EventManager eventManager;
    public static FileManager fileManager;
    public static TipSoundManager tipSoundManager;
    public static HUD hud;
    public static ClickGui clickGui;
    private static ResourceLocation background;
    private static long lastTick;
    private static long playTimeStart;
    public static DiscordRPC discordRPC;

    private Client() {
    }

    public final boolean isStarting() {
        return isStarting;
    }

    public final void setStarting(boolean bl) {
        isStarting = bl;
    }

    public final ModuleManager getModuleManager() {
        ModuleManager moduleManager = Client.moduleManager;
        if (moduleManager != null) {
            return moduleManager;
        }
        return null;
    }

    public final void setModuleManager(ModuleManager moduleManager) {
        Intrinsics.checkNotNullParameter((Object)moduleManager, (String)"<set-?>");
        Client.moduleManager = moduleManager;
    }

    public final CommandManager getCommandManager() {
        CommandManager commandManager = Client.commandManager;
        if (commandManager != null) {
            return commandManager;
        }
        return null;
    }

    public final void setCommandManager(CommandManager commandManager) {
        Intrinsics.checkNotNullParameter((Object)commandManager, (String)"<set-?>");
        Client.commandManager = commandManager;
    }

    public final EventManager getEventManager() {
        EventManager eventManager = Client.eventManager;
        if (eventManager != null) {
            return eventManager;
        }
        return null;
    }

    public final void setEventManager(EventManager eventManager) {
        Intrinsics.checkNotNullParameter((Object)eventManager, (String)"<set-?>");
        Client.eventManager = eventManager;
    }

    public final FileManager getFileManager() {
        FileManager fileManager = Client.fileManager;
        if (fileManager != null) {
            return fileManager;
        }
        return null;
    }

    public final void setFileManager(FileManager fileManager) {
        Intrinsics.checkNotNullParameter((Object)fileManager, (String)"<set-?>");
        Client.fileManager = fileManager;
    }

    public final TipSoundManager getTipSoundManager() {
        TipSoundManager tipSoundManager = Client.tipSoundManager;
        if (tipSoundManager != null) {
            return tipSoundManager;
        }
        return null;
    }

    public final void setTipSoundManager(TipSoundManager tipSoundManager) {
        Intrinsics.checkNotNullParameter((Object)tipSoundManager, (String)"<set-?>");
        Client.tipSoundManager = tipSoundManager;
    }

    public final HUD getHud() {
        HUD hUD = hud;
        if (hUD != null) {
            return hUD;
        }
        return null;
    }

    public final void setHud(HUD hUD) {
        Intrinsics.checkNotNullParameter((Object)hUD, (String)"<set-?>");
        hud = hUD;
    }

    public final ClickGui getClickGui() {
        ClickGui clickGui = Client.clickGui;
        if (clickGui != null) {
            return clickGui;
        }
        return null;
    }

    public final void setClickGui(ClickGui clickGui) {
        Intrinsics.checkNotNullParameter((Object)((Object)clickGui), (String)"<set-?>");
        Client.clickGui = clickGui;
    }

    public final ResourceLocation getBackground() {
        return background;
    }

    public final void setBackground(@Nullable ResourceLocation resourceLocation) {
        background = resourceLocation;
    }

    public final long getPlayTimeStart() {
        return playTimeStart;
    }

    public final void setPlayTimeStart(long l) {
        playTimeStart = l;
    }

    public final DiscordRPC getDiscordRPC() {
        DiscordRPC discordRPC = Client.discordRPC;
        if (discordRPC != null) {
            return discordRPC;
        }
        return null;
    }

    public final void setDiscordRPC(DiscordRPC discordRPC) {
        Intrinsics.checkNotNullParameter((Object)discordRPC, (String)"<set-?>");
        Client.discordRPC = discordRPC;
    }

    public final void startClient() {
        isStarting = true;
        ClientUtils.getLogger().info("Authenticating...");
        lastTick = System.currentTimeMillis();
        this.setFileManager(new FileManager());
        this.setEventManager(new EventManager());
        this.getEventManager().registerListener(new RotationUtils());
        this.getEventManager().registerListener(new ClientSpoof());
        this.getEventManager().registerListener(new InventoryUtils());
        this.getEventManager().registerListener(InventoryHelper.INSTANCE);
        this.getEventManager().registerListener(new PacketUtils());
        this.getEventManager().registerListener(new SessionUtils());
        this.getEventManager().registerListener(MacroManager.INSTANCE);
        this.setDiscordRPC(new DiscordRPC());
        this.setCommandManager(new CommandManager());
        Fonts.loadFonts();
        this.setTipSoundManager(new TipSoundManager());
        this.setModuleManager(new ModuleManager());
        this.getModuleManager().registerModules();
        this.getModuleManager().registerPremiumModules();
        this.getCommandManager().registerCommands();
        FileConfig[] fileConfigArray = new FileConfig[]{this.getFileManager().modulesConfig, this.getFileManager().valuesConfig, this.getFileManager().accountsConfig, this.getFileManager().friendsConfig};
        this.getFileManager().loadConfigs(fileConfigArray);
        this.setClickGui(new ClickGui());
        if (ClassUtils.INSTANCE.hasForge()) {
            new ModItems();
            new StackItems();
            new EnchantItems();
        }
        this.setHud(HUD.Companion.createDefault());
        this.getFileManager().loadConfig(this.getFileManager().hudConfig);
        if (this.getDiscordRPC().getShowRichPresenceValue()) {
            ThreadsKt.thread$default((boolean)false, (boolean)false, null, null, (int)0, (Function0)startClient.1.INSTANCE, (int)31, null);
        }
        ClientUtils.getLogger().info("Successfully loaded NightX in " + (System.currentTimeMillis() - lastTick) + "ms.");
        isStarting = false;
    }

    public final void stopClient() {
        this.getEventManager().callEvent(new ClientShutdownEvent());
        this.getFileManager().saveAllConfigs();
        this.getDiscordRPC().shutdown();
    }
}

