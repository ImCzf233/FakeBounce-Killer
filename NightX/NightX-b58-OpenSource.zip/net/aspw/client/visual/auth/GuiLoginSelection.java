/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.visual.auth;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.auth.GuiLoginScreen;
import net.aspw.client.visual.auth.LoginID;
import net.aspw.client.visual.client.GuiMainMenu;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public final class GuiLoginSelection
extends GuiScreen {
    private final GuiScreen prevGui;

    public GuiLoginSelection(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
    }

    public void initGui() {
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 104, "Free Login"));
        this.buttonList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 144, "User Login"));
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.width, this.height);
        Fonts.fontSFUI40.drawCenteredString("Select your authenticate type", (float)this.width / 2.0f, (float)(this.height / 4) + 64.0f, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        switch (button.id) {
            case 1: {
                this.mc.displayGuiScreen((GuiScreen)new GuiLoginScreen(this));
                break;
            }
            case 0: {
                LoginID.INSTANCE.setLoggedIn(true);
                LoginID.INSTANCE.setId("User");
                LoginID.INSTANCE.setPassword("Free");
                this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
                ClientUtils.getLogger().info("Logged in with Free Account!");
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) {
        if (1 == keyCode) {
            if (!LoginID.INSTANCE.getLoggedIn()) {
                return;
            }
            this.mc.displayGuiScreen((GuiScreen)new GuiLoginScreen(this));
        }
        super.keyTyped(typedChar, keyCode);
    }
}

