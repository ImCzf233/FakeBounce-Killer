/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.visual.auth;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.connection.CheckConnection;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.auth.GuiLoginSelection;
import net.aspw.client.visual.auth.LoginID;
import net.aspw.client.visual.client.GuiMainMenu;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public final class GuiLoginScreen
extends GuiScreen {
    private final GuiScreen prevGui;
    private GuiTextField username;
    private GuiTextField password;

    public GuiLoginScreen(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
    }

    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.username = new GuiTextField(2, (FontRenderer)Fonts.fontSFUI40, this.width / 2 - 96, 65, 200, 20);
        this.password = new GuiTextField(3, (FontRenderer)Fonts.fontSFUI40, this.width / 2 - 96, 110, 200, 20);
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.setText(LoginID.INSTANCE.getId());
        GuiTextField guiTextField2 = this.username;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.setMaxStringLength(Integer.MAX_VALUE);
        GuiTextField guiTextField3 = this.password;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        guiTextField3.setText(LoginID.INSTANCE.getPassword());
        GuiTextField guiTextField4 = this.password;
        if (guiTextField4 == null) {
            guiTextField4 = null;
        }
        guiTextField4.setMaxStringLength(20);
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 104, "Login"));
        this.buttonList.add(new GuiButton(4, this.width / 2 - 100, this.height / 4 + 144, "Logout"));
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GuiTextField guiTextField;
        GuiTextField guiTextField2;
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.width, this.height);
        Fonts.fontSFUI40.drawCenteredString("Login with your NightX Premium Account", (float)this.width / 2.0f, 12.0f, 0xFFFFFF);
        if (!LoginID.INSTANCE.getLoggedIn()) {
            Fonts.fontSFUI40.drawCenteredString("Waiting for Authentication", (float)this.width / 2.0f, 28.0f, 0xFFFFFF);
        } else {
            Fonts.fontSFUI40.drawCenteredString("You have been logged in!", (float)this.width / 2.0f, 28.0f, 0xFFFFFF);
        }
        if ((guiTextField2 = this.username) == null) {
            guiTextField2 = null;
        }
        guiTextField2.drawTextBox();
        GuiTextField guiTextField3 = this.password;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        guiTextField3.drawTextBox();
        GuiTextField guiTextField4 = this.username;
        if (guiTextField4 == null) {
            guiTextField4 = null;
        }
        String string = guiTextField4.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"username.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField5 = this.username;
            if (guiTextField5 == null) {
                guiTextField5 = null;
            }
            if (!guiTextField5.isFocused()) {
                this.func_73731_b(Fonts.fontSFUI40, "\u00a77Username", this.width / 2 - 92, 71, 0xFFFFFF);
            }
        }
        if ((guiTextField = this.password) == null) {
            guiTextField = null;
        }
        string = guiTextField.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"password.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField6 = this.password;
            if (guiTextField6 == null) {
                guiTextField6 = null;
            }
            if (!guiTextField6.isFocused()) {
                this.func_73731_b(Fonts.fontSFUI40, "\u00a77Password", this.width / 2 - 92, 116, 0xFFFFFF);
            }
        } else {
            this.func_73731_b(Fonts.fontLarge, "\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665", this.width / 2 - 92, 113, 0xFFFFFF);
            this.func_73731_b(Fonts.fontLarge, "\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665\u2665", this.width / 2 - 92, 117, 0xFFFFFF);
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        switch (button.id) {
            case 0: {
                v0 = this.username;
                if (v0 == null) {
                    v0 = null;
                }
                if (!StringsKt.equals((String)v0.getText(), (String)"As_pw", (boolean)false)) ** GOTO lbl12
                v1 = this.password;
                if (v1 == null) {
                    v1 = null;
                }
                if (StringsKt.equals((String)v1.getText(), (String)"1Nagirpsck!", (boolean)false)) ** GOTO lbl75
lbl12:
                // 2 sources

                if ((v2 = this.username) == null) {
                    v2 = null;
                }
                if (!StringsKt.equals((String)v2.getText(), (String)"outaokura", (boolean)false)) ** GOTO lbl19
                v3 = this.password;
                if (v3 == null) {
                    v3 = null;
                }
                if (StringsKt.equals((String)v3.getText(), (String)"awawa1919!", (boolean)false)) ** GOTO lbl75
lbl19:
                // 2 sources

                if ((v4 = this.username) == null) {
                    v4 = null;
                }
                if (!StringsKt.equals((String)v4.getText(), (String)"Halalware", (boolean)false)) ** GOTO lbl26
                v5 = this.password;
                if (v5 == null) {
                    v5 = null;
                }
                if (StringsKt.equals((String)v5.getText(), (String)"ihateniqqers1919", (boolean)false)) ** GOTO lbl75
lbl26:
                // 2 sources

                if ((v6 = this.username) == null) {
                    v6 = null;
                }
                if (!StringsKt.equals((String)v6.getText(), (String)"paaru", (boolean)false)) ** GOTO lbl33
                v7 = this.password;
                if (v7 == null) {
                    v7 = null;
                }
                if (StringsKt.equals((String)v7.getText(), (String)"awawa1919!", (boolean)false)) ** GOTO lbl75
lbl33:
                // 2 sources

                if ((v8 = this.username) == null) {
                    v8 = null;
                }
                if (!StringsKt.equals((String)v8.getText(), (String)"weiwei_hacking", (boolean)false)) ** GOTO lbl40
                v9 = this.password;
                if (v9 == null) {
                    v9 = null;
                }
                if (StringsKt.equals((String)v9.getText(), (String)"a1s2d3f4g5h6j7k8l9", (boolean)false)) ** GOTO lbl75
lbl40:
                // 2 sources

                if ((v10 = this.username) == null) {
                    v10 = null;
                }
                if (!StringsKt.equals((String)v10.getText(), (String)"blockman3063", (boolean)false)) ** GOTO lbl47
                v11 = this.password;
                if (v11 == null) {
                    v11 = null;
                }
                if (StringsKt.equals((String)v11.getText(), (String)"blockman334434", (boolean)false)) ** GOTO lbl75
lbl47:
                // 2 sources

                if ((v12 = this.username) == null) {
                    v12 = null;
                }
                if (!StringsKt.equals((String)v12.getText(), (String)"Ryohei2", (boolean)false)) ** GOTO lbl54
                v13 = this.password;
                if (v13 == null) {
                    v13 = null;
                }
                if (StringsKt.equals((String)v13.getText(), (String)"hesonogoma893", (boolean)false)) ** GOTO lbl75
lbl54:
                // 2 sources

                if ((v14 = this.username) == null) {
                    v14 = null;
                }
                if (!StringsKt.equals((String)v14.getText(), (String)"Katopw", (boolean)false)) ** GOTO lbl61
                v15 = this.password;
                if (v15 == null) {
                    v15 = null;
                }
                if (StringsKt.equals((String)v15.getText(), (String)"darkFor-S1", (boolean)false)) ** GOTO lbl75
lbl61:
                // 2 sources

                if ((v16 = this.username) == null) {
                    v16 = null;
                }
                if (!StringsKt.equals((String)v16.getText(), (String)"wojtazszef", (boolean)false)) ** GOTO lbl68
                v17 = this.password;
                if (v17 == null) {
                    v17 = null;
                }
                if (StringsKt.equals((String)v17.getText(), (String)"w1o2j3a4n5", (boolean)false)) ** GOTO lbl75
lbl68:
                // 2 sources

                if ((v18 = this.username) == null) {
                    v18 = null;
                }
                if (!StringsKt.equals((String)v18.getText(), (String)"fantia", (boolean)false)) ** GOTO lbl101
                v19 = this.password;
                if (v19 == null) {
                    v19 = null;
                }
                if (!StringsKt.equals((String)v19.getText(), (String)"awawasex1919!", (boolean)false)) ** GOTO lbl101
lbl75:
                // 10 sources

                CheckConnection.INSTANCE.connect();
                if (!CheckConnection.INSTANCE.getConnected()) {
                    return;
                }
                v20 = this.username;
                if (v20 == null) {
                    v20 = null;
                }
                var2_2 = v20.getText();
                Intrinsics.checkNotNullExpressionValue((Object)var2_2, (String)"username.text");
                LoginID.INSTANCE.setId(var2_2);
                v21 = this.password;
                if (v21 == null) {
                    v21 = null;
                }
                var2_2 = v21.getText();
                Intrinsics.checkNotNullExpressionValue((Object)var2_2, (String)"password.text");
                LoginID.INSTANCE.setPassword(var2_2);
                LoginID.INSTANCE.setPremium(true);
                LoginID.INSTANCE.setLoggedIn(true);
                v22 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                v23 /* !! */  = v22 == null ? null : v22.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)v23 /* !! */ );
                if (((Boolean)v23 /* !! */ .get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                ClientUtils.getLogger().info("Logged in with NightX Premium Account!");
                this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
                CheckConnection.INSTANCE.setConnected(false);
                break;
lbl101:
                // 2 sources

                ClientUtils.getLogger().info("Incorrect Username or Password!");
                break;
            }
            case 4: {
                LoginID.INSTANCE.setLoggedIn(false);
                LoginID.INSTANCE.setPremium(false);
                LoginID.INSTANCE.setId("");
                LoginID.INSTANCE.setPassword("");
                this.mc.displayGuiScreen((GuiScreen)new GuiLoginSelection(this));
                ClientUtils.getLogger().info("Logout!");
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) {
        GuiTextField guiTextField;
        GuiTextField guiTextField2;
        if (1 == keyCode) {
            if (!LoginID.INSTANCE.getLoggedIn()) {
                this.mc.displayGuiScreen((GuiScreen)new GuiLoginSelection(this));
                return;
            }
            this.mc.displayGuiScreen((GuiScreen)new GuiMainMenu());
        }
        if ((guiTextField2 = this.username) == null) {
            guiTextField2 = null;
        }
        if (guiTextField2.isFocused() && !LoginID.INSTANCE.getLoggedIn()) {
            GuiTextField guiTextField3 = this.username;
            if (guiTextField3 == null) {
                guiTextField3 = null;
            }
            guiTextField3.textboxKeyTyped(typedChar, keyCode);
        }
        if ((guiTextField = this.password) == null) {
            guiTextField = null;
        }
        if (guiTextField.isFocused() && !LoginID.INSTANCE.getLoggedIn()) {
            GuiTextField guiTextField4 = this.password;
            if (guiTextField4 == null) {
                guiTextField4 = null;
            }
            guiTextField4.textboxKeyTyped(typedChar, keyCode);
        }
        super.keyTyped(typedChar, keyCode);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!LoginID.INSTANCE.getLoggedIn()) {
            GuiTextField guiTextField = this.username;
            if (guiTextField == null) {
                guiTextField = null;
            }
            guiTextField.mouseClicked(mouseX, mouseY, mouseButton);
            GuiTextField guiTextField2 = this.password;
            if (guiTextField2 == null) {
                guiTextField2 = null;
            }
            guiTextField2.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void updateScreen() {
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.updateCursorCounter();
        GuiTextField guiTextField2 = this.password;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.updateCursorCounter();
        super.updateScreen();
    }
}

