/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thealtening.AltService
 *  com.thealtening.AltService$EnumAltService
 *  kotlin.NoWhenBranchMatchedException
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.io.FilesKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.random.Random
 *  kotlin.ranges.RangesKt
 *  kotlin.text.Regex
 *  kotlin.text.StringsKt
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MicrosoftAccount
 *  me.liuli.elixir.account.MinecraftAccount
 *  me.liuli.elixir.account.MojangAccount
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiSlot
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Session
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.visual.client.altmanager;

import com.thealtening.AltService;
import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.io.FilesKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MicrosoftAccount;
import me.liuli.elixir.account.MinecraftAccount;
import me.liuli.elixir.account.MojangAccount;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.login.LoginUtils;
import net.aspw.client.util.login.UserUtils;
import net.aspw.client.util.misc.MiscUtils;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.client.altmanager.menus.GuiDirectLogin;
import net.aspw.client.visual.client.altmanager.menus.GuiTheAltening;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.jetbrains.annotations.Nullable;

public final class GuiAltManager
extends GuiScreen {
    public static final Companion Companion = new Companion(null);
    private final GuiScreen prevGui;
    private String status;
    private GuiButton loginButton;
    private GuiButton randomButton;
    private GuiButton randomCracked;
    private GuiList altsList;
    private GuiTextField searchField;
    private String lastSessionToken;
    private static final AltService altService = new AltService();
    private static final Map<String, Boolean> activeGenerators = new LinkedHashMap();

    public GuiAltManager(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
        this.status = "\u00a77Waiting...";
    }

    public final String getStatus() {
        return this.status;
    }

    public final void setStatus(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.status = string;
    }

    public final String getLastSessionToken() {
        return this.lastSessionToken;
    }

    public final void setLastSessionToken(@Nullable String string) {
        this.lastSessionToken = string;
    }

    /*
     * WARNING - void declaration
     */
    public void initGui() {
        GuiButton it;
        GuiButton guiButton;
        GuiList guiList;
        GuiList guiList2;
        int mightBeTheCurrentAccount;
        block8: {
            int n;
            void $this$indexOfFirst$iv;
            int textFieldWidth = RangesKt.coerceAtLeast((int)(this.width / 8), (int)70);
            this.searchField = new GuiTextField(2, (FontRenderer)Fonts.fontSFUI40, this.width - textFieldWidth - 10, 10, textFieldWidth, 20);
            GuiTextField guiTextField = this.searchField;
            if (guiTextField == null) {
                guiTextField = null;
            }
            guiTextField.setMaxStringLength(Integer.MAX_VALUE);
            this.altsList = new GuiList(this);
            GuiList guiList3 = this.altsList;
            if (guiList3 == null) {
                guiList3 = null;
            }
            guiList3.registerScrollButtons(7, 8);
            List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
            Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
            boolean $i$f$indexOfFirst = false;
            int index$iv = 0;
            for (Object item$iv : $this$indexOfFirst$iv) {
                MinecraftAccount it2 = (MinecraftAccount)item$iv;
                boolean bl = false;
                if (it2.getName().equals(this.mc.session.getUsername())) {
                    n = index$iv;
                    break block8;
                }
                ++index$iv;
            }
            n = mightBeTheCurrentAccount = -1;
        }
        if ((guiList2 = this.altsList) == null) {
            guiList2 = null;
        }
        guiList2.elementClicked(mightBeTheCurrentAccount, false, 0, 0);
        GuiList guiList4 = this.altsList;
        if (guiList4 == null) {
            guiList4 = null;
        }
        if ((guiList = this.altsList) == null) {
            guiList = null;
        }
        guiList4.scrollBy(mightBeTheCurrentAccount * guiList.getSlotHeight());
        int startPositionY = 22;
        this.buttonList.add(new GuiButton(1, this.width - 80, startPositionY + 24, 70, 20, "Add"));
        this.buttonList.add(new GuiButton(2, this.width - 80, startPositionY + 48, 70, 20, "Delete"));
        this.buttonList.add(new GuiButton(7, this.width - 80, startPositionY + 72, 70, 20, "Import"));
        this.buttonList.add(new GuiButton(12, this.width - 80, startPositionY + 96, 70, 20, "Export"));
        this.buttonList.add(new GuiButton(0, this.width - 80, this.height - 65, 70, 20, "Done"));
        GuiButton index$iv = guiButton = new GuiButton(3, 5, startPositionY + 24, 90, 20, "Login");
        List list = this.buttonList;
        boolean bl = false;
        this.loginButton = it;
        list.add(guiButton);
        it = guiButton = new GuiButton(4, 5, startPositionY + 48, 90, 20, "Random Alt");
        list = this.buttonList;
        boolean bl2 = false;
        this.randomButton = it;
        list.add(guiButton);
        it = guiButton = new GuiButton(99, 5, startPositionY + 72, 90, 20, "Random Cracked");
        list = this.buttonList;
        boolean bl3 = false;
        this.randomCracked = it;
        list.add(guiButton);
        this.buttonList.add(new GuiButton(6, 5, startPositionY + 96, 90, 20, "Direct Login"));
        if (activeGenerators.getOrDefault("thealtening", true).booleanValue()) {
            this.buttonList.add(new GuiButton(9, 5, startPositionY + 120, 90, 20, "The Altening"));
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        String string;
        String string2;
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/altmanager.png"), 0, 0, this.width, this.height);
        GuiList guiList = this.altsList;
        if (guiList == null) {
            guiList = null;
        }
        guiList.drawScreen(mouseX, mouseY, partialTicks);
        Fonts.fontLarge.drawCenteredString("Alt Manager", (float)this.width / 2.0f, 12.0f, 0xFFFFFF);
        Fonts.fontSFUI37.drawCenteredString(Intrinsics.stringPlus((String)"\u00a77Status: \u00a7a", (Object)this.status), (float)this.width / 2.0f, 30.0f, 0xFFFFFF);
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        String string3 = guiTextField.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"searchField.text");
        if (((CharSequence)string3).length() == 0) {
            string2 = Intrinsics.stringPlus((String)"\u00a77Alts: \u00a7a", (Object)Client.INSTANCE.getFileManager().accountsConfig.getAccounts().size());
        } else {
            GuiList guiList2 = this.altsList;
            if (guiList2 == null) {
                guiList2 = null;
            }
            string2 = Intrinsics.stringPlus((String)"\u00a77Search Results: \u00a7a", (Object)guiList2.getAccounts().size());
        }
        Fonts.fontSFUI37.drawStringWithShadow(string2, 6.0f, 26.0f, 0xFFFFFF);
        Fonts.fontSFUI37.drawStringWithShadow(Intrinsics.stringPlus((String)"\u00a77Ign: \u00a7a", (Object)this.mc.getSession().getUsername()), 6.0f, 6.0f, 0xFFFFFF);
        if (altService.getCurrentService() == AltService.EnumAltService.THEALTENING) {
            string = "TheAltening";
        } else {
            string3 = this.mc.getSession().getToken();
            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"mc.getSession().token");
            string = UserUtils.INSTANCE.isValidTokenOffline(string3) ? "Microsoft" : "Cracked";
        }
        Fonts.fontSFUI37.drawStringWithShadow(Intrinsics.stringPlus((String)"\u00a77Type: \u00a7a", (Object)string), 6.0f, 16.0f, 0xFFFFFF);
        GuiTextField guiTextField2 = this.searchField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.drawTextBox();
        GuiTextField guiTextField3 = this.searchField;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        string3 = guiTextField3.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"searchField.text");
        if (((CharSequence)string3).length() == 0) {
            GuiTextField guiTextField4 = this.searchField;
            if (guiTextField4 == null) {
                guiTextField4 = null;
            }
            if (!guiTextField4.isFocused()) {
                GuiTextField guiTextField5 = this.searchField;
                if (guiTextField5 == null) {
                    guiTextField5 = null;
                }
                Fonts.fontSFUI40.drawStringWithShadow("\u00a77Search...", guiTextField5.xPosition + 4, 17.0f, 0xFFFFFF);
            }
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (!button.enabled) {
            return;
        }
        switch (button.id) {
            case 0: {
                this.mc.displayGuiScreen(this.prevGui);
                break;
            }
            case 1: {
                this.mc.displayGuiScreen((GuiScreen)new GuiDirectLogin(this, false, 2, null));
                break;
            }
            case 2: {
                v0 = this.altsList;
                if (v0 == null) {
                    v0 = null;
                }
                if (v0.getSelectedSlot() == -1) ** GOTO lbl-1000
                v1 = this.altsList;
                if (v1 == null) {
                    v1 = null;
                }
                v2 = v1.getSelectedSlot();
                v3 = this.altsList;
                if (v3 == null) {
                    v3 = null;
                }
                if (v2 < v3.getSize()) {
                    v4 = Client.INSTANCE.getFileManager().accountsConfig;
                    v5 = this.altsList;
                    if (v5 == null) {
                        v5 = null;
                    }
                    v6 = v5.getAccounts();
                    v7 = this.altsList;
                    if (v7 == null) {
                        v7 = null;
                    }
                    v4.removeAccount(v6.get(v7.getSelectedSlot()));
                    Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                    v8 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v9 /* !! */  = v8 == null ? null : v8.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v9 /* !! */ );
                    if (((Boolean)v9 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v10 = "\u00a7aThe account has been deleted.";
                } else lbl-1000:
                // 2 sources

                {
                    v10 = "\u00a7cSelect an account.";
                }
                this.status = v10;
                break;
            }
            case 3: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.mc.session.getToken();
                }
                v11 = this;
                v12 = this.altsList;
                if (v12 == null) {
                    v12 = null;
                }
                if ((var2_2 = v12.getSelectedAccount()) == null) {
                    v13 = "\u00a7cSelect an account.";
                } else {
                    var5_7 = var2_2;
                    var13_10 = v11;
                    $i$a$-let-GuiAltManager$actionPerformed$1 = false;
                    v14 = this.loginButton;
                    if (v14 == null) {
                        v14 = null;
                    }
                    v14.enabled = false;
                    v15 = this.randomButton;
                    if (v15 == null) {
                        v15 = null;
                    }
                    v15.enabled = false;
                    v16 = this.randomCracked;
                    if (v16 == null) {
                        v16 = null;
                    }
                    v16.enabled = false;
                    GuiAltManager.Companion.login((MinecraftAccount)it, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.mc.session.getUsername() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.enabled = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.enabled = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.enabled = true;
                        }
                    }));
                    v17 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v18 /* !! */  = v17 == null ? null : v17.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v18 /* !! */ );
                    if (((Boolean)v18 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v11 = var13_10;
                    v13 = var3_15 = "\u00a7aLogging in...";
                }
                v11.status = v13;
                break;
            }
            case 4: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.mc.session.getToken();
                }
                v19 = this;
                v20 = this.altsList;
                if (v20 == null) {
                    v20 = null;
                }
                if ((var2_3 = (MinecraftAccount)CollectionsKt.randomOrNull((Collection)v20.getAccounts(), (Random)((Random)Random.Default))) == null) {
                    v21 = "\u00a7cYou do not have any accounts.";
                } else {
                    it = var2_3;
                    var13_11 = v19;
                    $i$a$-let-GuiAltManager$actionPerformed$2 = false;
                    v22 = this.loginButton;
                    if (v22 == null) {
                        v22 = null;
                    }
                    v22.enabled = false;
                    v23 = this.randomButton;
                    if (v23 == null) {
                        v23 = null;
                    }
                    v23.enabled = false;
                    v24 = this.randomCracked;
                    if (v24 == null) {
                        v24 = null;
                    }
                    v24.enabled = false;
                    GuiAltManager.Companion.login(it, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.mc.session.getUsername() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.enabled = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.enabled = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.enabled = true;
                        }
                    }));
                    v25 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v26 /* !! */  = v25 == null ? null : v25.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v26 /* !! */ );
                    if (((Boolean)v26 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v19 = var13_11;
                    v21 = var3_16 = "\u00a7aLogging in...";
                }
                v19.status = v21;
                break;
            }
            case 99: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.mc.session.getToken();
                }
                if ((v27 = this.loginButton) == null) {
                    v27 = null;
                }
                v27.enabled = false;
                v28 = this.randomButton;
                if (v28 == null) {
                    v28 = null;
                }
                v28.enabled = false;
                v29 = this.randomCracked;
                if (v29 == null) {
                    v29 = null;
                }
                v29.enabled = false;
                rand = new CrackedAccount();
                var3_17 = RandomUtils.randomString(RandomUtils.nextInt(5, 16));
                Intrinsics.checkNotNullExpressionValue((Object)var3_17, (String)"randomString(RandomUtils.nextInt(5, 16))");
                rand.setName(var3_17);
                this.status = "\u00a7aGenerating...";
                GuiAltManager.Companion.login((MinecraftAccount)rand, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.mc.session.getUsername() + '.');
                    }
                }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(1);
                    }

                    public final void invoke(Exception exception) {
                        Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                        this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                    }
                }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                        if (guiButton == null) {
                            guiButton = null;
                        }
                        guiButton.enabled = true;
                        GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                        if (guiButton2 == null) {
                            guiButton2 = null;
                        }
                        guiButton2.enabled = true;
                        GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                        if (guiButton3 == null) {
                            guiButton3 = null;
                        }
                        guiButton3.enabled = true;
                    }
                }));
                break;
            }
            case 6: {
                this.mc.displayGuiScreen((GuiScreen)new GuiDirectLogin(this, true));
                break;
            }
            case 7: {
                v30 = MiscUtils.openFileChooser();
                if (v30 == null) {
                    return;
                }
                file = v30;
                $this$forEach$iv = FilesKt.readLines$default((File)file, null, (int)1, null);
                $i$f$forEach = false;
                for (T element$iv : $this$forEach$iv) {
                    it = (String)element$iv;
                    $i$a$-forEach-GuiAltManager$actionPerformed$6 = false;
                    var10_26 = new Regex(":");
                    var9_25 = it;
                    var11_27 = 2;
                    accountData = var10_26.split(var9_25, var11_27);
                    if (accountData.size() > 1) {
                        Client.INSTANCE.getFileManager().accountsConfig.addMojangAccount((String)accountData.get(0), (String)accountData.get(1));
                        continue;
                    }
                    if (((String)accountData.get(0)).length() >= 16) continue;
                    Client.INSTANCE.getFileManager().accountsConfig.addCrackedAccount((String)accountData.get(0));
                }
                Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                this.status = "\u00a7aThe accounts were imported successfully.";
                break;
            }
            case 12: {
                if (Client.INSTANCE.getFileManager().accountsConfig.getAccounts().isEmpty()) {
                    this.status = "\u00a7cYou do not have any accounts to export.";
                    return;
                }
                file = MiscUtils.saveFileChooser();
                if (file == null || file.isDirectory()) {
                    return;
                }
                try {
                    if (!file.exists()) {
                        file.createNewFile();
                    }
                    var4_22 = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
                    Intrinsics.checkNotNullExpressionValue(var4_22, (String)"fileManager.accountsConfig.accounts");
                    accounts = CollectionsKt.joinToString$default((Iterable)var4_22, (CharSequence)"\n", null, null, (int)0, null, (Function1)actionPerformed.accounts.1.INSTANCE, (int)30, null);
                    FilesKt.writeText$default((File)file, (String)accounts, null, (int)2, null);
                    this.status = "\u00a7aExported successfully!";
                }
                catch (Exception e) {
                    this.status = Intrinsics.stringPlus((String)"\u00a7cUnable to export due to error: ", (Object)e.getMessage());
                }
                break;
            }
            case 9: {
                this.mc.displayGuiScreen((GuiScreen)new GuiTheAltening(this));
                break;
            }
            case 727: {
                v31 = this.loginButton;
                if (v31 == null) {
                    v31 = null;
                }
                v31.enabled = false;
                v32 = this.randomButton;
                if (v32 == null) {
                    v32 = null;
                }
                v32.enabled = false;
                v33 = this.randomCracked;
                if (v33 == null) {
                    v33 = null;
                }
                v33.enabled = false;
                v34 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                v35 /* !! */  = v34 == null ? null : v34.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)v35 /* !! */ );
                if (((Boolean)v35 /* !! */ .get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                this.status = "\u00a7aLogging in...";
                ThreadsKt.thread$default((boolean)false, (boolean)false, null, null, (int)0, (Function0)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        String string;
                        String string2 = this.this$0.getLastSessionToken();
                        Intrinsics.checkNotNull((Object)string2);
                        LoginUtils.LoginResult loginResult = LoginUtils.loginSessionId(string2);
                        GuiAltManager guiAltManager = this.this$0;
                        switch (actionPerformed.WhenMappings.$EnumSwitchMapping$0[loginResult.ordinal()]) {
                            case 1: {
                                if (GuiAltManager.Companion.getAltService().getCurrentService() != AltService.EnumAltService.MOJANG) {
                                    GuiAltManager guiAltManager2 = guiAltManager;
                                    try {
                                        guiAltManager = guiAltManager2;
                                        GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                                    }
                                    catch (NoSuchFieldException e) {
                                        guiAltManager = guiAltManager2;
                                        ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                                    }
                                    catch (IllegalAccessException e) {
                                        guiAltManager = guiAltManager2;
                                        ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                                    }
                                }
                                string = "\u00a7cYour name is now \u00a7f\u00a7l" + this.this$0.mc.session.getUsername() + "\u00a7c";
                                break;
                            }
                            case 2: {
                                string = "\u00a7cFailed to parse Session ID!";
                                break;
                            }
                            case 3: {
                                string = "\u00a7cInvalid Session ID!";
                                break;
                            }
                            default: {
                                throw new NoWhenBranchMatchedException();
                            }
                        }
                        guiAltManager.setStatus(string);
                        GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                        if (guiButton == null) {
                            guiButton = null;
                        }
                        guiButton.enabled = true;
                        GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                        if (guiButton2 == null) {
                            guiButton2 = null;
                        }
                        guiButton2.enabled = true;
                        GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                        if (guiButton3 == null) {
                            guiButton3 = null;
                        }
                        guiButton3.enabled = true;
                        this.this$0.setLastSessionToken(null);
                    }
                }), (int)31, null);
            }
        }
    }

    public void keyTyped(char typedChar, int keyCode) {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        if (guiTextField.isFocused()) {
            GuiTextField guiTextField2 = this.searchField;
            if (guiTextField2 == null) {
                guiTextField2 = null;
            }
            guiTextField2.textboxKeyTyped(typedChar, keyCode);
        }
        switch (keyCode) {
            case 1: {
                this.mc.displayGuiScreen(this.prevGui);
                return;
            }
            case 200: {
                GuiList guiList;
                int i;
                GuiList guiList2 = this.altsList;
                if (guiList2 == null) {
                    guiList2 = null;
                }
                if ((i = guiList2.getSelectedSlot() - 1) < 0) {
                    i = 0;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList.elementClicked(i, false, 0, 0);
                break;
            }
            case 208: {
                GuiList guiList;
                GuiList guiList3 = this.altsList;
                if (guiList3 == null) {
                    guiList3 = null;
                }
                int i = guiList3.getSelectedSlot() + 1;
                GuiList guiList4 = this.altsList;
                if (guiList4 == null) {
                    guiList4 = null;
                }
                if (i >= guiList4.getSize()) {
                    GuiList guiList5 = this.altsList;
                    if (guiList5 == null) {
                        guiList5 = null;
                    }
                    i = guiList5.getSize() - 1;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList.elementClicked(i, false, 0, 0);
                break;
            }
            case 28: {
                GuiList guiList;
                GuiList guiList6 = this.altsList;
                if (guiList6 == null) {
                    guiList6 = null;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList6.elementClicked(guiList.getSelectedSlot(), true, 0, 0);
                break;
            }
            case 209: {
                GuiList guiList = this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                guiList.scrollBy(this.height - 100);
                break;
            }
            case 201: {
                GuiList guiList = this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                guiList.scrollBy(-this.height + 100);
                return;
            }
        }
        super.keyTyped(typedChar, keyCode);
    }

    public void handleMouseInput() {
        super.handleMouseInput();
        GuiList guiList = this.altsList;
        if (guiList == null) {
            guiList = null;
        }
        guiList.handleMouseInput();
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void updateScreen() {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.updateCursorCounter();
    }

    private final class GuiList
    extends GuiSlot {
        private int selectedSlot;

        public GuiList(GuiScreen prevGui) {
            Intrinsics.checkNotNullParameter((Object)((Object)GuiAltManager.this), (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
            super(GuiAltManager.this.mc, prevGui.width, prevGui.height, 40, prevGui.height - 40, 30);
        }

        /*
         * WARNING - void declaration
         */
        public final List<MinecraftAccount> getAccounts() {
            void $this$filterTo$iv$iv;
            String search = null;
            GuiTextField guiTextField = GuiAltManager.this.searchField;
            if (guiTextField == null) {
                guiTextField = null;
            }
            if ((search = guiTextField.getText()) == null || ((CharSequence)search).length() == 0) {
                List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
                Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
                return list;
            }
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            Object object = search.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
            search = object;
            List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
            Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
            Iterable $this$filter$iv = list;
            boolean $i$f$filter = false;
            object = $this$filter$iv;
            Collection destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                MinecraftAccount it = (MinecraftAccount)element$iv$iv;
                boolean bl = false;
                boolean bl2 = StringsKt.contains((CharSequence)it.getName(), (CharSequence)search, (boolean)true) || it instanceof MojangAccount && StringsKt.contains((CharSequence)((MojangAccount)it).getEmail(), (CharSequence)search, (boolean)true);
                if (!bl2) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            return (List)destination$iv$iv;
        }

        public final int getSelectedSlot() {
            return this.selectedSlot > this.getAccounts().size() ? -1 : this.selectedSlot;
        }

        public final void setSelectedSlot(int n) {
            this.selectedSlot = n;
        }

        public final MinecraftAccount getSelectedAccount() {
            return this.getSelectedSlot() >= 0 && this.getSelectedSlot() < this.getAccounts().size() ? this.getAccounts().get(this.getSelectedSlot()) : (MinecraftAccount)null;
        }

        protected boolean isSelected(int id) {
            return this.getSelectedSlot() == id;
        }

        public int getSize() {
            return this.getAccounts().size();
        }

        /*
         * WARNING - void declaration
         */
        public void elementClicked(int clickedElement, boolean doubleClick, int var3, int var4) {
            this.selectedSlot = clickedElement;
            if (doubleClick) {
                String string;
                MinecraftAccount minecraftAccount;
                GuiAltManager guiAltManager = GuiAltManager.this;
                GuiList guiList = GuiAltManager.this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                if ((minecraftAccount = guiList.getSelectedAccount()) == null) {
                    string = "\u00a7cSelect an account.";
                } else {
                    String string2;
                    void it;
                    MinecraftAccount minecraftAccount2 = minecraftAccount;
                    GuiAltManager guiAltManager2 = GuiAltManager.this;
                    MinecraftAccount minecraftAccount3 = minecraftAccount2;
                    GuiAltManager guiAltManager3 = guiAltManager;
                    boolean bl = false;
                    GuiButton guiButton = guiAltManager2.loginButton;
                    if (guiButton == null) {
                        guiButton = null;
                    }
                    guiButton.enabled = false;
                    GuiButton guiButton2 = guiAltManager2.randomButton;
                    if (guiButton2 == null) {
                        guiButton2 = null;
                    }
                    guiButton2.enabled = false;
                    GuiButton guiButton3 = guiAltManager2.randomCracked;
                    if (guiButton3 == null) {
                        guiButton3 = null;
                    }
                    guiButton3.enabled = false;
                    Companion.login((MinecraftAccount)it, (Function0<Unit>)((Function0)new Function0<Unit>(guiAltManager2, this){
                        final /* synthetic */ GuiAltManager this$0;
                        final /* synthetic */ GuiList this$1;
                        {
                            this.this$0 = $receiver;
                            this.this$1 = $receiver2;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + GuiList.access$getMc$p$s2037200985((GuiList)this.this$1).session.getUsername() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(guiAltManager2){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(guiAltManager2){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.enabled = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.enabled = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.enabled = true;
                        }
                    }));
                    Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)boolValue);
                    if (((Boolean)boolValue.get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    guiAltManager = guiAltManager3;
                    string = string2 = "\u00a7aLogging in...";
                }
                guiAltManager.setStatus(string);
            }
        }

        protected void drawSlot(int id, int x, int y, int var4, int var5, int var6) {
            MinecraftAccount minecraftAccount = this.getAccounts().get(id);
            String accountName = minecraftAccount instanceof MojangAccount && ((CharSequence)((MojangAccount)minecraftAccount).getName()).length() == 0 ? ((MojangAccount)minecraftAccount).getEmail() : minecraftAccount.getName();
            Fonts.fontSFUI40.drawCenteredString(accountName, (float)this.width / 2.0f, (float)y + 2.0f, Color.WHITE.getRGB());
            Fonts.fontSFUI40.drawCenteredString(minecraftAccount instanceof CrackedAccount ? "Cracked" : (minecraftAccount instanceof MicrosoftAccount ? "Microsoft" : (minecraftAccount instanceof MojangAccount ? "Mojang" : "Something else")), (float)this.width / 2.0f, (float)y + 15.0f, minecraftAccount instanceof CrackedAccount ? Color.GRAY.getRGB() : new Color(118, 255, 95).getRGB());
        }

        protected void drawBackground() {
        }

        public static final /* synthetic */ Minecraft access$getMc$p$s2037200985(GuiList $this) {
            return $this.mc;
        }
    }

    public static final class Companion {
        private Companion() {
        }

        public final AltService getAltService() {
            return altService;
        }

        public final Thread login(MinecraftAccount minecraftAccount, Function0<Unit> success, Function1<? super Exception, Unit> error, Function0<Unit> done) {
            Intrinsics.checkNotNullParameter((Object)minecraftAccount, (String)"minecraftAccount");
            Intrinsics.checkNotNullParameter(success, (String)"success");
            Intrinsics.checkNotNullParameter(error, (String)"error");
            Intrinsics.checkNotNullParameter(done, (String)"done");
            return ThreadsKt.thread$default((boolean)false, (boolean)false, null, (String)"LoginTask", (int)0, (Function0)((Function0)new Function0<Unit>(error, minecraftAccount, success, done){
                final /* synthetic */ Function1<Exception, Unit> $error;
                final /* synthetic */ MinecraftAccount $minecraftAccount;
                final /* synthetic */ Function0<Unit> $success;
                final /* synthetic */ Function0<Unit> $done;
                {
                    this.$error = $error;
                    this.$minecraftAccount = $minecraftAccount;
                    this.$success = $success;
                    this.$done = $done;
                    super(0);
                }

                public final void invoke() {
                    if (GuiAltManager.Companion.getAltService().getCurrentService() != AltService.EnumAltService.MOJANG) {
                        try {
                            GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                        }
                        catch (NoSuchFieldException e) {
                            this.$error.invoke((Object)e);
                            ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                        }
                        catch (IllegalAccessException e) {
                            this.$error.invoke((Object)e);
                            ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                        }
                    }
                    try {
                        this.$minecraftAccount.update();
                        Minecraft.getMinecraft().session = new Session(this.$minecraftAccount.getSession().getUsername(), this.$minecraftAccount.getSession().getUuid(), this.$minecraftAccount.getSession().getToken(), "mojang");
                        Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
                        this.$success.invoke();
                    }
                    catch (Exception exception) {
                        this.$error.invoke((Object)exception);
                    }
                    this.$done.invoke();
                }
            }), (int)23, null);
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

