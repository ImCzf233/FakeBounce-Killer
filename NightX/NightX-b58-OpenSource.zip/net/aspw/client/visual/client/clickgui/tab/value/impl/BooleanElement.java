/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.visual.client.clickgui.tab.value.impl;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.clickgui.tab.components.Checkbox;
import net.aspw.client.visual.client.clickgui.tab.value.ValueElement;
import net.aspw.client.visual.font.Fonts;

public final class BooleanElement
extends ValueElement<Boolean> {
    private final Checkbox checkbox;

    public BooleanElement(BoolValue value) {
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        super(value);
        this.checkbox = new Checkbox();
    }

    @Override
    public float drawElement(int mouseX, int mouseY, float x, float y, float width, Color bgColor, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)bgColor, (String)"bgColor");
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        this.checkbox.setState((Boolean)this.getValue().get());
        this.checkbox.onDraw(x + 10.0f, y + 5.0f, 10.0f, 10.0f, bgColor, accentColor);
        Fonts.fontSFUI40.drawString(this.getValue().getName(), x + 25.0f, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        return this.getValueHeight();
    }

    @Override
    public void onClick(int mouseX, int mouseY, float x, float y, float width) {
        if (this.isDisplayable() && MouseUtils.mouseWithinBounds(mouseX, mouseY, x, y, x + width, y + 20.0f)) {
            this.getValue().set((Boolean)this.getValue().get() == false);
        }
    }
}

