/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public final class Render3DEvent
extends Event {
    private final float partialTicks;

    public Render3DEvent(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public final float getPartialTicks() {
        return this.partialTicks;
    }
}

