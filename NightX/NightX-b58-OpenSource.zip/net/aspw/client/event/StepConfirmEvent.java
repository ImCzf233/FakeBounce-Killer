/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public final class StepConfirmEvent
extends Event {
}

