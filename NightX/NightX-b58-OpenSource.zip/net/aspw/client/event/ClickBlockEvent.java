/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.jetbrains.annotations.Nullable;

public final class ClickBlockEvent
extends Event {
    private final BlockPos clickedBlock;
    private final EnumFacing enumFacing;

    public ClickBlockEvent(@Nullable BlockPos clickedBlock, @Nullable EnumFacing enumFacing) {
        this.clickedBlock = clickedBlock;
        this.enumFacing = enumFacing;
    }

    public final BlockPos getClickedBlock() {
        return this.clickedBlock;
    }

    public final EnumFacing getEnumFacing() {
        return this.enumFacing;
    }
}

