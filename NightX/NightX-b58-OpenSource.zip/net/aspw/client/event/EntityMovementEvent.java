/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.minecraft.entity.Entity;
import org.jetbrains.annotations.Nullable;

public final class EntityMovementEvent
extends Event {
    private final Entity movedEntity;

    public EntityMovementEvent(Entity movedEntity) {
        Intrinsics.checkNotNullParameter((Object)movedEntity, (String)"movedEntity");
        this.movedEntity = movedEntity;
    }

    public final Entity getMovedEntity() {
        return this.movedEntity;
    }

    public final Entity component1() {
        return this.movedEntity;
    }

    public final EntityMovementEvent copy(Entity movedEntity) {
        Intrinsics.checkNotNullParameter((Object)movedEntity, (String)"movedEntity");
        return new EntityMovementEvent(movedEntity);
    }

    public static /* synthetic */ EntityMovementEvent copy$default(EntityMovementEvent entityMovementEvent, Entity entity, int n, Object object) {
        if ((n & 1) != 0) {
            entity = entityMovementEvent.movedEntity;
        }
        return entityMovementEvent.copy(entity);
    }

    public String toString() {
        return "EntityMovementEvent(movedEntity=" + this.movedEntity + ')';
    }

    public int hashCode() {
        return this.movedEntity.hashCode();
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof EntityMovementEvent)) {
            return false;
        }
        EntityMovementEvent entityMovementEvent = (EntityMovementEvent)other;
        return this.movedEntity.equals(entityMovementEvent.movedEntity);
    }
}

