/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.FontRenderer
 */
package net.aspw.client.value;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.value.Value;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.FontRenderer;

public final class FontValue
extends Value<FontRenderer> {
    public FontValue(String valueName, FontRenderer value, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)valueName, (String)"valueName");
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        super(valueName, value, displayable);
    }

    public FontValue(String valueName, FontRenderer value) {
        Intrinsics.checkNotNullParameter((Object)valueName, (String)"valueName");
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        this(valueName, value, (Function0<Boolean>)((Function0)1.INSTANCE));
    }

    @Override
    public JsonElement toJson() {
        Object[] objectArray = Fonts.getFontDetails((FontRenderer)this.getValue());
        if (objectArray == null) {
            return null;
        }
        Object[] fontDetails = objectArray;
        JsonObject valueObject = new JsonObject();
        Object object = fontDetails[0];
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        valueObject.addProperty("fontName", (String)object);
        Object object2 = fontDetails[1];
        if (object2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
        }
        valueObject.addProperty("fontSize", (Number)((Integer)object2));
        return (JsonElement)valueObject;
    }

    @Override
    public void fromJson(JsonElement element) {
        Intrinsics.checkNotNullParameter((Object)element, (String)"element");
        if (!element.isJsonObject()) {
            return;
        }
        JsonObject valueObject = element.getAsJsonObject();
        FontRenderer fontRenderer = Fonts.getFontRenderer(valueObject.get("fontName").getAsString(), valueObject.get("fontSize").getAsInt());
        Intrinsics.checkNotNullExpressionValue((Object)fontRenderer, (String)"getFontRenderer(valueObj\u2026Object[\"fontSize\"].asInt)");
        this.setValue(fontRenderer);
    }
}

