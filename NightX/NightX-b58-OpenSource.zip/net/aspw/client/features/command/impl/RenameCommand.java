/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.util.render.ColorUtils;
import net.minecraft.item.ItemStack;

public final class RenameCommand
extends Command {
    public RenameCommand() {
        boolean $i$f$emptyArray = false;
        super("rename", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            if (MinecraftInstance.mc.playerController.isNotCreative()) {
                this.chat("\u00a7c\u00a7lError: \u00a73You need to be in creative mode.");
                return;
            }
            ItemStack item = MinecraftInstance.mc.thePlayer.getHeldItem();
            if (item == null || item.getItem() == null) {
                this.chat("\u00a7c\u00a7lError: \u00a73You need to hold a item.");
                return;
            }
            String string = StringUtils.toCompleteString(args, 1);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"toCompleteString(args, 1)");
            item.setStackDisplayName(ColorUtils.translateAlternateColorCodes(string));
            this.chat("\u00a73Item renamed to '" + item.getDisplayName() + "\u00a73'");
            return;
        }
        this.chatSyntax("rename <name>");
    }
}

