/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.features.command.impl;

import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.api.MacroManager;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.misc.StringUtils;
import org.lwjgl.input.Keyboard;

public final class MacroCommand
extends Command {
    public MacroCommand() {
        boolean $i$f$emptyArray = false;
        super("macro", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        block25: {
            Object lastMessage;
            Iterator iterator;
            Intrinsics.checkNotNullParameter((Object)args, (String)"args");
            if (args.length > 2) {
                String string = args[2];
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                iterator = string.toUpperCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"this as java.lang.String).toUpperCase(locale)");
                int key = Keyboard.getKeyIndex((String)((Object)iterator));
                if (key == 0) {
                    this.chat("\u00a7c\u00a7lKeybind doesn't exist, or not allowed.");
                    this.chatSyntax("macro <list/clear/add/remove>");
                    return;
                }
                String string2 = args[1];
                iterator = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"getDefault()");
                String string3 = string2.toLowerCase((Locale)((Object)iterator));
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toLowerCase(locale)");
                String string4 = string3;
                if (string4.equals("add")) {
                    if (args.length < 4) {
                        this.chatSyntax("macro add <key name> <message>");
                        return;
                    }
                    String message = StringUtils.toCompleteString(args, 3);
                    boolean existed = MacroManager.INSTANCE.getMacroMapping().containsKey(key);
                    Intrinsics.checkNotNullExpressionValue((Object)message, (String)"message");
                    MacroManager.INSTANCE.addMacro(key, message);
                    Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().valuesConfig);
                    if (existed) {
                        this.chat("\u00a7a\u00a7lSuccessfully changed macro in key \u00a77" + Keyboard.getKeyName((int)key) + " to \u00a7r" + message + '.');
                    } else {
                        this.chat("\u00a7a\u00a7lSuccessfully added \u00a7r" + message + " \u00a7a\u00a7lto key \u00a77" + Keyboard.getKeyName((int)key) + '.');
                    }
                    return;
                }
                if (string4.equals("remove")) {
                    if (MacroManager.INSTANCE.getMacroMapping().containsKey(key)) {
                        lastMessage = MacroManager.INSTANCE.getMacroMapping().get(key);
                        MacroManager.INSTANCE.removeMacro(key);
                        Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().valuesConfig);
                        this.chat("\u00a7a\u00a7lSuccessfully removed the macro \u00a7r" + lastMessage + " \u00a7a\u00a7lfrom \u00a77" + Keyboard.getKeyName((int)key) + '.');
                        return;
                    }
                    this.chat("\u00a7c\u00a7lThere's no macro bound to this key.");
                    this.chatSyntax("macro remove <key name>");
                    return;
                }
            }
            if (args.length != 2) break block25;
            String string = args[1];
            lastMessage = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)lastMessage, (String)"getDefault()");
            iterator = string.toLowerCase((Locale)lastMessage);
            Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (iterator) {
                case "list": {
                    this.chat("\u00a76\u00a7lMacros:");
                    Map $this$forEach$iv = MacroManager.INSTANCE.getMacroMapping();
                    boolean $i$f$forEach = false;
                    iterator = $this$forEach$iv.entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry element$iv;
                        Map.Entry it = element$iv = iterator.next();
                        boolean bl = false;
                        ClientUtils.displayChatMessage("\u00a76> \u00a7c" + Keyboard.getKeyName((int)((Number)it.getKey()).intValue()) + ": \u00a7r" + (String)it.getValue());
                    }
                    return;
                }
                case "clear": {
                    MacroManager.INSTANCE.getMacroMapping().clear();
                    Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().valuesConfig);
                    this.chat("\u00a7a\u00a7lSuccessfully cleared macro list.");
                    return;
                }
                case "add": {
                    this.chatSyntax("macro add <key name> <message>");
                    return;
                }
                case "remove": {
                    this.chatSyntax("macro remove <key name>");
                    return;
                }
            }
        }
        this.chatSyntax("macro <list/clear/add/remove>");
    }
}

