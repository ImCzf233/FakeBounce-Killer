/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;

public final class IgnCommand
extends Command {
    public IgnCommand() {
        boolean $i$f$emptyArray = false;
        super("ign", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        String username = MinecraftInstance.mc.thePlayer.getName();
        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
        Intrinsics.checkNotNull((Object)boolValue);
        if (((Boolean)boolValue.get()).booleanValue()) {
            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
        }
        Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)"Copied Username: \u00a7a", (Object)username), Notification.Type.SUCCESS));
        StringSelection stringSelection = new StringSelection(username);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, stringSelection);
    }
}

