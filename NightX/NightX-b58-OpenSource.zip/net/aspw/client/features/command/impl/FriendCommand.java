/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.config.configs.FriendsConfig;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.misc.StringUtils;

public final class FriendCommand
extends Command {
    public FriendCommand() {
        String[] stringArray = new String[]{"friends"};
        super("friend", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            FriendsConfig friendsConfig = Client.INSTANCE.getFileManager().friendsConfig;
            if (StringsKt.equals((String)args[1], (String)"add", (boolean)true)) {
                if (args.length > 2) {
                    String name = args[2];
                    if (((CharSequence)name).length() == 0) {
                        this.chat("The name is empty.");
                        return;
                    }
                    if (args.length > 3 ? friendsConfig.addFriend(name, StringUtils.toCompleteString(args, 3)) : friendsConfig.addFriend(name)) {
                        Client.INSTANCE.getFileManager().saveConfig(friendsConfig);
                        this.chat("\u00a7a\u00a7l" + name + "\u00a73 was added to your friend list.");
                    } else {
                        this.chat("The name is already in the list.");
                    }
                    return;
                }
                this.chatSyntax("friend add <name> [alias]");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"remove", (boolean)true)) {
                if (args.length > 2) {
                    String name = args[2];
                    if (friendsConfig.removeFriend(name)) {
                        Client.INSTANCE.getFileManager().saveConfig(friendsConfig);
                        this.chat("\u00a7a\u00a7l" + name + "\u00a73 was removed from your friend list.");
                    } else {
                        this.chat("This name is not in the list.");
                    }
                    return;
                }
                this.chatSyntax("friend remove <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"clear", (boolean)true)) {
                int friends = friendsConfig.getFriends().size();
                friendsConfig.clearFriends();
                Client.INSTANCE.getFileManager().saveConfig(friendsConfig);
                this.chat("Removed " + friends + " friend(s).");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"list", (boolean)true)) {
                this.chat("Your Friends:");
                for (FriendsConfig.Friend friend : friendsConfig.getFriends()) {
                    this.chat("\u00a77> \u00a7a\u00a7l" + friend.getPlayerName() + " \u00a7c(\u00a77\u00a7l" + friend.getAlias() + "\u00a7c)");
                }
                this.chat("You have \u00a7c" + friendsConfig.getFriends().size() + "\u00a73 friends.");
                return;
            }
        }
        this.chatSyntax("friend <add/remove/list/clear>");
    }
}

