/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;

public final class HelpCommand
extends Command {
    public HelpCommand() {
        boolean $i$f$emptyArray = false;
        super("help", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        try {
            this.chat("\u00a7c\u00a7lHelp");
            this.chat("\u00a7a------------");
            this.chat(".bind <module> <key> / .bind <module> none");
            this.chat("\u00a7a------------");
            this.chat(".binds / .binds clear");
            this.chat("\u00a7a------------");
            this.chat(".clip <value>");
            this.chat("\u00a7a------------");
            this.chat(".(config, c) <load/save/list/delete/fix/folder>");
            this.chat("\u00a7a------------");
            this.chat(".enchant <type> [level]");
            this.chat("\u00a7a------------");
            this.chat(".friend <add/remove/list/clear>");
            this.chat("\u00a7a------------");
            this.chat(".(give, item, i, get) <item> [amount] [data] [datatag]");
            this.chat("\u00a7a------------");
            this.chat(".hide <module/list/clear/reset/category>");
            this.chat("\u00a7a------------");
            this.chat(".(damage, dmg) / .(damage, dmg) <size>");
            this.chat("\u00a7a------------");
            this.chat(".ign");
            this.chat("\u00a7a------------");
            this.chat(".(register, r)");
            this.chat("\u00a7a------------");
            this.chat(".(login, l)");
            this.chat("\u00a7a------------");
            this.chat(".macro <list/clear/add/remove>");
            this.chat("\u00a7a------------");
            this.chat(".(magictrick, mt)");
            this.chat("\u00a7a------------");
            this.chat(".ping");
            this.chat("\u00a7a------------");
            this.chat(".(plugins, pl)");
            this.chat("\u00a7a------------");
            this.chat(".reload");
            this.chat("\u00a7a------------");
            this.chat(".(remoteview, rv) <username>");
            this.chat("\u00a7a------------");
            this.chat(".rename <name>");
            this.chat("\u00a7a------------");
            this.chat(".(repeat, rp) <amount> <message>");
            this.chat("\u00a7a------------");
            this.chat(".say <message>");
            this.chat("\u00a7a------------");
            this.chat(".(skinstealer, steal) <id>");
            this.chat("\u00a7a------------");
            this.chat(".(teleport, tp) <player name/x y z>");
            this.chat("\u00a7a------------");
            this.chat(".theme <load/save/list/delete>");
            this.chat("\u00a7a------------");
            this.chat(".(toggle, t) <module> [on/off]");
            this.chat("\u00a7a------------");
            this.chat(".vclip <value>");
            this.chat("\u00a7a------------");
            return;
        }
        catch (NumberFormatException ex) {
            this.chatSyntaxError();
            return;
        }
    }
}

