/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Triple
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S0CPacketSpawnPlayer
 *  net.minecraft.util.Vec3
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.combat;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import kotlin.Triple;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EntityMovementEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.BacktrackData;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.IntegerValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="BackTrack", spacedName="Back Track", description="", category=ModuleCategory.COMBAT)
public final class BackTrack
extends Module {
    private final IntegerValue maximumDelay = new IntegerValue("MaxDelay", 250, 0, 1000);
    private final IntegerValue maximumCachedPositions = new IntegerValue("MaxCachedPositions", 10, 1, 20);
    private final Map<UUID, List<BacktrackData>> backtrackedPlayer = new LinkedHashMap();

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S0CPacketSpawnPlayer) {
            UUID uUID = ((S0CPacketSpawnPlayer)packet).getPlayer();
            Intrinsics.checkNotNullExpressionValue((Object)uUID, (String)"packet.player");
            this.addBacktrackData(uUID, (double)((S0CPacketSpawnPlayer)packet).getX() / 32.0, (double)((S0CPacketSpawnPlayer)packet).getY() / 32.0, (double)((S0CPacketSpawnPlayer)packet).getZ() / 32.0, System.currentTimeMillis());
        }
    }

    @EventTarget
    public final void onEntityMove(EntityMovementEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Entity entity = event.getMovedEntity();
        if (entity instanceof EntityPlayer) {
            UUID uUID = ((EntityPlayer)entity).getUniqueID();
            Intrinsics.checkNotNullExpressionValue((Object)uUID, (String)"entity.uniqueID");
            this.addBacktrackData(uUID, entity.posX, entity.posY, entity.posZ, System.currentTimeMillis());
        }
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Color color = Color.RED;
        for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityPlayer)) continue;
            GL11.glPushMatrix();
            GL11.glDisable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)2929);
            MinecraftInstance.mc.entityRenderer.disableLightmap();
            GL11.glBegin((int)3);
            RenderUtils.glColor(color);
            double renderPosX = MinecraftInstance.mc.getRenderManager().viewerPosX;
            double renderPosY = MinecraftInstance.mc.getRenderManager().viewerPosY;
            double renderPosZ = MinecraftInstance.mc.getRenderManager().viewerPosZ;
            this.loopThroughBacktrackData(entity, (Function0<Boolean>)((Function0)new Function0<Boolean>(entity, renderPosX, renderPosY, renderPosZ){
                final /* synthetic */ Entity $entity;
                final /* synthetic */ double $renderPosX;
                final /* synthetic */ double $renderPosY;
                final /* synthetic */ double $renderPosZ;
                {
                    this.$entity = $entity;
                    this.$renderPosX = $renderPosX;
                    this.$renderPosY = $renderPosY;
                    this.$renderPosZ = $renderPosZ;
                    super(0);
                }

                public final Boolean invoke() {
                    GL11.glVertex3d((double)(this.$entity.posX - this.$renderPosX), (double)(this.$entity.posY - this.$renderPosY), (double)(this.$entity.posZ - this.$renderPosZ));
                    return false;
                }
            }));
            GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
            GL11.glEnd();
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    private final void addBacktrackData(UUID id, double x, double y, double z, long time) {
        List<BacktrackData> backtrackData = this.getBacktrackData(id);
        if (backtrackData != null) {
            if (backtrackData.size() >= ((Number)this.maximumCachedPositions.get()).intValue()) {
                backtrackData.remove(0);
            }
            backtrackData.add(new BacktrackData(x, y, z, time));
        } else {
            Map<UUID, List<BacktrackData>> map = this.backtrackedPlayer;
            Object object = new BacktrackData[]{new BacktrackData(x, y, z, time)};
            object = CollectionsKt.mutableListOf((Object[])object);
            map.put(id, (List<BacktrackData>)object);
        }
    }

    private final List<BacktrackData> getBacktrackData(UUID id) {
        return this.backtrackedPlayer.get(id);
    }

    public final void loopThroughBacktrackData(Entity entity, Function0<Boolean> action) {
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        Intrinsics.checkNotNullParameter(action, (String)"action");
        if (!this.getState() || !(entity instanceof EntityPlayer)) {
            return;
        }
        UUID uUID = ((EntityPlayer)entity).getUniqueID();
        Intrinsics.checkNotNullExpressionValue((Object)uUID, (String)"entity.uniqueID");
        List<BacktrackData> list = this.getBacktrackData(uUID);
        if (list == null) {
            return;
        }
        List<BacktrackData> backtrackDataArray = list;
        Vec3 entityPosition = ((EntityPlayer)entity).getPositionVector();
        Triple prevPosition = new Triple((Object)entity.prevPosX, (Object)entity.prevPosY, (Object)entity.prevPosZ);
        for (BacktrackData backtrackData : CollectionsKt.reversed((Iterable)backtrackDataArray)) {
            entity.setPosition(backtrackData.getX(), backtrackData.getY(), backtrackData.getZ());
            entity.prevPosX = backtrackData.getX();
            entity.prevPosY = backtrackData.getY();
            entity.prevPosZ = backtrackData.getZ();
            if (!((Boolean)action.invoke()).booleanValue()) continue;
        }
        double prevX = ((Number)prevPosition.component1()).doubleValue();
        double prevY = ((Number)prevPosition.component2()).doubleValue();
        double prevZ = ((Number)prevPosition.component3()).doubleValue();
        entity.prevPosX = prevX;
        entity.prevPosY = prevY;
        entity.prevPosZ = prevZ;
        entity.setPosition(entityPosition.xCoord, entityPosition.yCoord, entityPosition.zCoord);
    }
}

