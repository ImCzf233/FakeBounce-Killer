/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.config.configs.FriendsConfig;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.TextEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.TextValue;

@ModuleInfo(name="NameProtect", spacedName="Name Protect", description="", category=ModuleCategory.OTHER)
public final class NameProtect
extends Module {
    private final BoolValue selfValue = new BoolValue("Yourself", true);
    private final BoolValue tagValue = new BoolValue("Tag", false);
    private final TextValue fakeNameValue = new TextValue("FakeName", "User");

    @EventTarget
    public final void onText(TextEvent event) {
        block5: {
            block4: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (MinecraftInstance.mc.thePlayer == null) break block4;
                String string = event.getText();
                Intrinsics.checkNotNull((Object)string);
                if (string.equals("\u00a7c\u00a7l>> \u00a7r\u00a73")) break block4;
                String string2 = event.getText();
                Intrinsics.checkNotNull((Object)string2);
                if (StringsKt.startsWith$default((String)string2, (String)"/", (boolean)false, (int)2, null)) break block4;
                String string3 = event.getText();
                Intrinsics.checkNotNull((Object)string3);
                if (!StringsKt.startsWith$default((String)string3, (String)".", (boolean)false, (int)2, null)) break block5;
            }
            return;
        }
        for (FriendsConfig.Friend friend : Client.INSTANCE.getFileManager().friendsConfig.getFriends()) {
            String string = event.getText();
            String string4 = friend.getPlayerName();
            String string5 = friend.getAlias();
            Intrinsics.checkNotNullExpressionValue((Object)string5, (String)"friend.alias");
            event.setText(StringUtils.replace(string, string4, Intrinsics.stringPlus((String)ColorUtils.translateAlternateColorCodes(string5), (Object)"\u00a7f")));
        }
        event.setText(StringUtils.replace(event.getText(), MinecraftInstance.mc.thePlayer.getName(), ((Boolean)this.selfValue.get()).booleanValue() ? (((Boolean)this.tagValue.get()).booleanValue() ? StringUtils.injectAirString(MinecraftInstance.mc.thePlayer.getName()) + " \u00a77(\u00a7a" + ColorUtils.translateAlternateColorCodes(Intrinsics.stringPlus((String)((String)this.fakeNameValue.get()), (Object)"\u00a77)")) : Intrinsics.stringPlus((String)ColorUtils.translateAlternateColorCodes((String)this.fakeNameValue.get()), (Object)"\u00a7r")) : MinecraftInstance.mc.thePlayer.getName()));
    }
}

