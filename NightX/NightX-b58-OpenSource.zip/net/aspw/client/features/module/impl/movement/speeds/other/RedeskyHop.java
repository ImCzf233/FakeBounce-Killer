/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class RedeskyHop
extends SpeedMode {
    private boolean slowCum = false;
    private double cumSpeed = 0.0;

    public RedeskyHop() {
        super("RedeskyHop");
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving()) {
            if (RedeskyHop.mc.thePlayer.onGround) {
                RedeskyHop.mc.thePlayer.jump();
                RedeskyHop.mc.thePlayer.motionY = 0.39;
                this.cumSpeed = 1.02875;
                this.slowCum = true;
            } else {
                if (this.slowCum) {
                    this.cumSpeed *= 0.969;
                    this.slowCum = false;
                }
                if ((double)RedeskyHop.mc.thePlayer.fallDistance < 0.1) {
                    this.cumSpeed *= 1.004;
                } else {
                    this.cumSpeed *= 0.995;
                    if ((double)RedeskyHop.mc.thePlayer.fallDistance > 0.93) {
                        RedeskyHop.mc.timer.timerSpeed = 1.14f;
                    }
                }
            }
            RedeskyHop.mc.thePlayer.motionX *= this.cumSpeed;
            RedeskyHop.mc.thePlayer.motionZ *= this.cumSpeed;
        } else {
            RedeskyHop.mc.thePlayer.motionZ = 0.0;
            RedeskyHop.mc.thePlayer.motionX = 0.0;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

