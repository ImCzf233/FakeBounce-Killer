/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class HiveHop
extends SpeedMode {
    public HiveHop() {
        super("HiveHop");
    }

    @Override
    public void onEnable() {
        HiveHop.mc.thePlayer.speedInAir = 0.0425f;
        HiveHop.mc.timer.timerSpeed = 1.04f;
    }

    @Override
    public void onDisable() {
        HiveHop.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (HiveHop.mc.thePlayer.onGround) {
                HiveHop.mc.thePlayer.motionY = 0.3;
            }
            HiveHop.mc.thePlayer.speedInAir = 0.0425f;
            HiveHop.mc.timer.timerSpeed = 1.04f;
            MovementUtils.strafe();
        } else {
            HiveHop.mc.thePlayer.motionZ = 0.0;
            HiveHop.mc.thePlayer.motionX = 0.0;
            HiveHop.mc.thePlayer.speedInAir = 0.02f;
            HiveHop.mc.timer.timerSpeed = 1.0f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

