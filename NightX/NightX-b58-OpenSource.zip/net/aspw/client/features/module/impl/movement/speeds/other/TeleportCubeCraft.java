/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.timer.MSTimer;

public class TeleportCubeCraft
extends SpeedMode {
    private final MSTimer timer = new MSTimer();

    public TeleportCubeCraft() {
        super("TeleportCubeCraft");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
        if (MovementUtils.isMoving() && TeleportCubeCraft.mc.thePlayer.onGround && this.timer.hasTimePassed(300L)) {
            double yaw = MovementUtils.getDirection();
            float length = ((Float)Client.moduleManager.getModule(Speed.class).cubecraftPortLengthValue.get()).floatValue();
            event.setX(-Math.sin(yaw) * (double)length);
            event.setZ(Math.cos(yaw) * (double)length);
            this.timer.reset();
        }
    }
}

