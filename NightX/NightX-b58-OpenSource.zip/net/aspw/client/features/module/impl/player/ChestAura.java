/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.multiplayer.PlayerControllerMP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.player.Blink;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.VecRotation;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.extensions.BlockExtensionKt;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BlockValue;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

@ModuleInfo(name="ChestAura", spacedName="Chest Aura", description="", category=ModuleCategory.PLAYER)
public final class ChestAura
extends Module {
    private final FloatValue rangeValue = new FloatValue("Range", 4.0f, 1.0f, 6.0f, "m");
    private final IntegerValue delayValue = new IntegerValue("Delay", 50, 50, 200, "ms");
    private final BoolValue throughWallsValue = new BoolValue("ThroughWalls", true);
    private final BoolValue visualSwing = new BoolValue("VisualSwing", true);
    private final BlockValue chestValue = new BlockValue("Chest", Block.getIdFromBlock((Block)((Block)Blocks.chest)));
    private final BoolValue rotationsValue = new BoolValue("Rotations", true);
    private BlockPos currentBlock;
    private final MSTimer timer = new MSTimer();
    private final List<BlockPos> clickedBlocks = new ArrayList();

    public final List<BlockPos> getClickedBlocks() {
        return this.clickedBlocks;
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Blink blink = Client.INSTANCE.getModuleManager().get(Blink.class);
        Intrinsics.checkNotNull((Object)blink);
        if (blink.getState()) {
            return;
        }
        switch (WhenMappings.$EnumSwitchMapping$0[event.getEventState().ordinal()]) {
            case 1: {
                Object v2;
                Map.Entry it;
                Map.Entry element$iv$iv;
                Map $this$filterTo$iv$iv;
                Map $this$filter$iv;
                if (MinecraftInstance.mc.currentScreen instanceof GuiContainer) {
                    this.timer.reset();
                }
                float radius = ((Number)this.rangeValue.get()).floatValue() + 1.0f;
                Vec3 eyesPos = new Vec3(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY + (double)MinecraftInstance.mc.thePlayer.getEyeHeight(), MinecraftInstance.mc.thePlayer.posZ);
                Map map = BlockUtils.searchBlocks((int)radius);
                ChestAura chestAura = this;
                boolean $i$f$filter = false;
                Iterator iterator = $this$filter$iv;
                Map destination$iv$iv = new LinkedHashMap();
                boolean $i$f$filterTo = false;
                Iterator iterator2 = $this$filterTo$iv$iv.entrySet().iterator();
                while (iterator2.hasNext()) {
                    it = element$iv$iv = iterator2.next();
                    boolean bl = false;
                    boolean bl2 = Block.getIdFromBlock((Block)((Block)it.getValue())) == ((Number)this.chestValue.get()).intValue() && !this.getClickedBlocks().contains(it.getKey()) && BlockUtils.getCenterDistance((BlockPos)it.getKey()) < (double)((Number)this.rangeValue.get()).floatValue();
                    if (!bl2) continue;
                    destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
                }
                $this$filter$iv = destination$iv$iv;
                $i$f$filter = false;
                $this$filterTo$iv$iv = $this$filter$iv;
                destination$iv$iv = new LinkedHashMap();
                $i$f$filterTo = false;
                iterator2 = $this$filterTo$iv$iv.entrySet().iterator();
                while (iterator2.hasNext()) {
                    BlockPos blockPos;
                    MovingObjectPosition movingObjectPosition;
                    it = element$iv$iv = iterator2.next();
                    boolean bl = false;
                    if (!((Boolean)this.throughWallsValue.get() != false ? true : (movingObjectPosition = MinecraftInstance.mc.theWorld.rayTraceBlocks(eyesPos, BlockExtensionKt.getVec(blockPos = (BlockPos)it.getKey()), false, true, false)) != null && movingObjectPosition.getBlockPos().equals(blockPos))) continue;
                    destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
                }
                map = destination$iv$iv;
                iterator = ((Iterable)map.entrySet()).iterator();
                if (!iterator.hasNext()) {
                    v2 = null;
                } else {
                    Object t = iterator.next();
                    if (!iterator.hasNext()) {
                        v2 = t;
                    } else {
                        Map.Entry it2 = (Map.Entry)t;
                        boolean bl = false;
                        double d = BlockUtils.getCenterDistance((BlockPos)it2.getKey());
                        do {
                            Object t2 = iterator.next();
                            Map.Entry it3 = (Map.Entry)t2;
                            $i$a$-minByOrNull-ChestAura$onMotion$3 = false;
                            double d2 = BlockUtils.getCenterDistance((BlockPos)it3.getKey());
                            if (Double.compare(d, d2) <= 0) continue;
                            t = t2;
                            d = d2;
                        } while (iterator.hasNext());
                        v2 = t;
                    }
                }
                Map.Entry entry = v2;
                BlockPos blockPos = chestAura.currentBlock = entry == null ? null : (BlockPos)entry.getKey();
                if (!((Boolean)this.rotationsValue.get()).booleanValue()) break;
                BlockPos blockPos2 = this.currentBlock;
                if (blockPos2 == null) {
                    return;
                }
                VecRotation vecRotation = RotationUtils.faceBlock(blockPos2);
                if (vecRotation == null) {
                    return;
                }
                RotationUtils.setTargetRotation(vecRotation.getRotation());
                break;
            }
            case 2: {
                if (this.currentBlock == null || !this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) break;
                PlayerControllerMP playerControllerMP = MinecraftInstance.mc.playerController;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                WorldClient worldClient = MinecraftInstance.mc.theWorld;
                ItemStack itemStack = MinecraftInstance.mc.thePlayer.getHeldItem();
                BlockPos blockPos = this.currentBlock;
                Intrinsics.checkNotNull((Object)blockPos);
                if (!playerControllerMP.onPlayerRightClick(entityPlayerSP, worldClient, itemStack, this.currentBlock, EnumFacing.DOWN, BlockExtensionKt.getVec(blockPos))) break;
                if (((Boolean)this.visualSwing.get()).booleanValue()) {
                    MinecraftInstance.mc.thePlayer.swingItem();
                } else {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                }
                BlockPos blockPos3 = this.currentBlock;
                Intrinsics.checkNotNull((Object)blockPos3);
                this.clickedBlocks.add(blockPos3);
                this.currentBlock = null;
                this.timer.reset();
            }
        }
    }

    @Override
    public void onDisable() {
        this.clickedBlocks.clear();
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[EventState.values().length];
            nArray[EventState.PRE.ordinal()] = 1;
            nArray[EventState.POST.ordinal()] = 2;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

