/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;

@ModuleInfo(name="FastBridge", spacedName="Fast Bridge", description="", category=ModuleCategory.PLAYER)
public final class FastBridge
extends Module {
    private final IntegerValue speedValue = new IntegerValue("Place-Speed", 0, 0, 20);
    private final TickTimer tickTimer = new TickTimer();

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        boolean shouldEagle;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.tickTimer.update();
        MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = shouldEagle = MinecraftInstance.mc.theWorld.getBlockState(new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 1.0, MinecraftInstance.mc.thePlayer.posZ)).getBlock() == Blocks.air;
        if (this.tickTimer.hasTimePassed(0 + ((Number)this.speedValue.get()).intValue()) && MinecraftInstance.mc.gameSettings.keyBindUseItem.isKeyDown() && shouldEagle || MinecraftInstance.mc.gameSettings.keyBindUseItem.isKeyDown() && !MinecraftInstance.mc.thePlayer.onGround) {
            KeyBinding.onTick((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode());
            this.tickTimer.reset();
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
        }
    }
}

