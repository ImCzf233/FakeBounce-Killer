/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class YPort2
extends SpeedMode {
    public YPort2() {
        super("YPort2");
    }

    @Override
    public void onMotion() {
        if (YPort2.mc.thePlayer.isOnLadder() || YPort2.mc.thePlayer.isInWater() || YPort2.mc.thePlayer.isInLava() || YPort2.mc.thePlayer.isInWeb || !MovementUtils.isMoving()) {
            return;
        }
        if (YPort2.mc.thePlayer.onGround) {
            YPort2.mc.thePlayer.jump();
        } else {
            YPort2.mc.thePlayer.motionY = -1.0;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!YPort2.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            YPort2.mc.thePlayer.motionX = 0.0;
            YPort2.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

