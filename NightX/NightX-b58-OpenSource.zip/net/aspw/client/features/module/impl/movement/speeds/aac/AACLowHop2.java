/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACLowHop2
extends SpeedMode {
    private boolean legitJump;

    public AACLowHop2() {
        super("AACLowHop2");
    }

    @Override
    public void onEnable() {
        this.legitJump = true;
        AACLowHop2.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onDisable() {
        AACLowHop2.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onMotion() {
        AACLowHop2.mc.timer.timerSpeed = 1.0f;
        if (AACLowHop2.mc.thePlayer.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            AACLowHop2.mc.timer.timerSpeed = 1.09f;
            if (AACLowHop2.mc.thePlayer.onGround) {
                if (this.legitJump) {
                    AACLowHop2.mc.thePlayer.jump();
                    this.legitJump = false;
                    return;
                }
                AACLowHop2.mc.thePlayer.motionY = 0.343f;
                MovementUtils.strafe(0.534f);
            }
        } else {
            this.legitJump = true;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

