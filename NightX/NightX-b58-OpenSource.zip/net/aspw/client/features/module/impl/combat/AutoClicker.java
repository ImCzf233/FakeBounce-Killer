/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.CooldownHelper;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.settings.KeyBinding;

@ModuleInfo(name="AutoClicker", spacedName="Auto Clicker", description="", category=ModuleCategory.COMBAT)
public final class AutoClicker
extends Module {
    private final BoolValue coolDownCheck = new BoolValue("Cooldown-Check", false);
    private final BoolValue leftValue = new BoolValue("Left", true);
    private final IntegerValue leftmaxCPSValue;
    private final IntegerValue leftminCPSValue;
    private final BoolValue rightValue;
    private final IntegerValue rightmaxCPSValue;
    private final IntegerValue rightminCPSValue;
    private long rightDelay;
    private long rightLastSwing;
    private long leftDelay;
    private long leftLastSwing;
    private final TickTimer tickTimer;

    public AutoClicker() {
        Object object = new Function0<Boolean>(this){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AutoClicker.access$getLeftValue$p(this.this$0).get() != false && (Boolean)AutoClicker.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.leftmaxCPSValue = new IntegerValue(this, (Object)object){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super("Left-MaxCPS", 12, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int leftminCPS = ((Number)AutoClicker.access$getLeftminCPSValue$p(this.this$0).get()).intValue();
                if (leftminCPS > newValue) {
                    this.set(leftminCPS);
                }
            }
        };
        object = new Function0<Boolean>(this){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AutoClicker.access$getLeftValue$p(this.this$0).get() != false && (Boolean)AutoClicker.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.leftminCPSValue = new IntegerValue(this, (Object)object){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super("Left-MinCPS", 8, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int leftmaxCPS = ((Number)AutoClicker.access$getLeftmaxCPSValue$p(this.this$0).get()).intValue();
                if (leftmaxCPS < newValue) {
                    this.set(leftmaxCPS);
                }
            }
        };
        this.rightValue = new BoolValue("Right", false);
        object = new Function0<Boolean>(this){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AutoClicker.access$getRightValue$p(this.this$0).get();
            }
        };
        this.rightmaxCPSValue = new IntegerValue(this, (Object)object){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super("Right-MaxCPS", 12, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int rightminCPS = ((Number)AutoClicker.access$getRightminCPSValue$p(this.this$0).get()).intValue();
                if (rightminCPS > newValue) {
                    this.set(rightminCPS);
                }
            }
        };
        object = new Function0<Boolean>(this){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AutoClicker.access$getRightValue$p(this.this$0).get();
            }
        };
        this.rightminCPSValue = new IntegerValue(this, (Object)object){
            final /* synthetic */ AutoClicker this$0;
            {
                this.this$0 = $receiver;
                super("Right-MinCPS", 8, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int rightmaxCPS = ((Number)AutoClicker.access$getRightmaxCPSValue$p(this.this$0).get()).intValue();
                if (rightmaxCPS < newValue) {
                    this.set(rightmaxCPS);
                }
            }
        };
        this.rightDelay = TimeUtils.randomClickDelay(((Number)this.rightminCPSValue.get()).intValue(), ((Number)this.rightmaxCPSValue.get()).intValue());
        this.leftDelay = (Boolean)this.coolDownCheck.get() != false ? TimeUtils.randomClickDelay(20, 20) : TimeUtils.randomClickDelay(((Number)this.leftminCPSValue.get()).intValue(), ((Number)this.leftmaxCPSValue.get()).intValue());
        this.tickTimer = new TickTimer();
    }

    @EventTarget
    public final void onRender(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.gameSettings.keyBindUseItem.isKeyDown() && !MinecraftInstance.mc.thePlayer.isUsingItem() && ((Boolean)this.rightValue.get()).booleanValue() && System.currentTimeMillis() - this.rightLastSwing >= this.rightDelay) {
            KeyBinding.onTick((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode());
            this.rightLastSwing = System.currentTimeMillis();
            this.rightDelay = TimeUtils.randomClickDelay(((Number)this.rightminCPSValue.get()).intValue(), ((Number)this.rightmaxCPSValue.get()).intValue());
        }
        if (MinecraftInstance.mc.gameSettings.keyBindAttack.isKeyDown() && ((Boolean)this.leftValue.get()).booleanValue() && System.currentTimeMillis() - this.leftLastSwing >= this.leftDelay && MinecraftInstance.mc.playerController.curBlockDamageMP == 0.0f) {
            if (((Boolean)this.coolDownCheck.get()).booleanValue() && CooldownHelper.INSTANCE.getAttackCooldownProgress() < 1.0) {
                return;
            }
            KeyBinding.onTick((int)MinecraftInstance.mc.gameSettings.keyBindAttack.getKeyCode());
            this.leftLastSwing = System.currentTimeMillis();
            this.leftDelay = TimeUtils.randomClickDelay(((Number)this.leftminCPSValue.get()).intValue(), ((Number)this.leftmaxCPSValue.get()).intValue());
        }
    }

    @Override
    public void onEnable() {
        this.tickTimer.update();
    }

    @Override
    public void onDisable() {
        this.tickTimer.reset();
    }

    public static final /* synthetic */ IntegerValue access$getLeftminCPSValue$p(AutoClicker $this) {
        return $this.leftminCPSValue;
    }

    public static final /* synthetic */ BoolValue access$getLeftValue$p(AutoClicker $this) {
        return $this.leftValue;
    }

    public static final /* synthetic */ BoolValue access$getCoolDownCheck$p(AutoClicker $this) {
        return $this.coolDownCheck;
    }

    public static final /* synthetic */ IntegerValue access$getLeftmaxCPSValue$p(AutoClicker $this) {
        return $this.leftmaxCPSValue;
    }

    public static final /* synthetic */ IntegerValue access$getRightminCPSValue$p(AutoClicker $this) {
        return $this.rightminCPSValue;
    }

    public static final /* synthetic */ BoolValue access$getRightValue$p(AutoClicker $this) {
        return $this.rightValue;
    }

    public static final /* synthetic */ IntegerValue access$getRightmaxCPSValue$p(AutoClicker $this) {
        return $this.rightmaxCPSValue;
    }
}

