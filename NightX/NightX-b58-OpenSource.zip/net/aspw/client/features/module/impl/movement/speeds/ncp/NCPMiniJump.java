/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPMiniJump
extends SpeedMode {
    public NCPMiniJump() {
        super("NCPMiniJump");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        if (NCPMiniJump.mc.thePlayer.onGround && !NCPMiniJump.mc.thePlayer.movementInput.jump) {
            NCPMiniJump.mc.thePlayer.motionY += 0.1;
            double multiplier = 1.8;
            NCPMiniJump.mc.thePlayer.motionX *= 1.8;
            NCPMiniJump.mc.thePlayer.motionZ *= 1.8;
            double currentSpeed = Math.sqrt(Math.pow(NCPMiniJump.mc.thePlayer.motionX, 2.0) + Math.pow(NCPMiniJump.mc.thePlayer.motionZ, 2.0));
            double maxSpeed = 0.66;
            if (currentSpeed > 0.66) {
                NCPMiniJump.mc.thePlayer.motionX = NCPMiniJump.mc.thePlayer.motionX / currentSpeed * 0.66;
                NCPMiniJump.mc.thePlayer.motionZ = NCPMiniJump.mc.thePlayer.motionZ / currentSpeed * 0.66;
            }
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPMiniJump.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPMiniJump.mc.thePlayer.motionX = 0.0;
            NCPMiniJump.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

