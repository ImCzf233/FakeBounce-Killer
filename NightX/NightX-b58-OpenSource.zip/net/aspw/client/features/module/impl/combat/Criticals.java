/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 */
package net.aspw.client.features.module.impl.combat;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.combat.TPAura;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;

@ModuleInfo(name="Criticals", description="", category=ModuleCategory.COMBAT)
public final class Criticals
extends Module {
    private final ListValue modeValue;
    private final IntegerValue delayValue;
    private final FloatValue jumpHeightValue;
    private final FloatValue downYValue;
    private final IntegerValue hurtTimeValue;
    private final BoolValue onlyAuraValue;
    private final MSTimer msTimer;
    private boolean readyCrits;
    private boolean canCrits;
    private int counter;
    private int attacked;

    public Criticals() {
        String[] stringArray = new String[]{"NewPacket", "Packet", "Packet2", "NewNCP", "NCPPacket", "NoGround", "Redesky", "AACv4", "Hop", "TPHop", "Jump", "Edit", "MiniPhase", "NanoPacket", "Non-Calculable", "Invalid", "VerusSmart"};
        this.modeValue = new ListValue("Mode", stringArray, "NCPPacket");
        this.delayValue = new IntegerValue("Delay", 0, 0, 500, "ms");
        this.jumpHeightValue = new FloatValue("JumpHeight", 0.42f, 0.1f, 0.42f);
        this.downYValue = new FloatValue("DownY", 0.0f, 0.0f, 0.1f);
        this.hurtTimeValue = new IntegerValue("HurtTime", 10, 0, 10);
        this.onlyAuraValue = new BoolValue("OnlyAura", false);
        this.msTimer = new MSTimer();
        this.canCrits = true;
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    public final IntegerValue getDelayValue() {
        return this.delayValue;
    }

    public final MSTimer getMsTimer() {
        return this.msTimer;
    }

    @Override
    public void onEnable() {
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"NoGround", (boolean)true)) {
            MinecraftInstance.mc.thePlayer.jump();
        }
        this.canCrits = true;
        this.counter = 0;
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        block55: {
            block57: {
                block56: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    if (((Boolean)this.onlyAuraValue.get()).booleanValue()) {
                        KillAura killAura = Client.INSTANCE.getModuleManager().get(KillAura.class);
                        Intrinsics.checkNotNull((Object)killAura);
                        if (!killAura.getState()) {
                            TPAura tPAura = Client.INSTANCE.getModuleManager().get(TPAura.class);
                            Intrinsics.checkNotNull((Object)tPAura);
                            if (!tPAura.getState()) {
                                return;
                            }
                        }
                    }
                    if (!(event.getTargetEntity() instanceof EntityLivingBase)) break block55;
                    Entity entity = event.getTargetEntity();
                    if (!MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.thePlayer.isOnLadder() || MinecraftInstance.mc.thePlayer.isInWeb || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.ridingEntity != null || ((EntityLivingBase)entity).hurtTime > ((Number)this.hurtTimeValue.get()).intValue()) break block56;
                    Flight flight = Client.INSTANCE.getModuleManager().get(Flight.class);
                    Intrinsics.checkNotNull((Object)flight);
                    if (!flight.getState() && this.msTimer.hasTimePassed(((Number)this.delayValue.get()).intValue())) break block57;
                }
                return;
            }
            double x = MinecraftInstance.mc.thePlayer.posX;
            double y = MinecraftInstance.mc.thePlayer.posY;
            double z = MinecraftInstance.mc.thePlayer.posZ;
            String string = (String)this.modeValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string2) {
                case "newpacket": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.05250000001304, z, true));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.00150000001304, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01400000001304, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.00150000001304, z, false));
                    break;
                }
                case "newncp": {
                    int n = this.attacked;
                    this.attacked = n + 1;
                    if (this.attacked < 5) break;
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.058293536E-5, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 9.16580235E-6, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.0371854E-7, z, false));
                    this.attacked = 0;
                    break;
                }
                case "packet": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.0625, z, true));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.1E-5, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                    break;
                }
                case "packet2": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.0625, MinecraftInstance.mc.thePlayer.posZ, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.09858, MinecraftInstance.mc.thePlayer.posZ, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.04114514, MinecraftInstance.mc.thePlayer.posZ, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.025, MinecraftInstance.mc.thePlayer.posZ, false));
                    break;
                }
                case "ncppacket": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.11, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.1100013579, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.3579E-6, z, false));
                    break;
                }
                case "aacv4": {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ *= 0.0;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX *= 0.0;
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 3.0E-14, MinecraftInstance.mc.thePlayer.posZ, true));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 8.0E-15, MinecraftInstance.mc.thePlayer.posZ, true));
                    break;
                }
                case "hop": {
                    MinecraftInstance.mc.thePlayer.motionY = 0.1;
                    MinecraftInstance.mc.thePlayer.fallDistance = 0.1f;
                    MinecraftInstance.mc.thePlayer.onGround = false;
                    break;
                }
                case "tphop": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.02, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01, z, false));
                    MinecraftInstance.mc.thePlayer.setPosition(x, y + 0.01, z);
                    break;
                }
                case "jump": {
                    if (MinecraftInstance.mc.thePlayer.onGround) {
                        MinecraftInstance.mc.thePlayer.motionY = ((Number)this.jumpHeightValue.get()).floatValue();
                        break;
                    }
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= ((Number)this.downYValue.get()).doubleValue();
                    break;
                }
                case "miniphase": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 0.0125, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01275, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 2.5E-4, z, true));
                    break;
                }
                case "nanopacket": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.00973333333333, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.001, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 0.01200000000007, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 5.0E-4, z, false));
                    break;
                }
                case "non-calculable": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.0E-5, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.0E-7, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 1.0E-6, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 1.0E-4, z, false));
                    break;
                }
                case "invalid": {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.0E27, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y - 1.0E68, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.0E41, z, false));
                    break;
                }
                case "verussmart": {
                    int n = this.counter;
                    this.counter = n + 1;
                    if (this.counter == 1) {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.001, z, true));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                    }
                    if (this.counter < 5) break;
                    this.counter = 0;
                }
            }
            this.readyCrits = true;
            this.msTimer.reset();
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.onlyAuraValue.get()).booleanValue()) {
            KillAura killAura = Client.INSTANCE.getModuleManager().get(KillAura.class);
            Intrinsics.checkNotNull((Object)killAura);
            if (!killAura.getState()) {
                return;
            }
        }
        Packet<?> packet = event.getPacket();
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "redesky": {
                if (packet instanceof C03PacketPlayer) {
                    C03PacketPlayer packetPlayer = (C03PacketPlayer)packet;
                    if (MinecraftInstance.mc.thePlayer.onGround && this.canCrits) {
                        packetPlayer.y += 1.0E-6;
                        packetPlayer.onGround = false;
                    }
                    if (MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, (MinecraftInstance.mc.thePlayer.motionY - 0.08) * 0.98, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                        packetPlayer.onGround = true;
                    }
                }
                if (!(packet instanceof C07PacketPlayerDigging)) break;
                if (((C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                    this.canCrits = false;
                    break;
                }
                if (((C07PacketPlayerDigging)packet).getStatus() != C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK && ((C07PacketPlayerDigging)packet).getStatus() != C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK) break;
                this.canCrits = true;
                break;
            }
            case "noground": {
                if (!(packet instanceof C03PacketPlayer)) break;
                ((C03PacketPlayer)packet).onGround = false;
                break;
            }
            case "edit": {
                if (!this.readyCrits) break;
                if (packet instanceof C03PacketPlayer) {
                    ((C03PacketPlayer)packet).onGround = false;
                }
                this.readyCrits = false;
            }
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

