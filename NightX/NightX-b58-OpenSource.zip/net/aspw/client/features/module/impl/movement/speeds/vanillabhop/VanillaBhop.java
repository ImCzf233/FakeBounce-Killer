/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.vanillabhop;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class VanillaBhop
extends SpeedMode {
    public VanillaBhop() {
        super("VanillaBhop");
    }

    @Override
    public void onMotion(MotionEvent eventMotion) {
        if (MovementUtils.isMoving()) {
            MovementUtils.strafe(((Float)Objects.requireNonNull(Client.moduleManager.getModule(Speed.class)).vanillaBhopSpeed.getValue()).floatValue());
        } else {
            VanillaBhop.mc.thePlayer.motionX = 0.0;
            VanillaBhop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving() && VanillaBhop.mc.thePlayer.onGround) {
            VanillaBhop.mc.thePlayer.jump();
        }
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!VanillaBhop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            VanillaBhop.mc.thePlayer.motionX = 0.0;
            VanillaBhop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

