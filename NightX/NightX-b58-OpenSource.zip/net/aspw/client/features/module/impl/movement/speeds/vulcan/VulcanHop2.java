/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.movement.speeds.vulcan;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public final class VulcanHop2
extends SpeedMode {
    private int jumpTicks;

    public VulcanHop2() {
        super("VulcanHop2");
    }

    @Override
    public void onUpdate() {
        ++this.jumpTicks;
        if (MovementUtils.isMoving()) {
            if (SpeedMode.mc.thePlayer.onGround) {
                SpeedMode.mc.thePlayer.jump();
                this.jumpTicks = 0;
            } else {
                if (this.jumpTicks > 3) {
                    SpeedMode.mc.thePlayer.motionY = (SpeedMode.mc.thePlayer.motionY - 0.08) * 0.98;
                }
                MovementUtils.strafe(MovementUtils.getSpeed() * (float)(1.01 - Math.random() / (double)500));
            }
        } else {
            SpeedMode.mc.timer.timerSpeed = 1.0f;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
        Scaffold scaffoldModule = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        if (!SpeedMode.mc.thePlayer.isSneaking()) {
            Scaffold scaffold = scaffoldModule;
            Intrinsics.checkNotNull((Object)scaffold);
            if (!scaffold.getState()) {
                MovementUtils.strafe(0.2f);
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

