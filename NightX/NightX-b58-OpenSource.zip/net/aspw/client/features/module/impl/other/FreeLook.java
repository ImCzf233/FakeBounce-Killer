/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  net.minecraft.client.Minecraft
 *  org.lwjgl.opengl.Display
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.JvmField;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

@ModuleInfo(name="FreeLook", spacedName="Free Look", description="", category=ModuleCategory.OTHER, array=false)
public final class FreeLook
extends Module {
    public static final Companion Companion = new Companion(null);
    private static final Minecraft mc = Minecraft.getMinecraft();
    @JvmField
    public static boolean perspectiveToggled;
    @JvmField
    public static float cameraYaw;
    @JvmField
    public static float cameraPitch;
    private static int previousPerspective;

    @Override
    public void onEnable() {
        perspectiveToggled = !perspectiveToggled;
        cameraYaw = FreeLook.mc.thePlayer.rotationYaw;
        cameraPitch = FreeLook.mc.thePlayer.rotationPitch;
        if (perspectiveToggled) {
            previousPerspective = FreeLook.mc.gameSettings.thirdPersonView;
        } else {
            FreeLook.mc.gameSettings.thirdPersonView = previousPerspective;
        }
    }

    @Override
    public void onDisable() {
        Companion.resetPerspective();
    }

    @JvmStatic
    public static final boolean overrideMouse() {
        return Companion.overrideMouse();
    }

    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final boolean overrideMouse() {
            if (mc.inGameHasFocus && Display.isActive()) {
                if (!perspectiveToggled) {
                    return true;
                }
                mc.mouseHelper.mouseXYChange();
                float f1 = mc.gameSettings.mouseSensitivity * 0.6f + 0.2f;
                float f2 = f1 * f1 * f1 * 8.0f;
                float f3 = (float)mc.mouseHelper.deltaX * f2;
                float f4 = (float)mc.mouseHelper.deltaY * f2;
                cameraYaw += f3 * 0.15f;
                cameraPitch -= f4 * 0.15f;
                if (cameraPitch > 90.0f) {
                    cameraPitch = 90.0f;
                }
                if (cameraPitch < -90.0f) {
                    cameraPitch = -90.0f;
                }
            }
            return false;
        }

        public final void resetPerspective() {
            perspectiveToggled = false;
            mc.gameSettings.thirdPersonView = previousPerspective;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

