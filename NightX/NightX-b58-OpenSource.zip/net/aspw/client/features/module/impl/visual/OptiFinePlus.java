/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityArmorStand
 *  net.minecraft.entity.item.EntityBoat
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.entity.item.EntityMinecart
 *  net.minecraft.entity.item.EntityTNTPrimed
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.extensions.PlayerExtensionKt;
import net.aspw.client.value.BoolValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityTNTPrimed;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="OptiFine+", description="", category=ModuleCategory.VISUAL)
public final class OptiFinePlus
extends Module {
    @JvmField
    public BoolValue entityOptimization = new BoolValue("Entity-Optimization", true);
    @JvmField
    public BoolValue fixMemoryLeaks = new BoolValue("FixMemoryLeaks", true);
    @JvmField
    public BoolValue noHitDelay = new BoolValue("NoHitDelay", true);
    @JvmField
    public BoolValue mouseDelayFix = new BoolValue("MouseDelayFix", true);

    public OptiFinePlus() {
        this.setState(true);
    }

    @EventTarget
    public final void onMotion(@Nullable MotionEvent event) {
        for (Entity en : MinecraftInstance.mc.theWorld.loadedEntityList) {
            Entity entity;
            Intrinsics.checkNotNull((Object)en);
            if (this.shouldStopRender(entity)) {
                entity.renderDistanceWeight = 0.0;
                continue;
            }
            entity.renderDistanceWeight = 1.0;
        }
    }

    @Override
    public void onDisable() {
        for (Entity en : MinecraftInstance.mc.theWorld.loadedEntityList) {
            Entity entity;
            Intrinsics.checkNotNull((Object)en);
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            if (entity.equals(entityPlayerSP) || !(entity.renderDistanceWeight <= 0.0)) continue;
            entity.renderDistanceWeight = 1.0;
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean shouldStopRender(Entity entity) {
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        if ((Boolean)this.entityOptimization.get() == false) return false;
        if (!(EntityUtils.isMob(entity) || EntityUtils.isAnimal(entity) || entity instanceof EntityBoat || entity instanceof EntityMinecart || entity instanceof EntityItemFrame || entity instanceof EntityTNTPrimed)) {
            if (!(entity instanceof EntityArmorStand)) return false;
        }
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entity.equals(entityPlayerSP)) return false;
        EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.thePlayer;
        Intrinsics.checkNotNull((Object)entityPlayerSP2);
        if (!((float)PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP2, entity) > 40.0f)) return false;
        return true;
    }
}

