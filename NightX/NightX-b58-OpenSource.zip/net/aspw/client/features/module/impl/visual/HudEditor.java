/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 */
package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.visual.hud.designer.GuiHudDesigner;
import net.minecraft.client.gui.GuiScreen;

@ModuleInfo(name="HudEditor", description="", category=ModuleCategory.VISUAL, onlyEnable=true, forceNoSound=true, array=false)
public final class HudEditor
extends Module {
    @Override
    public void onEnable() {
        MinecraftInstance.mc.displayGuiScreen((GuiScreen)new GuiHudDesigner());
    }
}

