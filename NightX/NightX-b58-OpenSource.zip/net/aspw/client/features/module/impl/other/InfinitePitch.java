/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.other;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;

@ModuleInfo(name="InfinitePitch", spacedName="Infinite Pitch", description="", category=ModuleCategory.OTHER)
public final class InfinitePitch
extends Module {
}

