/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.value.FloatValue;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

@ModuleInfo(name="FastMine", spacedName="Fast Mine", description="", category=ModuleCategory.OTHER)
public final class FastMine
extends Module {
    private final FloatValue speed = new FloatValue("Speed", 1.5f, 1.0f, 3.0f);
    private EnumFacing facing;
    private BlockPos pos;
    private boolean boost;
    private float damage;

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onMotion(MotionEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        if (e.getEventState() == EventState.PRE) {
            MinecraftInstance.mc.playerController.blockHitDelay = 0;
            if (this.pos != null && this.boost) {
                float f;
                float f2;
                IBlockState iBlockState = MinecraftInstance.mc.theWorld.getBlockState(this.pos);
                if (iBlockState == null) {
                    return;
                }
                IBlockState blockState = iBlockState;
                float f3 = this.damage;
                FastMine fastMine = this;
                try {
                    FastMine fastMine2 = fastMine;
                    f2 = f3;
                    f = blockState.getBlock().getPlayerRelativeBlockHardness((EntityPlayer)MinecraftInstance.mc.thePlayer, (World)MinecraftInstance.mc.theWorld, this.pos) * ((Number)this.speed.get()).floatValue();
                }
                catch (Exception exception) {
                    void ex;
                    FastMine fastMine3 = fastMine;
                    float f4 = f3;
                    ex.printStackTrace();
                    return;
                }
                fastMine2.damage = f2 + f;
                if (this.damage >= 1.0f) {
                    try {
                        MinecraftInstance.mc.theWorld.setBlockState(this.pos, Blocks.air.getDefaultState(), 11);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                        return;
                    }
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.pos, this.facing)));
                    this.damage = 0.0f;
                    this.boost = false;
                }
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        if (e.getPacket() instanceof C07PacketPlayerDigging) {
            Packet<?> packet = e.getPacket();
            if (((C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                this.boost = true;
                this.pos = ((C07PacketPlayerDigging)packet).getPosition();
                this.facing = ((C07PacketPlayerDigging)packet).getFacing();
                this.damage = 0.0f;
            } else if (((C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK | ((C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                this.boost = false;
                this.pos = null;
                this.facing = null;
            }
        }
    }
}

