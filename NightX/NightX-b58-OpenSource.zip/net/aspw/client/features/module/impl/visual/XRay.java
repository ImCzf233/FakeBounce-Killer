/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 */
package net.aspw.client.features.module.impl.visual;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

@ModuleInfo(name="XRay", description="", category=ModuleCategory.VISUAL, keyBind=65)
public final class XRay
extends Module {
    private final List<Block> xrayBlocks;

    public XRay() {
        Object[] objectArray = new Block[34];
        Block block = Blocks.coal_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"coal_ore");
        objectArray[0] = block;
        block = Blocks.iron_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"iron_ore");
        objectArray[1] = block;
        block = Blocks.gold_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"gold_ore");
        objectArray[2] = block;
        block = Blocks.redstone_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"redstone_ore");
        objectArray[3] = block;
        block = Blocks.lapis_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lapis_ore");
        objectArray[4] = block;
        block = Blocks.diamond_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"diamond_ore");
        objectArray[5] = block;
        block = Blocks.emerald_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"emerald_ore");
        objectArray[6] = block;
        block = Blocks.quartz_ore;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"quartz_ore");
        objectArray[7] = block;
        block = Blocks.clay;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"clay");
        objectArray[8] = block;
        block = Blocks.glowstone;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"glowstone");
        objectArray[9] = block;
        block = Blocks.crafting_table;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"crafting_table");
        objectArray[10] = block;
        block = Blocks.torch;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"torch");
        objectArray[11] = block;
        block = Blocks.ladder;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"ladder");
        objectArray[12] = block;
        block = Blocks.tnt;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"tnt");
        objectArray[13] = block;
        block = Blocks.coal_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"coal_block");
        objectArray[14] = block;
        block = Blocks.iron_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"iron_block");
        objectArray[15] = block;
        block = Blocks.gold_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"gold_block");
        objectArray[16] = block;
        block = Blocks.diamond_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"diamond_block");
        objectArray[17] = block;
        block = Blocks.emerald_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"emerald_block");
        objectArray[18] = block;
        block = Blocks.redstone_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"redstone_block");
        objectArray[19] = block;
        block = Blocks.lapis_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lapis_block");
        objectArray[20] = block;
        block = Blocks.fire;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"fire");
        objectArray[21] = block;
        block = Blocks.mossy_cobblestone;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"mossy_cobblestone");
        objectArray[22] = block;
        block = Blocks.mob_spawner;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"mob_spawner");
        objectArray[23] = block;
        block = Blocks.end_portal_frame;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"end_portal_frame");
        objectArray[24] = block;
        block = Blocks.enchanting_table;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"enchanting_table");
        objectArray[25] = block;
        block = Blocks.bookshelf;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"bookshelf");
        objectArray[26] = block;
        block = Blocks.command_block;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"command_block");
        objectArray[27] = block;
        block = Blocks.lava;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lava");
        objectArray[28] = block;
        block = Blocks.flowing_lava;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"flowing_lava");
        objectArray[29] = block;
        block = Blocks.water;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"water");
        objectArray[30] = block;
        block = Blocks.flowing_water;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"flowing_water");
        objectArray[31] = block;
        block = Blocks.furnace;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"furnace");
        objectArray[32] = block;
        block = Blocks.lit_furnace;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lit_furnace");
        objectArray[33] = block;
        this.xrayBlocks = CollectionsKt.mutableListOf((Object[])objectArray);
    }

    public final List<Block> getXrayBlocks() {
        return this.xrayBlocks;
    }

    @Override
    public void onToggle(boolean state) {
        MinecraftInstance.mc.renderGlobal.loadRenderers();
    }
}

