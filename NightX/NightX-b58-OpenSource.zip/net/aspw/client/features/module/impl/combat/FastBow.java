/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemBow
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.IntegerValue;
import net.minecraft.item.ItemBow;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="FastBow", spacedName="Fast Bow", description="", category=ModuleCategory.COMBAT)
public final class FastBow
extends Module {
    private final IntegerValue packetsValue = new IntegerValue("Packets", 20, 3, 20);
    private final IntegerValue delay = new IntegerValue("Delay", 0, 0, 500, "ms");
    private final MSTimer timer = new MSTimer();

    public final MSTimer getTimer() {
        return this.timer;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.thePlayer.isUsingItem()) {
            return;
        }
        if (MinecraftInstance.mc.thePlayer.inventory.getCurrentItem() != null && MinecraftInstance.mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemBow) {
            float f;
            float yaw;
            float f2;
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C08PacketPlayerBlockPlacement(BlockPos.ORIGIN, 255, MinecraftInstance.mc.thePlayer.getCurrentEquippedItem(), 0.0f, 0.0f, 0.0f));
            if (RotationUtils.targetRotation != null) {
                Rotation rotation = RotationUtils.targetRotation;
                Intrinsics.checkNotNull((Object)rotation);
                f2 = rotation.getYaw();
            } else {
                f2 = yaw = MinecraftInstance.mc.thePlayer.rotationYaw;
            }
            if (RotationUtils.targetRotation != null) {
                Rotation rotation = RotationUtils.targetRotation;
                Intrinsics.checkNotNull((Object)rotation);
                f = rotation.getPitch();
            } else {
                f = MinecraftInstance.mc.thePlayer.rotationPitch;
            }
            float pitch = f;
            int n = 0;
            int n2 = ((Number)this.packetsValue.get()).intValue();
            while (n < n2) {
                int i = n++;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C05PacketPlayerLook(yaw, pitch, true));
            }
            if (this.timer.hasTimePassed(((Number)this.delay.get()).intValue())) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                this.timer.reset();
            }
            MinecraftInstance.mc.thePlayer.itemInUseCount = MinecraftInstance.mc.thePlayer.inventory.getCurrentItem().getMaxItemUseDuration() - 1;
        }
    }
}

