/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.util.MathHelper;

public class AACBHop
extends SpeedMode {
    public AACBHop() {
        super("AACBHop");
    }

    @Override
    public void onMotion() {
        if (AACBHop.mc.thePlayer.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            AACBHop.mc.timer.timerSpeed = 1.08f;
            if (AACBHop.mc.thePlayer.onGround) {
                AACBHop.mc.thePlayer.motionY = 0.399;
                float f = AACBHop.mc.thePlayer.rotationYaw * ((float)Math.PI / 180);
                AACBHop.mc.thePlayer.motionX -= (double)(MathHelper.sin((float)f) * 0.2f);
                AACBHop.mc.thePlayer.motionZ += (double)(MathHelper.cos((float)f) * 0.2f);
                AACBHop.mc.timer.timerSpeed = 2.0f;
            } else {
                AACBHop.mc.thePlayer.motionY *= 0.97;
                AACBHop.mc.thePlayer.motionX *= 1.008;
                AACBHop.mc.thePlayer.motionZ *= 1.008;
            }
        } else {
            AACBHop.mc.timer.timerSpeed = 1.0f;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        AACBHop.mc.timer.timerSpeed = 1.0f;
    }
}

