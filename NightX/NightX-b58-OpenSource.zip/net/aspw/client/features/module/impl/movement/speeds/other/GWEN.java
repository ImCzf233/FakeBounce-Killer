/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventState;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.timer.MSTimer;

public final class GWEN
extends SpeedMode {
    private final MSTimer timer = new MSTimer();
    private boolean stage;

    public GWEN() {
        super("GWEN");
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() == EventState.PRE && MovementUtils.isMoving()) {
            if (this.stage) {
                SpeedMode.mc.timer.timerSpeed = 1.5f;
                if (this.timer.hasTimePassed(700L)) {
                    this.timer.reset();
                    this.stage = !this.stage;
                }
            } else {
                SpeedMode.mc.timer.timerSpeed = 0.8f;
                if (this.timer.hasTimePassed(400L)) {
                    this.timer.reset();
                    this.stage = !this.stage;
                }
            }
        }
    }
}

