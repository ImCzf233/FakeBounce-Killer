/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.targets;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;

@ModuleInfo(name="Animals", description="", category=ModuleCategory.TARGETS, array=false)
public final class Animals
extends Module {
    public Animals() {
        this.setState(true);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        EntityUtils.targetAnimals = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        EntityUtils.targetAnimals = false;
    }
}

