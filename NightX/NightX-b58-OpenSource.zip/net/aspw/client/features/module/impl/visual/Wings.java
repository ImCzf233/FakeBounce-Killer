/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.visual;

import java.util.Objects;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RenderWings;
import net.aspw.client.value.BoolValue;

@ModuleInfo(name="Wings", description="", category=ModuleCategory.VISUAL, array=false)
public final class Wings
extends Module {
    private final BoolValue onlyThirdPerson = new BoolValue("Only-ThirdPerson", true);

    @EventTarget
    public final void onRenderPlayer(Render3DEvent event) {
        block6: {
            block5: {
                Boolean bl;
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (((Boolean)this.onlyThirdPerson.get()).booleanValue() && MinecraftInstance.mc.gameSettings.thirdPersonView == 0) break block5;
                SilentView silentView = Objects.requireNonNull(Client.INSTANCE.getModuleManager().getModule(SilentView.class));
                Boolean bl2 = silentView == null ? null : Boolean.valueOf(silentView.getState());
                Intrinsics.checkNotNull((Object)bl2);
                if (!bl2.booleanValue()) break block6;
                SilentView silentView2 = Objects.requireNonNull(Client.INSTANCE.getModuleManager().getModule(SilentView.class));
                if (silentView2 == null) {
                    bl = null;
                } else {
                    BoolValue boolValue = silentView2.getSilentValue();
                    bl = boolValue == null ? null : (Boolean)boolValue.get();
                }
                Intrinsics.checkNotNull(bl);
                if (!bl.booleanValue()) break block6;
                silentView = Objects.requireNonNull(Client.INSTANCE.getModuleManager().getModule(SilentView.class));
                Boolean bl3 = silentView == null ? null : Boolean.valueOf(silentView.shouldRotate());
                Intrinsics.checkNotNull((Object)bl3);
                if (!bl3.booleanValue()) break block6;
            }
            return;
        }
        RenderWings renderWings = new RenderWings();
        renderWings.renderWings(event.getPartialTicks());
    }
}

