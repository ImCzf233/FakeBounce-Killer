/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.targets;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;

@ModuleInfo(name="Players", description="", category=ModuleCategory.TARGETS, array=false)
public final class Players
extends Module {
    public Players() {
        this.setState(true);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        EntityUtils.targetPlayer = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        EntityUtils.targetPlayer = false;
    }
}

