/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.module.impl.combat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;

@ModuleInfo(name="BowAura", spacedName="Bow Aura", description="", category=ModuleCategory.COMBAT)
public final class BowAura
extends Module {
    private final BoolValue silentValue = new BoolValue("Silent", true);
    private final BoolValue throughWallsValue = new BoolValue("ThroughWalls", false);
    private final ListValue priorityValue;
    private Entity target;

    public BowAura() {
        String[] stringArray = new String[]{"Health", "Distance", "Direction"};
        this.priorityValue = new ListValue("Priority", stringArray, "Direction");
    }

    public final BoolValue getSilentValue() {
        return this.silentValue;
    }

    @Override
    public void onDisable() {
        this.target = null;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.target = null;
        ItemStack itemStack = MinecraftInstance.mc.thePlayer.getItemInUse();
        if ((itemStack == null ? null : itemStack.getItem()) instanceof ItemBow) {
            Entity entity;
            Entity entity2 = this.getTarget((Boolean)this.throughWallsValue.get(), (String)this.priorityValue.get());
            if (entity2 == null) {
                return;
            }
            Entity entity3 = this.target = (entity = entity2);
            Intrinsics.checkNotNull((Object)entity3);
            RotationUtils.faceBow(entity3, (Boolean)this.silentValue.get(), false, 5.0f);
        }
    }

    private final Entity getTarget(boolean throughWalls, String priorityMode) {
        Entity entity;
        Locale $this$filterTo$iv$iv;
        Object object = MinecraftInstance.mc.theWorld.loadedEntityList;
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"mc.theWorld.loadedEntityList");
        Iterable $this$filter$iv = (Iterable)object;
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Object destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        Iterator iterator = $this$filterTo$iv$iv.iterator();
        while (iterator.hasNext()) {
            Object element$iv$iv = iterator.next();
            Entity it = (Entity)element$iv$iv;
            boolean bl = false;
            boolean bl2 = it instanceof EntityLivingBase && EntityUtils.isSelected(it, true) && (throughWalls || MinecraftInstance.mc.thePlayer.canEntityBeSeen(it));
            if (!bl2) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        List targets = (List)destination$iv$iv;
        $this$filterTo$iv$iv = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)$this$filterTo$iv$iv, (String)"getDefault()");
        destination$iv$iv = priorityMode.toUpperCase($this$filterTo$iv$iv);
        Intrinsics.checkNotNullExpressionValue((Object)destination$iv$iv, (String)"this as java.lang.String).toUpperCase(locale)");
        switch (destination$iv$iv) {
            case "DISTANCE": {
                Entity it;
                Object v1;
                Iterable $this$minByOrNull$iv = targets;
                boolean $i$f$minByOrNull = false;
                Iterator iterator$iv = $this$minByOrNull$iv.iterator();
                if (!iterator$iv.hasNext()) {
                    v1 = null;
                } else {
                    Object minElem$iv = iterator$iv.next();
                    if (!iterator$iv.hasNext()) {
                        v1 = minElem$iv;
                    } else {
                        it = (Entity)minElem$iv;
                        boolean bl = false;
                        float minValue$iv = MinecraftInstance.mc.thePlayer.getDistanceToEntity(it);
                        do {
                            Object e$iv = iterator$iv.next();
                            Entity it2 = (Entity)e$iv;
                            $i$a$-minByOrNull-BowAura$getTarget$1 = false;
                            float v$iv = MinecraftInstance.mc.thePlayer.getDistanceToEntity(it2);
                            if (Float.compare(minValue$iv, v$iv) <= 0) continue;
                            minElem$iv = e$iv;
                            minValue$iv = v$iv;
                        } while (iterator$iv.hasNext());
                        v1 = minElem$iv;
                    }
                }
                entity = v1;
                break;
            }
            case "DIRECTION": {
                Object v3;
                Entity it;
                Iterable $this$minByOrNull$iv = targets;
                boolean $i$f$minByOrNull = false;
                Iterator iterator$iv = $this$minByOrNull$iv.iterator();
                if (!iterator$iv.hasNext()) {
                    v3 = null;
                } else {
                    Object minElem$iv = iterator$iv.next();
                    if (!iterator$iv.hasNext()) {
                        v3 = minElem$iv;
                    } else {
                        it = (Entity)minElem$iv;
                        boolean bl = false;
                        double minValue$iv = RotationUtils.getRotationDifference(it);
                        do {
                            Object e$iv = iterator$iv.next();
                            Entity it3 = (Entity)e$iv;
                            $i$a$-minByOrNull-BowAura$getTarget$2 = false;
                            double v$iv = RotationUtils.getRotationDifference(it3);
                            if (Double.compare(minValue$iv, v$iv) <= 0) continue;
                            minElem$iv = e$iv;
                            minValue$iv = v$iv;
                        } while (iterator$iv.hasNext());
                        v3 = minElem$iv;
                    }
                }
                entity = v3;
                break;
            }
            case "HEALTH": {
                Object v4;
                Entity it;
                Iterable $this$minByOrNull$iv = targets;
                boolean $i$f$minByOrNull = false;
                Iterator iterator$iv = $this$minByOrNull$iv.iterator();
                if (!iterator$iv.hasNext()) {
                    v4 = null;
                } else {
                    Object minElem$iv = iterator$iv.next();
                    if (!iterator$iv.hasNext()) {
                        v4 = minElem$iv;
                    } else {
                        it = (Entity)minElem$iv;
                        boolean bl = false;
                        Entity entity2 = it;
                        if (entity2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.EntityLivingBase");
                        }
                        float minValue$iv = ((EntityLivingBase)entity2).getHealth();
                        do {
                            Object e$iv = iterator$iv.next();
                            Entity it4 = (Entity)e$iv;
                            $i$a$-minByOrNull-BowAura$getTarget$3 = false;
                            Entity entity3 = it4;
                            if (entity3 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.EntityLivingBase");
                            }
                            float v$iv = ((EntityLivingBase)entity3).getHealth();
                            if (Float.compare(minValue$iv, v$iv) <= 0) continue;
                            minElem$iv = e$iv;
                            minValue$iv = v$iv;
                        } while (iterator$iv.hasNext());
                        v4 = minElem$iv;
                    }
                }
                entity = v4;
                break;
            }
            default: {
                entity = null;
            }
        }
        return entity;
    }

    public final boolean hasTarget() {
        return this.target != null && MinecraftInstance.mc.thePlayer.canEntityBeSeen(this.target);
    }
}

