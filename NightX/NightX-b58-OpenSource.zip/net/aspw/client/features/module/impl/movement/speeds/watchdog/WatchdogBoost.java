/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.watchdog;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class WatchdogBoost
extends SpeedMode {
    public WatchdogBoost() {
        super("WatchdogBoost");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        WatchdogBoost.mc.timer.timerSpeed = 1.0f;
        if (MovementUtils.isMoving() && !WatchdogBoost.mc.thePlayer.isInWater() && !WatchdogBoost.mc.thePlayer.isInLava() && !WatchdogBoost.mc.gameSettings.keyBindJump.isKeyDown()) {
            double moveSpeed = Math.max(MovementUtils.getBaseMoveSpeed() * (double)((Float)speed2.baseStrengthValue.get()).floatValue(), (double)MovementUtils.getSpeed());
            if (WatchdogBoost.mc.thePlayer.onGround) {
                if (((Boolean)speed2.sendJumpValue.get()).booleanValue()) {
                    WatchdogBoost.mc.thePlayer.jump();
                }
                if (((Boolean)speed2.recalcValue.get()).booleanValue()) {
                    moveSpeed = Math.max(MovementUtils.getBaseMoveSpeed() * (double)((Float)speed2.baseStrengthValue.get()).floatValue(), (double)MovementUtils.getSpeed());
                }
                WatchdogBoost.mc.thePlayer.motionY = MovementUtils.getJumpBoostModifier(WatchdogBoost.mc.thePlayer.isCollidedHorizontally ? 0.41999998688698 : (double)((Float)speed2.jumpYValue.get()).floatValue());
                event.setY(WatchdogBoost.mc.thePlayer.motionY);
                moveSpeed *= (double)((Float)speed2.moveSpeedValue.get()).floatValue();
            } else if (((Float)speed2.glideStrengthValue.get()).floatValue() > 0.0f && event.getY() < 0.0) {
                event.setY(WatchdogBoost.mc.thePlayer.motionY += (double)((Float)speed2.glideStrengthValue.get()).floatValue());
            }
            WatchdogBoost.mc.timer.timerSpeed = Math.max(((Float)speed2.baseTimerValue.get()).floatValue() + Math.abs((float)WatchdogBoost.mc.thePlayer.motionY) * ((Float)speed2.baseMTimerValue.get()).floatValue(), 1.0f);
        }
    }
}

