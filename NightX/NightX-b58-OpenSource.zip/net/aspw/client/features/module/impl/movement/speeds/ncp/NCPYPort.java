/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.util.MathHelper;

public class NCPYPort
extends SpeedMode {
    private int jumps;

    public NCPYPort() {
        super("NCPYPort");
    }

    @Override
    public void onMotion() {
        if (NCPYPort.mc.thePlayer.isOnLadder() || NCPYPort.mc.thePlayer.isInWater() || NCPYPort.mc.thePlayer.isInLava() || NCPYPort.mc.thePlayer.isInWeb || !MovementUtils.isMoving() || NCPYPort.mc.thePlayer.isInWater()) {
            return;
        }
        if (this.jumps >= 4 && NCPYPort.mc.thePlayer.onGround) {
            this.jumps = 0;
        }
        if (NCPYPort.mc.thePlayer.onGround) {
            NCPYPort.mc.thePlayer.motionY = this.jumps <= 1 ? (double)0.42f : (double)0.4f;
            float f = NCPYPort.mc.thePlayer.rotationYaw * ((float)Math.PI / 180);
            NCPYPort.mc.thePlayer.motionX -= (double)(MathHelper.sin((float)f) * 0.2f);
            NCPYPort.mc.thePlayer.motionZ += (double)(MathHelper.cos((float)f) * 0.2f);
            ++this.jumps;
        } else if (this.jumps <= 1) {
            NCPYPort.mc.thePlayer.motionY = -5.0;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPYPort.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPYPort.mc.thePlayer.motionX = 0.0;
            NCPYPort.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

