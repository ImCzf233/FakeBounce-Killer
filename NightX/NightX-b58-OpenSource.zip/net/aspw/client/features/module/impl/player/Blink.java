/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0FPacketConfirmTransaction
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.player;

import java.awt.Color;
import java.util.LinkedList;
import java.util.concurrent.LinkedBlockingQueue;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.Trails;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="Blink", description="", category=ModuleCategory.PLAYER)
public final class Blink
extends Module {
    private final BoolValue pulseValue = new BoolValue("Pulse", true);
    private final LinkedBlockingQueue<Packet<?>> packets = new LinkedBlockingQueue();
    private final LinkedList<double[]> positions = new LinkedList();
    private final BoolValue c0FValue = new BoolValue("C0FCancel", false);
    private final IntegerValue pulseDelayValue = new IntegerValue("PulseDelay", 400, 10, 5000, "ms");
    private final MSTimer pulseTimer = new MSTimer();
    private EntityOtherPlayerMP fakePlayer;
    private boolean disableLogger;

    public final BoolValue getPulseValue() {
        return this.pulseValue;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        if (!((Boolean)this.pulseValue.get()).booleanValue()) {
            EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer = new EntityOtherPlayerMP((World)MinecraftInstance.mc.theWorld, MinecraftInstance.mc.thePlayer.getGameProfile());
            Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
            entityOtherPlayerMP.func_71049_a((EntityPlayer)MinecraftInstance.mc.thePlayer, true);
            EntityOtherPlayerMP entityOtherPlayerMP2 = this.fakePlayer;
            Intrinsics.checkNotNull((Object)entityOtherPlayerMP2);
            entityOtherPlayerMP2.copyLocationAndAnglesFrom((Entity)MinecraftInstance.mc.thePlayer);
            Intrinsics.checkNotNull((Object)this.fakePlayer);
            this.fakePlayer.field_70759_as = MinecraftInstance.mc.thePlayer.rotationYawHead;
            MinecraftInstance.mc.theWorld.addEntityToWorld(-1337, (Entity)this.fakePlayer);
        }
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            double[] dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY + (double)(MinecraftInstance.mc.thePlayer.getEyeHeight() / (float)2), MinecraftInstance.mc.thePlayer.posZ};
            this.positions.add(dArray);
            dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY, MinecraftInstance.mc.thePlayer.posZ};
            boolean bl2 = this.positions.add(dArray);
        }
        this.pulseTimer.reset();
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        this.blink();
        if (this.fakePlayer != null) {
            WorldClient worldClient = MinecraftInstance.mc.theWorld;
            EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer;
            Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
            worldClient.removeEntityFromWorld(entityOtherPlayerMP.getEntityId());
            this.fakePlayer = null;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (MinecraftInstance.mc.thePlayer == null || this.disableLogger) {
            return;
        }
        if (packet instanceof C03PacketPlayer) {
            event.cancelEvent();
        }
        if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity || ((Boolean)this.c0FValue.get()).booleanValue() && packet instanceof C0FPacketConfirmTransaction) {
            event.cancelEvent();
            this.packets.add(packet);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            double[] dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY, MinecraftInstance.mc.thePlayer.posZ};
            boolean bl2 = this.positions.add(dArray);
        }
        if (((Boolean)this.pulseValue.get()).booleanValue() && this.pulseTimer.hasTimePassed(((Number)this.pulseDelayValue.get()).intValue())) {
            this.blink();
            this.pulseTimer.reset();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        Trails breadcrumbs;
        Trails trails = breadcrumbs = Client.INSTANCE.getModuleManager().getModule(Trails.class);
        Intrinsics.checkNotNull((Object)trails);
        Color color = (Boolean)trails.getColorRainbow().get() != false ? ColorUtils.rainbow() : new Color(((Number)breadcrumbs.getColorRedValue().get()).intValue(), ((Number)breadcrumbs.getColorGreenValue().get()).intValue(), ((Number)breadcrumbs.getColorBlueValue().get()).intValue());
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            GL11.glPushMatrix();
            GL11.glDisable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)2929);
            MinecraftInstance.mc.entityRenderer.disableLightmap();
            GL11.glBegin((int)3);
            RenderUtils.glColor(color);
            double renderPosX = MinecraftInstance.mc.getRenderManager().viewerPosX;
            double renderPosY = MinecraftInstance.mc.getRenderManager().viewerPosY;
            double renderPosZ = MinecraftInstance.mc.getRenderManager().viewerPosZ;
            for (double[] pos : this.positions) {
                GL11.glVertex3d((double)(pos[0] - renderPosX), (double)(pos[1] - renderPosY), (double)(pos[2] - renderPosZ));
            }
            GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
            GL11.glEnd();
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
            Unit unit = Unit.INSTANCE;
        }
    }

    @Override
    public String getTag() {
        return String.valueOf(this.packets.size());
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void blink() {
        try {
            this.disableLogger = true;
            while (!this.packets.isEmpty()) {
                MinecraftInstance.mc.getNetHandler().getNetworkManager().sendPacket(this.packets.take());
            }
            this.disableLogger = false;
        }
        catch (Exception e) {
            e.printStackTrace();
            this.disableLogger = false;
        }
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            this.positions.clear();
            Unit unit = Unit.INSTANCE;
        }
    }
}

