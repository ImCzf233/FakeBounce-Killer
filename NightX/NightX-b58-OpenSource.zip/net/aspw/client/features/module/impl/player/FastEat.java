/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBucketMilk
 *  net.minecraft.item.ItemFood
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBucketMilk;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="FastEat", spacedName="Fast Eat", description="", category=ModuleCategory.PLAYER)
public final class FastEat
extends Module {
    private final ListValue modeValue;
    private final BoolValue noMoveValue;
    private final IntegerValue delayValue;
    private final IntegerValue customSpeedValue;
    private final FloatValue customTimer;
    private final MSTimer msTimer;
    private boolean usedTimer;

    public FastEat() {
        String[] stringArray = new String[]{"NCP", "AAC", "CustomDelay", "AACv4_2"};
        this.modeValue = new ListValue("Mode", stringArray, "NCP");
        this.noMoveValue = new BoolValue("NoMove", false);
        this.delayValue = new IntegerValue("CustomDelay", 0, 0, 300, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ FastEat this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)FastEat.access$getModeValue$p(this.this$0).get()), (String)"customdelay", (boolean)true);
            }
        }));
        this.customSpeedValue = new IntegerValue("CustomSpeed", 2, 0, 35, " packet", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ FastEat this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)FastEat.access$getModeValue$p(this.this$0).get()), (String)"customdelay", (boolean)true);
            }
        }));
        this.customTimer = new FloatValue("CustomTimer", 1.1f, 0.5f, 2.0f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ FastEat this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)FastEat.access$getModeValue$p(this.this$0).get()), (String)"customdelay", (boolean)true);
            }
        }));
        this.msTimer = new MSTimer();
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        block22: {
            Intrinsics.checkNotNullParameter((Object)event, (String)"event");
            if (this.usedTimer) {
                MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                this.usedTimer = false;
            }
            if (!MinecraftInstance.mc.thePlayer.isUsingItem()) {
                this.msTimer.reset();
                return;
            }
            Item usingItem = MinecraftInstance.mc.thePlayer.getItemInUse().getItem();
            if (!(usingItem instanceof ItemFood) && !(usingItem instanceof ItemBucketMilk) && !(usingItem instanceof ItemPotion)) break block22;
            String string = (String)this.modeValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string2) {
                case "ncp": {
                    if (MinecraftInstance.mc.thePlayer.getItemInUseDuration() <= 14) break;
                    int n = 20;
                    int n2 = 0;
                    while (n2 < n) {
                        int n3;
                        int it = n3 = n2++;
                        boolean bl = false;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(MinecraftInstance.mc.thePlayer.onGround));
                    }
                    MinecraftInstance.mc.playerController.onStoppedUsingItem((EntityPlayer)MinecraftInstance.mc.thePlayer);
                    break;
                }
                case "aac": {
                    MinecraftInstance.mc.timer.timerSpeed = 1.1f;
                    this.usedTimer = true;
                    break;
                }
                case "customdelay": {
                    MinecraftInstance.mc.timer.timerSpeed = ((Number)this.customTimer.get()).floatValue();
                    this.usedTimer = true;
                    if (!this.msTimer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
                        return;
                    }
                    int n = ((Number)this.customSpeedValue.get()).intValue();
                    int n4 = 0;
                    while (n4 < n) {
                        int n5;
                        int it = n5 = n4++;
                        boolean bl = false;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(MinecraftInstance.mc.thePlayer.onGround));
                    }
                    this.msTimer.reset();
                    break;
                }
                case "aacv4_2": {
                    MinecraftInstance.mc.timer.timerSpeed = 0.49f;
                    this.usedTimer = true;
                    if (MinecraftInstance.mc.thePlayer.getItemInUseDuration() <= 13) break;
                    int n = 23;
                    int n6 = 0;
                    while (n6 < n) {
                        int n7;
                        int it = n7 = n6++;
                        boolean bl = false;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(MinecraftInstance.mc.thePlayer.onGround));
                    }
                    MinecraftInstance.mc.playerController.onStoppedUsingItem((EntityPlayer)MinecraftInstance.mc.thePlayer);
                }
            }
        }
    }

    @EventTarget
    public final void onMove(@Nullable MoveEvent event) {
        if (event == null) {
            return;
        }
        if (!(this.getState() && MinecraftInstance.mc.thePlayer.isUsingItem() && ((Boolean)this.noMoveValue.get()).booleanValue())) {
            return;
        }
        Item usingItem = MinecraftInstance.mc.thePlayer.getItemInUse().getItem();
        if (usingItem instanceof ItemFood || usingItem instanceof ItemBucketMilk || usingItem instanceof ItemPotion) {
            event.zero();
        }
    }

    @Override
    public void onDisable() {
        if (this.usedTimer) {
            MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            this.usedTimer = false;
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(FastEat $this) {
        return $this.modeValue;
    }
}

