/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.BoolValue;

@ModuleInfo(name="AntiBlind", spacedName="Anti Blind", description="", category=ModuleCategory.VISUAL)
public final class AntiBlind
extends Module {
    private final BoolValue confusionEffect = new BoolValue("Confusion", true);
    private final BoolValue pumpkinEffect = new BoolValue("Pumpkin", true);
    private final BoolValue fireEffect = new BoolValue("Fire", true);
    private final BoolValue scoreBoard = new BoolValue("Scoreboard", false);
    private final BoolValue bossHealth = new BoolValue("Boss-Health", false);

    public final BoolValue getConfusionEffect() {
        return this.confusionEffect;
    }

    public final BoolValue getPumpkinEffect() {
        return this.pumpkinEffect;
    }

    public final BoolValue getFireEffect() {
        return this.fireEffect;
    }

    public final BoolValue getScoreBoard() {
        return this.scoreBoard;
    }

    public final BoolValue getBossHealth() {
        return this.bossHealth;
    }
}

