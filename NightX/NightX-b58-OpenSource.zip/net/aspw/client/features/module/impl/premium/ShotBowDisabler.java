/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 */
package net.aspw.client.features.module.impl.premium;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.auth.LoginID;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

@ModuleInfo(name="ShotBowDisabler", spacedName="Shot Bow Disabler", description="", category=ModuleCategory.PREMIUM)
public final class ShotBowDisabler
extends Module {
    private final IntegerValue cancelDelay = new IntegerValue("CancelDelay", 100, 1, 100);
    private final IntegerValue modifyDelay = new IntegerValue("ModifyDelay", 20, 1, 100);
    private final BoolValue modifyRotateValue = new BoolValue("ModifyRotate", true);
    private final BoolValue fakePosValue = new BoolValue("FakePos", true);
    private final BoolValue disablePacketValue = new BoolValue("DisablePacket", false);
    private final BoolValue debugValue = new BoolValue("Debug", true);

    private final void debug(String s, boolean force) {
        if (((Boolean)this.debugValue.get()).booleanValue() || force) {
            ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"ShotBowMomentDisabler2023 \u00a7c\u00a7l>> \u00a7r\u00a7f", (Object)s));
        }
    }

    static /* synthetic */ void debug$default(ShotBowDisabler shotBowDisabler, String string, boolean bl, int n, Object object) {
        if ((n & 2) != 0) {
            bl = false;
        }
        shotBowDisabler.debug(string, bl);
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!LoginID.INSTANCE.isPremium()) {
            this.chat("You are not using NightX Premium Account!");
            this.setState(false);
            return;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C0DPacketCloseWindow) {
            event.cancelEvent();
            ShotBowDisabler.debug$default(this, "Cancelled C0D", false, 2, null);
        }
        if (packet instanceof C03PacketPlayer) {
            ((C03PacketPlayer)packet).onGround = true;
        }
        if (packet instanceof S08PacketPlayerPosLook) {
            double z;
            double y;
            if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.thePlayer.ticksExisted <= 0) {
                return;
            }
            double x = ((S08PacketPlayerPosLook)packet).getX() - MinecraftInstance.mc.thePlayer.posX;
            double diff = Math.sqrt(x * x + (y = ((S08PacketPlayerPosLook)packet).getY() - MinecraftInstance.mc.thePlayer.posY) * y + (z = ((S08PacketPlayerPosLook)packet).getZ() - MinecraftInstance.mc.thePlayer.posZ) * z);
            if (diff <= (double)((Number)this.cancelDelay.get()).intValue()) {
                event.cancelEvent();
                ShotBowDisabler.debug$default(this, "Cancelled S08", false, 2, null);
            }
            if (diff <= (double)((Number)this.modifyDelay.get()).intValue()) {
                if (((Boolean)this.modifyRotateValue.get()).booleanValue()) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(((S08PacketPlayerPosLook)packet).x, ((S08PacketPlayerPosLook)packet).y, ((S08PacketPlayerPosLook)packet).z, ((S08PacketPlayerPosLook)packet).yaw, ((S08PacketPlayerPosLook)packet).pitch, true)));
                    ShotBowDisabler.debug$default(this, "Modified C06", false, 2, null);
                }
                if (((Boolean)this.fakePosValue.get()).booleanValue()) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.1, MinecraftInstance.mc.thePlayer.posZ, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                    ShotBowDisabler.debug$default(this, "Modified C04", false, 2, null);
                }
            }
        }
    }

    @Override
    public void onDisable() {
        if (((Boolean)this.disablePacketValue.get()).booleanValue()) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0DPacketCloseWindow()));
        }
    }
}

