/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.other;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.ListValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="AntiSuffocation", spacedName="Anti Suffocation", description="", category=ModuleCategory.OTHER)
public final class AntiSuffocation
extends Module {
    private final ListValue modeValue;
    private final ListValue breakPositionValue;
    private final ListValue swingValue;

    public AntiSuffocation() {
        String[] stringArray = new String[]{"Legit", "Teleport", "GodMode"};
        this.modeValue = new ListValue("Mode", stringArray, "Legit");
        stringArray = new String[]{"Normal", "Down"};
        this.breakPositionValue = new ListValue("BreakPosition", stringArray, "Normal", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiSuffocation this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiSuffocation.access$getModeValue$p(this.this$0).get()), (String)"legit", (boolean)true);
            }
        }));
        stringArray = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Packet", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiSuffocation this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiSuffocation.access$getModeValue$p(this.this$0).get()), (String)"legit", (boolean)true);
            }
        }));
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer.isEntityInsideOpaqueBlock()) {
            String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
            String string2 = string;
            if (string2.equals("legit")) {
                Object object = ((String)this.breakPositionValue.get()).toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
                String string3 = object;
                if (string3.equals("normal")) {
                    MinecraftInstance.mc.playerController.onPlayerDamageBlock(new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0, MinecraftInstance.mc.thePlayer.posZ), EnumFacing.NORTH);
                } else if (string3.equals("down")) {
                    MinecraftInstance.mc.playerController.onPlayerDamageBlock(new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 1.0, MinecraftInstance.mc.thePlayer.posZ), EnumFacing.NORTH);
                }
                String string4 = (String)this.swingValue.get();
                object = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDefault()");
                String string5 = string4.toLowerCase((Locale)object);
                Intrinsics.checkNotNullExpressionValue((Object)string5, (String)"this as java.lang.String).toLowerCase(locale)");
                string3 = string5;
                if (string3.equals("normal")) {
                    MinecraftInstance.mc.thePlayer.swingItem();
                } else if (string3.equals("packet")) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                }
            } else if (string2.equals("teleport")) {
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)3, MinecraftInstance.mc.thePlayer.posZ);
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (MinecraftInstance.mc.thePlayer.isEntityInsideOpaqueBlock()) {
            String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
            if (string.equals("godmode") && (packet instanceof C03PacketPlayer || packet instanceof C0BPacketEntityAction)) {
                event.cancelEvent();
            }
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(AntiSuffocation $this) {
        return $this.modeValue;
    }
}

