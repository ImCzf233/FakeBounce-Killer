/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.projectile.EntityFireball
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C0APacketAnimation
 */
package net.aspw.client.features.module.impl.combat;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C0APacketAnimation;

@ModuleInfo(name="AntiFireBall", spacedName="Anti Fire Ball", description="", category=ModuleCategory.COMBAT)
public final class AntiFireBall
extends Module {
    private final MSTimer timer = new MSTimer();
    private final ListValue swingValue;
    private final BoolValue rotationValue;
    private final FloatValue maxTurnSpeed;
    private final FloatValue minTurnSpeed;

    public AntiFireBall() {
        Object object = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", (String[])object, "Normal");
        this.rotationValue = new BoolValue("Rotation", true);
        object = new Function0<Boolean>(this){
            final /* synthetic */ AntiFireBall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiFireBall.access$getRotationValue$p(this.this$0).get();
            }
        };
        this.maxTurnSpeed = new FloatValue(this, (Object)object){
            final /* synthetic */ AntiFireBall this$0;
            {
                this.this$0 = $receiver;
                super("MaxTurnSpeed", 120.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float i = ((Number)AntiFireBall.access$getMinTurnSpeed$p(this.this$0).get()).floatValue();
                if (i > newValue) {
                    this.set(Float.valueOf(i));
                }
            }
        };
        object = new Function0<Boolean>(this){
            final /* synthetic */ AntiFireBall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiFireBall.access$getRotationValue$p(this.this$0).get();
            }
        };
        this.minTurnSpeed = new FloatValue(this, (Object)object){
            final /* synthetic */ AntiFireBall this$0;
            {
                this.this$0 = $receiver;
                super("MinTurnSpeed", 80.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float i = ((Number)AntiFireBall.access$getMaxTurnSpeed$p(this.this$0).get()).floatValue();
                if (i < newValue) {
                    this.set(Float.valueOf(i));
                }
            }
        };
    }

    @EventTarget
    private final void onUpdate(UpdateEvent event) {
        for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityFireball) || !((double)MinecraftInstance.mc.thePlayer.getDistanceToEntity(entity) < 5.5) || !this.timer.hasTimePassed(300L)) continue;
            if (((Boolean)this.rotationValue.get()).booleanValue()) {
                Rotation rotation = RotationUtils.serverRotation;
                Intrinsics.checkNotNull((Object)rotation);
                Rotation rotation2 = RotationUtils.getRotations(entity);
                Intrinsics.checkNotNull((Object)rotation2);
                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation, rotation2, RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
            }
            String string = (String)this.swingValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            String string3 = string2;
            if (string3.equals("normal")) {
                MinecraftInstance.mc.thePlayer.swingItem();
            } else if (string3.equals("packet")) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
            }
            MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
            this.timer.reset();
            break;
        }
    }

    public static final /* synthetic */ FloatValue access$getMinTurnSpeed$p(AntiFireBall $this) {
        return $this.minTurnSpeed;
    }

    public static final /* synthetic */ BoolValue access$getRotationValue$p(AntiFireBall $this) {
        return $this.rotationValue;
    }

    public static final /* synthetic */ FloatValue access$getMaxTurnSpeed$p(AntiFireBall $this) {
        return $this.maxTurnSpeed;
    }
}

