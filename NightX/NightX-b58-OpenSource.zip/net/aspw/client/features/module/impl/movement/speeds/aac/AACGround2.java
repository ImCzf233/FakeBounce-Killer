/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACGround2
extends SpeedMode {
    public AACGround2() {
        super("AACGround2");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        AACGround2.mc.timer.timerSpeed = ((Float)Client.moduleManager.getModule(Speed.class).aacGroundTimerValue.get()).floatValue();
        MovementUtils.strafe(0.02f);
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        AACGround2.mc.timer.timerSpeed = 1.0f;
    }
}

