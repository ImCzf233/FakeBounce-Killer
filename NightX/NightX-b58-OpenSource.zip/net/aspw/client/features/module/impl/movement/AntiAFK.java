/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

@ModuleInfo(name="AntiAFK", spacedName="Anti AFK", description="", category=ModuleCategory.MOVEMENT)
public final class AntiAFK
extends Module {
    private final MSTimer swingDelayTimer = new MSTimer();
    private final MSTimer delayTimer = new MSTimer();
    private final ListValue modeValue;
    private final IntegerValue swingDelayValue;
    private final IntegerValue rotationDelayValue;
    private final FloatValue rotationAngleValue;
    private final BoolValue jumpValue;
    private final BoolValue moveValue;
    private final BoolValue rotateValue;
    private final BoolValue swingValue;
    private boolean shouldMove;
    private long randomTimerDelay;

    public AntiAFK() {
        String[] stringArray = new String[]{"Old", "Random", "Custom"};
        this.modeValue = new ListValue("Mode", stringArray, "Random");
        this.swingDelayValue = new IntegerValue("SwingDelay", 100, 0, 1000);
        this.rotationDelayValue = new IntegerValue("RotationDelay", 100, 0, 1000);
        this.rotationAngleValue = new FloatValue("RotationAngle", 1.0f, -180.0f, 180.0f);
        this.jumpValue = new BoolValue("Jump", true);
        this.moveValue = new BoolValue("Move", true);
        this.rotateValue = new BoolValue("Rotate", true);
        this.swingValue = new BoolValue("Swing", true);
        this.randomTimerDelay = 500L;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "old": {
                MinecraftInstance.mc.gameSettings.keyBindForward.pressed = true;
                if (!this.delayTimer.hasTimePassed(500L)) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.rotationYaw += 180.0f;
                this.delayTimer.reset();
                break;
            }
            case "random": {
                KeyBinding.setKeyBindState((int)this.getRandomMoveKeyBind(), (boolean)this.shouldMove);
                if (!this.delayTimer.hasTimePassed(this.randomTimerDelay)) {
                    return;
                }
                this.shouldMove = false;
                this.randomTimerDelay = 500L;
                switch (RandomUtils.nextInt(0, 6)) {
                    case 0: {
                        if (MinecraftInstance.mc.thePlayer.onGround) {
                            MinecraftInstance.mc.thePlayer.jump();
                        }
                        this.delayTimer.reset();
                        break;
                    }
                    case 1: {
                        if (!MinecraftInstance.mc.thePlayer.isSwingInProgress) {
                            MinecraftInstance.mc.thePlayer.swingItem();
                        }
                        this.delayTimer.reset();
                        break;
                    }
                    case 2: {
                        this.randomTimerDelay = RandomUtils.nextInt(0, 1000);
                        this.shouldMove = true;
                        this.delayTimer.reset();
                        break;
                    }
                    case 3: {
                        MinecraftInstance.mc.thePlayer.inventory.currentItem = RandomUtils.nextInt(0, 9);
                        MinecraftInstance.mc.playerController.updateController();
                        this.delayTimer.reset();
                        break;
                    }
                    case 4: {
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).rotationYaw += RandomUtils.nextFloat(-180.0f, 180.0f);
                        this.delayTimer.reset();
                        break;
                    }
                    case 5: {
                        if (MinecraftInstance.mc.thePlayer.rotationPitch <= -90.0f || MinecraftInstance.mc.thePlayer.rotationPitch >= 90.0f) {
                            MinecraftInstance.mc.thePlayer.rotationPitch = 0.0f;
                        }
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).rotationPitch += RandomUtils.nextFloat(-10.0f, 10.0f);
                        this.delayTimer.reset();
                    }
                }
                break;
            }
            case "custom": {
                if (((Boolean)this.moveValue.get()).booleanValue()) {
                    MinecraftInstance.mc.gameSettings.keyBindForward.pressed = true;
                }
                if (((Boolean)this.jumpValue.get()).booleanValue() && MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.jump();
                }
                if (((Boolean)this.rotateValue.get()).booleanValue() && this.delayTimer.hasTimePassed(((Number)this.rotationDelayValue.get()).intValue())) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.rotationYaw += ((Number)this.rotationAngleValue.get()).floatValue();
                    if (MinecraftInstance.mc.thePlayer.rotationPitch <= -90.0f || MinecraftInstance.mc.thePlayer.rotationPitch >= 90.0f) {
                        MinecraftInstance.mc.thePlayer.rotationPitch = 0.0f;
                    }
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.rotationPitch += RandomUtils.nextFloat(0.0f, 1.0f) * (float)2 - 1.0f;
                    this.delayTimer.reset();
                }
                if (!((Boolean)this.swingValue.get()).booleanValue() || MinecraftInstance.mc.thePlayer.isSwingInProgress || !this.swingDelayTimer.hasTimePassed(((Number)this.swingDelayValue.get()).intValue())) break;
                MinecraftInstance.mc.thePlayer.swingItem();
                this.swingDelayTimer.reset();
            }
        }
    }

    private final int getRandomMoveKeyBind() {
        switch (RandomUtils.nextInt(0, 4)) {
            case 0: {
                return MinecraftInstance.mc.gameSettings.keyBindRight.getKeyCode();
            }
            case 1: {
                return MinecraftInstance.mc.gameSettings.keyBindLeft.getKeyCode();
            }
            case 2: {
                return MinecraftInstance.mc.gameSettings.keyBindBack.getKeyCode();
            }
            case 3: {
                return MinecraftInstance.mc.gameSettings.keyBindForward.getKeyCode();
            }
        }
        return 0;
    }

    @Override
    public void onDisable() {
        if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindForward)) {
            MinecraftInstance.mc.gameSettings.keyBindForward.pressed = false;
        }
    }
}

