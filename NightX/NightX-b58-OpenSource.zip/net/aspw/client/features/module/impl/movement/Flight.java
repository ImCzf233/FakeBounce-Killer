/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  javax.vecmath.Vector2f
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.math.MathKt
 *  kotlin.text.StringsKt
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockSlime
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemEnderPearl
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C00PacketKeepAlive
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 *  net.minecraft.network.play.client.C0FPacketConfirmTransaction
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;
import javax.vecmath.Vector2f;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.ActionEvent;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.StepEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.MovementUtilsFix;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.TransferUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockSlime;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Flight", description="", category=ModuleCategory.MOVEMENT)
public final class Flight
extends Module {
    @JvmField
    public final ListValue modeValue;
    private final FloatValue vanillaSpeedValue;
    private final FloatValue vanillaVSpeedValue;
    private final FloatValue vanillaMotionYValue;
    private final BoolValue groundSpoofValue;
    private final FloatValue ncpMotionValue;
    private final ListValue verusDmgModeValue;
    private final ListValue verusBoostModeValue;
    private final BoolValue verusReDamageValue;
    private final IntegerValue verusReDmgTickValue;
    private final FloatValue verusSpeedValue;
    private final FloatValue verusTimerValue;
    private final IntegerValue verusDmgTickValue;
    private final BoolValue verusVisualValue;
    private final FloatValue verusVisualHeightValue;
    private final BoolValue verusSpoofGround;
    private final FloatValue timerSpeedValue;
    private final FloatValue timerValue;
    private final ListValue bypassMode;
    private final FloatValue speed;
    private final FloatValue customYMotion;
    private final FloatValue jumpTimer;
    private final FloatValue speedTimer;
    private final BoolValue aac5NofallValue;
    private final BoolValue aac5UseC04Packet;
    private final ListValue aac5Packet;
    private final IntegerValue aac5PursePacketsValue;
    private final IntegerValue clipDelay;
    private final FloatValue clipH;
    private final FloatValue clipV;
    private final FloatValue clipMotionY;
    private final FloatValue clipTimer;
    private final BoolValue clipGroundSpoof;
    private final BoolValue clipCollisionCheck;
    private final BoolValue clipNoMove;
    private final ListValue pearlActivateCheck;
    private final FloatValue aacSpeedValue;
    private final BoolValue aacFast;
    private final FloatValue aacMotion;
    private final FloatValue aacMotion2;
    private final ListValue hypixelBoostMode;
    private final BoolValue hypixelVisualY;
    private final BoolValue hypixelC04;
    private final IntegerValue neruxVaceTicks;
    private final BoolValue fakeSprintingValue;
    private final BoolValue fakeNoMoveValue;
    private final BoolValue fakeDmgValue;
    private final BoolValue fakeYValue;
    private final BoolValue viewBobbingValue;
    private final FloatValue bobbingAmountValue;
    private final MSTimer flyTimer;
    private final MSTimer boostTimer;
    private final TickTimer spartanTimer;
    private final TickTimer verusTimer;
    private final TickTimer hypixelTimer;
    private final TickTimer cubecraftTeleportTickTimer;
    private final TickTimer cubecraftTeleportYTickTimer;
    private final TickTimer cubecraftTeleportYDownTickTimer;
    private final ArrayList<C03PacketPlayer> aac5C03List;
    private int tick;
    private boolean boost;
    private boolean boostGround;
    private boolean disableLogger;
    private final LinkedBlockingQueue<Packet<INetHandlerPlayServer>> packetBuffer;
    private int wdState;
    private int wdTick;
    private boolean fly;
    private double y;
    private final MSTimer timer;
    private final LinkedList<C0FPacketConfirmTransaction> packetLol;
    private boolean flag;
    private double startY;
    private boolean shouldFakeJump;
    private int tickso;
    private int modifyTicks;
    private FlyStage stage;
    private int flags;
    private double groundX;
    private double groundY;
    private double groundZ;
    private boolean shouldActive;
    private boolean noPacketModify;
    private boolean isBoostActive;
    private boolean noFlag;
    private int boostMotion;
    private boolean pog;
    private boolean started;
    private double lastSentX;
    private double lastSentY;
    private double lastSentZ;
    private boolean c;
    private Vec3 startVec;
    private Vector2f rotationVec;
    private int pearlState;
    private double bypassValue;
    private boolean wasDead;
    private int boostTicks;
    private int dmgCooldown;
    private int verusJumpTimes;
    private boolean verusDmged;
    private boolean shouldActiveDmg;
    private float lastYaw;
    private float lastPitch;
    private double moveSpeed;
    private boolean waitFlag;
    private boolean canGlide;
    private int ticks;
    private int expectItemStack;
    private double aacJump;
    private int aac3delay;
    private int aac3glideDelay;
    private int boostHypixelState;
    private double lastDistance;
    private boolean failedStart;

    public Flight() {
        String[] stringArray = new String[]{"Motion", "NoClip", "Creative", "Vanilla", "Water", "Pearl", "Packet", "Desync", "NCPTest1", "NCPTest2", "NCP", "AAC1.9.10", "AAC3.0.5", "AAC3.1.6", "AAC3.3.12", "AAC3.3.13", "AAC5-Vanilla", "Exploit", "Zoom", "BlockDrop", "Jump", "FakeGround", "Minemora", "Sentinel", "Cubecraft", "Funcraft", "NeruxVace", "Verus", "VerusLowHop", "Matrix", "VulcanZoom", "VulcanFast", "VulcanClip", "VulcanGlide", "NewSpartan", "OldSpartan", "BugSpartan", "BoostHypixel", "Slime", "Float", "Jetpack", "KeepAlive", "Flag", "Clip"};
        this.modeValue = new ListValue("Mode", stringArray, "Motion");
        this.vanillaSpeedValue = new FloatValue("Speed", 1.0f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"motion", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"noclip", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"blockdrop", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"desync", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"pearl", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac5-vanilla", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"bugspartan", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"keepalive", (boolean)true);
            }
        }));
        this.vanillaVSpeedValue = new FloatValue("V-Speed", 0.6f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"motion", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"noclip", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"blockdrop", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"desync", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"bugspartan", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"keepalive", (boolean)true);
            }
        }));
        this.vanillaMotionYValue = new FloatValue("Y-Motion", 0.0f, -1.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"motion", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"noclip", (boolean)true);
            }
        }));
        this.groundSpoofValue = new BoolValue("SpoofGround", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"motion", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"noclip", (boolean)true) || StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"creative", (boolean)true);
            }
        }));
        this.ncpMotionValue = new FloatValue("NCPMotion", 0.04f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"ncp", (boolean)true);
            }
        }));
        stringArray = new String[]{"None", "Instant", "InstantC06", "Jump"};
        this.verusDmgModeValue = new ListValue("Verus-DamageMode", stringArray, "Instant", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true);
            }
        }));
        stringArray = new String[]{"Static", "Gradual"};
        this.verusBoostModeValue = new ListValue("Verus-BoostMode", stringArray, "Gradual", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true);
            }
        }));
        this.verusReDamageValue = new BoolValue("Verus-ReDamage", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"jump", (boolean)true);
            }
        }));
        this.verusReDmgTickValue = new IntegerValue("Verus-ReDamage-Ticks", 100, 0, 300, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"jump", (boolean)true) && (Boolean)Flight.access$getVerusReDamageValue$p(this.this$0).get() != false;
            }
        }));
        this.verusSpeedValue = new FloatValue("Verus-Speed", 1.0f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true);
            }
        }));
        this.verusTimerValue = new FloatValue("Verus-Timer", 1.0f, 0.1f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true);
            }
        }));
        this.verusDmgTickValue = new IntegerValue("Verus-Ticks", 200, 0, 300, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && !StringsKt.equals((String)((String)Flight.access$getVerusDmgModeValue$p(this.this$0).get()), (String)"none", (boolean)true);
            }
        }));
        this.verusVisualValue = new BoolValue("Verus-VisualPos", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true);
            }
        }));
        this.verusVisualHeightValue = new FloatValue("Verus-VisualHeight", 0.3f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true) && (Boolean)Flight.access$getVerusVisualValue$p(this.this$0).get() != false;
            }
        }));
        this.verusSpoofGround = new BoolValue("Verus-SpoofGround", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"verus", (boolean)true);
            }
        }));
        this.timerSpeedValue = new FloatValue("NCP-TimerSpeed", 0.1f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"ncptest2", (boolean)true);
            }
        }));
        this.timerValue = new FloatValue("VulcanFast-Timer", 3.0f, 1.0f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"vulcanfast", (boolean)true);
            }
        }));
        stringArray = new String[]{"New", "Stable", "High", "Custom"};
        this.bypassMode = new ListValue("BypassMode", stringArray, "New", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"matrix", (boolean)true);
            }
        }));
        this.speed = new FloatValue("BoostSpeed", 2.0f, 1.0f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"matrix", (boolean)true);
            }
        }));
        this.customYMotion = new FloatValue("CustomJumpMotion", 0.6f, 0.2f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"matrix", (boolean)true) && Flight.access$getBypassMode$p(this.this$0).equals("Custom");
            }
        }));
        this.jumpTimer = new FloatValue("JumpTimer", 0.1f, 0.1f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"matrix", (boolean)true);
            }
        }));
        this.speedTimer = new FloatValue("BoostTimer", 1.0f, 0.5f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"matrix", (boolean)true);
            }
        }));
        this.aac5NofallValue = new BoolValue("AAC5-NoFall", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac5-vanilla", (boolean)true);
            }
        }));
        this.aac5UseC04Packet = new BoolValue("AAC5-UseC04", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac5-vanilla", (boolean)true);
            }
        }));
        stringArray = new String[]{"Original", "Rise", "Other"};
        this.aac5Packet = new ListValue("AAC5-Packet", stringArray, "Original", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac5-vanilla", (boolean)true);
            }
        }));
        this.aac5PursePacketsValue = new IntegerValue("AAC5-Purse", 7, 3, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac5-vanilla", (boolean)true);
            }
        }));
        this.clipDelay = new IntegerValue("Clip-DelayTick", 25, 1, 50, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipH = new FloatValue("Clip-Horizontal", 8.0f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipV = new FloatValue("Clip-Vertical", -1.75f, -10.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipMotionY = new FloatValue("Clip-MotionY", 0.0f, -2.0f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipTimer = new FloatValue("Clip-Timer", 1.0f, 0.08f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipGroundSpoof = new BoolValue("Clip-GroundSpoof", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipCollisionCheck = new BoolValue("Clip-CollisionCheck", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        this.clipNoMove = new BoolValue("Clip-NoMove", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"clip", (boolean)true);
            }
        }));
        stringArray = new String[]{"Teleport", "Damage"};
        this.pearlActivateCheck = new ListValue("PearlActiveCheck", stringArray, "Teleport", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"pearl", (boolean)true);
            }
        }));
        this.aacSpeedValue = new FloatValue("AAC1.9.10-Speed", 0.3f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac1.9.10", (boolean)true);
            }
        }));
        this.aacFast = new BoolValue("AAC3.0.5-Fast", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac3.0.5", (boolean)true);
            }
        }));
        this.aacMotion = new FloatValue("AAC3.3.12-Motion", 8.0f, 0.1f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac3.3.12", (boolean)true);
            }
        }));
        this.aacMotion2 = new FloatValue("AAC3.3.13-Motion", 8.0f, 0.1f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"aac3.3.13", (boolean)true);
            }
        }));
        stringArray = new String[]{"Default", "MorePackets", "NCP"};
        this.hypixelBoostMode = new ListValue("BoostHypixel-Mode", stringArray, "Default", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"boosthypixel", (boolean)true);
            }
        }));
        this.hypixelVisualY = new BoolValue("BoostHypixel-VisualY", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"boosthypixel", (boolean)true);
            }
        }));
        this.hypixelC04 = new BoolValue("BoostHypixel-MoreC04s", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"boosthypixel", (boolean)true);
            }
        }));
        this.neruxVaceTicks = new IntegerValue("NeruxVace-Ticks", 6, 0, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.modeValue.get()), (String)"neruxvace", (boolean)true);
            }
        }));
        this.fakeSprintingValue = new BoolValue("FakeSprinting", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                String string = (String)this.this$0.modeValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                return string2.equals("exploit");
            }
        }));
        this.fakeNoMoveValue = new BoolValue("FakeNoMove", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                String string = (String)this.this$0.modeValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                return string2.equals("exploit");
            }
        }));
        this.fakeDmgValue = new BoolValue("FakeDamage", false);
        this.fakeYValue = new BoolValue("FakeY", false);
        this.viewBobbingValue = new BoolValue("ViewBobbing", false);
        this.bobbingAmountValue = new FloatValue("BobbingAmount", 0.1f, 0.0f, 0.1f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Flight this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Flight.access$getViewBobbingValue$p(this.this$0).get();
            }
        }));
        this.flyTimer = new MSTimer();
        this.boostTimer = new MSTimer();
        this.spartanTimer = new TickTimer();
        this.verusTimer = new TickTimer();
        this.hypixelTimer = new TickTimer();
        this.cubecraftTeleportTickTimer = new TickTimer();
        this.cubecraftTeleportYTickTimer = new TickTimer();
        this.cubecraftTeleportYDownTickTimer = new TickTimer();
        this.aac5C03List = new ArrayList();
        this.packetBuffer = new LinkedBlockingQueue();
        this.timer = new MSTimer();
        this.packetLol = new LinkedList();
        this.stage = FlyStage.WAITING;
        this.expectItemStack = -1;
        this.boostHypixelState = 1;
    }

    public final BoolValue getFakeYValue() {
        return this.fakeYValue;
    }

    public final int getWdState() {
        return this.wdState;
    }

    public final void setWdState(int n) {
        this.wdState = n;
    }

    public final int getWdTick() {
        return this.wdTick;
    }

    public final void setWdTick(int n) {
        this.wdTick = n;
    }

    public final double getY() {
        return this.y;
    }

    public final void setY(double d) {
        this.y = d;
    }

    private final void doMove(double h, double v) {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        double x = MinecraftInstance.mc.thePlayer.posX;
        double y = MinecraftInstance.mc.thePlayer.posY;
        double z = MinecraftInstance.mc.thePlayer.posZ;
        double yaw = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
        double expectedX = x + -Math.sin(yaw) * h;
        double expectedY = y + v;
        double expectedZ = z + Math.cos(yaw) * h;
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(expectedX, expectedY, expectedZ, MinecraftInstance.mc.thePlayer.onGround));
        MinecraftInstance.mc.thePlayer.setPosition(expectedX, expectedY, expectedZ);
    }

    public final boolean isInventory(short action) {
        return action > 0 && action < 100;
    }

    private final void hClip(double x, double y, double z) {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        double expectedX = MinecraftInstance.mc.thePlayer.posX + x;
        double expectedY = MinecraftInstance.mc.thePlayer.posY + y;
        double expectedZ = MinecraftInstance.mc.thePlayer.posZ + z;
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(expectedX, expectedY, expectedZ, MinecraftInstance.mc.thePlayer.onGround));
        MinecraftInstance.mc.thePlayer.setPosition(expectedX, expectedY, expectedZ);
    }

    private final double[] getMoves(double h, double v) {
        if (MinecraftInstance.mc.thePlayer == null) {
            double[] dArray = new double[]{0.0, 0.0, 0.0};
            return dArray;
        }
        double yaw = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
        double expectedX = -Math.sin(yaw) * h;
        double expectedZ = Math.cos(yaw) * h;
        double[] dArray = new double[]{expectedX, v, expectedZ};
        return dArray;
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        this.noPacketModify = true;
        this.verusTimer.reset();
        this.flyTimer.reset();
        this.bypassValue = 0.0;
        this.packetLol.clear();
        this.y = MinecraftInstance.mc.thePlayer.posY;
        this.shouldFakeJump = false;
        this.boostMotion = 0;
        this.shouldActive = true;
        this.fly = false;
        this.isBoostActive = false;
        this.expectItemStack = -1;
        double x = MinecraftInstance.mc.thePlayer.posX;
        double y = MinecraftInstance.mc.thePlayer.posY;
        double z = MinecraftInstance.mc.thePlayer.posZ;
        this.lastYaw = MinecraftInstance.mc.thePlayer.rotationYaw;
        this.lastPitch = MinecraftInstance.mc.thePlayer.rotationPitch;
        String mode = (String)this.modeValue.get();
        this.boostTicks = 0;
        this.dmgCooldown = 0;
        this.pearlState = 0;
        this.flag = false;
        this.timer.reset();
        this.verusJumpTimes = 0;
        this.verusDmged = false;
        this.moveSpeed = 0.0;
        this.wdState = 0;
        this.wdTick = 0;
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = mode.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string) {
            case "ncp": {
                MinecraftInstance.mc.thePlayer.motionY = -((double)((Number)this.ncpMotionValue.get()).floatValue());
                if (MinecraftInstance.mc.gameSettings.keyBindSneak.isKeyDown()) {
                    MinecraftInstance.mc.thePlayer.motionY = -0.5;
                }
                MovementUtils.strafe();
                break;
            }
            case "vulcanzoom": {
                this.pog = false;
                this.lastSentX = MinecraftInstance.mc.thePlayer.posX;
                this.lastSentY = MinecraftInstance.mc.thePlayer.posY;
                this.lastSentZ = MinecraftInstance.mc.thePlayer.posZ;
                this.started = false;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                if (!MinecraftInstance.mc.thePlayer.onGround) break;
                MinecraftInstance.mc.thePlayer.onGround = false;
                MinecraftInstance.mc.timer.timerSpeed = 0.1f;
                this.started = true;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 2.8 + Math.random() / (double)50, MinecraftInstance.mc.thePlayer.posZ, false)));
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                break;
            }
            case "ncptest2": {
                this.c = true;
                break;
            }
            case "vulcanfast": {
                this.tickso = 0;
                this.modifyTicks = 0;
                this.flags = 0;
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, (double)MathKt.roundToInt((double)(MinecraftInstance.mc.thePlayer.posY * (double)2)) / (double)2, MinecraftInstance.mc.thePlayer.posZ);
                this.stage = FlyStage.WAITING;
                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7aPlease press sneak before you land on ground!");
                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7aYou can go Up/Down by pressing Jump/Sneak");
                break;
            }
            case "minemora": {
                this.boostGround = !MinecraftInstance.mc.thePlayer.onGround;
                this.boost = false;
                this.tick = 0;
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = false;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                break;
            }
            case "vulcanclip": {
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    this.clip(0.0f, -0.1f);
                    this.waitFlag = true;
                    this.canGlide = false;
                    this.ticks = 0;
                    MinecraftInstance.mc.timer.timerSpeed = 0.1f;
                    break;
                }
                this.waitFlag = false;
                this.canGlide = true;
                break;
            }
            case "blockdrop": {
                this.startVec = new Vec3(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ);
                this.rotationVec = new Vector2f(MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch);
                break;
            }
            case "verus": {
                if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Instant", (boolean)true)) {
                    if (MinecraftInstance.mc.thePlayer.onGround && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y + (double)4, MinecraftInstance.mc.thePlayer.posZ, false)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, false)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, true)));
                        MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        if (((Boolean)this.verusReDamageValue.get()).booleanValue()) {
                            this.dmgCooldown = ((Number)this.verusReDmgTickValue.get()).intValue();
                        }
                    }
                } else if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"InstantC06", (boolean)true)) {
                    if (MinecraftInstance.mc.thePlayer.onGround && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y + (double)4, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, true)));
                        MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        if (((Boolean)this.verusReDamageValue.get()).booleanValue()) {
                            this.dmgCooldown = ((Number)this.verusReDmgTickValue.get()).intValue();
                        }
                    }
                } else if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true)) {
                    if (MinecraftInstance.mc.thePlayer.onGround) {
                        MinecraftInstance.mc.thePlayer.jump();
                        this.verusJumpTimes = 1;
                    }
                } else {
                    this.verusDmged = true;
                }
                if (((Boolean)this.verusVisualValue.get()).booleanValue()) {
                    MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, y + ((Number)this.verusVisualHeightValue.get()).doubleValue(), MinecraftInstance.mc.thePlayer.posZ);
                }
                this.shouldActiveDmg = this.dmgCooldown > 0;
                break;
            }
            case "bugspartan": {
                for (int i = 0; i < 65; ++i) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.049, z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                }
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.1, z, true));
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionX *= 0.1;
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionZ *= 0.1;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                break;
            }
            case "funcraft": {
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.jump();
                    this.moveSpeed = 1.61;
                    break;
                }
                this.moveSpeed = 0.25;
                break;
            }
            case "zoom": {
                double awax = MinecraftInstance.mc.thePlayer.posX;
                double away = MinecraftInstance.mc.thePlayer.posY;
                double awaz = MinecraftInstance.mc.thePlayer.posZ;
                int n = 65;
                int n2 = 0;
                while (n2 < n) {
                    int n3;
                    int it = n3 = n2++;
                    boolean bl = false;
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(awax, away + 0.049, awaz, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(awax, away, awaz, false));
                }
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(awax, away, awaz, true));
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.jump();
                }
                this.moveSpeed = 2.0;
                break;
            }
            case "slime": {
                this.expectItemStack = this.getSlimeSlot();
                if (this.expectItemStack == -1) {
                    Client.INSTANCE.getHud().addNotification(new Notification("The fly requires slime blocks to be activated properly."));
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) break;
                MinecraftInstance.mc.thePlayer.jump();
                this.wdState = 1;
                break;
            }
            case "boosthypixel": {
                int i;
                if (!MinecraftInstance.mc.thePlayer.onGround && ((Boolean)this.hypixelC04.get()).booleanValue()) {
                    i = 0;
                    while (i < 10) {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true));
                        int n = i;
                        i = n + 1;
                    }
                }
                if (StringsKt.equals((String)((String)this.hypixelBoostMode.get()), (String)"ncp", (boolean)true)) {
                    i = 0;
                    while (i < 65) {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.049, MinecraftInstance.mc.thePlayer.posZ, false));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, false));
                        int n = i;
                        i = n + 1;
                    }
                } else {
                    double fallDistance;
                    double d = fallDistance = StringsKt.equals((String)((String)this.hypixelBoostMode.get()), (String)"morepackets", (boolean)true) ? 3.4025 : 3.0125;
                    while (fallDistance > 0.0) {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.0624986421, MinecraftInstance.mc.thePlayer.posZ, false));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.0625, MinecraftInstance.mc.thePlayer.posZ, false));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.0624986421, MinecraftInstance.mc.thePlayer.posZ, false));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.3579E-6, MinecraftInstance.mc.thePlayer.posZ, false));
                        fallDistance -= 0.0624986421;
                    }
                }
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true));
                if (((Boolean)this.hypixelVisualY.get()).booleanValue()) {
                    MinecraftInstance.mc.thePlayer.jump();
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.posY += 0.41999998688698;
                }
                this.boostHypixelState = 1;
                this.moveSpeed = 0.1;
                this.lastDistance = 0.0;
                this.failedStart = false;
            }
        }
        this.startY = MinecraftInstance.mc.thePlayer.posY;
        this.noPacketModify = false;
        this.aacJump = -3.8;
        if (!(!((Boolean)this.fakeDmgValue.get()).booleanValue() || StringsKt.equals((String)mode, (String)"slime", (boolean)true) || StringsKt.equals((String)mode, (String)"exploit", (boolean)true) || StringsKt.equals((String)mode, (String)"bugspartan", (boolean)true) || StringsKt.equals((String)mode, (String)"verus", (boolean)true))) {
            MinecraftInstance.mc.thePlayer.handleStatusUpdate((byte)2);
        }
        super.onEnable();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onDisable() {
        String mode;
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        MinecraftInstance.mc.thePlayer.eyeHeight = MinecraftInstance.mc.thePlayer.getDefaultEyeHeight();
        this.wasDead = false;
        this.fly = false;
        this.c = false;
        this.packetLol.clear();
        if (MinecraftInstance.mc.thePlayer != null) {
            MinecraftInstance.mc.thePlayer.noClip = false;
        }
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        this.noFlag = false;
        if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = true;
        }
        if ((mode = (String)this.modeValue.get()).equals("Minemora")) {
            this.tick = 0;
            try {
                this.disableLogger = true;
                while (!this.packetBuffer.isEmpty()) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue(this.packetBuffer.take());
                }
                this.disableLogger = false;
            }
            finally {
                this.disableLogger = false;
            }
        }
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = mode.toUpperCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toUpperCase(locale)");
        if (!(StringsKt.startsWith$default((String)string, (String)"NCP", (boolean)false, (int)2, null) || StringsKt.equals((String)mode, (String)"float", (boolean)true) || StringsKt.equals((String)mode, (String)"vanilla", (boolean)true) || StringsKt.equals((String)mode, (String)"creative", (boolean)true) || StringsKt.equals((String)mode, (String)"water", (boolean)true) || StringsKt.equals((String)mode, (String)"vanilla", (boolean)true) || StringsKt.equals((String)mode, (String)"newspartan", (boolean)true) || StringsKt.equals((String)mode, (String)"aac1.9.10", (boolean)true) || StringsKt.equals((String)mode, (String)"aac3.3.12", (boolean)true) || StringsKt.equals((String)mode, (String)"neruxvace", (boolean)true) || StringsKt.equals((String)mode, (String)"jump", (boolean)true) || StringsKt.equals((String)mode, (String)"fakeground", (boolean)true) || StringsKt.equals((String)mode, (String)"oldspartan", (boolean)true) || StringsKt.equals((String)mode, (String)"jetpack", (boolean)true) || StringsKt.equals((String)mode, (String)"clip", (boolean)true) || StringsKt.equals((String)mode, (String)"vulcanglide", (boolean)true) || StringsKt.equals((String)mode, (String)"matrix", (boolean)true))) {
            Speed speed3 = speed2;
            Boolean bl = speed3 == null ? null : Boolean.valueOf(speed3.getState());
            Intrinsics.checkNotNull((Object)bl);
            if (bl.booleanValue()) {
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
            } else {
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
            }
        }
        if (StringsKt.equals((String)mode, (String)"AAC5-Vanilla", (boolean)true) && !MinecraftInstance.mc.isIntegratedServerRunning()) {
            this.sendAAC5Packets();
        }
        if (StringsKt.equals((String)mode, (String)"VulcanFast", (boolean)true)) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
        }
        MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
        MinecraftInstance.mc.thePlayer.capabilities.allowFlying = false;
        if (MinecraftInstance.mc.thePlayer.capabilities.isCreativeMode) {
            MinecraftInstance.mc.thePlayer.capabilities.allowFlying = true;
        }
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.packetLol.clear();
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        float vanillaSpeed = ((Number)this.vanillaSpeedValue.get()).floatValue();
        float vanillaVSpeed = ((Number)this.vanillaVSpeedValue.get()).floatValue();
        MinecraftInstance.mc.thePlayer.noClip = false;
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "vulcanzoom": {
                if (!this.started) return;
                if (!this.pog) return;
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = false;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                MovementUtils.strafe((float)(1.96 + Math.random() / (double)50));
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.motionX = 0.0;
                    MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                    MinecraftInstance.mc.thePlayer.motionY = 0.2;
                }
                if (!MovementUtils.isMoving()) {
                    MinecraftInstance.mc.thePlayer.motionX = 0.0;
                    MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                }
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                return;
            }
            case "vulcanfast": {
                Object playerYaw3;
                int n = this.tickso;
                this.tickso = n + 1;
                int n2 = this.modifyTicks;
                this.modifyTicks = n2 + 1;
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = false;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                switch (WhenMappings.$EnumSwitchMapping$0[this.stage.ordinal()]) {
                    case 1: 
                    case 2: {
                        MinecraftInstance.mc.timer.timerSpeed = this.stage == FlyStage.FLYING ? ((Number)this.timerValue.get()).floatValue() : 1.0f;
                        if (this.tickso == 2 && GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindJump) && this.modifyTicks >= 6 && MinecraftInstance.mc.theWorld.getCollisionBoxes(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 0.5, 0.0)).isEmpty()) {
                            MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.5, MinecraftInstance.mc.thePlayer.posZ);
                            this.modifyTicks = 0;
                        }
                        if (!MovementUtils.isMoving() && this.tickso == 1 && (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak) || GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindJump)) && this.modifyTicks >= 5) {
                            double playerYaw2 = (double)MinecraftInstance.mc.thePlayer.rotationYaw * Math.PI / (double)180;
                            MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX + 0.05 * -Math.sin(playerYaw2), MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ + 0.05 * Math.cos(playerYaw2));
                        }
                        if (this.tickso == 2 && GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak) && this.modifyTicks >= 6 && MinecraftInstance.mc.theWorld.getCollisionBoxes(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, -0.5, 0.0)).isEmpty()) {
                            MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 0.5, MinecraftInstance.mc.thePlayer.posZ);
                            this.modifyTicks = 0;
                        } else if (this.tickso == 2 && GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                            playerYaw3 = MinecraftInstance.mc.theWorld.getCollisionBoxes(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, -0.5, 0.0));
                            Intrinsics.checkNotNullExpressionValue((Object)playerYaw3, (String)"mc.theWorld.getCollision\u2026                        )");
                            if (!((Collection)playerYaw3).isEmpty()) {
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + 0.05, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.42, MinecraftInstance.mc.thePlayer.posZ, true)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.7532, MinecraftInstance.mc.thePlayer.posZ, true)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0, MinecraftInstance.mc.thePlayer.posZ, true)));
                                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0, MinecraftInstance.mc.thePlayer.posZ);
                                this.stage = FlyStage.WAIT_APPLY;
                                this.modifyTicks = 0;
                                this.groundY = MinecraftInstance.mc.thePlayer.posY - 1.0;
                                this.groundX = MinecraftInstance.mc.thePlayer.posX;
                                this.groundZ = MinecraftInstance.mc.thePlayer.posZ;
                                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7aWaiting to land...");
                            }
                        }
                        MinecraftInstance.mc.thePlayer.onGround = true;
                        MinecraftInstance.mc.thePlayer.motionY = 0.0;
                        return;
                    }
                    case 3: {
                        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                        MinecraftInstance.mc.thePlayer.motionX = 0.0;
                        MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                        if (this.modifyTicks < 10) break;
                        double playerYaw3 = (double)MinecraftInstance.mc.thePlayer.rotationYaw * Math.PI / (double)180;
                        if (this.modifyTicks % 2 != 0) {
                            MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX + 0.1 * -Math.sin(playerYaw3), MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ + 0.1 * Math.cos(playerYaw3));
                            return;
                        }
                        MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX - 0.1 * -Math.sin(playerYaw3), MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ - 0.1 * Math.cos(playerYaw3));
                        if (this.modifyTicks < 16 || this.tickso != 2) break;
                        this.modifyTicks = 16;
                        MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.5, MinecraftInstance.mc.thePlayer.posZ);
                        return;
                    }
                }
                return;
            }
            case "matrix": {
                Object playerYaw3;
                if (this.boostMotion == 0) {
                    double d = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true));
                    if (this.bypassMode.equals("High")) {
                        MovementUtils.strafe(5.0f);
                        MinecraftInstance.mc.thePlayer.motionY = 2.0;
                    } else {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + -Math.sin(d) * 1.5, MinecraftInstance.mc.thePlayer.posY + 1.0, MinecraftInstance.mc.thePlayer.posZ + Math.cos(d) * 1.5, false));
                    }
                    this.boostMotion = 1;
                    MinecraftInstance.mc.timer.timerSpeed = ((Number)this.jumpTimer.get()).floatValue();
                    return;
                }
                if (this.boostMotion == 1 && this.bypassMode.equals("High")) {
                    MovementUtils.strafe(1.89f);
                    MinecraftInstance.mc.thePlayer.motionY = 2.0;
                    return;
                }
                if (this.boostMotion == 2) {
                    MovementUtils.strafe(((Number)this.speed.get()).floatValue());
                    playerYaw3 = ((String)this.bypassMode.get()).toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue((Object)playerYaw3, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
                    switch (playerYaw3) {
                        case "stable": {
                            MinecraftInstance.mc.thePlayer.motionY = 0.8;
                            break;
                        }
                        case "new": {
                            MinecraftInstance.mc.thePlayer.motionY = 0.48;
                            break;
                        }
                        case "high": {
                            double yaw = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + -Math.sin(yaw) * (double)2, MinecraftInstance.mc.thePlayer.posY + 2.0, MinecraftInstance.mc.thePlayer.posZ + Math.cos(yaw) * (double)2, true));
                            MinecraftInstance.mc.thePlayer.motionY = 2.0;
                            MovementUtils.strafe(1.89f);
                            break;
                        }
                        case "custom": {
                            MinecraftInstance.mc.thePlayer.motionY = ((Number)this.customYMotion.get()).floatValue();
                            break;
                        }
                    }
                    this.boostMotion = 3;
                    return;
                }
                if (this.boostMotion < 5) {
                    int n = this.boostMotion;
                    this.boostMotion = n + 1;
                    return;
                }
                if (this.boostMotion < 5) return;
                MinecraftInstance.mc.timer.timerSpeed = ((Number)this.speedTimer.get()).floatValue();
                return;
            }
            case "motion": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.vanillaMotionYValue.get()).floatValue();
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "ncptest2": {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.025;
                if (MovementUtils.isMoving()) {
                    if (MinecraftInstance.mc.thePlayer.onGround) {
                        MinecraftInstance.mc.thePlayer.jump();
                    }
                    if (!MinecraftInstance.mc.thePlayer.onGround) {
                        MinecraftInstance.mc.timer.timerSpeed = ((Number)this.timerSpeedValue.get()).floatValue();
                    }
                }
                if (MinecraftInstance.mc.thePlayer.onGround) return;
                MovementUtils.strafe(MovementUtils.getSpeed() * (this.c ? 55.80269f : 1.0f));
                if (!this.c) return;
                this.c = false;
                return;
            }
            case "veruslowhop": {
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) return;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                return;
            }
            case "fakeground": {
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) return;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                return;
            }
            case "cubecraft": {
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += 0.07;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) return;
                MovementUtils.strafe(0.6f);
                return;
            }
            case "minemora": {
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) return;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                return;
            }
            case "jump": {
                if (!MinecraftInstance.mc.thePlayer.onGround) return;
                MinecraftInstance.mc.thePlayer.jump();
                return;
            }
            case "noclip": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.vanillaMotionYValue.get()).floatValue();
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                MinecraftInstance.mc.thePlayer.noClip = true;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "newspartan": {
                if (!((String)this.modeValue.get()).equals("NewSpartan")) return;
                if (MinecraftInstance.mc.thePlayer.onGround) return;
                if (MinecraftInstance.mc.thePlayer.isSneaking()) return;
                if (MinecraftInstance.mc.thePlayer.ticksExisted % 3 != 0) {
                    return;
                }
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                if (MinecraftInstance.mc.thePlayer.fallDistance > 0.0f) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.2;
                    MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                }
                if (!(MinecraftInstance.mc.thePlayer.moveForward == 0.0f)) return;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                return;
            }
            case "vanilla": {
                MinecraftInstance.mc.thePlayer.capabilities.allowFlying = true;
                return;
            }
            case "desync": {
                MinecraftInstance.mc.thePlayer.noClip = true;
                MinecraftInstance.mc.thePlayer.onGround = false;
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                if (MinecraftInstance.mc.thePlayer.ticksExisted % 180 != 0) return;
                while (this.packetLol.size() > 22) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)this.packetLol.poll()));
                }
                return;
            }
            case "packet": {
                MovementUtils.strafe(0.0f);
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.onGround = true;
                MinecraftInstance.mc.timer.timerSpeed = 1.3f;
                double d = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
                double x = -Math.sin(d) * 0.2873;
                double z = Math.cos(d) * 0.2873;
                if (MovementUtils.isMoving() && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindJump) && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + x, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ + z, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + x, MinecraftInstance.mc.thePlayer.posY + (double)60, MinecraftInstance.mc.thePlayer.posZ + z, true));
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindJump)) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, false));
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)20, MinecraftInstance.mc.thePlayer.posZ, true));
                }
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) return;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, false));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - (double)20, MinecraftInstance.mc.thePlayer.posZ, true));
                return;
            }
            case "blockdrop": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "sentinel": {
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                this.cubecraftTeleportTickTimer.update();
                this.cubecraftTeleportYTickTimer.update();
                this.cubecraftTeleportYDownTickTimer.update();
                MinecraftInstance.mc.timer.timerSpeed = 0.6f;
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) return;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                return;
            }
            case "ncp": {
                MinecraftInstance.mc.thePlayer.motionY = -((double)((Number)this.ncpMotionValue.get()).floatValue());
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    MinecraftInstance.mc.thePlayer.motionY = -0.5;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe();
                return;
            }
            case "clip": {
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.clipMotionY.get()).floatValue();
                MinecraftInstance.mc.timer.timerSpeed = ((Number)this.clipTimer.get()).floatValue();
                if (MinecraftInstance.mc.thePlayer.ticksExisted % ((Number)this.clipDelay.get()).intValue() != 0) return;
                double[] dArray = this.getMoves(((Number)this.clipH.get()).floatValue(), ((Number)this.clipV.get()).floatValue());
                if (((Boolean)this.clipCollisionCheck.get()).booleanValue()) {
                    if (!MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(dArray[0], dArray[1], dArray[2]).expand(0.0, 0.0, 0.0)).isEmpty()) return;
                }
                this.hClip(dArray[0], dArray[1], dArray[2]);
                return;
            }
            case "aac5-vanilla": 
            case "bugspartan": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "verus": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                Flight $this$onUpdate_u24lambda_u2d22 = this;
                boolean bl = false;
                MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (!StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) || this.shouldActiveDmg || this.verusDmged) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.0;
                }
                if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) && this.verusJumpTimes < 5) {
                    if (!MinecraftInstance.mc.thePlayer.onGround) return;
                    MinecraftInstance.mc.thePlayer.jump();
                    ++this.verusJumpTimes;
                    return;
                }
                if (this.shouldActiveDmg) {
                    if (this.dmgCooldown > 0) {
                        int n = this.dmgCooldown;
                        this.dmgCooldown = n + -1;
                    } else if (this.verusDmged) {
                        this.verusDmged = false;
                        double d = MinecraftInstance.mc.thePlayer.posY;
                        if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Instant", (boolean)true)) {
                            if (MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, d + (double)4, MinecraftInstance.mc.thePlayer.posZ, false)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, d, MinecraftInstance.mc.thePlayer.posZ, false)));
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, d, MinecraftInstance.mc.thePlayer.posZ, true)));
                                MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                            }
                        } else if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"InstantC06", (boolean)true) && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, d + (double)4, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, d, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, d, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, true)));
                            MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        }
                        this.dmgCooldown = ((Number)this.verusReDmgTickValue.get()).intValue();
                    }
                }
                if (!this.verusDmged && MinecraftInstance.mc.thePlayer.hurtTime > 0) {
                    this.verusDmged = true;
                    this.boostTicks = ((Number)this.verusDmgTickValue.get()).intValue();
                }
                if (this.boostTicks > 0) {
                    MinecraftInstance.mc.timer.timerSpeed = ((Number)this.verusTimerValue.get()).floatValue();
                    float f = 0.0f;
                    f = StringsKt.equals((String)((String)this.verusBoostModeValue.get()), (String)"static", (boolean)true) ? ((Number)this.verusSpeedValue.get()).floatValue() : (float)this.boostTicks / (float)((Number)this.verusDmgTickValue.get()).intValue() * ((Number)this.verusSpeedValue.get()).floatValue();
                    int $this$onUpdate_u24lambda_u2d22 = this.boostTicks;
                    this.boostTicks = $this$onUpdate_u24lambda_u2d22 + -1;
                    MovementUtils.strafe(f);
                    return;
                }
                if (this.verusDmged) {
                    MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                    MovementUtils.strafe((float)MovementUtils.getBaseMoveSpeed() * 0.6f);
                    return;
                }
                MinecraftInstance.mc.thePlayer.movementInput.moveForward = 0.0f;
                MinecraftInstance.mc.thePlayer.movementInput.moveStrafe = 0.0f;
                return;
            }
            case "creative": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = true;
                return;
            }
            case "aac1.9.10": {
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    this.aacJump += 0.2;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    this.aacJump -= 0.2;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                if (this.startY + this.aacJump > MinecraftInstance.mc.thePlayer.posY) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                    MinecraftInstance.mc.thePlayer.motionY = 0.8;
                    MovementUtils.strafe(((Number)this.aacSpeedValue.get()).floatValue());
                }
                MovementUtils.strafe();
                return;
            }
            case "aac3.0.5": {
                if (this.aac3delay == 2) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.1;
                } else if (this.aac3delay > 2) {
                    this.aac3delay = 0;
                }
                if (((Boolean)this.aacFast.get()).booleanValue()) {
                    MinecraftInstance.mc.thePlayer.jumpMovementFactor = (double)MinecraftInstance.mc.thePlayer.movementInput.moveStrafe == 0.0 ? 0.08f : 0.0f;
                }
                int n = this.aac3delay;
                this.aac3delay = n + 1;
                return;
            }
            case "aac3.1.6": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = true;
                if (this.aac3delay == 2) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += 0.05;
                } else if (this.aac3delay > 2) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= 0.05;
                    this.aac3delay = 0;
                }
                int n = this.aac3delay;
                this.aac3delay = n + 1;
                if (!this.noFlag) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.onGround));
                }
                if (!(MinecraftInstance.mc.thePlayer.posY <= 0.0)) return;
                this.noFlag = true;
                return;
            }
            case "flag": {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX + MinecraftInstance.mc.thePlayer.motionX * (double)999, MinecraftInstance.mc.thePlayer.posY + (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() ? 1.5624 : 1.0E-8) - (MinecraftInstance.mc.gameSettings.keyBindSneak.isKeyDown() ? 0.0624 : 2.0E-8), MinecraftInstance.mc.thePlayer.posZ + MinecraftInstance.mc.thePlayer.motionZ * (double)999, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, true));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX + MinecraftInstance.mc.thePlayer.motionX * (double)999, MinecraftInstance.mc.thePlayer.posY - (double)6969, MinecraftInstance.mc.thePlayer.posZ + MinecraftInstance.mc.thePlayer.motionZ * (double)999, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, true));
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX + MinecraftInstance.mc.thePlayer.motionX * (double)11, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ + MinecraftInstance.mc.thePlayer.motionZ * (double)11);
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                return;
            }
            case "keepalive": {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C00PacketKeepAlive());
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += (double)vanillaVSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY -= (double)vanillaVSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "jetpack": {
                if (!MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) return;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.14;
                if (!MinecraftInstance.mc.thePlayer.isSprinting()) return;
                EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.thePlayer;
                entityPlayerSP2.motionX *= 1.15;
                EntityPlayerSP entityPlayerSP3 = MinecraftInstance.mc.thePlayer;
                entityPlayerSP3.motionZ *= 1.15;
                return;
            }
            case "aac3.3.12": {
                if (MinecraftInstance.mc.thePlayer.posY < -70.0) {
                    MinecraftInstance.mc.thePlayer.motionY = ((Number)this.aacMotion.get()).floatValue();
                }
                MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                return;
            }
            case "aac3.3.13": {
                if (MinecraftInstance.mc.thePlayer.isDead) {
                    this.wasDead = true;
                }
                if (this.wasDead || MinecraftInstance.mc.thePlayer.onGround) {
                    this.wasDead = false;
                    MinecraftInstance.mc.thePlayer.motionY = ((Number)this.aacMotion2.get()).floatValue();
                    MinecraftInstance.mc.thePlayer.onGround = false;
                }
                MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                return;
            }
            case "oldspartan": {
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                this.spartanTimer.update();
                if (!this.spartanTimer.hasTimePassed(12)) return;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)8, MinecraftInstance.mc.thePlayer.posZ, true));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - (double)8, MinecraftInstance.mc.thePlayer.posZ, true));
                this.spartanTimer.reset();
                return;
            }
            case "pearl": {
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                Flight $this$onUpdate_u24lambda_u2d3 = this;
                boolean bl = false;
                MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionY = (MinecraftInstance.mc.thePlayer.motionZ = 0.0);
                int n = this.getPearlSlot();
                if (this.pearlState == 0) {
                    if (n == -1) {
                        Client.INSTANCE.getHud().addNotification(new Notification("You don't have any ender pearl!", Notification.Type.ERROR));
                        this.pearlState = -1;
                        this.setState(false);
                        return;
                    }
                    if (MinecraftInstance.mc.thePlayer.inventory.currentItem != n) {
                        MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C09PacketHeldItemChange(n));
                    }
                    MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C05PacketPlayerLook(MinecraftInstance.mc.thePlayer.rotationYaw, 90.0f, MinecraftInstance.mc.thePlayer.onGround));
                    MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(n + 36).getStack(), 0.0f, 0.0f, 0.0f));
                    if (n != MinecraftInstance.mc.thePlayer.inventory.currentItem) {
                        MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.thePlayer.inventory.currentItem));
                    }
                    this.pearlState = 1;
                }
                if (StringsKt.equals((String)((String)this.pearlActivateCheck.get()), (String)"damage", (boolean)true) && this.pearlState == 1 && MinecraftInstance.mc.thePlayer.hurtTime > 0) {
                    this.pearlState = 2;
                }
                if (this.pearlState != 2) return;
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
                    locale = MinecraftInstance.mc.thePlayer;
                    ((EntityPlayerSP)locale).motionY += (double)vanillaSpeed;
                }
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    locale = MinecraftInstance.mc.thePlayer;
                    ((EntityPlayerSP)locale).motionY -= (double)vanillaSpeed;
                    MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                }
                MovementUtils.strafe(vanillaSpeed);
                return;
            }
            case "exploit": {
                if (this.wdState == 0) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.1;
                    int n = this.wdState;
                    this.wdState = n + 1;
                }
                if (this.wdState == 1 && this.wdTick == 3) {
                    int n = this.wdState;
                    this.wdState = n + 1;
                }
                if (this.wdState != 4) return;
                MinecraftInstance.mc.timer.timerSpeed = !this.boostTimer.hasTimePassed(500L) ? 1.6f : (!this.boostTimer.hasTimePassed(800L) ? 1.4f : (!this.boostTimer.hasTimePassed(1000L) ? 1.2f : 1.0f));
                MinecraftInstance.mc.thePlayer.motionY = 1.0E-4;
                MovementUtils.strafe((float)(MovementUtils.getBaseMoveSpeed(1.0) * (MinecraftInstance.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 0.81 : 0.77)));
                return;
            }
            case "neruxvace": {
                if (!MinecraftInstance.mc.thePlayer.onGround) {
                    int n = this.aac3glideDelay;
                    this.aac3glideDelay = n + 1;
                }
                if (this.aac3glideDelay < ((Number)this.neruxVaceTicks.get()).intValue()) return;
                if (MinecraftInstance.mc.thePlayer.onGround) return;
                this.aac3glideDelay = 0;
                MinecraftInstance.mc.thePlayer.motionY = 0.015;
                return;
            }
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        if (MovementUtils.isMoving() && ((Boolean)this.viewBobbingValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.cameraYaw = ((Number)this.bobbingAmountValue.get()).floatValue();
        }
        if (((Boolean)this.fakeYValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.cameraPitch = 0.0f;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"vulcanfast", (boolean)true) && event.getEventState() == EventState.PRE) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ncptest2", (boolean)true)) {
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            entityPlayerSP.posY -= MinecraftInstance.mc.thePlayer.posY - MinecraftInstance.mc.thePlayer.lastTickPosY;
            entityPlayerSP = MinecraftInstance.mc.thePlayer;
            entityPlayerSP.lastTickPosY -= MinecraftInstance.mc.thePlayer.posY - MinecraftInstance.mc.thePlayer.lastTickPosY;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ncptest1", (boolean)true)) {
            AxisAlignedBB bb = MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 1.0, 0.0);
            if (this.fly) {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.025;
                MovementUtilsFix.INSTANCE.theStrafe(8.05);
            }
            if (MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, bb).isEmpty() && !this.fly) {
                this.fly = true;
                MinecraftInstance.mc.thePlayer.jump();
                MovementUtilsFix.INSTANCE.theStrafe(9.0);
            }
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"boosthypixel", (boolean)true)) {
            switch (WhenMappings.$EnumSwitchMapping$1[event.getEventState().ordinal()]) {
                case 1: {
                    this.hypixelTimer.update();
                    if (this.hypixelTimer.hasTimePassed(2)) {
                        MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0E-5, MinecraftInstance.mc.thePlayer.posZ);
                        this.hypixelTimer.reset();
                    }
                    if (this.failedStart) break;
                    MinecraftInstance.mc.thePlayer.motionY = 0.0;
                    break;
                }
                case 2: {
                    double xDist = MinecraftInstance.mc.thePlayer.posX - MinecraftInstance.mc.thePlayer.prevPosX;
                    double zDist = MinecraftInstance.mc.thePlayer.posZ - MinecraftInstance.mc.thePlayer.prevPosZ;
                    this.lastDistance = Math.sqrt(xDist * xDist + zDist * zDist);
                }
            }
        }
        if (event.getEventState() == EventState.PRE && StringsKt.equals((String)((String)this.modeValue.get()), (String)"vulcanclip", (boolean)true)) {
            MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            MinecraftInstance.mc.thePlayer.motionY = -(this.ticks % 2 == 0 ? 0.17 : 0.1);
            if (this.ticks == 0) {
                MinecraftInstance.mc.thePlayer.motionY = -0.07;
            }
            int n = this.ticks;
            this.ticks = n + 1;
        }
        if (event.getEventState() == EventState.PRE && !MinecraftInstance.mc.thePlayer.onGround && StringsKt.equals((String)((String)this.modeValue.get()), (String)"vulcanglide", (boolean)true)) {
            MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            MinecraftInstance.mc.thePlayer.motionY = -(this.ticks % 2 == 0 ? 0.17 : 0.1);
            if (this.ticks == 0) {
                MinecraftInstance.mc.thePlayer.motionY = -0.16;
            }
            int n = this.ticks;
            this.ticks = n + 1;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"minemora", (boolean)true)) {
            if (event.getEventState() != EventState.PRE) {
                return;
            }
            int n = this.tick;
            this.tick = n + 1;
            MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            if (this.tick == 1) {
                MinecraftInstance.mc.timer.timerSpeed = 0.25f;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)3.42f, MinecraftInstance.mc.thePlayer.posZ, false));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, false));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true));
                MinecraftInstance.mc.thePlayer.jump();
            } else {
                if (MovementUtils.isMoving()) {
                    MovementUtils.strafe(1.7f);
                }
                if (MinecraftInstance.mc.gameSettings.keyBindJump.pressed) {
                    MinecraftInstance.mc.thePlayer.motionY = 1.7;
                } else if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
                    MinecraftInstance.mc.thePlayer.motionY = -1.7;
                    if (MinecraftInstance.mc.thePlayer.onGround) {
                        if (this.boostGround) {
                            this.boost = true;
                        } else {
                            this.setState(false);
                        }
                    }
                } else {
                    MinecraftInstance.mc.thePlayer.motionY = 0.0;
                }
            }
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"blockdrop", (boolean)true)) {
            switch (WhenMappings.$EnumSwitchMapping$1[event.getEventState().ordinal()]) {
                case 1: {
                    MinecraftInstance.mc.thePlayer.motionY = MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() ? 2.0 : (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() ? -2.0 : 0.0);
                    for (int var10_8 = 0; var10_8 < 3; ++var10_8) {
                        Vec3 vec3 = this.startVec;
                        Intrinsics.checkNotNull((Object)vec3);
                        double d = vec3.xCoord;
                        Vec3 vec32 = this.startVec;
                        Intrinsics.checkNotNull((Object)vec32);
                        double d2 = vec32.yCoord;
                        Vec3 vec33 = this.startVec;
                        Intrinsics.checkNotNull((Object)vec33);
                        double d3 = vec33.zCoord;
                        Vector2f vector2f = this.rotationVec;
                        Intrinsics.checkNotNull((Object)vector2f);
                        float f = vector2f.getX();
                        Vector2f vector2f2 = this.rotationVec;
                        Intrinsics.checkNotNull((Object)vector2f2);
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(d, d2, d3, f, vector2f2.getY(), false)));
                    }
                    break;
                }
                case 2: {
                    for (int i2 = 0; i2 < 1; ++i2) {
                        double d = MinecraftInstance.mc.thePlayer.posX;
                        double d4 = MinecraftInstance.mc.thePlayer.posY;
                        double d5 = MinecraftInstance.mc.thePlayer.posZ;
                        Vector2f vector2f = this.rotationVec;
                        Intrinsics.checkNotNull((Object)vector2f);
                        float f = vector2f.getX();
                        Vector2f vector2f3 = this.rotationVec;
                        Intrinsics.checkNotNull((Object)vector2f3);
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(d, d4, d5, f, vector2f3.getY(), false)));
                    }
                    break;
                }
            }
        }
        String string = (String)this.modeValue.get();
        Locale i2 = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)i2, (String)"getDefault()");
        String string2 = string.toLowerCase(i2);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "funcraft": {
                event.setOnGround(true);
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                if (MovementUtils.isMoving() && !MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.timer.timerSpeed = 1.65f;
                }
                if (!MovementUtils.isMoving() || MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                    this.moveSpeed = 0.25;
                }
                if (this.moveSpeed > 0.25) {
                    this.moveSpeed -= this.moveSpeed / (double)169;
                }
                if (event.getEventState() == EventState.PRE) {
                    MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 8.0E-6, MinecraftInstance.mc.thePlayer.posZ);
                }
                MovementUtils.strafe((float)this.moveSpeed);
                break;
            }
            case "float": {
                if (event.getEventState() != EventState.PRE) break;
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                break;
            }
            case "zoom": {
                event.setOnGround(true);
                if (!MovementUtils.isMoving()) {
                    this.moveSpeed = 0.25;
                }
                if (this.moveSpeed > 0.25) {
                    this.moveSpeed -= this.moveSpeed / 260.0;
                }
                if (event.getEventState() != EventState.POST) break;
                MinecraftInstance.mc.thePlayer.capabilities.isFlying = false;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                MovementUtils.strafe((float)this.moveSpeed);
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0E-5, MinecraftInstance.mc.thePlayer.posZ);
                break;
            }
            case "exploit": {
                if (event.getEventState() != EventState.PRE) break;
                int n = this.wdTick;
                this.wdTick = n + 1;
                break;
            }
            case "slime": {
                int current = MinecraftInstance.mc.thePlayer.inventory.currentItem;
                if (event.getEventState() == EventState.PRE) {
                    if (this.wdState == 1 && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, -1.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(this.expectItemStack)));
                        this.wdState = 2;
                    }
                    MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                    if (this.wdState == 3 && this.expectItemStack != -1) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(current)));
                        this.expectItemStack = -1;
                    }
                    if (this.wdState == 4) {
                        if (MovementUtils.isMoving()) {
                            MovementUtils.strafe((float)MovementUtils.getBaseMoveSpeed() * 0.938f);
                        } else {
                            MovementUtils.strafe(0.0f);
                        }
                        MinecraftInstance.mc.thePlayer.motionY = -0.0015;
                        break;
                    }
                    if (this.wdState < 3) {
                        Rotation rot = RotationUtils.getRotationFromPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posZ, (int)MinecraftInstance.mc.thePlayer.posY - 1);
                        RotationUtils.setTargetRotation(rot);
                        event.setYaw(rot.getYaw());
                        event.setPitch(rot.getPitch());
                        break;
                    }
                    event.setY(event.getY() - 0.08);
                    break;
                }
                if (this.wdState != 2) break;
                if (MinecraftInstance.mc.playerController.onPlayerRightClick(MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.theWorld, MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(this.expectItemStack).getStack(), new BlockPos(MinecraftInstance.mc.thePlayer.posX, (double)((int)MinecraftInstance.mc.thePlayer.posY - 2), MinecraftInstance.mc.thePlayer.posZ), EnumFacing.UP, RotationUtils.getVectorForRotation(RotationUtils.getRotationFromPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posZ, (int)MinecraftInstance.mc.thePlayer.posY - 1)))) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                }
                this.wdState = 3;
            }
        }
    }

    @EventTarget
    public final void onAction(ActionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        if (string2.equals("exploit") && ((Boolean)this.fakeSprintingValue.get()).booleanValue()) {
            event.setSprinting(false);
        }
    }

    @EventTarget
    public final void onRender2D(@Nullable Render2DEvent event) {
        float width;
        String mode = (String)this.modeValue.get();
        ScaledResolution scaledRes = new ScaledResolution(MinecraftInstance.mc);
        if (StringsKt.equals((String)mode, (String)"Verus", (boolean)true) && this.boostTicks > 0) {
            width = (float)(((Number)this.verusDmgTickValue.get()).intValue() - this.boostTicks) / (float)((Number)this.verusDmgTickValue.get()).intValue() * 60.0f;
            RenderUtils.drawRect((float)scaledRes.getScaledWidth() / 2.0f - 31.0f, (float)scaledRes.getScaledHeight() / 2.0f + 14.0f, (float)scaledRes.getScaledWidth() / 2.0f + 31.0f, (float)scaledRes.getScaledHeight() / 2.0f + 18.0f, -1610612736);
            RenderUtils.drawRect((float)scaledRes.getScaledWidth() / 2.0f - 30.0f, (float)scaledRes.getScaledHeight() / 2.0f + 15.0f, (float)scaledRes.getScaledWidth() / 2.0f - 30.0f + width, (float)scaledRes.getScaledHeight() / 2.0f + 17.0f, -1);
        }
        if (StringsKt.equals((String)mode, (String)"Verus", (boolean)true) && this.shouldActiveDmg) {
            width = (float)(((Number)this.verusReDmgTickValue.get()).intValue() - this.dmgCooldown) / (float)((Number)this.verusReDmgTickValue.get()).intValue() * 60.0f;
            RenderUtils.drawRect((float)scaledRes.getScaledWidth() / 2.0f - 31.0f, (float)scaledRes.getScaledHeight() / 2.0f + 14.0f + 10.0f, (float)scaledRes.getScaledWidth() / 2.0f + 31.0f, (float)scaledRes.getScaledHeight() / 2.0f + 18.0f + 10.0f, -1610612736);
            RenderUtils.drawRect((float)scaledRes.getScaledWidth() / 2.0f - 30.0f, (float)scaledRes.getScaledHeight() / 2.0f + 15.0f + 10.0f, (float)scaledRes.getScaledWidth() / 2.0f - 30.0f + width, (float)scaledRes.getScaledHeight() / 2.0f + 17.0f + 10.0f, -57569);
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        int n;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        String mode = (String)this.modeValue.get();
        if (this.noPacketModify) {
            return;
        }
        if (StringsKt.equals((String)mode, (String)"matrix", (boolean)true) && MinecraftInstance.mc.currentScreen == null && packet instanceof S08PacketPlayerPosLook) {
            TransferUtils.INSTANCE.setNoMotionSet(true);
            if (this.boostMotion == 1) {
                this.boostMotion = 2;
            }
        }
        if (StringsKt.equals((String)mode, (String)"vulcanzoom", (boolean)true)) {
            if (packet instanceof C03PacketPlayer && !this.pog) {
                event.cancelEvent();
            } else if (packet instanceof C03PacketPlayer && (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook)) {
                double deltaX = ((C03PacketPlayer)packet).x - this.lastSentX;
                double deltaY = ((C03PacketPlayer)packet).y - this.lastSentY;
                double deltaZ = ((C03PacketPlayer)packet).z - this.lastSentZ;
                if (Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ) > 9.3) {
                    this.lastSentX = ((C03PacketPlayer)packet).x;
                    this.lastSentY = ((C03PacketPlayer)packet).y;
                    this.lastSentZ = ((C03PacketPlayer)packet).z;
                    return;
                }
                event.cancelEvent();
            } else if (packet instanceof C03PacketPlayer) {
                event.cancelEvent();
            }
            if (packet instanceof S08PacketPlayerPosLook && !this.pog) {
                this.lastSentX = ((S08PacketPlayerPosLook)packet).x;
                this.lastSentY = ((S08PacketPlayerPosLook)packet).y;
                this.lastSentZ = ((S08PacketPlayerPosLook)packet).z;
                this.pog = true;
                MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                event.cancelEvent();
            }
        }
        if (StringsKt.equals((String)mode, (String)"vulcanfast", (boolean)true)) {
            Packet<?> deltaX = packet;
            if (deltaX instanceof C03PacketPlayer) {
                if (this.tickso > 2) {
                    this.tickso = 0;
                    ((C03PacketPlayer)packet).y += 0.5;
                }
                ((C03PacketPlayer)packet).onGround = true;
            } else if (deltaX instanceof S08PacketPlayerPosLook) {
                if (this.stage == FlyStage.WAITING) {
                    n = this.flags;
                    this.flags = n + 1;
                    if (this.flags >= 2) {
                        this.flags = 0;
                        this.stage = FlyStage.FLYING;
                    }
                }
                if (this.stage == FlyStage.WAIT_APPLY) {
                    if (Math.sqrt((((S08PacketPlayerPosLook)packet).x - this.groundX) * (((S08PacketPlayerPosLook)packet).x - this.groundX) + (((S08PacketPlayerPosLook)packet).z - this.groundZ) * (((S08PacketPlayerPosLook)packet).z - this.groundZ)) < 1.4 && ((S08PacketPlayerPosLook)packet).y >= this.groundY - 0.5) {
                        Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
                        if (flight != null) {
                            flight.setState(false);
                        }
                        return;
                    }
                }
                event.cancelEvent();
            } else if (deltaX instanceof C0BPacketEntityAction) {
                event.cancelEvent();
            }
        }
        if (StringsKt.equals((String)mode, (String)"desync", (boolean)true)) {
            if (packet instanceof C03PacketPlayer) {
                double yPos = Math.rint(MinecraftInstance.mc.thePlayer.posY / 0.015625) * 0.015625;
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, yPos, MinecraftInstance.mc.thePlayer.posZ);
                if (MinecraftInstance.mc.thePlayer.ticksExisted % 45 == 0) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 11.725, MinecraftInstance.mc.thePlayer.posZ, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, true)));
                }
            }
            if (packet instanceof S08PacketPlayerPosLook) {
                double z;
                double y;
                if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.thePlayer.ticksExisted <= 0) {
                    return;
                }
                double x = ((S08PacketPlayerPosLook)packet).getX() - MinecraftInstance.mc.thePlayer.posX;
                double diff = Math.sqrt(x * x + (y = ((S08PacketPlayerPosLook)packet).getY() - MinecraftInstance.mc.thePlayer.posY) * y + (z = ((S08PacketPlayerPosLook)packet).getZ() - MinecraftInstance.mc.thePlayer.posZ) * z);
                if (diff <= 8.0) {
                    event.cancelEvent();
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(((S08PacketPlayerPosLook)packet).getX(), ((S08PacketPlayerPosLook)packet).getY(), ((S08PacketPlayerPosLook)packet).getZ(), ((S08PacketPlayerPosLook)packet).getYaw(), ((S08PacketPlayerPosLook)packet).getPitch(), true)));
                }
            }
            if (packet instanceof C0FPacketConfirmTransaction && !this.isInventory(((C0FPacketConfirmTransaction)packet).uid)) {
                int x = 4;
                n = 0;
                while (n < x) {
                    int n2;
                    int it = n2 = n++;
                    boolean bl = false;
                    this.packetLol.add((C0FPacketConfirmTransaction)packet);
                }
                event.cancelEvent();
            }
        }
        if (StringsKt.equals((String)mode, (String)"cubecraft", (boolean)true) && packet instanceof C03PacketPlayer && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            ((C03PacketPlayer)packet).onGround = true;
        }
        if (StringsKt.equals((String)mode, (String)"minemora", (boolean)true)) {
            if (MinecraftInstance.mc.thePlayer == null || this.disableLogger) {
                return;
            }
            if (packet instanceof C03PacketPlayer) {
                event.cancelEvent();
            }
            if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity) {
                event.cancelEvent();
                this.packetBuffer.add(packet);
            }
        }
        if (StringsKt.equals((String)mode, (String)"vulcanclip", (boolean)true) && packet instanceof S08PacketPlayerPosLook && this.waitFlag) {
            this.waitFlag = false;
            MinecraftInstance.mc.thePlayer.setPosition(((S08PacketPlayerPosLook)packet).x, ((S08PacketPlayerPosLook)packet).y, ((S08PacketPlayerPosLook)packet).z);
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false));
            event.cancelEvent();
            MinecraftInstance.mc.thePlayer.jump();
            this.clip(0.127318f, 0.0f);
            this.clip(3.425559f, 3.7f);
            this.clip(3.14285f, 3.54f);
            this.clip(2.88522f, 3.4f);
            this.canGlide = true;
        }
        if (StringsKt.equals((String)mode, (String)"blockdrop", (boolean)true)) {
            if (packet instanceof S08PacketPlayerPosLook) {
                if (MinecraftInstance.mc.thePlayer.ticksExisted <= 20) {
                    return;
                }
                S08PacketPlayerPosLook i2 = (S08PacketPlayerPosLook)event.getPacket();
                event.cancelEvent();
                this.startVec = new Vec3(i2.getX(), i2.getY(), i2.getZ());
                this.rotationVec = new Vector2f(i2.getYaw(), i2.getPitch());
            }
            if (packet instanceof C03PacketPlayer) {
                event.cancelEvent();
                return;
            }
            if (!(packet instanceof C02PacketUseEntity)) {
                return;
            }
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
        }
        if (packet instanceof S08PacketPlayerPosLook && StringsKt.equals((String)mode, (String)"exploit", (boolean)true) && this.wdState == 3) {
            this.wdState = 4;
            if (this.boostTimer.hasTimePassed(8000L)) {
                Client.INSTANCE.getHud().addNotification(new Notification("Exploit Activated!", Notification.Type.SUCCESS));
                this.boostTimer.reset();
            } else {
                Client.INSTANCE.getHud().addNotification(new Notification("Exploit Activated!", Notification.Type.SUCCESS));
            }
            if (((Boolean)this.fakeDmgValue.get()).booleanValue() && MinecraftInstance.mc.thePlayer != null) {
                MinecraftInstance.mc.thePlayer.handleStatusUpdate((byte)2);
            }
        }
        if (packet instanceof C09PacketHeldItemChange && StringsKt.equals((String)mode, (String)"slime", (boolean)true) && this.wdState < 4) {
            event.cancelEvent();
        }
        if (packet instanceof S08PacketPlayerPosLook) {
            if (StringsKt.equals((String)mode, (String)"slime", (boolean)true) && this.wdState == 3) {
                this.wdState = 4;
                if (((Boolean)this.fakeDmgValue.get()).booleanValue() && MinecraftInstance.mc.thePlayer != null) {
                    MinecraftInstance.mc.thePlayer.handleStatusUpdate((byte)2);
                }
            }
            if (StringsKt.equals((String)mode, (String)"pearl", (boolean)true) && StringsKt.equals((String)((String)this.pearlActivateCheck.get()), (String)"teleport", (boolean)true) && this.pearlState == 1) {
                this.pearlState = 2;
            }
            if (StringsKt.equals((String)mode, (String)"BoostHypixel", (boolean)true)) {
                this.failedStart = true;
            }
        }
        if (packet instanceof C03PacketPlayer) {
            Packet<?> packetPlayer = packet;
            if (StringsKt.equals((String)mode, (String)"NCP", (boolean)true) || StringsKt.equals((String)mode, (String)"Verus", (boolean)true) && ((Boolean)this.verusSpoofGround.get()).booleanValue() && this.verusDmged) {
                ((C03PacketPlayer)packetPlayer).onGround = true;
            }
            if (StringsKt.equals((String)mode, (String)"BoostHypixel", (boolean)true)) {
                ((C03PacketPlayer)packetPlayer).onGround = false;
            }
            if (StringsKt.equals((String)mode, (String)"AAC5-Vanilla", (boolean)true) && !MinecraftInstance.mc.isIntegratedServerRunning()) {
                if (((Boolean)this.aac5NofallValue.get()).booleanValue()) {
                    ((C03PacketPlayer)packetPlayer).onGround = true;
                }
                this.aac5C03List.add((C03PacketPlayer)packetPlayer);
                event.cancelEvent();
                if (this.aac5C03List.size() > ((Number)this.aac5PursePacketsValue.get()).intValue()) {
                    this.sendAAC5Packets();
                }
            }
            if (StringsKt.equals((String)mode, (String)"clip", (boolean)true) && ((Boolean)this.clipGroundSpoof.get()).booleanValue()) {
                ((C03PacketPlayer)packetPlayer).onGround = true;
            }
            if ((StringsKt.equals((String)mode, (String)"motion", (boolean)true) || StringsKt.equals((String)mode, (String)"creative", (boolean)true) || StringsKt.equals((String)mode, (String)"noclip", (boolean)true)) && ((Boolean)this.groundSpoofValue.get()).booleanValue()) {
                ((C03PacketPlayer)packetPlayer).onGround = true;
            }
            if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) && this.verusJumpTimes < 5 && StringsKt.equals((String)mode, (String)"Verus", (boolean)true)) {
                ((C03PacketPlayer)packetPlayer).onGround = false;
            }
            if (StringsKt.equals((String)mode, (String)"exploit", (boolean)true)) {
                if (this.wdState == 2) {
                    ((C03PacketPlayer)packetPlayer).y -= 0.187;
                    n = this.wdState;
                    this.wdState = n + 1;
                }
                if (this.wdState > 3 && ((Boolean)this.fakeNoMoveValue.get()).booleanValue()) {
                    ((C03PacketPlayer)packetPlayer).setMoving(false);
                }
            }
        }
    }

    private final void clip(float dist, float y) {
        double yaw = Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw);
        double x = -Math.sin(yaw) * (double)dist;
        double z = Math.cos(yaw) * (double)dist;
        MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX + x, MinecraftInstance.mc.thePlayer.posY + (double)y, MinecraftInstance.mc.thePlayer.posZ + z);
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, false));
    }

    private final void sendAAC5Packets() {
        float yaw = MinecraftInstance.mc.thePlayer.rotationYaw;
        float pitch = MinecraftInstance.mc.thePlayer.rotationPitch;
        for (C03PacketPlayer packet : this.aac5C03List) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)packet));
            if (!packet.isMoving()) continue;
            if (packet.getRotating()) {
                yaw = packet.yaw;
                pitch = packet.pitch;
            }
            switch ((String)this.aac5Packet.get()) {
                case "Original": {
                    if (((Boolean)this.aac5UseC04Packet.get()).booleanValue()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, 1.0E159, packet.z, true)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, packet.y, packet.z, true)));
                        break;
                    }
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, 1.0E159, packet.z, yaw, pitch, true)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, packet.y, packet.z, yaw, pitch, true)));
                    break;
                }
                case "Rise": {
                    if (((Boolean)this.aac5UseC04Packet.get()).booleanValue()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, -1.0E159, packet.z + (double)10, true)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, packet.y, packet.z, true)));
                        break;
                    }
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, -1.0E159, packet.z + (double)10, yaw, pitch, true)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, packet.y, packet.z, yaw, pitch, true)));
                    break;
                }
                case "Other": {
                    if (((Boolean)this.aac5UseC04Packet.get()).booleanValue()) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, Double.MAX_VALUE, packet.z, true)));
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(packet.x, packet.y, packet.z, true)));
                        break;
                    }
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, Double.MAX_VALUE, packet.z, yaw, pitch, true)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(packet.x, packet.y, packet.z, yaw, pitch, true)));
                }
            }
        }
        this.aac5C03List.clear();
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "pearl": {
                if (this.pearlState == 2 || this.pearlState == -1) break;
                event.cancelEvent();
                break;
            }
            case "verus": {
                if (this.verusDmged) break;
                if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true)) {
                    event.zeroXZ();
                    break;
                }
                event.cancelEvent();
                break;
            }
            case "clip": {
                if (!((Boolean)this.clipNoMove.get()).booleanValue()) break;
                event.zeroXZ();
                break;
            }
            case "veruslowhop": {
                if (MinecraftInstance.mc.thePlayer.isInWeb || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isOnLadder() || MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() || MinecraftInstance.mc.thePlayer.ridingEntity != null || !MovementUtils.isMoving()) break;
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = false;
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.jump();
                    MinecraftInstance.mc.thePlayer.motionY = 0.0;
                    MovementUtils.strafe(0.61f);
                    event.setY(0.41999998688698);
                }
                MovementUtils.strafe();
                break;
            }
            case "slime": {
                if (this.wdState >= 4) break;
                event.zeroXZ();
                break;
            }
            case "sentinel": {
                if (MovementUtils.isMoving() && this.cubecraftTeleportTickTimer.hasTimePassed(2)) {
                    event.setX(-Math.sin(Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw)) * 2.4);
                    event.setZ(Math.cos(Math.toRadians(MinecraftInstance.mc.thePlayer.rotationYaw)) * 2.4);
                    this.cubecraftTeleportTickTimer.reset();
                }
                if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() && this.cubecraftTeleportYTickTimer.hasTimePassed(2)) {
                    event.setY(1.6);
                    this.cubecraftTeleportYTickTimer.reset();
                }
                if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak) || !this.cubecraftTeleportYDownTickTimer.hasTimePassed(2)) break;
                event.setY(-1.6);
                this.cubecraftTeleportYDownTickTimer.reset();
                break;
            }
            case "boosthypixel": {
                if (!MovementUtils.isMoving()) {
                    event.setX(0.0);
                    event.setZ(0.0);
                }
                double amplifier = 1.0;
                if (MinecraftInstance.mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
                    double cfr_ignored_0 = 1.2 * (double)(MinecraftInstance.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
                }
                double baseSpeed = 0.29 * amplifier;
                switch (this.boostHypixelState) {
                    case 1: {
                        this.moveSpeed = (MinecraftInstance.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.034) * baseSpeed;
                        this.boostHypixelState = 2;
                        break;
                    }
                    case 2: {
                        this.moveSpeed *= 2.16;
                        this.boostHypixelState = 3;
                        break;
                    }
                    case 3: {
                        this.moveSpeed = this.lastDistance - (MinecraftInstance.mc.thePlayer.ticksExisted % 2 == 0 ? 0.0103 : 0.0123) * (this.lastDistance - baseSpeed);
                        this.boostHypixelState = 4;
                        break;
                    }
                    default: {
                        this.moveSpeed = this.lastDistance - this.lastDistance / 159.8;
                    }
                }
                this.moveSpeed = Math.max(this.moveSpeed, 0.3);
                double yaw = MovementUtils.getDirection();
                event.setX(-Math.sin(yaw) * this.moveSpeed);
                event.setZ(Math.cos(yaw) * this.moveSpeed);
                MinecraftInstance.mc.thePlayer.motionX = event.getX();
                MinecraftInstance.mc.thePlayer.motionZ = event.getZ();
            }
        }
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        String mode = (String)this.modeValue.get();
        if (event.getBlock() instanceof BlockAir && (StringsKt.equals((String)mode, (String)"BoostHypixel", (boolean)true) || StringsKt.equals((String)mode, (String)"Verus", (boolean)true)) && (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"none", (boolean)true) || this.verusDmged) && (double)event.getY() < MinecraftInstance.mc.thePlayer.posY) {
            event.setBoundingBox(AxisAlignedBB.fromBounds((double)event.getX(), (double)event.getY(), (double)event.getZ(), (double)(event.getX() + 1), (double)MinecraftInstance.mc.thePlayer.posY, (double)(event.getZ() + 1)));
        }
        if ((StringsKt.equals((String)mode, (String)"Jump", (boolean)true) || StringsKt.equals((String)mode, (String)"VulcanZoom", (boolean)true)) && (double)event.getY() < this.startY) {
            event.setBoundingBox(AxisAlignedBB.fromBounds((double)event.getX(), (double)event.getY(), (double)event.getZ(), (double)((double)event.getX() + 1.0), (double)this.startY, (double)((double)event.getZ() + 1.0)));
        }
        if (event.getBlock() instanceof BlockAir && StringsKt.equals((String)mode, (String)"FakeGround", (boolean)true) && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak) || event.getBlock() instanceof BlockAir && StringsKt.equals((String)mode, (String)"Cubecraft", (boolean)true) && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak) || StringsKt.equals((String)mode, (String)"VerusLowHop", (boolean)true) && !GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            event.setBoundingBox(new AxisAlignedBB(-2.0, -1.0, -2.0, 2.0, 1.0, 2.0).offset((double)event.getX(), (double)event.getY(), (double)event.getZ()));
        }
    }

    @EventTarget
    public final void onJump(JumpEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"BoostHypixel", (boolean)true) || StringsKt.equals((String)mode, (String)"funcraft", (boolean)true) && this.moveSpeed > 0.0 || StringsKt.equals((String)mode, (String)"exploit", (boolean)true) && this.wdState >= 1 || StringsKt.equals((String)mode, (String)"slime", (boolean)true) && this.wdState >= 1) {
            e.cancelEvent();
        }
        if (StringsKt.equals((String)mode, (String)"ncptest2", (boolean)true)) {
            this.c = true;
        }
    }

    @EventTarget
    public final void onStep(StepEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"BoostHypixel", (boolean)true) || StringsKt.equals((String)mode, (String)"funcraft", (boolean)true) || StringsKt.equals((String)mode, (String)"exploit", (boolean)true) && this.wdState > 2 || StringsKt.equals((String)mode, (String)"slime", (boolean)true)) {
            e.setStepHeight(0.0f);
        }
    }

    private final double calculateGround() {
        AxisAlignedBB playerBoundingBox = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
        double blockHeight = 1.0;
        for (double ground = MinecraftInstance.mc.thePlayer.posY; ground > 0.0; ground -= blockHeight) {
            AxisAlignedBB customBox = new AxisAlignedBB(playerBoundingBox.maxX, ground + blockHeight, playerBoundingBox.maxZ, playerBoundingBox.minX, ground, playerBoundingBox.minZ);
            if (!MinecraftInstance.mc.theWorld.checkBlockCollision(customBox)) continue;
            if (blockHeight <= 0.05) {
                return ground + blockHeight;
            }
            ground += blockHeight;
            blockHeight = 0.05;
        }
        return 0.0;
    }

    private final int getPearlSlot() {
        int n = 36;
        while (n < 45) {
            int i;
            ItemStack stack;
            if ((stack = MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(i = n++).getStack()) == null || !(stack.getItem() instanceof ItemEnderPearl)) continue;
            return i - 36;
        }
        return -1;
    }

    private final int getSlimeSlot() {
        int n = 36;
        while (n < 45) {
            int i;
            ItemStack stack;
            if ((stack = MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(i = n++).getStack()) == null || stack.getItem() == null || !(stack.getItem() instanceof ItemBlock)) continue;
            Item item = stack.getItem();
            if (item == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemBlock");
            }
            ItemBlock itemBlock = (ItemBlock)item;
            if (!(itemBlock.getBlock() instanceof BlockSlime)) continue;
            return i - 36;
        }
        return -1;
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public static final /* synthetic */ ListValue access$getVerusDmgModeValue$p(Flight $this) {
        return $this.verusDmgModeValue;
    }

    public static final /* synthetic */ BoolValue access$getVerusReDamageValue$p(Flight $this) {
        return $this.verusReDamageValue;
    }

    public static final /* synthetic */ BoolValue access$getVerusVisualValue$p(Flight $this) {
        return $this.verusVisualValue;
    }

    public static final /* synthetic */ ListValue access$getBypassMode$p(Flight $this) {
        return $this.bypassMode;
    }

    public static final /* synthetic */ BoolValue access$getViewBobbingValue$p(Flight $this) {
        return $this.viewBobbingValue;
    }

    public static final class FlyStage
    extends Enum<FlyStage> {
        public static final /* enum */ FlyStage WAITING = new FlyStage();
        public static final /* enum */ FlyStage FLYING = new FlyStage();
        public static final /* enum */ FlyStage WAIT_APPLY = new FlyStage();
        private static final /* synthetic */ FlyStage[] $VALUES;

        public static FlyStage[] values() {
            return (FlyStage[])$VALUES.clone();
        }

        public static FlyStage valueOf(String value) {
            return Enum.valueOf(FlyStage.class, value);
        }

        static {
            $VALUES = flyStageArray = new FlyStage[]{FlyStage.WAITING, FlyStage.FLYING, FlyStage.WAIT_APPLY};
        }
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;
        public static final /* synthetic */ int[] $EnumSwitchMapping$1;

        static {
            int[] nArray = new int[FlyStage.values().length];
            nArray[FlyStage.FLYING.ordinal()] = 1;
            nArray[FlyStage.WAITING.ordinal()] = 2;
            nArray[FlyStage.WAIT_APPLY.ordinal()] = 3;
            $EnumSwitchMapping$0 = nArray;
            nArray = new int[EventState.values().length];
            nArray[EventState.PRE.ordinal()] = 1;
            nArray[EventState.POST.ordinal()] = 2;
            $EnumSwitchMapping$1 = nArray;
        }
    }
}

