/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

@ModuleInfo(name="AirPlace", spacedName="Air Place", description="", category=ModuleCategory.PLAYER)
public final class AirPlace
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            MinecraftInstance.mc.playerController.onPlayerRightClick(MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.theWorld, MinecraftInstance.mc.thePlayer.getHeldItem(), new BlockPos((Entity)MinecraftInstance.mc.thePlayer).down(1), MinecraftInstance.mc.thePlayer.getHorizontalFacing(), new Vec3(0.0, 0.0, 0.0));
        } else {
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
            MinecraftInstance.mc.playerController.onPlayerRightClick(MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.theWorld, MinecraftInstance.mc.thePlayer.getHeldItem(), new BlockPos((Entity)MinecraftInstance.mc.thePlayer).down(2), MinecraftInstance.mc.thePlayer.getHorizontalFacing(), new Vec3(0.0, 0.0, 0.0));
        }
    }
}

