/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.client.C16PacketClientStatus
 *  net.minecraft.network.play.client.C16PacketClientStatus$EnumState
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.combat;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.injection.implementations.IItemStack;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.item.ArmorComparator;
import net.aspw.client.util.item.ArmorPiece;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="AutoArmor", spacedName="Auto Armor", description="", category=ModuleCategory.COMBAT)
public final class AutoArmor
extends Module {
    public static final Companion Companion = new Companion(null);
    private final BoolValue invOpenValue = new BoolValue("InvOpen", false);
    private final BoolValue simulateInventory = new BoolValue("SimulateInventory", false);
    private final IntegerValue maxDelayValue = new IntegerValue(this){
        final /* synthetic */ AutoArmor this$0;
        {
            this.this$0 = $receiver;
            super("MaxDelay", 14, 0, 1000);
        }

        protected void onChanged(int oldValue, int newValue) {
            int minDelay = ((Number)AutoArmor.access$getMinDelayValue$p(this.this$0).get()).intValue();
            if (minDelay > newValue) {
                this.set(minDelay);
            }
        }
    };
    private final IntegerValue minDelayValue = new IntegerValue(this){
        final /* synthetic */ AutoArmor this$0;
        {
            this.this$0 = $receiver;
            super("MinDelay", 10, 0, 1000);
        }

        protected void onChanged(int oldValue, int newValue) {
            int maxDelay = ((Number)AutoArmor.access$getMaxDelayValue$p(this.this$0).get()).intValue();
            if (maxDelay < newValue) {
                this.set(maxDelay);
            }
        }
    };
    private final BoolValue animationValue = new BoolValue("Animation", false);
    private final BoolValue noMoveValue = new BoolValue("NoMove", false);
    private final BoolValue hotbarValue = new BoolValue("Hotbar", false);
    private long delay;
    private static final ArmorComparator ARMOR_COMPARATOR = new ArmorComparator();

    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        if (!InventoryUtils.CLICK_TIMER.hasTimePassed(this.delay) || MinecraftInstance.mc.thePlayer.openContainer != null && MinecraftInstance.mc.thePlayer.openContainer.windowId != 0) {
            return;
        }
        Map<Integer, List<ArmorPiece>> armorPieces = IntStream.range(0, 36).filter(AutoArmor::onRender3D$lambda-0).mapToObj(AutoArmor::onRender3D$lambda-1).collect(Collectors.groupingBy(AutoArmor::onRender3D$lambda-2));
        ArmorPiece[] bestArmor = new ArmorPiece[4];
        Intrinsics.checkNotNullExpressionValue(armorPieces, (String)"armorPieces");
        for (Map.Entry<Integer, List<ArmorPiece>> entry : armorPieces.entrySet()) {
            Integer key = entry.getKey();
            List<ArmorPiece> value = entry.getValue();
            Intrinsics.checkNotNullExpressionValue((Object)key, (String)"key");
            bestArmor[key.intValue()] = value.stream().max(ARMOR_COMPARATOR).orElse(null);
        }
        int n = 0;
        while (n < 4) {
            ArmorPiece armorPiece;
            int armorSlot;
            ArmorPiece oldArmor;
            int i;
            if (bestArmor[i = n++] == null || (oldArmor = new ArmorPiece(MinecraftInstance.mc.thePlayer.inventory.armorItemInSlot(armorSlot = 3 - i), -1)).getItemStack() != null && oldArmor.getItemStack().getItem() instanceof ItemArmor && ARMOR_COMPARATOR.compare(oldArmor, armorPiece) >= 0) continue;
            if (oldArmor.getItemStack() != null && this.move(8 - armorSlot, true)) {
                return;
            }
            if (MinecraftInstance.mc.thePlayer.inventory.armorItemInSlot(armorSlot) != null || !this.move(armorPiece.getSlot(), false)) continue;
            return;
        }
    }

    private final boolean move(int item, boolean isArmorSlot) {
        if (!isArmorSlot && item < 9 && ((Boolean)this.hotbarValue.get()).booleanValue() && !(MinecraftInstance.mc.currentScreen instanceof GuiInventory)) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(item));
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(item).getStack()));
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.thePlayer.inventory.currentItem));
            if (((Boolean)this.animationValue.get()).booleanValue()) {
                MinecraftInstance.mc.getItemRenderer().resetEquippedProgress2();
            }
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            return true;
        }
        if (!(((Boolean)this.noMoveValue.get()).booleanValue() && MovementUtils.isMoving() || ((Boolean)this.invOpenValue.get()).booleanValue() && !(MinecraftInstance.mc.currentScreen instanceof GuiInventory) || item == -1)) {
            boolean openInventory;
            boolean bl = openInventory = (Boolean)this.simulateInventory.get() != false && !(MinecraftInstance.mc.currentScreen instanceof GuiInventory);
            if (openInventory) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
            }
            MinecraftInstance.mc.playerController.windowClick(MinecraftInstance.mc.thePlayer.inventoryContainer.windowId, isArmorSlot ? item : (item < 9 ? item + 36 : item), 0, 1, (EntityPlayer)MinecraftInstance.mc.thePlayer);
            if (((Boolean)this.animationValue.get()).booleanValue()) {
                MinecraftInstance.mc.getItemRenderer().resetEquippedProgress2();
            }
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            if (openInventory) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0DPacketCloseWindow());
            }
            return true;
        }
        return false;
    }

    private static final boolean onRender3D$lambda-0(int i) {
        ItemStack itemStack = MinecraftInstance.mc.thePlayer.inventory.getStackInSlot(i);
        return itemStack != null && itemStack.getItem() instanceof ItemArmor && (i < 9 || System.currentTimeMillis() - ((IItemStack)itemStack).getItemDelay() >= 200L);
    }

    private static final ArmorPiece onRender3D$lambda-1(int i) {
        return new ArmorPiece(MinecraftInstance.mc.thePlayer.inventory.getStackInSlot(i), i);
    }

    private static final Integer onRender3D$lambda-2(ArmorPiece obj) {
        ArmorPiece armorPiece = obj;
        Intrinsics.checkNotNull((Object)armorPiece);
        return armorPiece.getArmorType();
    }

    public static final /* synthetic */ IntegerValue access$getMinDelayValue$p(AutoArmor $this) {
        return $this.minDelayValue;
    }

    public static final /* synthetic */ IntegerValue access$getMaxDelayValue$p(AutoArmor $this) {
        return $this.maxDelayValue;
    }

    public static final class Companion {
        private Companion() {
        }

        public final ArmorComparator getARMOR_COMPARATOR() {
            return ARMOR_COMPARATOR;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

