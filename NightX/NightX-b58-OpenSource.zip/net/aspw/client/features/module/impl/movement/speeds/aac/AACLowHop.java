/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACLowHop
extends SpeedMode {
    private boolean legitJump;

    public AACLowHop() {
        super("AACLowHop");
    }

    @Override
    public void onEnable() {
        this.legitJump = true;
        super.onEnable();
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving()) {
            if (AACLowHop.mc.thePlayer.onGround) {
                if (this.legitJump) {
                    AACLowHop.mc.thePlayer.jump();
                    this.legitJump = false;
                    return;
                }
                AACLowHop.mc.thePlayer.motionY = 0.343f;
                MovementUtils.strafe(0.534f);
            }
        } else {
            this.legitJump = true;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

