/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityBoat
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C0CPacketInput
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.util.Vec3;

@ModuleInfo(name="EntityJump", spacedName="Entity Jump", description="", category=ModuleCategory.MOVEMENT)
public final class EntityJump
extends Module {
    private final ListValue modeValue;
    private final FloatValue hBoostValue;
    private final FloatValue vBoostValue;
    private final FloatValue matrixTimerStartValue;
    private final FloatValue matrixTimerAirValue;
    private final FloatValue launchRadiusValue;
    private final IntegerValue delayValue;
    private final BoolValue autoHitValue;
    private int jumpState;
    private final MSTimer timer;
    private final MSTimer hitTimer;
    private boolean lastRide;
    private boolean hasStopped;

    public EntityJump() {
        String[] stringArray = new String[]{"Boost", "Launch", "Matrix"};
        this.modeValue = new ListValue("Mode", stringArray, "Boost");
        this.hBoostValue = new FloatValue("HBoost", 2.0f, 0.0f, 6.0f);
        this.vBoostValue = new FloatValue("VBoost", 2.0f, 0.0f, 6.0f);
        this.matrixTimerStartValue = new FloatValue("MatrixTimerStart", 0.3f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ EntityJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return EntityJump.access$getModeValue$p(this.this$0).equals("Matrix");
            }
        }));
        this.matrixTimerAirValue = new FloatValue("MatrixTimerAir", 0.5f, 0.1f, 1.5f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ EntityJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return EntityJump.access$getModeValue$p(this.this$0).equals("Matrix");
            }
        }));
        this.launchRadiusValue = new FloatValue("LaunchRadius", 4.0f, 3.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ EntityJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return EntityJump.access$getModeValue$p(this.this$0).equals("Launch");
            }
        }));
        this.delayValue = new IntegerValue("Delay", 200, 100, 500);
        this.autoHitValue = new BoolValue("AutoDestroy", false);
        this.jumpState = 1;
        this.timer = new MSTimer();
        this.hitTimer = new MSTimer();
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @Override
    public void onEnable() {
        this.jumpState = 1;
        this.lastRide = false;
    }

    @Override
    public void onDisable() {
        this.hasStopped = false;
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        block23: {
            block22: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (MinecraftInstance.mc.thePlayer.onGround && !MinecraftInstance.mc.thePlayer.isRiding()) {
                    this.hasStopped = false;
                    MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                }
                String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
                if (string.equals("matrix")) {
                    MinecraftInstance.mc.timer.timerSpeed = this.hasStopped ? ((Number)this.matrixTimerAirValue.get()).floatValue() : 1.0f;
                }
                if (!MinecraftInstance.mc.thePlayer.isRiding() || this.jumpState != 1) break block22;
                if (!this.lastRide) {
                    this.timer.reset();
                }
                if (this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
                    this.jumpState = 2;
                    string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
                    Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
                    if (string.equals("matrix")) {
                        MinecraftInstance.mc.timer.timerSpeed = ((Number)this.matrixTimerStartValue.get()).floatValue();
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0CPacketInput(MinecraftInstance.mc.thePlayer.moveStrafing, MinecraftInstance.mc.thePlayer.moveForward, false, true));
                    } else {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0CPacketInput(MinecraftInstance.mc.thePlayer.moveStrafing, MinecraftInstance.mc.thePlayer.moveForward, false, true));
                    }
                }
                break block23;
            }
            if (this.jumpState != 2 || MinecraftInstance.mc.thePlayer.isRiding()) break block23;
            double radiansYaw = (double)MinecraftInstance.mc.thePlayer.rotationYaw * Math.PI / (double)180;
            String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
            switch (string) {
                case "boost": {
                    MinecraftInstance.mc.thePlayer.motionX = ((Number)this.hBoostValue.get()).doubleValue() * -Math.sin(radiansYaw);
                    MinecraftInstance.mc.thePlayer.motionZ = ((Number)this.hBoostValue.get()).doubleValue() * Math.cos(radiansYaw);
                    MinecraftInstance.mc.thePlayer.motionY = ((Number)this.vBoostValue.get()).floatValue();
                    this.jumpState = 1;
                    break;
                }
                case "launch": {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX += ((Number)this.hBoostValue.get()).doubleValue() * 0.1 * -Math.sin(radiansYaw);
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ += ((Number)this.hBoostValue.get()).doubleValue() * 0.1 * Math.cos(radiansYaw);
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += ((Number)this.vBoostValue.get()).doubleValue() * 0.1;
                    boolean hasBoat = false;
                    for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
                        if (!(entity instanceof EntityBoat) || !(MinecraftInstance.mc.thePlayer.getDistanceToEntity(entity) < ((Number)this.launchRadiusValue.get()).floatValue())) continue;
                        hasBoat = true;
                        break;
                    }
                    if (hasBoat) break;
                    this.jumpState = 1;
                    break;
                }
                case "matrix": {
                    this.hasStopped = true;
                    MinecraftInstance.mc.timer.timerSpeed = ((Number)this.matrixTimerAirValue.get()).floatValue();
                    MinecraftInstance.mc.thePlayer.motionX = ((Number)this.hBoostValue.get()).doubleValue() * -Math.sin(radiansYaw);
                    MinecraftInstance.mc.thePlayer.motionZ = ((Number)this.hBoostValue.get()).doubleValue() * Math.cos(radiansYaw);
                    MinecraftInstance.mc.thePlayer.motionY = ((Number)this.vBoostValue.get()).floatValue();
                    this.jumpState = 1;
                }
            }
            this.timer.reset();
            this.hitTimer.reset();
        }
        this.lastRide = MinecraftInstance.mc.thePlayer.isRiding();
        if (((Boolean)this.autoHitValue.get()).booleanValue() && !MinecraftInstance.mc.thePlayer.isRiding() && this.hitTimer.hasTimePassed(1500L)) {
            for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
                if (!(entity instanceof EntityBoat) || !(MinecraftInstance.mc.thePlayer.getDistanceToEntity(entity) < 3.0f)) continue;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity(entity, new Vec3(0.5, 0.5, 0.5)));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity(entity, C02PacketUseEntity.Action.INTERACT));
                this.hitTimer.reset();
            }
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(EntityJump $this) {
        return $this.modeValue;
    }
}

