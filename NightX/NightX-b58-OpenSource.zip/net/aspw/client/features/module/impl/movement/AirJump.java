/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;

@ModuleInfo(name="AirJump", spacedName="Air Jump", description="", category=ModuleCategory.MOVEMENT)
public final class AirJump
extends Module {
}

