/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Mouse;

@ModuleInfo(name="GodBridge", spacedName="God Bridge", description="", category=ModuleCategory.PLAYER)
public final class GodBridge
extends Module {
    private final FloatValue dl = new FloatValue("Delay", 0.0f, 0.0f, 10.0f);
    private final BoolValue md = new BoolValue("MouseDown", true);
    private long l;
    private int f;
    private MovingObjectPosition lm;
    private BlockPos lp;

    @EventTarget
    public final void onRender(Render3DEvent event) {
        block5: {
            long n;
            Block b;
            BlockPos pos;
            MovingObjectPosition m;
            ItemStack i;
            block7: {
                block6: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    if (MinecraftInstance.mc.currentScreen != null || MinecraftInstance.mc.thePlayer.capabilities.isFlying || (i = MinecraftInstance.mc.thePlayer.getHeldItem()) == null || !(i.getItem() instanceof ItemBlock) || ((m = MinecraftInstance.mc.objectMouseOver) == null || m.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK || m.sideHit == EnumFacing.UP || m.sideHit == EnumFacing.DOWN) && m.sideHit != EnumFacing.NORTH && m.sideHit != EnumFacing.EAST && m.sideHit != EnumFacing.SOUTH && m.sideHit != EnumFacing.WEST) break block5;
                    if (this.lm == null || !((double)this.f < (double)((Number)this.dl.get()).floatValue())) break block6;
                    ++this.f;
                    break block5;
                }
                this.lm = m;
                pos = m.getBlockPos();
                if (this.lp == null) break block7;
                int n2 = pos.getX();
                BlockPos blockPos = this.lp;
                Intrinsics.checkNotNull((Object)blockPos);
                if (n2 != blockPos.getX()) break block7;
                int n3 = pos.getY();
                BlockPos blockPos2 = this.lp;
                Intrinsics.checkNotNull((Object)blockPos2);
                if (n3 != blockPos2.getY()) break block7;
                int n4 = pos.getZ();
                BlockPos blockPos3 = this.lp;
                Intrinsics.checkNotNull((Object)blockPos3);
                if (n4 == blockPos3.getZ()) break block5;
            }
            if (!((b = MinecraftInstance.mc.theWorld.getBlockState(pos).getBlock()) == null || b == Blocks.air || b instanceof BlockLiquid || ((Boolean)this.md.get()).booleanValue() && !Mouse.isButtonDown((int)1) || (n = System.currentTimeMillis()) - this.l < 25L)) {
                this.l = n;
                if (MinecraftInstance.mc.playerController.onPlayerRightClick(MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.theWorld, i, pos, m.sideHit, m.hitVec)) {
                    MouseUtils.INSTANCE.setMouseButtonState(1, true);
                    MinecraftInstance.mc.thePlayer.swingItem();
                    MinecraftInstance.mc.getItemRenderer().resetEquippedProgress();
                    MouseUtils.INSTANCE.setMouseButtonState(1, false);
                    this.lp = pos;
                    this.f = 0;
                }
            }
        }
    }
}

