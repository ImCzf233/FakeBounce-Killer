/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC3BHop
extends SpeedMode {
    private boolean legitJump;

    public AAC3BHop() {
        super("AAC3BHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onTick() {
        AAC3BHop.mc.timer.timerSpeed = 1.0f;
        if (AAC3BHop.mc.thePlayer.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (AAC3BHop.mc.thePlayer.onGround) {
                if (this.legitJump) {
                    AAC3BHop.mc.thePlayer.jump();
                    this.legitJump = false;
                    return;
                }
                AAC3BHop.mc.thePlayer.motionY = 0.3852;
                AAC3BHop.mc.thePlayer.onGround = false;
                MovementUtils.strafe(0.374f);
            } else if (AAC3BHop.mc.thePlayer.motionY < 0.0) {
                AAC3BHop.mc.thePlayer.speedInAir = 0.0201f;
                AAC3BHop.mc.timer.timerSpeed = 1.02f;
            } else {
                AAC3BHop.mc.timer.timerSpeed = 1.01f;
            }
        } else {
            this.legitJump = true;
        }
    }
}

