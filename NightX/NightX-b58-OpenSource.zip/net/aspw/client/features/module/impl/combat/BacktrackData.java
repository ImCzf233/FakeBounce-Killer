/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.combat;

import org.jetbrains.annotations.Nullable;

public final class BacktrackData {
    private final double x;
    private final double y;
    private final double z;
    private final long time;

    public BacktrackData(double x, double y, double z, long time) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.time = time;
    }

    public final double getX() {
        return this.x;
    }

    public final double getY() {
        return this.y;
    }

    public final double getZ() {
        return this.z;
    }

    public final long getTime() {
        return this.time;
    }

    public final double component1() {
        return this.x;
    }

    public final double component2() {
        return this.y;
    }

    public final double component3() {
        return this.z;
    }

    public final long component4() {
        return this.time;
    }

    public final BacktrackData copy(double x, double y, double z, long time) {
        return new BacktrackData(x, y, z, time);
    }

    public static /* synthetic */ BacktrackData copy$default(BacktrackData backtrackData, double d, double d2, double d3, long l, int n, Object object) {
        if ((n & 1) != 0) {
            d = backtrackData.x;
        }
        if ((n & 2) != 0) {
            d2 = backtrackData.y;
        }
        if ((n & 4) != 0) {
            d3 = backtrackData.z;
        }
        if ((n & 8) != 0) {
            l = backtrackData.time;
        }
        return backtrackData.copy(d, d2, d3, l);
    }

    public String toString() {
        return "BacktrackData(x=" + this.x + ", y=" + this.y + ", z=" + this.z + ", time=" + this.time + ')';
    }

    public int hashCode() {
        int result = Double.hashCode(this.x);
        result = result * 31 + Double.hashCode(this.y);
        result = result * 31 + Double.hashCode(this.z);
        result = result * 31 + Long.hashCode(this.time);
        return result;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof BacktrackData)) {
            return false;
        }
        BacktrackData backtrackData = (BacktrackData)other;
        if (!((Object)this.x).equals(backtrackData.x)) {
            return false;
        }
        if (!((Object)this.y).equals(backtrackData.y)) {
            return false;
        }
        if (!((Object)this.z).equals(backtrackData.z)) {
            return false;
        }
        return this.time == backtrackData.time;
    }
}

