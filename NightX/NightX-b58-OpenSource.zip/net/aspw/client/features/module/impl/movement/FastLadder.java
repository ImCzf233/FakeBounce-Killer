/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLadder
 *  net.minecraft.block.BlockVine
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.FastLadder;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockVine;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="FastLadder", spacedName="Fast Ladder", description="", category=ModuleCategory.MOVEMENT)
public final class FastLadder
extends Module {
    private final ListValue modeValue;
    private final FloatValue upSpeedValue;
    private final FloatValue downSpeedValue;
    private final FloatValue timerValue;
    private final BoolValue spartanTimerBoostValue;
    private boolean usedTimer;

    public FastLadder() {
        String[] stringArray = new String[]{"Vanilla", "Clip", "AAC3.0.0", "AAC3.0.5", "SAAC3.1.2", "AAC3.1.2", "Spartan", "Negativity", "Horizon1.4.6", "HiveMC"};
        this.modeValue = new ListValue("Mode", stringArray, "Vanilla");
        this.upSpeedValue = new FloatValue("UpSpeed", 0.3f, 0.01f, 10.0f);
        this.downSpeedValue = new FloatValue("DownSpeed", 0.15f, 0.01f, 10.0f);
        this.timerValue = new FloatValue("Timer", 1.0f, 0.1f, 10.0f, "x");
        this.spartanTimerBoostValue = new BoolValue("SpartanTimerBoost", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ FastLadder this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getModeValue().get()), (String)"spartan", (boolean)true);
            }
        }));
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onMove(MoveEvent event) {
        int i;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.usedTimer) {
            MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            this.usedTimer = false;
        }
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"Vanilla", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(((Number)this.upSpeedValue.get()).floatValue());
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-((double)((Number)this.downSpeedValue.get()).floatValue()));
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            MinecraftInstance.mc.timer.timerSpeed = ((Number)this.timerValue.get()).floatValue();
            this.usedTimer = true;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.0.0", (boolean)true) && MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
            double x = 0.0;
            double z = 0.0;
            EnumFacing enumFacing = MinecraftInstance.mc.thePlayer.getHorizontalFacing();
            switch (enumFacing == null ? -1 : WhenMappings.$EnumSwitchMapping$0[enumFacing.ordinal()]) {
                case 1: {
                    z = -0.99;
                    break;
                }
                case 2: {
                    x = 0.99;
                    break;
                }
                case 3: {
                    z = 0.99;
                    break;
                }
                case 4: {
                    x = -0.99;
                    break;
                }
            }
            Block block = BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.thePlayer.posX + x, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ + z));
            if (!(block instanceof BlockLadder)) {
                if (!(block instanceof BlockVine)) return;
            }
            event.setY(0.5);
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.0.5", (boolean)true) && MinecraftInstance.mc.gameSettings.keyBindForward.isKeyDown()) {
            AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
            Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBoundingBox");
            if (BlockUtils.collideBlockIntersects(axisAlignedBB, (Function1<? super Block, Boolean>)((Function1)onMove.1.INSTANCE))) {
                event.setX(0.0);
                event.setY(0.5);
                event.setZ(0.0);
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                return;
            }
        }
        if (StringsKt.equals((String)mode, (String)"SAAC3.1.2", (boolean)true) && MinecraftInstance.mc.thePlayer.isCollidedHorizontally && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            event.setY(0.1649);
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.1.2", (boolean)true) && MinecraftInstance.mc.thePlayer.isCollidedHorizontally && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            event.setY(0.1699);
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Spartan", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(0.199);
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-1.3489);
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            if ((Boolean)this.spartanTimerBoostValue.get() == false) return;
            if (!MinecraftInstance.mc.thePlayer.isOnLadder()) return;
            if (MinecraftInstance.mc.thePlayer.ticksExisted % 2 == 0) {
                MinecraftInstance.mc.timer.timerSpeed = 2.5f;
            }
            if (MinecraftInstance.mc.thePlayer.ticksExisted % 30 == 0) {
                MinecraftInstance.mc.timer.timerSpeed = 3.0f;
            }
            this.usedTimer = true;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Negativity", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(0.2299);
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-0.226);
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Twillight", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(0.16);
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-7.99);
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Horizon1.4.6", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(0.125);
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-0.16);
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"HiveMC", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                event.setY(0.179);
            } else if (!MinecraftInstance.mc.gameSettings.keyBindSneak.pressed) {
                event.setY(-0.225);
            }
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
            return;
        }
        if (!StringsKt.equals((String)mode, (String)"Clip", (boolean)true)) return;
        if (!MinecraftInstance.mc.thePlayer.isOnLadder()) return;
        if (!MinecraftInstance.mc.gameSettings.keyBindForward.isKeyDown()) return;
        int n = (int)MinecraftInstance.mc.thePlayer.posY;
        int n2 = (int)MinecraftInstance.mc.thePlayer.posY + 8;
        if (n > n2) return;
        do {
            Block block;
            if (!((block = BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.thePlayer.posX, (double)(i = n++), MinecraftInstance.mc.thePlayer.posZ))) instanceof BlockLadder)) {
                double x = 0.0;
                double z = 0.0;
                EnumFacing enumFacing = MinecraftInstance.mc.thePlayer.getHorizontalFacing();
                switch (enumFacing == null ? -1 : WhenMappings.$EnumSwitchMapping$0[enumFacing.ordinal()]) {
                    case 1: {
                        z = -1.0;
                        break;
                    }
                    case 2: {
                        x = 1.0;
                        break;
                    }
                    case 3: {
                        z = 1.0;
                        break;
                    }
                    case 4: {
                        x = -1.0;
                        break;
                    }
                }
                MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX + x, (double)i, MinecraftInstance.mc.thePlayer.posZ + z);
                return;
            }
            MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, (double)i, MinecraftInstance.mc.thePlayer.posZ);
        } while (i != n2);
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer != null && (event.getBlock() instanceof BlockLadder || event.getBlock() instanceof BlockVine) && StringsKt.equals((String)((String)this.modeValue.get()), (String)"AAC3.0.5", (boolean)true) && MinecraftInstance.mc.thePlayer.isOnLadder()) {
            event.setBoundingBox(null);
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[EnumFacing.values().length];
            nArray[EnumFacing.NORTH.ordinal()] = 1;
            nArray[EnumFacing.EAST.ordinal()] = 2;
            nArray[EnumFacing.SOUTH.ordinal()] = 3;
            nArray[EnumFacing.WEST.ordinal()] = 4;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

