/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.features.module.impl.visual;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.ListValue;
import net.minecraft.util.ResourceLocation;

@ModuleInfo(name="Cape", description="", category=ModuleCategory.VISUAL, array=false)
public final class Cape
extends Module {
    private final ListValue styleValue;
    private final HashMap<String, CapeStyle> capeCache;

    public Cape() {
        String[] stringArray = new String[]{"None", "Crazy", "Delta", "NightX", "Aspw", "Infinity", "Funny", "Astolfo", "Exhibition", "Novoline", "Dortware", "Skidware", "Crosssine", "Moon", "Rise5Light", "Rise5Dark", "Rise6", "Tenacity", "FDP", "Lunar", "Minecon2011", "Minecon2012", "Minecon2013", "Minecon2015", "Minecon2016", "MojangDeveloper", "Migrator", "Vanilla"};
        this.styleValue = new ListValue("Mode", stringArray, "Crazy");
        this.capeCache = new HashMap();
        this.setState(true);
    }

    public final ListValue getStyleValue() {
        return this.styleValue;
    }

    public final ResourceLocation getCapeLocation(String value) {
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        Object object = value.toUpperCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toUpperCase(locale)");
        if (this.capeCache.get(object) == null) {
            try {
                Map map = this.capeCache;
                object = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDefault()");
                Object object2 = value.toUpperCase((Locale)object);
                Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"this as java.lang.String).toUpperCase(locale)");
                String string = object2;
                object2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"getDefault()");
                String string2 = value.toUpperCase((Locale)object2);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toUpperCase(locale)");
                map.put(string, CapeStyle.valueOf(string2));
            }
            catch (Exception e) {
                Map map = this.capeCache;
                Locale locale2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale2, (String)"getDefault()");
                String string = value.toUpperCase(locale2);
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toUpperCase(locale)");
                map.put(string, CapeStyle.NONE);
            }
        }
        locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        object = value.toUpperCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toUpperCase(locale)");
        CapeStyle capeStyle = this.capeCache.get(object);
        Intrinsics.checkNotNull((Object)((Object)capeStyle));
        return capeStyle.getLocation();
    }

    @Override
    public String getTag() {
        return (String)this.styleValue.get();
    }

    public static final class CapeStyle
    extends Enum<CapeStyle> {
        private final ResourceLocation location;
        public static final /* enum */ CapeStyle NONE = new CapeStyle(new ResourceLocation("client/cape/none.png"));
        public static final /* enum */ CapeStyle CRAZY = new CapeStyle(new ResourceLocation("client/cape/crazy.png"));
        public static final /* enum */ CapeStyle DELTA = new CapeStyle(new ResourceLocation("client/cape/delta.png"));
        public static final /* enum */ CapeStyle NIGHTX = new CapeStyle(new ResourceLocation("client/cape/nightx.png"));
        public static final /* enum */ CapeStyle ASPW = new CapeStyle(new ResourceLocation("client/cape/aspw.png"));
        public static final /* enum */ CapeStyle INFINITY = new CapeStyle(new ResourceLocation("client/cape/infinity.png"));
        public static final /* enum */ CapeStyle FUNNY = new CapeStyle(new ResourceLocation("client/cape/funny.png"));
        public static final /* enum */ CapeStyle ASTOLFO = new CapeStyle(new ResourceLocation("client/cape/astolfo.png"));
        public static final /* enum */ CapeStyle EXHIBITION = new CapeStyle(new ResourceLocation("client/cape/exhibition.png"));
        public static final /* enum */ CapeStyle NOVOLINE = new CapeStyle(new ResourceLocation("client/cape/novoline.png"));
        public static final /* enum */ CapeStyle DORTWARE = new CapeStyle(new ResourceLocation("client/cape/dortware.png"));
        public static final /* enum */ CapeStyle SKIDWARE = new CapeStyle(new ResourceLocation("client/cape/skidware.png"));
        public static final /* enum */ CapeStyle CROSSSINE = new CapeStyle(new ResourceLocation("client/cape/crosssine.png"));
        public static final /* enum */ CapeStyle MOON = new CapeStyle(new ResourceLocation("client/cape/moon.png"));
        public static final /* enum */ CapeStyle RISE5LIGHT = new CapeStyle(new ResourceLocation("client/cape/rise5light.png"));
        public static final /* enum */ CapeStyle RISE5DARK = new CapeStyle(new ResourceLocation("client/cape/rise5dark.png"));
        public static final /* enum */ CapeStyle RISE6 = new CapeStyle(new ResourceLocation("client/cape/rise6.png"));
        public static final /* enum */ CapeStyle TENACITY = new CapeStyle(new ResourceLocation("client/cape/tenacity.png"));
        public static final /* enum */ CapeStyle FDP = new CapeStyle(new ResourceLocation("client/cape/fdp.png"));
        public static final /* enum */ CapeStyle LUNAR = new CapeStyle(new ResourceLocation("client/cape/lunar.png"));
        public static final /* enum */ CapeStyle MINECON2011 = new CapeStyle(new ResourceLocation("client/cape/2011.png"));
        public static final /* enum */ CapeStyle MINECON2012 = new CapeStyle(new ResourceLocation("client/cape/2012.png"));
        public static final /* enum */ CapeStyle MINECON2013 = new CapeStyle(new ResourceLocation("client/cape/2013.png"));
        public static final /* enum */ CapeStyle MINECON2015 = new CapeStyle(new ResourceLocation("client/cape/2015.png"));
        public static final /* enum */ CapeStyle MINECON2016 = new CapeStyle(new ResourceLocation("client/cape/2016.png"));
        public static final /* enum */ CapeStyle MOJANGDEVELOPER = new CapeStyle(new ResourceLocation("client/cape/mojangdeveloper.png"));
        public static final /* enum */ CapeStyle MIGRATOR = new CapeStyle(new ResourceLocation("client/cape/migrator.png"));
        public static final /* enum */ CapeStyle VANILLA = new CapeStyle(new ResourceLocation("client/cape/vanilla.png"));
        private static final /* synthetic */ CapeStyle[] $VALUES;

        private CapeStyle(ResourceLocation location) {
            this.location = location;
        }

        public final ResourceLocation getLocation() {
            return this.location;
        }

        public static CapeStyle[] values() {
            return (CapeStyle[])$VALUES.clone();
        }

        public static CapeStyle valueOf(String value) {
            return Enum.valueOf(CapeStyle.class, value);
        }

        static {
            $VALUES = capeStyleArray = new CapeStyle[]{CapeStyle.NONE, CapeStyle.CRAZY, CapeStyle.DELTA, CapeStyle.NIGHTX, CapeStyle.ASPW, CapeStyle.INFINITY, CapeStyle.FUNNY, CapeStyle.ASTOLFO, CapeStyle.EXHIBITION, CapeStyle.NOVOLINE, CapeStyle.DORTWARE, CapeStyle.SKIDWARE, CapeStyle.CROSSSINE, CapeStyle.MOON, CapeStyle.RISE5LIGHT, CapeStyle.RISE5DARK, CapeStyle.RISE6, CapeStyle.TENACITY, CapeStyle.FDP, CapeStyle.LUNAR, CapeStyle.MINECON2011, CapeStyle.MINECON2012, CapeStyle.MINECON2013, CapeStyle.MINECON2015, CapeStyle.MINECON2016, CapeStyle.MOJANGDEVELOPER, CapeStyle.MIGRATOR, CapeStyle.VANILLA};
        }
    }
}

