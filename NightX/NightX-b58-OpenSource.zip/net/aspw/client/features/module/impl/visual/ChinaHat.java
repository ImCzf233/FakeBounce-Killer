/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.WorldRenderer
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.AxisAlignedBB
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.ColorMixer;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="ChinaHat", spacedName="China Hat", description="", category=ModuleCategory.VISUAL)
public class ChinaHat
extends Module {
    private final ListValue colorModeValue = new ListValue("Color", new String[]{"Custom", "Rainbow", "Sky", "LiquidSlowly", "Fade", "Mixer"}, "Custom");
    private final IntegerValue colorRedValue = new IntegerValue("Red", 255, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("Green", 120, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("Blue", 255, 0, 255);
    private final IntegerValue colorAlphaValue = new IntegerValue("Alpha", 180, 0, 255);
    private final IntegerValue colorEndAlphaValue = new IntegerValue("EndAlpha", 80, 0, 255);
    private final FloatValue saturationValue = new FloatValue("Saturation", 1.0f, 0.0f, 1.0f);
    private final FloatValue brightnessValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
    private final IntegerValue mixerSecondsValue = new IntegerValue("Seconds", 2, 1, 10);
    private final IntegerValue spaceValue = new IntegerValue("Color-Space", 100, 0, 100);
    private final BoolValue noFirstPerson = new BoolValue("NoFirstPerson", true);
    private final BoolValue hatBorder = new BoolValue("HatBorder", false);
    private final IntegerValue borderAlphaValue = new IntegerValue("BorderAlpha", 120, 0, 255);
    private final FloatValue borderWidthValue = new FloatValue("BorderWidth", 1.0f, 0.1f, 4.0f);
    private final List<double[]> positions = new ArrayList<double[]>();
    private double lastRadius = 0.0;

    public static void pre3D() {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glShadeModel((int)7425);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)2896);
        GL11.glDepthMask((boolean)false);
        GL11.glHint((int)3154, (int)4354);
        GL11.glDisable((int)2884);
    }

    public static void post3D() {
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    private void checkPosition(double radius) {
        if (radius != this.lastRadius) {
            this.positions.clear();
            for (int i = 0; i <= 360; ++i) {
                this.positions.add(new double[]{-Math.sin((double)i * Math.PI / 180.0) * radius, Math.cos((double)i * Math.PI / 180.0) * radius});
            }
        }
        this.lastRadius = radius;
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        EntityPlayerSP entity = ChinaHat.mc.thePlayer;
        if (entity == null || ((Boolean)this.noFirstPerson.get()).booleanValue() && ChinaHat.mc.gameSettings.thirdPersonView == 0) {
            return;
        }
        AxisAlignedBB bb = entity.getEntityBoundingBox();
        float partialTicks = event.getPartialTicks();
        double radius = bb.maxX - bb.minX;
        double height = bb.maxY - bb.minY;
        double posX = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks;
        double posY = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks;
        double posZ = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks;
        double viewX = -ChinaHat.mc.getRenderManager().viewerPosX;
        double viewY = -ChinaHat.mc.getRenderManager().viewerPosY;
        double viewZ = -ChinaHat.mc.getRenderManager().viewerPosZ;
        Color colour = this.getColor((Entity)entity, 0);
        float r = (float)colour.getRed() / 255.0f;
        float g = (float)colour.getGreen() / 255.0f;
        float b = (float)colour.getBlue() / 255.0f;
        float al = (float)((Integer)this.colorAlphaValue.get()).intValue() / 255.0f;
        float Eal = (float)((Integer)this.colorEndAlphaValue.get()).intValue() / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        this.checkPosition(radius);
        GL11.glPushMatrix();
        GlStateManager.translate((double)(viewX + posX), (double)(viewY + posY + height - 0.4), (double)(viewZ + posZ));
        ChinaHat.pre3D();
        worldrenderer.begin(9, DefaultVertexFormats.POSITION_COLOR);
        worldrenderer.pos(0.0, 0.7, 0.0).color(r, g, b, al).endVertex();
        int i = 0;
        for (double[] smolPos : this.positions) {
            if ((Integer)this.spaceValue.get() > 0 && !((String)this.colorModeValue.get()).equalsIgnoreCase("Custom")) {
                Color colour2 = this.getColor((Entity)entity, i * (Integer)this.spaceValue.get());
                float r2 = (float)colour2.getRed() / 255.0f;
                float g2 = (float)colour2.getGreen() / 255.0f;
                float b2 = (float)colour2.getBlue() / 255.0f;
                worldrenderer.pos(smolPos[0], 0.4, smolPos[1]).color(r2, g2, b2, Eal).endVertex();
            } else {
                worldrenderer.pos(smolPos[0], 0.4, smolPos[1]).color(r, g, b, Eal).endVertex();
            }
            ++i;
        }
        worldrenderer.pos(0.0, 0.7, 0.0).color(r, g, b, al).endVertex();
        tessellator.draw();
        if (((Boolean)this.hatBorder.get()).booleanValue()) {
            float lineAlp = (float)((Integer)this.borderAlphaValue.get()).intValue() / 255.0f;
            GL11.glLineWidth((float)((Float)this.borderWidthValue.get()).floatValue());
            worldrenderer.begin(2, DefaultVertexFormats.POSITION_COLOR);
            i = 0;
            for (double[] smolPos : this.positions) {
                if ((Integer)this.spaceValue.get() > 0 && !((String)this.colorModeValue.get()).equalsIgnoreCase("Custom")) {
                    Color colour2 = this.getColor((Entity)entity, i * (Integer)this.spaceValue.get());
                    float r2 = (float)colour2.getRed() / 255.0f;
                    float g2 = (float)colour2.getGreen() / 255.0f;
                    float b2 = (float)colour2.getBlue() / 255.0f;
                    worldrenderer.pos(smolPos[0], 0.4, smolPos[1]).color(r2, g2, b2, lineAlp).endVertex();
                } else {
                    worldrenderer.pos(smolPos[0], 0.4, smolPos[1]).color(r, g, b, lineAlp).endVertex();
                }
                ++i;
            }
            tessellator.draw();
        }
        ChinaHat.post3D();
        GL11.glPopMatrix();
    }

    public final Color getColor(Entity ent, int index) {
        switch ((String)this.colorModeValue.get()) {
            case "Custom": {
                return new Color((Integer)this.colorRedValue.get(), (Integer)this.colorGreenValue.get(), (Integer)this.colorBlueValue.get());
            }
            case "Rainbow": {
                return new Color(RenderUtils.getRainbowOpaque((Integer)this.mixerSecondsValue.get(), ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue(), index));
            }
            case "Sky": {
                return RenderUtils.skyRainbow(index, ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue());
            }
            case "LiquidSlowly": {
                return ColorUtils.LiquidSlowly(System.nanoTime(), index, ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue());
            }
            case "Mixer": {
                return ColorMixer.getMixedColor(index, (Integer)this.mixerSecondsValue.get());
            }
        }
        return ColorUtils.fade(new Color((Integer)this.colorRedValue.get(), (Integer)this.colorGreenValue.get(), (Integer)this.colorBlueValue.get()), index, 100);
    }
}

