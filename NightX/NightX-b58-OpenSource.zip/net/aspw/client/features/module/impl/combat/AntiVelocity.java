/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C0FPacketConfirmTransaction
 *  net.minecraft.network.play.server.S12PacketEntityVelocity
 *  net.minecraft.network.play.server.S27PacketExplosion
 *  net.minecraft.network.play.server.S32PacketConfirmTransaction
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.combat;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

@ModuleInfo(name="AntiVelocity", spacedName="Anti Velocity", description="", category=ModuleCategory.COMBAT)
public final class AntiVelocity
extends Module {
    private final FloatValue horizontalValue = new FloatValue("Horizontal", 0.0f, -1.0f, 1.0f, "%", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AntiVelocity this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aac", (boolean)true) || StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"simple", (boolean)true);
        }
    }));
    private final FloatValue verticalValue = new FloatValue("Vertical", 0.0f, -1.0f, 1.0f, "%", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AntiVelocity this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aac", (boolean)true) || StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"simple", (boolean)true);
        }
    }));
    private final FloatValue horizontalExplosionValue = new FloatValue("HorizontalExplosion", 0.0f, 0.0f, 1.0f, "%");
    private final FloatValue verticalExplosionValue = new FloatValue("VerticalExplosion", 0.0f, 0.0f, 1.0f, "%");
    private final ListValue modeValue;
    private final BoolValue aac5KillAuraValue;
    private final FloatValue reduceChance;
    private boolean shouldAffect;
    private final FloatValue reverseStrengthValue;
    private final FloatValue reverse2StrengthValue;
    private final FloatValue aacPushXZReducerValue;
    private final BoolValue aacPushYReducerValue;
    private final BoolValue legitStrafeValue;
    private final BoolValue legitFaceValue;
    private final BoolValue aacStrafeValue;
    private final FloatValue phaseOffsetValue;
    private MSTimer velocityTimer;
    private boolean velocityInput;
    private BlockPos pos;
    private boolean reverseHurt;
    private boolean jump;
    private int cancelPacket;
    private int resetPersec;
    private int grimTCancel;
    private int updates;

    public AntiVelocity() {
        String[] stringArray = new String[]{"Cancel", "Simple", "AACv4", "AAC4Reduce", "AAC5Reduce", "AAC5.2.0", "AAC", "AACPush", "AACZero", "Reverse", "SmoothReverse", "Jump", "Phase", "YMotion", "Vulcan", "Grim", "GrimReverse", "MatrixReduce", "MatrixSimple", "MatrixReverse", "MatrixSpoof", "MatrixGround", "Legit", "AEMine"};
        this.modeValue = new ListValue("Mode", stringArray, "Cancel");
        this.aac5KillAuraValue = new BoolValue("AAC5.2.0-Attack-Only", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aac5.2.0", (boolean)true);
            }
        }));
        this.reduceChance = new FloatValue("Chance", 100.0f, 0.0f, 100.0f, "%");
        this.shouldAffect = true;
        this.reverseStrengthValue = new FloatValue("ReverseStrength", 1.0f, 0.1f, 1.0f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"reverse", (boolean)true);
            }
        }));
        this.reverse2StrengthValue = new FloatValue("SmoothReverseStrength", 0.05f, 0.02f, 0.1f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"smoothreverse", (boolean)true);
            }
        }));
        this.aacPushXZReducerValue = new FloatValue("AACPushXZReducer", 2.0f, 1.0f, 3.0f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aacpush", (boolean)true);
            }
        }));
        this.aacPushYReducerValue = new BoolValue("AACPushYReducer", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aacpush", (boolean)true);
            }
        }));
        this.legitStrafeValue = new BoolValue("LegitStrafe", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"legit", (boolean)true);
            }
        }));
        this.legitFaceValue = new BoolValue("LegitFace", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"legit", (boolean)true);
            }
        }));
        this.aacStrafeValue = new BoolValue("AACStrafeValue", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"aac", (boolean)true);
            }
        }));
        this.phaseOffsetValue = new FloatValue("Phase-Offset", 0.05f, -10.0f, 10.0f, "m", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVelocity this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVelocity.access$getModeValue$p(this.this$0).get()), (String)"phase", (boolean)true);
            }
        }));
        this.velocityTimer = new MSTimer();
        this.cancelPacket = 6;
        this.resetPersec = 8;
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer != null) {
            MinecraftInstance.mc.thePlayer.speedInAir = 0.02f;
        }
        this.grimTCancel = 0;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer.hurtTime <= 0) {
            boolean bl = this.shouldAffect = (float)Math.random() < ((Number)this.reduceChance.get()).floatValue() / 100.0f;
        }
        if (MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.isInWeb || !this.shouldAffect) {
            return;
        }
        int n = this.updates;
        this.updates = n + 1;
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "jump": {
                if (MinecraftInstance.mc.thePlayer.hurtTime <= 0 || !MinecraftInstance.mc.thePlayer.onGround) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.41999998688698;
                float yaw = MinecraftInstance.mc.thePlayer.rotationYaw * ((float)Math.PI / 180);
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionX -= (double)MathHelper.sin((float)yaw) * 0.2;
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionZ += (double)MathHelper.cos((float)yaw) * 0.2;
                break;
            }
            case "grim": {
                if (this.resetPersec <= 0 || this.updates < 0 && this.updates < this.resetPersec) break;
                this.updates = 0;
                if (this.grimTCancel <= 0) break;
                int yaw = this.grimTCancel;
                this.grimTCancel = yaw + -1;
                break;
            }
            case "reverse": {
                if (!this.velocityInput) {
                    return;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.getSpeed() * ((Number)this.reverseStrengthValue.get()).floatValue());
                    break;
                }
                if (!this.velocityTimer.hasTimePassed(80L)) break;
                this.velocityInput = false;
                break;
            }
            case "aacv4": {
                if (!MinecraftInstance.mc.thePlayer.onGround) {
                    if (!this.velocityInput) break;
                    MinecraftInstance.mc.thePlayer.speedInAir = 0.02f;
                    EntityPlayerSP yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionX *= 0.6;
                    yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionZ *= 0.6;
                    break;
                }
                if (!this.velocityTimer.hasTimePassed(80L)) break;
                this.velocityInput = false;
                MinecraftInstance.mc.thePlayer.speedInAir = 0.02f;
                break;
            }
            case "aac4reduce": {
                if (MinecraftInstance.mc.thePlayer.hurtTime > 0 && !MinecraftInstance.mc.thePlayer.onGround && this.velocityInput && this.velocityTimer.hasTimePassed(80L)) {
                    EntityPlayerSP yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionX *= 0.62;
                    yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionZ *= 0.62;
                }
                if (!this.velocityInput || MinecraftInstance.mc.thePlayer.hurtTime >= 4 && !MinecraftInstance.mc.thePlayer.onGround || !this.velocityTimer.hasTimePassed(120L)) break;
                this.velocityInput = false;
                break;
            }
            case "aac5reduce": {
                if (MinecraftInstance.mc.thePlayer.hurtTime > 1 && this.velocityInput) {
                    EntityPlayerSP yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionX *= 0.81;
                    yaw = MinecraftInstance.mc.thePlayer;
                    yaw.motionZ *= 0.81;
                }
                if (!this.velocityInput || MinecraftInstance.mc.thePlayer.hurtTime >= 5 && !MinecraftInstance.mc.thePlayer.onGround || !this.velocityTimer.hasTimePassed(120L)) break;
                this.velocityInput = false;
                break;
            }
            case "smoothreverse": {
                if (!this.velocityInput) {
                    MinecraftInstance.mc.thePlayer.speedInAir = 0.02f;
                    return;
                }
                if (MinecraftInstance.mc.thePlayer.hurtTime > 0) {
                    this.reverseHurt = true;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) {
                    if (!this.reverseHurt) break;
                    MinecraftInstance.mc.thePlayer.speedInAir = ((Number)this.reverse2StrengthValue.get()).floatValue();
                    break;
                }
                if (!this.velocityTimer.hasTimePassed(80L)) break;
                this.velocityInput = false;
                this.reverseHurt = false;
                break;
            }
            case "aac": {
                if (!this.velocityInput || !this.velocityTimer.hasTimePassed(50L)) break;
                EntityPlayerSP yaw = MinecraftInstance.mc.thePlayer;
                yaw.motionX *= ((Number)this.horizontalValue.get()).doubleValue();
                yaw = MinecraftInstance.mc.thePlayer;
                yaw.motionZ *= ((Number)this.horizontalValue.get()).doubleValue();
                yaw = MinecraftInstance.mc.thePlayer;
                yaw.motionY *= ((Number)this.verticalValue.get()).doubleValue();
                if (((Boolean)this.aacStrafeValue.get()).booleanValue()) {
                    MovementUtils.strafe();
                }
                this.velocityInput = false;
                break;
            }
            case "aacpush": {
                if (this.jump) {
                    if (MinecraftInstance.mc.thePlayer.onGround) {
                        this.jump = false;
                    }
                } else {
                    if (MinecraftInstance.mc.thePlayer.hurtTime > 0 && !(MinecraftInstance.mc.thePlayer.motionX == 0.0) && !(MinecraftInstance.mc.thePlayer.motionZ == 0.0)) {
                        MinecraftInstance.mc.thePlayer.onGround = true;
                    }
                    if (MinecraftInstance.mc.thePlayer.hurtResistantTime > 0 && ((Boolean)this.aacPushYReducerValue.get()).booleanValue()) {
                        Speed speed2 = Client.INSTANCE.getModuleManager().get(Speed.class);
                        Intrinsics.checkNotNull((Object)speed2);
                        if (!speed2.getState()) {
                            EntityPlayerSP yaw = MinecraftInstance.mc.thePlayer;
                            yaw.motionY -= 0.014999993;
                        }
                    }
                }
                if (MinecraftInstance.mc.thePlayer.hurtResistantTime < 19) break;
                float reduce = ((Number)this.aacPushXZReducerValue.get()).floatValue();
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionX /= (double)reduce;
                locale = MinecraftInstance.mc.thePlayer;
                ((EntityPlayerSP)locale).motionZ /= (double)reduce;
                break;
            }
            case "aaczero": {
                if (MinecraftInstance.mc.thePlayer.hurtTime > 0) {
                    if (!this.velocityInput || MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.thePlayer.fallDistance > 2.0f) {
                        return;
                    }
                    MinecraftInstance.mc.thePlayer.addVelocity(0.0, -1.0, 0.0);
                    MinecraftInstance.mc.thePlayer.onGround = true;
                    break;
                }
                this.velocityInput = false;
                break;
            }
            case "matrixreduce": {
                if (MinecraftInstance.mc.thePlayer.hurtTime <= 0) break;
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    EntityPlayerSP entityPlayerSP;
                    if (MinecraftInstance.mc.thePlayer.hurtTime <= 6) {
                        entityPlayerSP = MinecraftInstance.mc.thePlayer;
                        entityPlayerSP.motionX *= 0.7;
                        entityPlayerSP = MinecraftInstance.mc.thePlayer;
                        entityPlayerSP.motionZ *= 0.7;
                    }
                    if (MinecraftInstance.mc.thePlayer.hurtTime > 5) break;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX *= 0.8;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ *= 0.8;
                    break;
                }
                if (MinecraftInstance.mc.thePlayer.hurtTime > 10) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 0.6;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ *= 0.6;
                break;
            }
            case "matrixground": {
                if (!MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) break;
                MinecraftInstance.mc.thePlayer.onGround = false;
                break;
            }
            case "aemine": {
                if (MinecraftInstance.mc.thePlayer.hurtTime <= 0) {
                    return;
                }
                if (MinecraftInstance.mc.thePlayer.hurtTime >= 6) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX *= 0.605001;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ *= 0.605001;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY *= 0.727;
                    break;
                }
                if (MinecraftInstance.mc.thePlayer.onGround) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 0.305001;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ *= 0.305001;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY -= 0.095;
                break;
            }
            case "grimreverse": {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX += -1.0E-7;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += -1.0E-7;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ += -1.0E-7;
                MinecraftInstance.mc.thePlayer.isAirBorne = true;
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Packet<?> packet;
        block69: {
            KillAura killAura;
            block71: {
                block70: {
                    Object object;
                    short transUID;
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    packet = event.getPacket();
                    KillAura killAura2 = Client.INSTANCE.getModuleManager().get(KillAura.class);
                    if (killAura2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.combat.KillAura");
                    }
                    killAura = killAura2;
                    if (packet instanceof S32PacketConfirmTransaction && this.grimTCancel > 0) {
                        event.cancelEvent();
                        int n = this.grimTCancel;
                        this.grimTCancel = n + -1;
                    }
                    if (packet instanceof C0FPacketConfirmTransaction && ((String)this.modeValue.get()).equals("Vulcan") && (transUID = ((C0FPacketConfirmTransaction)packet).uid) >= -31767 && transUID <= -30769) {
                        event.cancelEvent();
                    }
                    if (!(packet instanceof S12PacketEntityVelocity)) break block69;
                    if (MinecraftInstance.mc.thePlayer == null) break block70;
                    WorldClient worldClient = MinecraftInstance.mc.theWorld;
                    Object object2 = object = worldClient == null ? null : worldClient.getEntityByID(((S12PacketEntityVelocity)packet).getEntityID());
                    if (object == null) {
                        return;
                    }
                    if (object.equals(MinecraftInstance.mc.thePlayer) && this.shouldAffect) break block71;
                }
                return;
            }
            this.velocityTimer.reset();
            String string = (String)this.modeValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string2) {
                case "cancel": 
                case "vulcan": {
                    event.cancelEvent();
                    break;
                }
                case "simple": {
                    float horizontal = ((Number)this.horizontalValue.get()).floatValue();
                    float vertical = ((Number)this.verticalValue.get()).floatValue();
                    ((S12PacketEntityVelocity)packet).motionX = (int)((float)((S12PacketEntityVelocity)packet).getMotionX() * horizontal);
                    ((S12PacketEntityVelocity)packet).motionY = (int)((float)((S12PacketEntityVelocity)packet).getMotionY() * vertical);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((float)((S12PacketEntityVelocity)packet).getMotionZ() * horizontal);
                    break;
                }
                case "ymotion": {
                    if (MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInWeb || MinecraftInstance.mc.thePlayer.fallDistance < 0.0f) {
                        MinecraftInstance.mc.thePlayer.motionY = (double)((S12PacketEntityVelocity)packet).getMotionY() / 8000.0;
                        event.cancelEvent();
                        break;
                    }
                    event.cancelEvent();
                    break;
                }
                case "grim": {
                    if (((S12PacketEntityVelocity)packet).getEntityID() != MinecraftInstance.mc.thePlayer.getEntityId()) break;
                    event.cancelEvent();
                    this.grimTCancel = this.cancelPacket;
                    break;
                }
                case "aac4reduce": {
                    this.velocityInput = true;
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * 0.6);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * 0.6);
                    break;
                }
                case "aac": 
                case "aacv4": 
                case "aaczero": 
                case "reverse": 
                case "aac5reduce": 
                case "smoothreverse": {
                    this.velocityInput = true;
                    break;
                }
                case "aac5.2.0": {
                    event.cancelEvent();
                    if (MinecraftInstance.mc.isIntegratedServerRunning() || ((Boolean)this.aac5KillAuraValue.get()).booleanValue() && killAura.getTarget() == null) break;
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, Double.MAX_VALUE, MinecraftInstance.mc.thePlayer.posZ, true));
                    break;
                }
                case "matrixsimple": {
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * 0.36);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * 0.36);
                    if (!MinecraftInstance.mc.thePlayer.onGround) break;
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * 0.9);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * 0.9);
                    break;
                }
                case "matrixground": {
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * 0.36);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * 0.36);
                    if (!MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) break;
                    ((S12PacketEntityVelocity)packet).motionY = -628;
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * 0.6);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * 0.6);
                    break;
                }
                case "matrixreverse": {
                    ((S12PacketEntityVelocity)packet).motionX = (int)((double)((S12PacketEntityVelocity)packet).getMotionX() * -0.3);
                    ((S12PacketEntityVelocity)packet).motionZ = (int)((double)((S12PacketEntityVelocity)packet).getMotionZ() * -0.3);
                    break;
                }
                case "matrixspoof": {
                    event.cancelEvent();
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX + (double)((S12PacketEntityVelocity)packet).motionX / -24000.0, MinecraftInstance.mc.thePlayer.posY + (double)((S12PacketEntityVelocity)packet).motionY / -24000.0, MinecraftInstance.mc.thePlayer.posZ + (double)((S12PacketEntityVelocity)packet).motionZ / 8000.0, false));
                    break;
                }
                case "glitch": {
                    if (!MinecraftInstance.mc.thePlayer.onGround) {
                        return;
                    }
                    this.velocityInput = true;
                    event.cancelEvent();
                    break;
                }
                case "phase": {
                    MinecraftInstance.mc.thePlayer.setPositionAndUpdate(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)((Number)this.phaseOffsetValue.get()).floatValue(), MinecraftInstance.mc.thePlayer.posZ);
                    break;
                }
                case "legit": {
                    this.pos = new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ);
                }
            }
        }
        if (packet instanceof S27PacketExplosion) {
            MinecraftInstance.mc.thePlayer.motionX += (double)(((S27PacketExplosion)packet).func_149149_c() * ((Number)this.horizontalExplosionValue.get()).floatValue());
            MinecraftInstance.mc.thePlayer.motionY += (double)(((S27PacketExplosion)packet).func_149144_d() * ((Number)this.verticalExplosionValue.get()).floatValue());
            MinecraftInstance.mc.thePlayer.motionZ += (double)(((S27PacketExplosion)packet).func_149147_e() * ((Number)this.horizontalExplosionValue.get()).floatValue());
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onStrafe(StrafeEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        if (string2.equals("legit")) {
            if (this.pos == null || MinecraftInstance.mc.thePlayer.hurtTime <= 0) {
                return;
            }
            BlockPos blockPos = this.pos;
            Intrinsics.checkNotNull((Object)blockPos);
            double d = blockPos.getX();
            BlockPos blockPos2 = this.pos;
            Intrinsics.checkNotNull((Object)blockPos2);
            double d2 = blockPos2.getY();
            BlockPos blockPos3 = this.pos;
            Intrinsics.checkNotNull((Object)blockPos3);
            Rotation rot = RotationUtils.getRotations(d, d2, blockPos3.getZ());
            if (((Boolean)this.legitFaceValue.get()).booleanValue()) {
                RotationUtils.setTargetRotation(rot);
            }
            float yaw = rot.getYaw();
            if (((Boolean)this.legitStrafeValue.get()).booleanValue()) {
                float speed2 = MovementUtils.getSpeed();
                double yaw1 = Math.toRadians(yaw);
                MinecraftInstance.mc.thePlayer.motionX = -Math.sin(yaw1) * (double)speed2;
                MinecraftInstance.mc.thePlayer.motionZ = Math.cos(yaw1) * (double)speed2;
            } else {
                float strafe = event.getStrafe();
                float forward = event.getForward();
                float friction = event.getFriction();
                float f = strafe * strafe + forward * forward;
                if (f >= 1.0E-4f) {
                    if ((f = MathHelper.sqrt_float((float)f)) < 1.0f) {
                        f = 1.0f;
                    }
                    f = friction / f;
                    float yawSin = MathHelper.sin((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                    float yawCos = MathHelper.cos((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX += (double)((strafe *= f) * yawCos - (forward *= f) * yawSin);
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ += (double)(forward * yawCos + strafe * yawSin);
                }
            }
        }
    }

    @EventTarget
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.isInWeb || !this.shouldAffect) {
            return;
        }
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "aacpush": {
                this.jump = true;
                if (MinecraftInstance.mc.thePlayer.isCollidedVertically) break;
                event.cancelEvent();
                break;
            }
            case "aacv4": {
                if (MinecraftInstance.mc.thePlayer.hurtTime <= 0) break;
                event.cancelEvent();
                break;
            }
            case "aaczero": {
                if (MinecraftInstance.mc.thePlayer.hurtTime <= 0) break;
                event.cancelEvent();
            }
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(AntiVelocity $this) {
        return $this.modeValue;
    }
}

