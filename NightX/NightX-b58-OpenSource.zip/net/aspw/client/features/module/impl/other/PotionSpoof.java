/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.other;

import net.aspw.client.event.ClientShutdownEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="PotionSpoof", spacedName="Potion Spoof", description="", category=ModuleCategory.OTHER)
public final class PotionSpoof
extends Module {
    private final BoolValue speedValue = new BoolValue("Speed", false);
    private final BoolValue moveSlowDownValue = new BoolValue("Slowness", false);
    private final BoolValue hasteValue = new BoolValue("Haste", false);
    private final BoolValue digSlowDownValue = new BoolValue("MiningFatigue", false);
    private final BoolValue blindnessValue = new BoolValue("Blindness", false);
    private final BoolValue strengthValue = new BoolValue("Strength", false);
    private final BoolValue jumpBoostValue = new BoolValue("JumpBoost", false);
    private final BoolValue weaknessValue = new BoolValue("Weakness", false);
    private final BoolValue regenerationValue = new BoolValue("Regeneration", false);
    private final BoolValue witherValue = new BoolValue("Wither", false);
    private final BoolValue resistanceValue = new BoolValue("Resistance", false);
    private final BoolValue fireResistanceValue = new BoolValue("FireResistance", false);
    private final BoolValue absorptionValue = new BoolValue("Absorption", false);
    private final BoolValue healthBoostValue = new BoolValue("HealthBoost", false);
    private final BoolValue poisonValue = new BoolValue("Poison", false);
    private final BoolValue saturationValue = new BoolValue("Saturation", false);
    private final BoolValue waterBreathingValue = new BoolValue("WaterBreathing", false);

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer != null) {
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.moveSpeed.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.digSpeed.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.moveSlowdown.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.blindness.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.damageBoost.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.jump.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.weakness.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.regeneration.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.fireResistance.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.wither.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.resistance.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.absorption.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.healthBoost.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.digSlowdown.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.poison.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.saturation.id);
            MinecraftInstance.mc.thePlayer.removePotionEffectClient(Potion.waterBreathing.id);
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (this.getState() && ((Boolean)this.speedValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.moveSpeed.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.hasteValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.moveSlowDownValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.moveSlowdown.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.blindnessValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.blindness.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.strengthValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.damageBoost.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.jumpBoostValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.jump.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.weaknessValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.weakness.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.regenerationValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.regeneration.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.fireResistanceValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.fireResistance.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.witherValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.wither.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.resistanceValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.resistance.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.absorptionValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.absorption.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.healthBoostValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.healthBoost.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.digSlowDownValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSlowdown.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.poisonValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.poison.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.saturationValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.saturation.id, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.waterBreathingValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.addPotionEffect(new PotionEffect(Potion.waterBreathing.id, 1337, 1));
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onShutdown(@Nullable ClientShutdownEvent event) {
        this.onDisable();
    }
}

