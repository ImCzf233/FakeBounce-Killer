/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package net.aspw.client.features.api;

import kotlin.jvm.JvmField;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.aspw.client.features.module.Module;
import net.aspw.client.value.BoolValue;

public final class GuiFastRender
extends Module {
    public static final Companion Companion = new Companion(null);
    @JvmField
    public static final BoolValue fixValue = new BoolValue("Fix", false);

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

