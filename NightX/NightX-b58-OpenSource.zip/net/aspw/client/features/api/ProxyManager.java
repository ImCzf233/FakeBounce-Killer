/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.bootstrap.ChannelFactory
 *  io.netty.channel.socket.oio.OioSocketChannel
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.api;

import io.netty.bootstrap.ChannelFactory;
import io.netty.channel.socket.oio.OioSocketChannel;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Socket;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;

public final class ProxyManager {
    public static final ProxyManager INSTANCE = new ProxyManager();
    private static boolean isEnable;
    private static String proxy;
    private static Proxy.Type proxyType;

    private ProxyManager() {
    }

    public final boolean isEnable() {
        return isEnable;
    }

    public final void setEnable(boolean bl) {
        isEnable = bl;
    }

    public final String getProxy() {
        return proxy;
    }

    public final void setProxy(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        proxy = string;
    }

    public final Proxy.Type getProxyType() {
        return proxyType;
    }

    public final void setProxyType(Proxy.Type type) {
        Intrinsics.checkNotNullParameter((Object)((Object)type), (String)"<set-?>");
        proxyType = type;
    }

    public final Proxy getProxyInstance() {
        String[] stringArray = new String[]{":"};
        List it = StringsKt.split$default((CharSequence)proxy, (String[])stringArray, (boolean)false, (int)0, (int)6, null);
        boolean bl = false;
        return new Proxy(INSTANCE.getProxyType(), new InetSocketAddress((String)CollectionsKt.first((List)it), Integer.parseInt((String)CollectionsKt.last((List)it))));
    }

    static {
        proxy = "";
        proxyType = Proxy.Type.SOCKS;
    }

    public static final class ProxyOioChannelFactory
    implements ChannelFactory<OioSocketChannel> {
        private final Proxy proxy;

        public ProxyOioChannelFactory(Proxy proxy) {
            Intrinsics.checkNotNullParameter((Object)proxy, (String)"proxy");
            this.proxy = proxy;
        }

        public OioSocketChannel newChannel() {
            return new OioSocketChannel(new Socket(this.proxy));
        }
    }
}

