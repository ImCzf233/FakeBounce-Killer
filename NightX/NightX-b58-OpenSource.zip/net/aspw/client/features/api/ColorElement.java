/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 */
package net.aspw.client.features.api;

import kotlin.jvm.functions.Function0;
import net.aspw.client.value.IntegerValue;

public class ColorElement
extends IntegerValue {
    public ColorElement(int counter, Material m, IntegerValue basis) {
        super("Color" + counter + "-" + m.getColorName(), 255, 0, 255, (Function0<Boolean>)((Function0)() -> (Integer)basis.get() >= counter));
    }

    public ColorElement(int counter, Material m) {
        super("Color" + counter + "-" + m.getColorName(), 255, 0, 255);
    }

    @Override
    protected void onChanged(Integer oldValue, Integer newValue) {
    }

    static enum Material {
        RED("Red"),
        GREEN("Green"),
        BLUE("Blue");

        private final String colName;

        private Material(String name) {
            this.colName = name;
        }

        public String getColorName() {
            return this.colName;
        }
    }
}

