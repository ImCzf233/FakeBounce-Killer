/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelVillager
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 */
package net.aspw.client.injection.forge.mixins.render;

import net.minecraft.client.model.ModelVillager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value={ModelVillager.class})
public class MixinModelVillager {
    @ModifyConstant(method={"<init>(FFII)V"}, constant={@Constant(intValue=18)})
    private int changeTextureHeight(int original) {
        return 20;
    }
}

