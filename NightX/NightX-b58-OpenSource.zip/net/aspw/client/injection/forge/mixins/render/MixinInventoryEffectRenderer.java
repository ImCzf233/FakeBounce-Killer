/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.InventoryEffectRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.injection.forge.mixins.gui.MixinGuiContainer;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={InventoryEffectRenderer.class})
public abstract class MixinInventoryEffectRenderer
extends MixinGuiContainer {
    @Shadow
    private boolean field_147045_u;

    @Overwrite
    public void func_175378_g() {
        Hud hud = Client.moduleManager.getModule(Hud.class);
        if (!((Boolean)Objects.requireNonNull(hud).getInvEffectOffset().get()).booleanValue()) {
            this.field_147003_i = (this.field_146294_l - this.field_146999_f) / 2;
            this.field_147045_u = !this.field_146297_k.thePlayer.getActivePotionEffects().isEmpty();
        } else if (!this.field_146297_k.thePlayer.getActivePotionEffects().isEmpty()) {
            this.field_147003_i = 160 + (this.field_146294_l - this.field_146999_f - 200) / 2;
            this.field_147045_u = true;
        } else {
            this.field_147003_i = (this.field_146294_l - this.field_146999_f) / 2;
            this.field_147045_u = false;
        }
    }
}

