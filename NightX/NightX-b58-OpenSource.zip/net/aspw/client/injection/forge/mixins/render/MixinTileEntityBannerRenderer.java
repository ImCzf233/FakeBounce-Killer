/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.texture.ITextureObject
 *  net.minecraft.client.renderer.texture.LayeredColorMaskTexture
 *  net.minecraft.client.renderer.tileentity.TileEntityBannerRenderer
 *  net.minecraft.client.renderer.tileentity.TileEntityBannerRenderer$TimedBannerTexture
 *  net.minecraft.tileentity.TileEntityBanner
 *  net.minecraft.tileentity.TileEntityBanner$EnumBannerPattern
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.World
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package net.aspw.client.injection.forge.mixins.render;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.LayeredColorMaskTexture;
import net.minecraft.client.renderer.tileentity.TileEntityBannerRenderer;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={TileEntityBannerRenderer.class})
public class MixinTileEntityBannerRenderer {
    @Shadow
    @Final
    private static Map<String, TileEntityBannerRenderer.TimedBannerTexture> field_178466_c;
    @Shadow
    @Final
    private static ResourceLocation field_178464_d;

    @Overwrite
    private ResourceLocation func_178463_a(TileEntityBanner banner) {
        String texture = banner.getPatternResourceLocation();
        if (texture.isEmpty()) {
            return null;
        }
        TileEntityBannerRenderer.TimedBannerTexture timedTexture = field_178466_c.get(texture);
        if (timedTexture == null) {
            if (field_178466_c.size() >= 256 && !this.freeCacheSlot()) {
                return field_178464_d;
            }
            List patternList = banner.getPatternList();
            List colorList = banner.getColorList();
            ArrayList patternPath = Lists.newArrayList();
            for (TileEntityBanner.EnumBannerPattern pattern : patternList) {
                patternPath.add("textures/entity/banner/" + pattern.getPatternName() + ".png");
            }
            timedTexture = new TileEntityBannerRenderer.TimedBannerTexture();
            timedTexture.bannerTexture = new ResourceLocation(texture);
            Minecraft.getMinecraft().getTextureManager().loadTexture(timedTexture.bannerTexture, (ITextureObject)new LayeredColorMaskTexture(field_178464_d, (List)patternPath, colorList));
            field_178466_c.put(texture, timedTexture);
        }
        timedTexture.systemTime = System.currentTimeMillis();
        return timedTexture.bannerTexture;
    }

    @Unique
    private boolean freeCacheSlot() {
        long start = System.currentTimeMillis();
        Iterator<String> iterator = field_178466_c.keySet().iterator();
        while (iterator.hasNext()) {
            String next = iterator.next();
            TileEntityBannerRenderer.TimedBannerTexture timedTexture = field_178466_c.get(next);
            if (start - timedTexture.systemTime <= 5000L) continue;
            Minecraft.getMinecraft().getTextureManager().deleteTexture(timedTexture.bannerTexture);
            iterator.remove();
            return true;
        }
        return field_178466_c.size() < 256;
    }

    @Redirect(method={"renderTileEntityAt(Lnet/minecraft/tileentity/TileEntityBanner;DDDFI)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/World;getTotalWorldTime()J"))
    private long resolveOverflow(World world) {
        return world.getTotalWorldTime() % 100L;
    }
}

