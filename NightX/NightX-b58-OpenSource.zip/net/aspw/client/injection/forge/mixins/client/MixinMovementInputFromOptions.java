/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MovementInputFromOptions
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 */
package net.aspw.client.injection.forge.mixins.client;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.movement.NoSlow;
import net.minecraft.util.MovementInputFromOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value={MovementInputFromOptions.class})
public class MixinMovementInputFromOptions {
    @ModifyConstant(method={"updatePlayerMoveState"}, constant={@Constant(doubleValue=0.3, ordinal=0)})
    public double noSlowSneakStrafe(double constant) {
        NoSlow noSlow = Objects.requireNonNull(Client.moduleManager.getModule(NoSlow.class));
        return Client.moduleManager != null && Client.moduleManager.getModule(NoSlow.class) != null && noSlow.getState() ? (double)((Float)noSlow.getSneakStrafeMultiplier().get()).floatValue() : 0.3;
    }

    @ModifyConstant(method={"updatePlayerMoveState"}, constant={@Constant(doubleValue=0.3, ordinal=1)})
    public double noSlowSneakForward(double constant) {
        NoSlow noSlow = Objects.requireNonNull(Client.moduleManager.getModule(NoSlow.class));
        return Client.moduleManager != null && Client.moduleManager.getModule(NoSlow.class) != null && noSlow.getState() ? (double)((Float)noSlow.getSneakForwardMultiplier().get()).floatValue() : 0.3;
    }
}

