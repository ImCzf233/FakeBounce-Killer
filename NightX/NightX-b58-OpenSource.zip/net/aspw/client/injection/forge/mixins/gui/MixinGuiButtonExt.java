/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraftforge.fml.client.config.GuiButtonExt
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.awt.Color;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.auth.GuiLoginScreen;
import net.aspw.client.visual.auth.GuiLoginSelection;
import net.aspw.client.visual.client.GuiMainMenu;
import net.aspw.client.visual.client.GuiProxyManager;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.client.altmanager.menus.GuiDirectLogin;
import net.aspw.client.visual.client.altmanager.menus.GuiLoginProgress;
import net.aspw.client.visual.client.altmanager.menus.GuiTheAltening;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.client.config.GuiButtonExt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={GuiButtonExt.class})
public abstract class MixinGuiButtonExt
extends GuiButton {
    private float alpha;

    public MixinGuiButtonExt(int p_i46323_1_, int p_i46323_2_, int p_i46323_3_, int p_i46323_4_, int p_i46323_5_, String p_i46323_6_) {
        super(p_i46323_1_, p_i46323_2_, p_i46323_3_, p_i46323_4_, p_i46323_5_, p_i46323_6_);
    }

    @Overwrite
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (this.visible) {
            FontRenderer fontRenderer = mc.getLanguageManager().isCurrentLocaleUnicode() ? mc.fontRendererObj : Fonts.minecraftFont;
            this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            Hud hud = Client.moduleManager.getModule(Hud.class);
            if (hud == null) {
                return;
            }
            this.alpha = this.enabled && this.hovered ? 140.0f : 100.0f;
            if (mc.currentScreen instanceof GuiMainMenu) {
                RenderUtils.originalRoundedRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, 0.0f, this.enabled ? new Color(0.0f, 0.0f, 0.0f, this.alpha / 255.0f).getRGB() : new Color(0.0f, 0.0f, 0.0f, 100.0f).getRGB());
            } else {
                RenderUtils.originalRoundedRect(this.xPosition, this.yPosition, this.xPosition + this.width, this.yPosition + this.height, 0.0f, new Color(0.0f, 0.0f, 0.0f, this.alpha / 255.0f).getRGB());
            }
            int j = 0xE0E0E0;
            int b = 0xE0E0E0;
            if (!this.enabled) {
                j = 0xA0A0A0;
                b = 0xA0A0A0;
            } else if (this.hovered) {
                j = 0xFFFFA0;
                b = 0x5050FF;
            }
            if (mc.currentScreen instanceof GuiMainMenu || mc.currentScreen instanceof GuiAltManager || mc.currentScreen instanceof GuiDirectLogin || mc.currentScreen instanceof GuiLoginProgress || mc.currentScreen instanceof GuiTheAltening || mc.currentScreen instanceof GuiProxyManager || mc.currentScreen instanceof GuiLoginScreen || mc.currentScreen instanceof GuiLoginSelection) {
                Fonts.fontSFUI40.drawCenteredString(this.displayString, (float)this.xPosition + (float)this.width / 2.0f, (float)this.yPosition + (float)(this.height - 8) / 2.0f, j);
            } else {
                mc.getTextureManager().bindTexture(buttonTextures);
                this.mouseDragged(mc, mouseX, mouseY);
                fontRenderer.drawString(this.displayString, this.xPosition + this.width / 2 - fontRenderer.getStringWidth(this.displayString) / 2, (int)((float)this.yPosition + (float)(this.height - 4) / 2.0f - 2.0f), b);
                GlStateManager.resetColor();
            }
        }
    }
}

