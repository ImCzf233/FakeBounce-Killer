/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.block.model.ItemCameraTransforms$TransformType
 *  net.minecraft.client.renderer.entity.RendererLivingEntity
 *  net.minecraft.client.renderer.entity.layers.LayerHeldItem
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 */
package net.aspw.client.injection.forge.mixins.render;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={LayerHeldItem.class})
public class MixinLayerHeldItem {
    @Shadow
    @Final
    private RendererLivingEntity<?> field_177206_a;

    @Overwrite
    public void func_177141_a(EntityLivingBase entitylivingbaseIn, float p_177141_2_, float p_177141_3_, float partialTicks, float p_177141_5_, float p_177141_6_, float p_177141_7_, float scale) {
        ItemStack itemstack = entitylivingbaseIn.getHeldItem();
        if (itemstack != null) {
            GlStateManager.pushMatrix();
            if (this.field_177206_a.getMainModel().isChild) {
                float f = 0.5f;
                GlStateManager.translate((float)0.0f, (float)0.625f, (float)0.0f);
                GlStateManager.rotate((float)-20.0f, (float)-1.0f, (float)0.0f, (float)0.0f);
                GlStateManager.scale((float)f, (float)f, (float)f);
            }
            Item item = itemstack.getItem();
            ((ModelBiped)this.field_177206_a.getMainModel()).postRenderArm(0.0625f);
            GlStateManager.translate((float)-0.0625f, (float)0.4375f, (float)0.0625f);
            if (entitylivingbaseIn instanceof EntityPlayer && ((EntityPlayer)entitylivingbaseIn).fishEntity != null) {
                itemstack = new ItemStack((Item)Items.fishing_rod, 0);
            }
            Minecraft minecraft = Minecraft.getMinecraft();
            if (item instanceof ItemBlock && Block.getBlockFromItem((Item)item).getRenderType() == 2) {
                GlStateManager.translate((float)0.0f, (float)0.1875f, (float)-0.3125f);
                GlStateManager.rotate((float)20.0f, (float)1.0f, (float)0.0f, (float)0.0f);
                GlStateManager.rotate((float)45.0f, (float)0.0f, (float)1.0f, (float)0.0f);
                float f1 = 0.375f;
                GlStateManager.scale((float)(-f1), (float)(-f1), (float)f1);
            }
            if (entitylivingbaseIn.isSneaking()) {
                GlStateManager.translate((float)0.0f, (float)0.203125f, (float)0.0f);
            }
            minecraft.getItemRenderer().renderItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON);
            GlStateManager.popMatrix();
        }
    }
}

