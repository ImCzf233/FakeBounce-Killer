/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.TextEvent;
import net.aspw.client.util.misc.StringUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={FontRenderer.class})
public abstract class MixinFontRenderer {
    @Shadow
    protected abstract void func_78265_b();

    @Inject(method={"drawString(Ljava/lang/String;FFIZ)I"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/FontRenderer;renderString(Ljava/lang/String;FFIZ)I", ordinal=0, shift=At.Shift.AFTER)})
    private void resetStyle(CallbackInfoReturnable<Integer> ci) {
        this.func_78265_b();
    }

    @ModifyVariable(method={"renderString"}, at=@At(value="HEAD"), require=1, ordinal=0, argsOnly=true)
    private String renderString(String string) {
        if (string == null) {
            return null;
        }
        if (Client.eventManager == null) {
            return string;
        }
        TextEvent textEvent = new TextEvent(string);
        Client.eventManager.callEvent(textEvent);
        if (Minecraft.getMinecraft().thePlayer == null || Objects.requireNonNull(textEvent.getText()).contains("\u00a7c\u00a7l>> \u00a7r\u00a73") || textEvent.getText().startsWith("/") || textEvent.getText().startsWith(".")) {
            return textEvent.getText();
        }
        textEvent.setText(StringUtils.replace(textEvent.getText(), "As_pw", "\u00a7r[\u00a7dNightX Owner\u00a7r] As\u00a7r_pw") + "\u00a7f");
        textEvent.setText(StringUtils.replace(textEvent.getText(), "sex_3p_19194545", "\u00a7r[\u00a7dNightX Dev\u00a7r] se\u00a7rx_3p_19194545") + "\u00a7f");
        textEvent.setText(StringUtils.replace(textEvent.getText(), "Favpw", "\u00a7r[\u00a7dNightX Dev\u00a7r] Fa\u00a7rvpw") + "\u00a7f");
        textEvent.setText(StringUtils.replace(textEvent.getText(), "outaokura", "\u00a7r[\u00a7cGay Donut\u00a7r] ou\u00a7rtaokura") + "\u00a7f");
        return textEvent.getText();
    }

    @ModifyVariable(method={"getStringWidth"}, at=@At(value="HEAD"), require=1, ordinal=0, argsOnly=true)
    private String getStringWidth(String string) {
        if (string == null) {
            return null;
        }
        if (Client.eventManager == null) {
            return string;
        }
        TextEvent textEvent = new TextEvent(string);
        Client.eventManager.callEvent(textEvent);
        return textEvent.getText();
    }
}

