/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.item;

import net.aspw.client.injection.implementations.IItemStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ItemStack.class})
public class MixinItemStack
implements IItemStack {
    private long itemDelay;
    private String cachedDisplayName;

    @Inject(method={"<init>(Lnet/minecraft/item/Item;IILnet/minecraft/nbt/NBTTagCompound;)V"}, at={@At(value="RETURN")})
    private void init(CallbackInfo callbackInfo) {
        this.itemDelay = System.currentTimeMillis();
    }

    @Override
    public long getItemDelay() {
        return this.itemDelay;
    }

    @Redirect(method={"getTooltip"}, at=@At(value="INVOKE", target="Ljava/lang/Integer;toHexString(I)Ljava/lang/String;"))
    private String fixHexColorString(int i) {
        return String.format("%06X", i);
    }

    @Inject(method={"getDisplayName"}, at={@At(value="HEAD")}, cancellable=true)
    private void returnCachedDisplayName(CallbackInfoReturnable<String> cir) {
        if (this.cachedDisplayName != null) {
            cir.setReturnValue((Object)this.cachedDisplayName);
        }
    }

    @Inject(method={"getDisplayName"}, at={@At(value="RETURN")})
    private void cacheDisplayName(CallbackInfoReturnable<String> cir) {
        this.cachedDisplayName = (String)cir.getReturnValue();
    }

    @Inject(method={"setStackDisplayName"}, at={@At(value="HEAD")})
    private void resetCachedDisplayName(String displayName, CallbackInfoReturnable<ItemStack> cir) {
        this.cachedDisplayName = null;
    }
}

