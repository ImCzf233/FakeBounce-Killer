/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.injection.implementations;

public interface IItemStack {
    public long getItemDelay();
}

