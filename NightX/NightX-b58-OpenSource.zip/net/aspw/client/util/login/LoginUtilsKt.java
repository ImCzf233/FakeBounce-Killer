/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  me.liuli.elixir.compat.Session
 *  net.minecraft.util.Session
 */
package net.aspw.client.util.login;

import kotlin.jvm.internal.Intrinsics;
import net.minecraft.util.Session;

public final class LoginUtilsKt {
    public static final Session intoMinecraftSession(me.liuli.elixir.compat.Session $this$intoMinecraftSession) {
        Intrinsics.checkNotNullParameter((Object)$this$intoMinecraftSession, (String)"<this>");
        return new Session($this$intoMinecraftSession.getUsername(), $this$intoMinecraftSession.getUuid(), $this$intoMinecraftSession.getToken(), $this$intoMinecraftSession.getType());
    }
}

