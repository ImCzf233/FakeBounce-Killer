/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  kotlin.Unit
 *  kotlin.io.CloseableKt
 *  kotlin.jvm.internal.Intrinsics
 *  org.apache.http.Header
 *  org.apache.http.HttpEntity
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpPost
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.entity.StringEntity
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 *  org.apache.http.message.BasicHeader
 *  org.apache.http.util.EntityUtils
 */
package net.aspw.client.util.login;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.Closeable;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.HttpsURLConnection;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

public final class UserUtils {
    public static final UserUtils INSTANCE = new UserUtils();

    private UserUtils() {
    }

    public final boolean isValidTokenOffline(String token) {
        Intrinsics.checkNotNullParameter((Object)token, (String)"token");
        return token.length() >= 32;
    }

    public final boolean isValidToken(String token) {
        Intrinsics.checkNotNullParameter((Object)token, (String)"token");
        CloseableHttpClient client = HttpClients.createDefault();
        BasicHeader[] basicHeaderArray = new BasicHeader[]{new BasicHeader("Content-Type", "application/json")};
        BasicHeader[] headers = basicHeaderArray;
        HttpPost request = new HttpPost("https://authserver.mojang.com/validate");
        request.setHeaders((Header[])headers);
        JsonObject body = new JsonObject();
        body.addProperty("accessToken", token);
        request.setEntity((HttpEntity)new StringEntity(new Gson().toJson((JsonElement)body)));
        CloseableHttpResponse response = client.execute((HttpUriRequest)request);
        return response.getStatusLine().getStatusCode() == 204;
    }

    public final String getUsername(String uuid) {
        Intrinsics.checkNotNullParameter((Object)uuid, (String)"uuid");
        CloseableHttpClient client = HttpClients.createDefault();
        HttpGet request = new HttpGet("https://api.mojang.com/user/profiles/" + uuid + "/names");
        CloseableHttpResponse response = client.execute((HttpUriRequest)request);
        if (response.getStatusLine().getStatusCode() != 200) {
            return null;
        }
        JsonArray names = new JsonParser().parse(EntityUtils.toString((HttpEntity)response.getEntity())).getAsJsonArray();
        return names.get(names.size() - 1).getAsJsonObject().get("name").getAsString();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public final String getUUID(String username) {
        Intrinsics.checkNotNullParameter((Object)username, (String)"username");
        try {
            URLConnection uRLConnection = new URL(Intrinsics.stringPlus((String)"https://api.mojang.com/users/profiles/minecraft/", (Object)username)).openConnection();
            if (uRLConnection == null) {
                throw new NullPointerException("null cannot be cast to non-null type javax.net.ssl.HttpsURLConnection");
            }
            HttpsURLConnection httpConnection = (HttpsURLConnection)uRLConnection;
            httpConnection.setConnectTimeout(2000);
            httpConnection.setReadTimeout(2000);
            httpConnection.setRequestMethod("GET");
            httpConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:25.0) Gecko/20100101 Firefox/25.0");
            HttpURLConnection.setFollowRedirects(true);
            httpConnection.setDoOutput(true);
            if (httpConnection.getResponseCode() != 200) {
                return "";
            }
            Closeable closeable = new InputStreamReader(httpConnection.getInputStream());
            Throwable throwable = null;
            try {
                InputStreamReader it = (InputStreamReader)closeable;
                boolean bl = false;
                JsonElement jsonElement = new JsonParser().parse((Reader)it);
                if (jsonElement.isJsonObject()) {
                    String string = jsonElement.getAsJsonObject().get("id").getAsString();
                    Intrinsics.checkNotNullExpressionValue((Object)string, (String)"jsonElement.asJsonObject.get(\"id\").asString");
                    String string2 = string;
                    return string2;
                }
                Unit unit = Unit.INSTANCE;
            }
            catch (Throwable throwable2) {
                throwable = throwable2;
                throw throwable2;
            }
            finally {
                CloseableKt.closeFinally((Closeable)closeable, (Throwable)throwable);
            }
        }
        catch (Throwable throwable) {
            // empty catch block
        }
        return "";
    }
}

