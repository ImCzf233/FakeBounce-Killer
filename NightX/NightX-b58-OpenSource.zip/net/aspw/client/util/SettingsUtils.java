/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.api.MacroManager;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.impl.exploit.Plugins;
import net.aspw.client.features.module.impl.exploit.ThunderNotifier;
import net.aspw.client.features.module.impl.other.FreeLook;
import net.aspw.client.features.module.impl.other.HackerDetect;
import net.aspw.client.features.module.impl.other.MoreParticles;
import net.aspw.client.features.module.impl.other.NameProtect;
import net.aspw.client.features.module.impl.other.PlayerEdit;
import net.aspw.client.features.module.impl.player.Freecam;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.BlockOverlay;
import net.aspw.client.features.module.impl.visual.Cape;
import net.aspw.client.features.module.impl.visual.ChestESP;
import net.aspw.client.features.module.impl.visual.ChinaHat;
import net.aspw.client.features.module.impl.visual.Crosshair;
import net.aspw.client.features.module.impl.visual.CustomModel;
import net.aspw.client.features.module.impl.visual.EnchantColor;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.features.module.impl.visual.HudEditor;
import net.aspw.client.features.module.impl.visual.ItemESP;
import net.aspw.client.features.module.impl.visual.ItemPhysics;
import net.aspw.client.features.module.impl.visual.JumpCircle;
import net.aspw.client.features.module.impl.visual.OptiFinePlus;
import net.aspw.client.features.module.impl.visual.PointerESP;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.features.module.impl.visual.Tracers;
import net.aspw.client.features.module.impl.visual.Trails;
import net.aspw.client.features.module.impl.visual.ViewBobbing;
import net.aspw.client.features.module.impl.visual.Wings;
import net.aspw.client.features.module.impl.visual.XRay;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.misc.HttpUtils;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.value.TextValue;
import net.aspw.client.value.Value;
import org.lwjgl.input.Keyboard;

public final class SettingsUtils {
    public static final SettingsUtils INSTANCE = new SettingsUtils();

    private SettingsUtils() {
    }

    /*
     * WARNING - void declaration
     */
    public final void executeScript(String script) {
        void $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter((Object)script, (String)"script");
        Iterable $this$filter$iv = StringsKt.lines((CharSequence)script);
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            String it = (String)element$iv$iv;
            boolean bl = false;
            if (!(((CharSequence)it).length() > 0 && !StringsKt.startsWith$default((CharSequence)it, (char)'#', (boolean)false, (int)2, null))) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEachIndexed$iv = (List)destination$iv$iv;
        boolean $i$f$forEachIndexed = false;
        int index$iv = 0;
        block30: for (Object item$iv : $this$forEachIndexed$iv) {
            String[] args;
            void s;
            Object element$iv$iv;
            int n = index$iv;
            index$iv = n + 1;
            if (n < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            element$iv$iv = (String)item$iv;
            int index = n;
            boolean bl = false;
            Object object = new String[]{" "};
            Collection $this$toTypedArray$iv = StringsKt.split$default((CharSequence)((CharSequence)s), (String[])object, (boolean)false, (int)0, (int)6, null);
            boolean $i$f$toTypedArray2 = false;
            Collection thisCollection$iv = $this$toTypedArray$iv;
            if (thisCollection$iv.toArray(new String[0]) == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
            }
            if (args.length <= 1) continue;
            switch (args[0]) {
                case "chat": {
                    String $i$f$toTypedArray2 = StringUtils.toCompleteString(args, 1);
                    Intrinsics.checkNotNullExpressionValue((Object)$i$f$toTypedArray2, (String)"toCompleteString(args, 1)");
                    ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a7e", (Object)ColorUtils.translateAlternateColorCodes($i$f$toTypedArray2)));
                    break;
                }
                case "unchat": {
                    String $i$f$toTypedArray2 = StringUtils.toCompleteString(args, 1);
                    Intrinsics.checkNotNullExpressionValue((Object)$i$f$toTypedArray2, (String)"toCompleteString(\n      \u2026                        )");
                    ClientUtils.displayChatMessage(ColorUtils.translateAlternateColorCodes($i$f$toTypedArray2));
                    break;
                }
                case "load": {
                    String urlRaw;
                    String url = urlRaw = StringUtils.toCompleteString(args, 1);
                    try {
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a77Loading settings from \u00a7a\u00a7l" + url + "\u00a77...");
                        Intrinsics.checkNotNullExpressionValue((Object)url, (String)"url");
                        INSTANCE.executeScript(HttpUtils.get(url));
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a77Loaded settings from \u00a7a\u00a7l" + url + "\u00a77.");
                    }
                    catch (Exception e) {
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a77Failed to load settings from \u00a7a\u00a7l" + url + "\u00a77.");
                    }
                    break;
                }
                case "macro": {
                    if (args[1].equals("0")) continue block30;
                    String macroBind = args[1];
                    String macroCommand = StringUtils.toCompleteString(args, 2);
                    try {
                        int n2 = Integer.parseInt(macroBind);
                        Intrinsics.checkNotNullExpressionValue((Object)macroCommand, (String)"macroCommand");
                        MacroManager.INSTANCE.addMacro(n2, macroCommand);
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7rMacro \u00a7c\u00a7l" + macroCommand + "\u00a77 has been bound to \u00a7a\u00a7l" + macroBind + "\u00a77.");
                    }
                    catch (Exception e) {
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + e.getClass().getName() + "\u00a77(" + e.getMessage() + ") \u00a7cAn Exception occurred while importing macro with keybind \u00a7a\u00a7l" + macroBind + "\u00a7c to \u00a7a\u00a7l" + macroCommand + "\u00a7c.");
                    }
                    break;
                }
                case "targetPlayer": 
                case "targetPlayers": {
                    EntityUtils.targetPlayer = StringsKt.equals((String)args[1], (String)"true", (boolean)true);
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + args[0] + "\u00a77 set to \u00a7c\u00a7l" + EntityUtils.targetPlayer + "\u00a77.");
                    break;
                }
                case "targetMobs": {
                    EntityUtils.targetMobs = StringsKt.equals((String)args[1], (String)"true", (boolean)true);
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + args[0] + "\u00a77 set to \u00a7c\u00a7l" + EntityUtils.targetMobs + "\u00a77.");
                    break;
                }
                case "targetAnimals": {
                    EntityUtils.targetAnimals = StringsKt.equals((String)args[1], (String)"true", (boolean)true);
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + args[0] + "\u00a77 set to \u00a7c\u00a7l" + EntityUtils.targetAnimals + "\u00a77.");
                    break;
                }
                case "targetInvisible": {
                    EntityUtils.targetInvisible = StringsKt.equals((String)args[1], (String)"true", (boolean)true);
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + args[0] + "\u00a77 set to \u00a7c\u00a7l" + EntityUtils.targetInvisible + "\u00a77.");
                    break;
                }
                case "targetDead": {
                    EntityUtils.targetDead = StringsKt.equals((String)args[1], (String)"false", (boolean)true);
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7a\u00a7l" + args[0] + "\u00a77 set to \u00a7c\u00a7l" + EntityUtils.targetDead + "\u00a77.");
                    break;
                }
                default: {
                    if (args.length != 3) continue block30;
                    String moduleName = args[0];
                    String valueName = args[1];
                    String value = args[2];
                    Module module = Client.INSTANCE.getModuleManager().getModule(moduleName);
                    if (module == null) continue block30;
                    if (StringsKt.equals((String)valueName, (String)"toggle", (boolean)true)) {
                        module.setState(StringsKt.equals((String)value, (String)"true", (boolean)true));
                        continue block30;
                    }
                    if (StringsKt.equals((String)valueName, (String)"bind", (boolean)true)) {
                        module.setKeyBind(Keyboard.getKeyIndex((String)value));
                        continue block30;
                    }
                    Value<?> moduleValue = module.getValue(valueName);
                    if (moduleValue == null) continue block30;
                    try {
                        Value<?> value2 = moduleValue;
                        if (value2 instanceof BoolValue) {
                            ((BoolValue)moduleValue).changeValue(Boolean.parseBoolean(value));
                            break;
                        }
                        if (value2 instanceof FloatValue) {
                            ((FloatValue)moduleValue).changeValue(Float.valueOf(Float.parseFloat(value)));
                            break;
                        }
                        if (value2 instanceof IntegerValue) {
                            ((IntegerValue)moduleValue).changeValue(Integer.parseInt(value));
                            break;
                        }
                        if (value2 instanceof TextValue) {
                            ((TextValue)moduleValue).changeValue(value);
                            break;
                        }
                        if (!(value2 instanceof ListValue)) continue block30;
                        ((ListValue)moduleValue).changeValue(value);
                        break;
                    }
                    catch (Exception exception) {
                    }
                }
            }
        }
        Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().valuesConfig);
    }

    /*
     * WARNING - void declaration
     */
    public final String generateScript(boolean values, boolean binds, boolean states) {
        void $this$forEach$iv;
        Object it;
        Object $this$filterTo$iv$iv;
        StringBuilder stringBuilder = new StringBuilder();
        Object $this$filter$iv = MacroManager.INSTANCE.getMacroMapping();
        boolean $i$f$filter = false;
        Object object = $this$filter$iv;
        Object destination$iv$iv = new LinkedHashMap();
        boolean $i$f$filterTo = false;
        for (Map.Entry element$iv$iv : $this$filterTo$iv$iv.entrySet()) {
            it = element$iv$iv;
            boolean bl = false;
            if (!(((Number)it.getKey()).intValue() != 0)) continue;
            destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
        }
        $this$filter$iv = destination$iv$iv;
        boolean $i$f$forEach = false;
        $this$filterTo$iv$iv = $this$forEach$iv.entrySet().iterator();
        while ($this$filterTo$iv$iv.hasNext()) {
            Map.Entry element$iv;
            Map.Entry it2 = element$iv = $this$filterTo$iv$iv.next();
            boolean bl = false;
            stringBuilder.append("macro " + ((Number)it2.getKey()).intValue() + ' ' + (String)it2.getValue()).append("\n");
        }
        $this$filter$iv = Client.INSTANCE.getModuleManager().getModules();
        $i$f$filter = false;
        $this$filterTo$iv$iv = $this$filter$iv;
        destination$iv$iv = new ArrayList();
        $i$f$filterTo = false;
        Iterator bl = $this$filterTo$iv$iv.iterator();
        while (bl.hasNext()) {
            Map.Entry element$iv$iv;
            element$iv$iv = bl.next();
            it = (Module)((Object)element$iv$iv);
            boolean bl2 = false;
            if (!(((Module)it).getCategory() != ModuleCategory.PREMIUM && !(it instanceof SilentView) && !(it instanceof Gui) && !(it instanceof OptiFinePlus) && !(it instanceof Cape) && !(it instanceof HackerDetect) && !(it instanceof HudEditor) && !(it instanceof XRay) && !(it instanceof Wings) && !(it instanceof BlockOverlay) && !(it instanceof ChestESP) && !(it instanceof Crosshair) && !(it instanceof CustomModel) && !(it instanceof EnchantColor) && !(it instanceof MoreParticles) && !(it instanceof ItemESP) && !(it instanceof ItemPhysics) && !(it instanceof JumpCircle) && !(it instanceof PlayerEdit) && !(it instanceof PointerESP) && !(it instanceof ViewBobbing) && !(it instanceof ChinaHat) && !(it instanceof NameProtect) && !(it instanceof Tracers) && !(it instanceof Trails) && !(it instanceof Freecam) && !(it instanceof FreeLook) && !(it instanceof Plugins) && !(it instanceof ThunderNotifier) && !(it instanceof Hud) && !(it instanceof Animations))) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        $this$filter$iv = (List)destination$iv$iv;
        $i$f$forEach = false;
        for (Map.Entry element$iv : $this$forEach$iv) {
            Module it3 = (Module)((Object)element$iv);
            boolean bl3 = false;
            if (values) {
                Iterable $this$forEach$iv2 = it3.getValues();
                boolean $i$f$forEach2 = false;
                for (Object element$iv2 : $this$forEach$iv2) {
                    Value value = (Value)element$iv2;
                    boolean bl4 = false;
                    stringBuilder.append(it3.getName() + ' ' + value.getName() + ' ' + value.get()).append("\n");
                }
            }
            if (states) {
                stringBuilder.append(it3.getName() + " toggle " + it3.getState()).append("\n");
            }
            if (!binds) continue;
            stringBuilder.append(it3.getName() + " bind " + Keyboard.getKeyName((int)it3.getKeyBind())).append("\n");
        }
        String string = stringBuilder.toString();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"stringBuilder.toString()");
        return string;
    }
}

