/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.util;

import net.aspw.client.util.MinecraftInstance;

public final class TransferUtils
extends MinecraftInstance {
    public static final TransferUtils INSTANCE = new TransferUtils();
    private static boolean noMotionSet;

    private TransferUtils() {
    }

    public final boolean getNoMotionSet() {
        return noMotionSet;
    }

    public final void setNoMotionSet(boolean bl) {
        noMotionSet = bl;
    }
}

