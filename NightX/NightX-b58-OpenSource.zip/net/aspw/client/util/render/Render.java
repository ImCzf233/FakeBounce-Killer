/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.Vec3
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.util.render;

import java.awt.Color;
import net.aspw.client.util.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

public class Render {
    public float alpha = 255.0f;
    public Vec3 vec3;
    public long time;
    public float d;
    public Color color;

    public Render(double x, double y, double z, long time, Color color) {
        this.vec3 = new Vec3(x, y, z);
        this.time = time;
        this.color = color;
    }

    public void draw() {
        double var15;
        int i;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glShadeModel((int)7425);
        GL11.glDisable((int)3553);
        GlStateManager.disableDepth();
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2896);
        GL11.glDepthMask((boolean)false);
        GL11.glHint((int)3154, (int)4354);
        GL11.glLineWidth((float)3.0f);
        GL11.glBegin((int)3);
        double renderPosX = Minecraft.getMinecraft().getRenderManager().viewerPosX;
        double renderPosY = Minecraft.getMinecraft().getRenderManager().viewerPosY;
        double renderPosZ = Minecraft.getMinecraft().getRenderManager().viewerPosZ;
        RenderUtils.glColor(new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), (int)this.alpha));
        for (i = 0; i <= 360; ++i) {
            GL11.glVertex3d((double)(this.vec3.xCoord - renderPosX + Math.cos((double)i * Math.PI / 180.0) * 0.6 * (double)this.d), (double)(this.vec3.yCoord - renderPosY), (double)(this.vec3.zCoord - renderPosZ + Math.sin((double)i * Math.PI / 180.0) * 0.6 * (double)this.d));
        }
        GL11.glEnd();
        GL11.glBegin((int)5);
        for (i = 0; i <= 360; i += 10) {
            for (int var11 = 0; var11 <= 3; ++var11) {
                GL11.glVertex3d((double)(this.vec3.xCoord - renderPosX + -Math.sin(Math.toRadians(i)) * (double)this.d), (double)(this.vec3.yCoord - renderPosY), (double)(this.vec3.zCoord - renderPosZ + Math.cos(Math.toRadians(i)) * (double)this.d));
                GL11.glVertex3d((double)(this.vec3.xCoord - renderPosX + -Math.sin(Math.toRadians(i)) * ((double)this.d - (double)var11 / 10.0)), (double)(this.vec3.yCoord - renderPosY), (double)(this.vec3.zCoord - renderPosZ + Math.cos(Math.toRadians(i)) * ((double)this.d - (double)var11 / 10.0)));
            }
        }
        double var14 = 0.0;
        if (var14 < 361.0) {
            var14 += 5.0;
        }
        if ((var15 = 0.0) < 255.0) {
            var15 += 3.0;
        }
        GL11.glEnd();
        GL11.glDepthMask((boolean)true);
        GlStateManager.enableDepth();
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
        if (this.d == 1.5f) {
            this.alpha = (float)((double)this.alpha - var15);
            this.alpha = MathHelper.clamp_float((float)this.alpha, (float)0.0f, (float)255.0f);
        }
        this.d = (float)((double)this.d + 0.005 * var14);
        this.d = MathHelper.clamp_float((float)this.d, (float)0.0f, (float)1.5f);
    }

    public float alpha() {
        return this.alpha;
    }
}

