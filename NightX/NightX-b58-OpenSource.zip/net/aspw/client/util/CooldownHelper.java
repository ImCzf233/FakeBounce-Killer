/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.item.Item$ToolMaterial
 *  net.minecraft.item.ItemAxe
 *  net.minecraft.item.ItemHoe
 *  net.minecraft.item.ItemPickaxe
 *  net.minecraft.item.ItemSpade
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.MathHelper
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;
import org.jetbrains.annotations.Nullable;

public final class CooldownHelper {
    public static final CooldownHelper INSTANCE = new CooldownHelper();
    private static int lastAttackedTicks;
    private static double genericAttackSpeed;

    private CooldownHelper() {
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public final void updateGenericAttackSpeed(@Nullable ItemStack itemStack) {
        block22: {
            block26: {
                block25: {
                    block24: {
                        block23: {
                            block21: {
                                v0 = itemStack;
                                v1 /* !! */  = var2_2 = v0 == null ? null : v0.getItem();
                                if (!(var2_2 instanceof ItemSword)) break block21;
                                v2 = 1.6;
                                break block22;
                            }
                            if (!(var2_2 instanceof ItemAxe)) break block23;
                            v3 = itemStack.getItem();
                            if (v3 == null) {
                                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemAxe");
                            }
                            axe = (ItemAxe)v3;
                            v4 = axe.func_150913_i();
                            switch (v4 == null ? -1 : WhenMappings.$EnumSwitchMapping$0[v4.ordinal()]) {
                                case 1: {
                                    v2 = 0.9;
                                    break;
                                }
                                case 2: 
                                case 3: {
                                    v2 = 0.8;
                                    break;
                                }
                                default: {
                                    v2 = 1.0;
                                    break;
                                }
                            }
                            break block22;
                        }
                        if (!(var2_2 instanceof ItemPickaxe)) break block24;
                        v2 = 1.2;
                        break block22;
                    }
                    if (!(var2_2 instanceof ItemSpade)) break block25;
                    v2 = 1.0;
                    break block22;
                }
                if (!(var2_2 instanceof ItemHoe)) break block26;
                v5 = itemStack.getItem();
                if (v5 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemHoe");
                }
                hoe = (ItemHoe)v5;
                var4_5 = hoe.getMaterialName();
                if (var4_5 == null) ** GOTO lbl-1000
                tmp = -1;
                switch (var4_5.hashCode()) {
                    case -1921929932: {
                        if (var4_5.equals("DIAMOND")) {
                            tmp = 1;
                        }
                        break;
                    }
                    case 2256072: {
                        if (var4_5.equals("IRON")) {
                            tmp = 2;
                        }
                        break;
                    }
                    case 79233093: {
                        if (var4_5.equals("STONE")) {
                            tmp = 3;
                        }
                        break;
                    }
                }
                switch (tmp) {
                    case 3: {
                        v2 = 2.0;
                        break;
                    }
                    case 2: {
                        v2 = 3.0;
                        break;
                    }
                    case 1: {
                        v2 = 4.0;
                        break;
                    }
                    default: lbl-1000:
                    // 2 sources

                    {
                        v2 = 1.0;
                        break;
                    }
                }
                break block22;
            }
            v2 = CooldownHelper.genericAttackSpeed = 4.0;
        }
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.digSlowdown)) {
            CooldownHelper.genericAttackSpeed *= 1.0 - Math.min(1.0, 0.1 * (double)(Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.digSlowdown).getAmplifier() + 1));
        }
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.digSpeed)) {
            CooldownHelper.genericAttackSpeed *= 1.0 + 0.1 * (double)(Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.digSpeed).getAmplifier() + 1);
        }
    }

    public final double getAttackCooldownProgressPerTick() {
        return 1.0 / genericAttackSpeed * 20.0;
    }

    public final double getAttackCooldownProgress() {
        return MathHelper.clamp_double((double)((double)((float)lastAttackedTicks + Minecraft.getMinecraft().timer.renderPartialTicks) / this.getAttackCooldownProgressPerTick()), (double)0.0, (double)1.0);
    }

    public final void resetLastAttackedTicks() {
        lastAttackedTicks = 0;
    }

    public final void incrementLastAttackedTicks() {
        int n = lastAttackedTicks;
        lastAttackedTicks = n + 1;
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[Item.ToolMaterial.values().length];
            nArray[Item.ToolMaterial.IRON.ordinal()] = 1;
            nArray[Item.ToolMaterial.WOOD.ordinal()] = 2;
            nArray[Item.ToolMaterial.STONE.ordinal()] = 3;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

