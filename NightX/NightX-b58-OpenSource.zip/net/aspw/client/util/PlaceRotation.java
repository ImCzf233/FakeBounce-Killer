/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.util;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.block.PlaceInfo;
import org.jetbrains.annotations.Nullable;

public final class PlaceRotation {
    private final PlaceInfo placeInfo;
    private final Rotation rotation;

    public PlaceRotation(PlaceInfo placeInfo, Rotation rotation) {
        Intrinsics.checkNotNullParameter((Object)placeInfo, (String)"placeInfo");
        Intrinsics.checkNotNullParameter((Object)rotation, (String)"rotation");
        this.placeInfo = placeInfo;
        this.rotation = rotation;
    }

    public final PlaceInfo getPlaceInfo() {
        return this.placeInfo;
    }

    public final Rotation getRotation() {
        return this.rotation;
    }

    public final PlaceInfo component1() {
        return this.placeInfo;
    }

    public final Rotation component2() {
        return this.rotation;
    }

    public final PlaceRotation copy(PlaceInfo placeInfo, Rotation rotation) {
        Intrinsics.checkNotNullParameter((Object)placeInfo, (String)"placeInfo");
        Intrinsics.checkNotNullParameter((Object)rotation, (String)"rotation");
        return new PlaceRotation(placeInfo, rotation);
    }

    public static /* synthetic */ PlaceRotation copy$default(PlaceRotation placeRotation, PlaceInfo placeInfo, Rotation rotation, int n, Object object) {
        if ((n & 1) != 0) {
            placeInfo = placeRotation.placeInfo;
        }
        if ((n & 2) != 0) {
            rotation = placeRotation.rotation;
        }
        return placeRotation.copy(placeInfo, rotation);
    }

    public String toString() {
        return "PlaceRotation(placeInfo=" + this.placeInfo + ", rotation=" + this.rotation + ')';
    }

    public int hashCode() {
        int result = this.placeInfo.hashCode();
        result = result * 31 + this.rotation.hashCode();
        return result;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof PlaceRotation)) {
            return false;
        }
        PlaceRotation placeRotation = (PlaceRotation)other;
        if (!this.placeInfo.equals(placeRotation.placeInfo)) {
            return false;
        }
        return ((Object)this.rotation).equals(placeRotation.rotation);
    }
}

