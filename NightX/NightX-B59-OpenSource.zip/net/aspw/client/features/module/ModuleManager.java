/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.Listenable;
import net.aspw.client.features.command.impl.ModuleCommand;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.impl.combat.AimAssist;
import net.aspw.client.features.module.impl.combat.AntiFireBall;
import net.aspw.client.features.module.impl.combat.AntiStaff;
import net.aspw.client.features.module.impl.combat.AntiVelocity;
import net.aspw.client.features.module.impl.combat.AttackFreeze;
import net.aspw.client.features.module.impl.combat.AutoArmor;
import net.aspw.client.features.module.impl.combat.AutoClicker;
import net.aspw.client.features.module.impl.combat.AutoGapple;
import net.aspw.client.features.module.impl.combat.AutoHeal;
import net.aspw.client.features.module.impl.combat.AutoProjectile;
import net.aspw.client.features.module.impl.combat.BackTrack;
import net.aspw.client.features.module.impl.combat.BowAura;
import net.aspw.client.features.module.impl.combat.Criticals;
import net.aspw.client.features.module.impl.combat.FastBow;
import net.aspw.client.features.module.impl.combat.HitBox;
import net.aspw.client.features.module.impl.combat.KeepSprint;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.combat.KnockBackPlus;
import net.aspw.client.features.module.impl.combat.Reach;
import net.aspw.client.features.module.impl.combat.TPAura;
import net.aspw.client.features.module.impl.combat.TriggerBot;
import net.aspw.client.features.module.impl.exploit.AntiDesync;
import net.aspw.client.features.module.impl.exploit.AntiHunger;
import net.aspw.client.features.module.impl.exploit.BedWalker;
import net.aspw.client.features.module.impl.exploit.CivBreak;
import net.aspw.client.features.module.impl.exploit.ConsoleSpammer;
import net.aspw.client.features.module.impl.exploit.Disabler;
import net.aspw.client.features.module.impl.exploit.EntityDesync;
import net.aspw.client.features.module.impl.exploit.FakeLag;
import net.aspw.client.features.module.impl.exploit.GhostMode;
import net.aspw.client.features.module.impl.exploit.InfiniteDurability;
import net.aspw.client.features.module.impl.exploit.LiquidInteract;
import net.aspw.client.features.module.impl.exploit.NoMouseIntersect;
import net.aspw.client.features.module.impl.exploit.PacketDumper;
import net.aspw.client.features.module.impl.exploit.PingSpoofer;
import net.aspw.client.features.module.impl.exploit.Plugins;
import net.aspw.client.features.module.impl.exploit.PortalMenu;
import net.aspw.client.features.module.impl.exploit.Regen;
import net.aspw.client.features.module.impl.exploit.ResetVL;
import net.aspw.client.features.module.impl.exploit.ServerCrasher;
import net.aspw.client.features.module.impl.exploit.ThunderNotifier;
import net.aspw.client.features.module.impl.exploit.ViaVersionFix;
import net.aspw.client.features.module.impl.movement.AirJump;
import net.aspw.client.features.module.impl.movement.AntiAFK;
import net.aspw.client.features.module.impl.movement.AntiVoid;
import net.aspw.client.features.module.impl.movement.AntiWaterPush;
import net.aspw.client.features.module.impl.movement.EntityFlight;
import net.aspw.client.features.module.impl.movement.EntityJump;
import net.aspw.client.features.module.impl.movement.FastLadder;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.movement.HorseJump;
import net.aspw.client.features.module.impl.movement.InvMove;
import net.aspw.client.features.module.impl.movement.Jesus;
import net.aspw.client.features.module.impl.movement.LongJump;
import net.aspw.client.features.module.impl.movement.NoFall;
import net.aspw.client.features.module.impl.movement.NoSlow;
import net.aspw.client.features.module.impl.movement.Parkour;
import net.aspw.client.features.module.impl.movement.SafeWalk;
import net.aspw.client.features.module.impl.movement.SilentSneak;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.Sprint;
import net.aspw.client.features.module.impl.other.Annoy;
import net.aspw.client.features.module.impl.other.AntiSuffocation;
import net.aspw.client.features.module.impl.other.AutoAuth;
import net.aspw.client.features.module.impl.other.ChatFilter;
import net.aspw.client.features.module.impl.other.ClickTP;
import net.aspw.client.features.module.impl.other.ClientSpoof;
import net.aspw.client.features.module.impl.other.FakePlayer;
import net.aspw.client.features.module.impl.other.FastMine;
import net.aspw.client.features.module.impl.other.FastPlace;
import net.aspw.client.features.module.impl.other.FreeLook;
import net.aspw.client.features.module.impl.other.GamePlay;
import net.aspw.client.features.module.impl.other.HackerDetect;
import net.aspw.client.features.module.impl.other.InfiniteChat;
import net.aspw.client.features.module.impl.other.InfinitePitch;
import net.aspw.client.features.module.impl.other.LagBack;
import net.aspw.client.features.module.impl.other.MoreParticles;
import net.aspw.client.features.module.impl.other.NameProtect;
import net.aspw.client.features.module.impl.other.PackSpoofer;
import net.aspw.client.features.module.impl.other.PlayerEdit;
import net.aspw.client.features.module.impl.other.PotionSpoof;
import net.aspw.client.features.module.impl.other.Spammer;
import net.aspw.client.features.module.impl.other.Tweaks;
import net.aspw.client.features.module.impl.other.WorldTime;
import net.aspw.client.features.module.impl.player.AirPlace;
import net.aspw.client.features.module.impl.player.AutoFish;
import net.aspw.client.features.module.impl.player.AutoRespawn;
import net.aspw.client.features.module.impl.player.AutoTool;
import net.aspw.client.features.module.impl.player.BedBreaker;
import net.aspw.client.features.module.impl.player.Blink;
import net.aspw.client.features.module.impl.player.BowLongJump;
import net.aspw.client.features.module.impl.player.ChestAura;
import net.aspw.client.features.module.impl.player.ChestStealer;
import net.aspw.client.features.module.impl.player.FastBridge;
import net.aspw.client.features.module.impl.player.FastEat;
import net.aspw.client.features.module.impl.player.Freecam;
import net.aspw.client.features.module.impl.player.GodBridge;
import net.aspw.client.features.module.impl.player.HighJump;
import net.aspw.client.features.module.impl.player.InvManager;
import net.aspw.client.features.module.impl.player.NoViewReset;
import net.aspw.client.features.module.impl.player.Nuker;
import net.aspw.client.features.module.impl.player.Phase;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.features.module.impl.player.Spider;
import net.aspw.client.features.module.impl.player.Step;
import net.aspw.client.features.module.impl.player.TargetStrafe;
import net.aspw.client.features.module.impl.player.Timer;
import net.aspw.client.features.module.impl.premium.KeepChest;
import net.aspw.client.features.module.impl.premium.Protect;
import net.aspw.client.features.module.impl.premium.ShotBowDisabler;
import net.aspw.client.features.module.impl.premium.TestModule;
import net.aspw.client.features.module.impl.targets.Animals;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.targets.AntiTeams;
import net.aspw.client.features.module.impl.targets.Dead;
import net.aspw.client.features.module.impl.targets.Invisible;
import net.aspw.client.features.module.impl.targets.Mobs;
import net.aspw.client.features.module.impl.targets.Players;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.AntiBlind;
import net.aspw.client.features.module.impl.visual.BlockOverlay;
import net.aspw.client.features.module.impl.visual.CameraNoClip;
import net.aspw.client.features.module.impl.visual.Cape;
import net.aspw.client.features.module.impl.visual.ChestESP;
import net.aspw.client.features.module.impl.visual.ChinaHat;
import net.aspw.client.features.module.impl.visual.Crosshair;
import net.aspw.client.features.module.impl.visual.CustomModel;
import net.aspw.client.features.module.impl.visual.ESP;
import net.aspw.client.features.module.impl.visual.EnchantColor;
import net.aspw.client.features.module.impl.visual.FullBright;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.features.module.impl.visual.HudEditor;
import net.aspw.client.features.module.impl.visual.ItemESP;
import net.aspw.client.features.module.impl.visual.ItemPhysics;
import net.aspw.client.features.module.impl.visual.JumpCircle;
import net.aspw.client.features.module.impl.visual.OptiFinePlus;
import net.aspw.client.features.module.impl.visual.PointerESP;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.features.module.impl.visual.Skeletal;
import net.aspw.client.features.module.impl.visual.Tracers;
import net.aspw.client.features.module.impl.visual.Trails;
import net.aspw.client.features.module.impl.visual.ViewBobbing;
import net.aspw.client.features.module.impl.visual.Wings;
import net.aspw.client.features.module.impl.visual.XRay;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.value.Value;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ModuleManager
implements Listenable {
    private final TreeSet<Module> modules = new TreeSet(ModuleManager::modules$lambda-0);
    private final HashMap<Class<?>, Module> moduleClassMap = new HashMap();
    private boolean shouldNotify;
    private int toggleSoundMode;
    private float toggleVolume;
    private float popSoundPower = 90.0f;
    private float swingSoundPower = 75.0f;

    public ModuleManager() {
        Client.INSTANCE.getEventManager().registerListener(this);
    }

    public final TreeSet<Module> getModules() {
        return this.modules;
    }

    public final boolean getShouldNotify() {
        return this.shouldNotify;
    }

    public final void setShouldNotify(boolean bl) {
        this.shouldNotify = bl;
    }

    public final int getToggleSoundMode() {
        return this.toggleSoundMode;
    }

    public final void setToggleSoundMode(int n) {
        this.toggleSoundMode = n;
    }

    public final float getToggleVolume() {
        return this.toggleVolume;
    }

    public final void setToggleVolume(float f) {
        this.toggleVolume = f;
    }

    public final float getPopSoundPower() {
        return this.popSoundPower;
    }

    public final void setPopSoundPower(float f) {
        this.popSoundPower = f;
    }

    public final float getSwingSoundPower() {
        return this.swingSoundPower;
    }

    public final void setSwingSoundPower(float f) {
        this.swingSoundPower = f;
    }

    public final void registerPremiumModules() {
        ClientUtils.getLogger().info("Loading premium modules...");
        Class[] classArray = new Class[]{KeepChest.class, Protect.class, ShotBowDisabler.class, TestModule.class};
        this.registerModules(classArray);
    }

    public final void registerModules() {
        ClientUtils.getLogger().info("Loading modules...");
        Class[] classArray = new Class[]{BowAura.class, AimAssist.class, AutoProjectile.class, FastBow.class, Criticals.class, KillAura.class, AntiVelocity.class, Flight.class, HighJump.class, InvMove.class, NoSlow.class, Jesus.class, Sprint.class, AntiTeams.class, NoViewReset.class, AntiBots.class, ChestStealer.class, Scaffold.class, FastPlace.class, SilentSneak.class, Speed.class, Tracers.class, FastEat.class, FullBright.class, ItemESP.class, ChestESP.class, PingSpoofer.class, Step.class, AutoRespawn.class, AutoTool.class, Spammer.class, Regen.class, NoFall.class, Blink.class, NameProtect.class, Timer.class, Freecam.class, HitBox.class, Plugins.class, LongJump.class, AutoClicker.class, BlockOverlay.class, Phase.class, ServerCrasher.class, Animations.class, InvManager.class, AntiBlind.class, Trails.class, Reach.class, Hud.class, PackSpoofer.class, PortalMenu.class, WorldTime.class, EnchantColor.class, AutoAuth.class, AutoGapple.class, Disabler.class, Crosshair.class, AntiVoid.class, AntiFireBall.class, KeepSprint.class, ClickTP.class, ChinaHat.class, BowLongJump.class, PointerESP.class, SafeWalk.class, NoMouseIntersect.class, AntiHunger.class, AirJump.class, FastBridge.class, FastLadder.class, Parkour.class, Spider.class, FakeLag.class, GamePlay.class, AntiStaff.class, TPAura.class, AutoHeal.class, AntiAFK.class, AutoFish.class, GhostMode.class, HorseJump.class, LiquidInteract.class, Nuker.class, ResetVL.class, FastMine.class, Annoy.class, EntityDesync.class, ThunderNotifier.class, Mobs.class, Players.class, Animals.class, Invisible.class, AutoArmor.class, ViewBobbing.class, TargetStrafe.class, LagBack.class, Animals.class, Mobs.class, Players.class, ItemPhysics.class, Tweaks.class, Dead.class, Invisible.class, PotionSpoof.class, MoreParticles.class, CivBreak.class, PlayerEdit.class, ClientSpoof.class, KnockBackPlus.class, TriggerBot.class, FakePlayer.class, JumpCircle.class, AntiDesync.class, FreeLook.class, CameraNoClip.class, CustomModel.class, InfiniteDurability.class, EntityFlight.class, BedBreaker.class, ChestAura.class, BedWalker.class, Wings.class, SilentView.class, BackTrack.class, ChatFilter.class, AntiWaterPush.class, XRay.class, Cape.class, HudEditor.class, Gui.class, InfinitePitch.class, PacketDumper.class, HackerDetect.class, ViaVersionFix.class, InfiniteChat.class, OptiFinePlus.class, EntityJump.class, ConsoleSpammer.class, ESP.class, GodBridge.class, AirPlace.class, Skeletal.class, AntiSuffocation.class, AttackFreeze.class};
        this.registerModules(classArray);
        ClientUtils.getLogger().info("Successfully loaded " + this.modules.size() + " modules.");
    }

    private final void registerModule(Module module) {
        ((Collection)this.modules).add(module);
        Map map = this.moduleClassMap;
        Class<?> clazz = module.getClass();
        map.put(clazz, module);
        module.onInitialize();
        this.generateCommand$nightx(module);
        Client.INSTANCE.getEventManager().registerListener(module);
    }

    private final void registerModule(Class<? extends Module> moduleClass) {
        try {
            Module module = moduleClass.newInstance();
            Intrinsics.checkNotNullExpressionValue((Object)module, (String)"moduleClass.newInstance()");
            this.registerModule(module);
        }
        catch (Throwable e) {
            ClientUtils.getLogger().error("Failed to load module: " + moduleClass.getName() + " (" + e.getClass().getName() + ": " + e.getMessage() + ')');
        }
    }

    @SafeVarargs
    public final void registerModules(Class<? extends Module> ... modules) {
        Intrinsics.checkNotNullParameter(modules, (String)"modules");
        Class<? extends Module>[] $this$forEach$iv = modules;
        boolean $i$f$forEach = false;
        for (Class<? extends Module> element$iv : $this$forEach$iv) {
            Class<? extends Module> p0 = element$iv;
            boolean bl = false;
            this.registerModule(p0);
        }
    }

    public final void generateCommand$nightx(Module module) {
        Intrinsics.checkNotNullParameter((Object)module, (String)"module");
        List<Value<?>> values = module.getValues();
        if (values.isEmpty()) {
            return;
        }
        Client.INSTANCE.getCommandManager().registerCommand(new ModuleCommand(module, values));
    }

    public final <T extends Module> T getModule(Class<T> moduleClass) {
        Intrinsics.checkNotNullParameter(moduleClass, (String)"moduleClass");
        return (T)this.moduleClassMap.get(moduleClass);
    }

    public final <T extends Module> T get(Class<T> clazz) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        return this.getModule(clazz);
    }

    public final Module getModule(@Nullable String moduleName) {
        Object v0;
        block1: {
            for (Object t : (Iterable)this.modules) {
                Module it = (Module)t;
                boolean bl = false;
                if (!StringsKt.equals((String)it.getName(), (String)moduleName, (boolean)true)) continue;
                v0 = t;
                break block1;
            }
            v0 = null;
        }
        return v0;
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    private final void onKey(KeyEvent event) {
        void $this$filterTo$iv$iv;
        Iterable $this$filter$iv = this.modules;
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Module it = (Module)element$iv$iv;
            boolean bl = false;
            if (!(it.getKeyBind() == event.getKey())) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEach$iv = (List)destination$iv$iv;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Module it = (Module)element$iv;
            boolean bl = false;
            it.toggle();
        }
    }

    @Override
    public boolean handleEvents() {
        return true;
    }

    private static final int modules$lambda-0(Module module1, Module module2) {
        return module1.getName().compareTo(module2.getName());
    }
}

