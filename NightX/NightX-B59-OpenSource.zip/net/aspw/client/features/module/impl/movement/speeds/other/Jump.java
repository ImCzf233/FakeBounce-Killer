/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class Jump
extends SpeedMode {
    public Jump() {
        super("Jump");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        if (MovementUtils.isMoving() && Jump.mc.thePlayer.onGround && !Jump.mc.gameSettings.keyBindJump.isKeyDown() && !Jump.mc.thePlayer.isInWater() && !Jump.mc.thePlayer.isInLava() && Jump.mc.thePlayer.jumpTicks == 0) {
            Jump.mc.thePlayer.jump();
            Jump.mc.thePlayer.jumpTicks = 10;
        }
        if (((Boolean)speed2.jumpStrafe.get()).booleanValue() && MovementUtils.isMoving() && !Jump.mc.thePlayer.onGround && !Jump.mc.thePlayer.isInWater() && !Jump.mc.thePlayer.isInLava()) {
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

