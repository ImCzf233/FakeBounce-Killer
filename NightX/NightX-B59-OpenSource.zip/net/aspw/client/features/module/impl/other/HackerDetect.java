/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockHopper
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import java.util.ArrayList;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockHopper;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

@ModuleInfo(name="HackerDetect", spacedName="Hacker Detect", description="", category=ModuleCategory.OTHER)
public final class HackerDetect
extends Module {
    private final ArrayList<EntityPlayer> hackers = new ArrayList();

    public HackerDetect() {
        this.setState(true);
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() != EventState.PRE) {
            return;
        }
        if (MinecraftInstance.mc.thePlayer.ticksExisted <= 105) {
            this.hackers.clear();
            return;
        }
        for (EntityPlayer player : MinecraftInstance.mc.theWorld.playerEntities) {
            int n;
            double lastY;
            double y;
            double yDiff;
            if (player == MinecraftInstance.mc.thePlayer || player.ticksExisted < 105 || this.hackers.contains(player)) continue;
            Intrinsics.checkNotNullExpressionValue((Object)player, (String)"player");
            if (AntiBots.Companion.isBot((EntityLivingBase)player) || player.capabilities.isFlying || player.capabilities.isCreativeMode) continue;
            double playerSpeed = this.getBPS((EntityLivingBase)player);
            if ((player.isUsingItem() || player.isBlocking()) && player.onGround && playerSpeed >= 6.5) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using NoSlow!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (player.isSprinting() && (player.moveForward < 0.0f || player.moveForward == 0.0f && !(player.moveStrafing == 0.0f))) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using Speed!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (!MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)player, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, player.motionY, 0.0)).isEmpty() && player.motionY > 0.0 && playerSpeed > 10.0) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using Flight!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            double d = yDiff = (y = (double)Math.abs((int)player.posY)) > (lastY = (double)Math.abs((int)player.lastTickPosY)) ? y - lastY : lastY - y;
            if (yDiff > 0.0 && MinecraftInstance.mc.thePlayer.onGround && player.motionY == -0.0784000015258789) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using Step!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            boolean bl = 5 <= (n = player.hurtTime) ? n < 9 : false;
            if (bl && MinecraftInstance.mc.thePlayer.onGround && player.motionY == -0.0784000015258789 && player.motionX == 0.0 && player.motionZ == 0.0) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using Anti Velocity!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (!(player.fallDistance == 0.0f) || player.motionY >= -0.08 || this.InsideBlock(player) || player.onGround || !MinecraftInstance.mc.thePlayer.isInWater()) continue;
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.getName(), (Object)" is using No Fall!"), Notification.Type.INFO));
            this.hackers.add(player);
        }
    }

    public final int getBPS(EntityLivingBase entityIn) {
        Intrinsics.checkNotNullParameter((Object)entityIn, (String)"entityIn");
        double bps = this.getLastDist(entityIn) * 10.0;
        return (int)bps;
    }

    public final double getLastDist(EntityLivingBase entIn) {
        Intrinsics.checkNotNullParameter((Object)entIn, (String)"entIn");
        double xDist = entIn.posX - entIn.prevPosX;
        double zDist = entIn.posZ - entIn.prevPosZ;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public final boolean InsideBlock(EntityPlayer player) {
        Intrinsics.checkNotNullParameter((Object)player, (String)"player");
        int n = MathHelper.floor_double((double)player.getEntityBoundingBox().minX);
        int n2 = MathHelper.floor_double((double)player.getEntityBoundingBox().maxX) + 1;
        while (n < n2) {
            int x = n++;
            int n3 = MathHelper.floor_double((double)player.getEntityBoundingBox().minY);
            int n4 = MathHelper.floor_double((double)player.getEntityBoundingBox().maxY) + 1;
            while (n3 < n4) {
                int y = n3++;
                int n5 = MathHelper.floor_double((double)player.getEntityBoundingBox().minZ);
                int n6 = MathHelper.floor_double((double)player.getEntityBoundingBox().maxZ) + 1;
                while (n5 < n6) {
                    int z;
                    Block block;
                    if ((block = MinecraftInstance.mc.theWorld.getBlockState(new BlockPos(x, y, z = n5++)).getBlock()) == null || block instanceof BlockAir) continue;
                    WorldClient worldClient = MinecraftInstance.mc.theWorld;
                    if (worldClient == null) {
                        throw new NullPointerException("null cannot be cast to non-null type net.minecraft.world.World");
                    }
                    AxisAlignedBB boundingBox = block.getCollisionBoundingBox((World)worldClient, new BlockPos(x, y, z), MinecraftInstance.mc.theWorld.getBlockState(new BlockPos(x, y, z)));
                    if (block instanceof BlockHopper) {
                        boundingBox = new AxisAlignedBB((double)x, (double)y, (double)z, (double)(x + 1), (double)(y + 1), (double)(z + 1));
                    }
                    if (boundingBox == null || !player.getEntityBoundingBox().intersectsWith(boundingBox)) continue;
                    return true;
                }
            }
        }
        return false;
    }
}

