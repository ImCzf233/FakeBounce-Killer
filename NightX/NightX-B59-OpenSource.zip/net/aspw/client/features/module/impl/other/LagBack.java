/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.combat.TPAura;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.movement.LongJump;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.player.BowLongJump;
import net.aspw.client.features.module.impl.player.ChestStealer;
import net.aspw.client.features.module.impl.player.InvManager;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

@ModuleInfo(name="LagBack", spacedName="Lag Back", description="", category=ModuleCategory.OTHER, array=false)
public final class LagBack
extends Module {
    private final BoolValue invManagerValue = new BoolValue("InvManager-WorldChange", false);
    private final BoolValue stealerValue = new BoolValue("ChestStealer-WorldChange", false);
    private final BoolValue flightValue = new BoolValue("Flight-LagBack", false);
    private final BoolValue killAuraValue = new BoolValue("KillAura-WorldChange", true);
    private final BoolValue tpAuraValue = new BoolValue("TPAura-WorldChange", true);
    private final BoolValue flightwValue = new BoolValue("Flight-WorldChange", true);
    private final BoolValue speedwValue = new BoolValue("Speed-WorldChange", true);
    private final BoolValue speedValue = new BoolValue("Speed-LagBack", true);
    private final BoolValue longJumpValue = new BoolValue("LongJump-LagBack", true);
    private final BoolValue bowLongJumpValue = new BoolValue("BowLongJump-LagBack", true);

    public LagBack() {
        this.setState(true);
    }

    @EventTarget
    public final void onWorld(WorldEvent e) {
        TPAura tpAura;
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        KillAura killAura = Client.INSTANCE.getModuleManager().getModule(KillAura.class);
        Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        InvManager invManager = Client.INSTANCE.getModuleManager().getModule(InvManager.class);
        ChestStealer chestStealer = Client.INSTANCE.getModuleManager().getModule(ChestStealer.class);
        TPAura tPAura = tpAura = Client.INSTANCE.getModuleManager().getModule(TPAura.class);
        Intrinsics.checkNotNull((Object)tPAura);
        if (tPAura.getState() && ((Boolean)this.tpAuraValue.get()).booleanValue()) {
            tpAura.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("TPAura was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
        KillAura killAura2 = killAura;
        Intrinsics.checkNotNull((Object)killAura2);
        if (killAura2.getState() && ((Boolean)this.killAuraValue.get()).booleanValue()) {
            killAura.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("KillAura was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
        Flight flight2 = flight;
        Intrinsics.checkNotNull((Object)flight2);
        if (flight2.getState() && ((Boolean)this.flightwValue.get()).booleanValue()) {
            flight.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("Fly was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
        Speed speed3 = speed2;
        Intrinsics.checkNotNull((Object)speed3);
        if (speed3.getState() && ((Boolean)this.speedwValue.get()).booleanValue()) {
            speed2.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("Speed was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
        InvManager invManager2 = invManager;
        Intrinsics.checkNotNull((Object)invManager2);
        if (invManager2.getState() && ((Boolean)this.invManagerValue.get()).booleanValue()) {
            invManager.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("InvManager was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
        ChestStealer chestStealer2 = chestStealer;
        Intrinsics.checkNotNull((Object)chestStealer2);
        if (chestStealer2.getState() && ((Boolean)this.stealerValue.get()).booleanValue()) {
            chestStealer.setState(false);
            Client.INSTANCE.getHud().addNotification(new Notification("ChestStealer was disabled", Notification.Type.WARNING));
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof S08PacketPlayerPosLook) {
            LongJump longJump = Client.INSTANCE.getModuleManager().getModule(LongJump.class);
            Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
            BowLongJump bowLongJump = Client.INSTANCE.getModuleManager().getModule(BowLongJump.class);
            Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
            LongJump longJump2 = longJump;
            Intrinsics.checkNotNull((Object)longJump2);
            if (longJump2.getState() && ((Boolean)this.longJumpValue.get()).booleanValue()) {
                longJump.setState(false);
                Client.INSTANCE.getHud().addNotification(new Notification("Disabling LongJump due to lag back", Notification.Type.WARNING));
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
            }
            Speed speed3 = speed2;
            Intrinsics.checkNotNull((Object)speed3);
            if (speed3.getState() && ((Boolean)this.speedValue.get()).booleanValue()) {
                speed2.setState(false);
                Client.INSTANCE.getHud().addNotification(new Notification("Disabling Speed due to lag back", Notification.Type.WARNING));
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
            }
            BowLongJump bowLongJump2 = bowLongJump;
            Intrinsics.checkNotNull((Object)bowLongJump2);
            if (bowLongJump2.getState() && ((Boolean)this.bowLongJumpValue.get()).booleanValue()) {
                bowLongJump.setState(false);
                Client.INSTANCE.getHud().addNotification(new Notification("Disabling BowLongJump due to lag back", Notification.Type.WARNING));
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
            }
            Flight flight2 = flight;
            Intrinsics.checkNotNull((Object)flight2);
            if (flight2.getState() && ((Boolean)this.flightValue.get()).booleanValue()) {
                flight.setState(false);
                Client.INSTANCE.getHud().addNotification(new Notification("Disabling Fly due to lag back", Notification.Type.WARNING));
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
            }
        }
    }
}

