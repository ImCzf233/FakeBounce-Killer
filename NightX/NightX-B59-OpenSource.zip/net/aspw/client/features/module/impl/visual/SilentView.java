/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.AutoHeal;
import net.aspw.client.features.module.impl.combat.BowAura;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.exploit.CivBreak;
import net.aspw.client.features.module.impl.other.Annoy;
import net.aspw.client.features.module.impl.player.BedBreaker;
import net.aspw.client.features.module.impl.player.Nuker;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.minecraft.client.entity.EntityPlayerSP;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="SilentView", spacedName="Silent View", description="", category=ModuleCategory.VISUAL, array=false)
public final class SilentView
extends Module {
    public static final Companion Companion = new Companion(null);
    private final BoolValue normalRotationsValue = new BoolValue("Normal-Rotations", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ SilentView this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getSilentValue().get() == false;
        }
    }));
    private final BoolValue moduleCheckValue = new BoolValue("Module-Check", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ SilentView this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getSilentValue().get() == false;
        }
    }));
    private final BoolValue bodyLockValue = new BoolValue("Body-Lock", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ SilentView this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getSilentValue().get() == false;
        }
    }));
    private final BoolValue silentValue = new BoolValue("Silent", false);
    private Float playerYaw;
    private static float prevHeadPitch;
    private static float headPitch;

    public SilentView() {
        this.setState(true);
    }

    public final BoolValue getNormalRotationsValue() {
        return this.normalRotationsValue;
    }

    public final BoolValue getModuleCheckValue() {
        return this.moduleCheckValue;
    }

    public final BoolValue getBodyLockValue() {
        return this.bodyLockValue;
    }

    public final BoolValue getSilentValue() {
        return this.silentValue;
    }

    public final Float getPlayerYaw() {
        return this.playerYaw;
    }

    public final void setPlayerYaw(@Nullable Float f) {
        this.playerYaw = f;
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        EntityPlayerSP thePlayer = MinecraftInstance.mc.thePlayer;
        if (thePlayer == null) {
            this.playerYaw = null;
            return;
        }
        prevHeadPitch = headPitch;
        headPitch = RotationUtils.serverRotation.getPitch();
        this.playerYaw = Float.valueOf(RotationUtils.serverRotation.getYaw());
    }

    private final boolean getState(Class<? extends Module> module) {
        Module module2 = Client.INSTANCE.getModuleManager().get(module);
        Intrinsics.checkNotNull((Object)module2);
        return module2.getState();
    }

    public final boolean shouldRotate() {
        KillAura killAura = Client.INSTANCE.getModuleManager().getModule(KillAura.class);
        if (killAura == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.combat.KillAura");
        }
        KillAura killAura2 = killAura;
        BowAura bowAura = Client.INSTANCE.getModuleManager().getModule(BowAura.class);
        if (bowAura == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.combat.BowAura");
        }
        BowAura bowAim = bowAura;
        CivBreak civBreak = Client.INSTANCE.getModuleManager().getModule(CivBreak.class);
        if (civBreak == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.exploit.CivBreak");
        }
        CivBreak civBreak2 = civBreak;
        BedBreaker bedBreaker = Client.INSTANCE.getModuleManager().getModule(BedBreaker.class);
        if (bedBreaker == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.BedBreaker");
        }
        BedBreaker bedBreaker2 = bedBreaker;
        Nuker nuker = Client.INSTANCE.getModuleManager().getModule(Nuker.class);
        if (nuker == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.Nuker");
        }
        Nuker nuker2 = nuker;
        AutoHeal autoHeal = Client.INSTANCE.getModuleManager().getModule(AutoHeal.class);
        if (autoHeal == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.combat.AutoHeal");
        }
        AutoHeal autoHeal2 = autoHeal;
        Annoy annoy = Client.INSTANCE.getModuleManager().getModule(Annoy.class);
        if (annoy == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.other.Annoy");
        }
        Annoy annoy2 = annoy;
        return this.getState(KillAura.class) && killAura2.getTarget() != null && (Boolean)killAura2.getSilentRotationValue().get() != false && !((String)killAura2.getRotations().get()).equals("None") || this.getState(Scaffold.class) || this.getState(Nuker.class) && nuker2.isBreaking() || this.getState(BowAura.class) && (Boolean)bowAim.getSilentValue().get() != false && bowAim.hasTarget() || this.getState(CivBreak.class) && (Boolean)civBreak2.getRotationsValue().get() != false && civBreak2.isBreaking() || this.getState(BedBreaker.class) && bedBreaker2.getBreaking() || this.getState(AutoHeal.class) && (autoHeal2.getThrowing() || autoHeal2.isRotating()) || this.getState(Annoy.class) && (Boolean)annoy2.getRotateValue().get() != false;
    }

    public static final float getPrevHeadPitch() {
        return Companion.getPrevHeadPitch();
    }

    public static final void setPrevHeadPitch(float f) {
        Companion.setPrevHeadPitch(f);
    }

    public static final float getHeadPitch() {
        return Companion.getHeadPitch();
    }

    public static final void setHeadPitch(float f) {
        Companion.setHeadPitch(f);
    }

    @JvmStatic
    public static final float lerp(float tickDelta, float old, float f) {
        return Companion.lerp(tickDelta, old, f);
    }

    public static final class Companion {
        private Companion() {
        }

        public final float getPrevHeadPitch() {
            return prevHeadPitch;
        }

        public final void setPrevHeadPitch(float f) {
            prevHeadPitch = f;
        }

        @JvmStatic
        public static /* synthetic */ void getPrevHeadPitch$annotations() {
        }

        public final float getHeadPitch() {
            return headPitch;
        }

        public final void setHeadPitch(float f) {
            headPitch = f;
        }

        @JvmStatic
        public static /* synthetic */ void getHeadPitch$annotations() {
        }

        @JvmStatic
        public final float lerp(float tickDelta, float old, float f) {
            return old + (f - old) * tickDelta;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

