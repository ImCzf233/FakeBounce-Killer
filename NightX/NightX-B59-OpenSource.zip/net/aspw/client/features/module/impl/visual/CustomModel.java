/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.ListValue;

@ModuleInfo(name="CustomModel", spacedName="Custom Model", description="", category=ModuleCategory.VISUAL)
public final class CustomModel
extends Module {
    private final ListValue mode;
    private final BoolValue hideCape;
    private final BoolValue onlySelf;

    public CustomModel() {
        String[] stringArray = new String[]{"Amongus", "Rabbit", "Freddy"};
        this.mode = new ListValue("Mode", stringArray, "Amongus");
        this.hideCape = new BoolValue("HideCape", true);
        this.onlySelf = new BoolValue("OnlySelf", false);
    }

    public final ListValue getMode() {
        return this.mode;
    }

    public final BoolValue getHideCape() {
        return this.hideCape;
    }

    public final BoolValue getOnlySelf() {
        return this.onlySelf;
    }

    @Override
    public String getTag() {
        return (String)this.mode.get();
    }
}

