/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.inventory.Container
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.server.S2EPacketCloseWindow
 */
package net.aspw.client.features.module.impl.premium;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.ScreenEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.connection.LoginID;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.inventory.Container;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.server.S2EPacketCloseWindow;

@ModuleInfo(name="KeepChest", spacedName="Keep Chest", description="", category=ModuleCategory.PREMIUM)
public final class KeepChest
extends Module {
    private GuiContainer container;

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!LoginID.INSTANCE.isPremium()) {
            this.chat("You are not using NightX Premium Account!");
            this.setState(false);
            return;
        }
    }

    @Override
    public void onDisable() {
        if (this.container != null) {
            GuiContainer guiContainer = this.container;
            Intrinsics.checkNotNull((Object)guiContainer);
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0DPacketCloseWindow(guiContainer.inventorySlots.windowId)));
        }
        this.container = null;
    }

    @EventTarget
    public final void onGui(ScreenEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getGuiScreen() instanceof GuiContainer && !(event.getGuiScreen() instanceof GuiInventory)) {
            this.container = (GuiContainer)event.getGuiScreen();
        }
    }

    @EventTarget
    public final void onKey(KeyEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getKey() == 210) {
            if (this.container == null) {
                return;
            }
            MinecraftInstance.mc.displayGuiScreen((GuiScreen)this.container);
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof C0DPacketCloseWindow) {
            event.cancelEvent();
        } else if (event.getPacket() instanceof S2EPacketCloseWindow) {
            Container container;
            int n = ((S2EPacketCloseWindow)event.getPacket()).windowId;
            GuiContainer guiContainer = this.container;
            if (guiContainer == null ? false : ((container = guiContainer.inventorySlots) == null ? false : n == container.windowId)) {
                this.container = null;
            }
        }
    }
}

