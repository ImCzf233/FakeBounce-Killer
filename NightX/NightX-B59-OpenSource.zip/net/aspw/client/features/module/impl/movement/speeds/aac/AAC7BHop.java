/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC7BHop
extends SpeedMode {
    public AAC7BHop() {
        super("AAC7BHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || AAC7BHop.mc.thePlayer.ridingEntity != null || AAC7BHop.mc.thePlayer.hurtTime > 0) {
            return;
        }
        if (AAC7BHop.mc.thePlayer.onGround) {
            AAC7BHop.mc.thePlayer.jump();
            AAC7BHop.mc.thePlayer.motionY = 0.405;
            AAC7BHop.mc.thePlayer.motionX *= 1.004;
            AAC7BHop.mc.thePlayer.motionZ *= 1.004;
            return;
        }
        double speed2 = (double)MovementUtils.getSpeed() * 1.0072;
        double yaw = Math.toRadians(AAC7BHop.mc.thePlayer.rotationYaw);
        AAC7BHop.mc.thePlayer.motionX = -Math.sin(yaw) * speed2;
        AAC7BHop.mc.thePlayer.motionZ = Math.cos(yaw) * speed2;
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

