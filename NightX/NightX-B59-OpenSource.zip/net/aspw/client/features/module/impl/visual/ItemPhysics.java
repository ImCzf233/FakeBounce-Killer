/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.FloatValue;

@ModuleInfo(name="ItemPhysics", spacedName="Item Physics", description="", category=ModuleCategory.VISUAL)
public final class ItemPhysics
extends Module {
    private final FloatValue xzValue = new FloatValue("X-Z", 2.0f, 0.0f, 2.0f, "x");

    public final FloatValue getXzValue() {
        return this.xzValue;
    }
}

