/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.kauri;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class KauriLowHop
extends SpeedMode {
    private int ticks;

    public KauriLowHop() {
        super("KauriLowHop");
    }

    @Override
    public void onUpdate() {
        int n = this.ticks;
        this.ticks = n + 1;
        if (!SpeedMode.mc.thePlayer.onGround && this.ticks == 3) {
            SpeedMode.mc.thePlayer.motionY = 0.0;
        }
        SpeedMode.mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown((KeyBinding)SpeedMode.mc.gameSettings.keyBindJump);
        if (SpeedMode.mc.thePlayer.onGround && MovementUtils.isMoving()) {
            SpeedMode.mc.gameSettings.keyBindJump.pressed = false;
            SpeedMode.mc.thePlayer.jump();
            SpeedMode.mc.thePlayer.motionY = 0.300114514191981;
            if ((double)MovementUtils.getSpeed() < 0.22) {
                MovementUtils.strafe(0.22f);
            } else {
                MovementUtils.strafe(0.48f);
            }
        }
        if (!MovementUtils.isMoving()) {
            SpeedMode.mc.thePlayer.motionX = 0.0;
            SpeedMode.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onDisable() {
        this.ticks = 0;
        SpeedMode.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        super.onEnable();
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

