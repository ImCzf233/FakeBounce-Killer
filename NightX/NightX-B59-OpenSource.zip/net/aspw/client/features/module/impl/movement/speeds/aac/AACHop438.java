/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class AACHop438
extends SpeedMode {
    public AACHop438() {
        super("AACHop4.3.8");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.thePlayer;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        SpeedMode.mc.timer.timerSpeed = 1.0f;
        if (!MovementUtils.isMoving() || thePlayer.isInWater() || thePlayer.isInLava() || thePlayer.isOnLadder() || thePlayer.isRiding()) {
            return;
        }
        if (thePlayer.onGround) {
            thePlayer.jump();
        } else {
            SpeedMode.mc.timer.timerSpeed = (double)thePlayer.fallDistance <= 0.1 ? 1.5f : ((double)thePlayer.fallDistance < 1.3 ? 0.7f : 1.0f);
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
    }
}

