/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AEMine
extends SpeedMode {
    public AEMine() {
        super("AEMine");
    }

    @Override
    public void onDisable() {
        AEMine.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onMotion() {
        if (AEMine.mc.thePlayer.onGround && MovementUtils.isMoving()) {
            AEMine.mc.thePlayer.jump();
            AEMine.mc.timer.timerSpeed = 1.0f;
        } else {
            AEMine.mc.timer.timerSpeed = 1.3091955f;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

