/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.targets;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;

@ModuleInfo(name="Invisible", description="", category=ModuleCategory.TARGETS, array=false)
public final class Invisible
extends Module {
    public Invisible() {
        this.setState(true);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        EntityUtils.targetInvisible = true;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        EntityUtils.targetInvisible = false;
    }
}

