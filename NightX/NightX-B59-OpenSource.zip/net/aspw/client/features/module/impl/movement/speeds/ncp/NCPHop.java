/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPHop
extends SpeedMode {
    public NCPHop() {
        super("NCPHop");
    }

    @Override
    public void onEnable() {
        NCPHop.mc.timer.timerSpeed = 1.0865f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        NCPHop.mc.timer.timerSpeed = 1.0f;
        super.onDisable();
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPHop.mc.thePlayer.motionX = 0.0;
            NCPHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (NCPHop.mc.thePlayer.onGround) {
                NCPHop.mc.thePlayer.jump();
                NCPHop.mc.thePlayer.speedInAir = 0.0223f;
            }
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

