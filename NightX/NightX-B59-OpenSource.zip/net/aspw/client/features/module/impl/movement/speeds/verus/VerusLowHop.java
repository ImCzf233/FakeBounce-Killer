/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.verus;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class VerusLowHop
extends SpeedMode {
    public VerusLowHop() {
        super("VerusLowHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!VerusLowHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            VerusLowHop.mc.thePlayer.motionX = 0.0;
            VerusLowHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        if (!(VerusLowHop.mc.thePlayer.isInWeb || VerusLowHop.mc.thePlayer.isInLava() || VerusLowHop.mc.thePlayer.isInWater() || VerusLowHop.mc.thePlayer.isOnLadder() || VerusLowHop.mc.thePlayer.ridingEntity != null || !MovementUtils.isMoving())) {
            VerusLowHop.mc.gameSettings.keyBindJump.pressed = false;
            if (VerusLowHop.mc.thePlayer.onGround) {
                VerusLowHop.mc.thePlayer.jump();
                VerusLowHop.mc.thePlayer.motionY = 0.0;
                MovementUtils.strafe(0.61f);
                event.setY(0.41999998688698);
            }
            MovementUtils.strafe();
        }
    }
}

