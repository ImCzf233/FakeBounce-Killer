/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.MovementInput
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

public class NCPBHop
extends SpeedMode {
    private int level = 1;
    private double moveSpeed = 0.2873;
    private double lastDist;

    public NCPBHop() {
        super("NCPBHop");
    }

    @Override
    public void onEnable() {
        this.level = NCPBHop.mc.theWorld.getCollidingBoundingBoxes((Entity)NCPBHop.mc.thePlayer, NCPBHop.mc.thePlayer.getEntityBoundingBox().offset(0.0, NCPBHop.mc.thePlayer.motionY, 0.0)).size() > 0 || NCPBHop.mc.thePlayer.isCollidedVertically ? 1 : 4;
    }

    @Override
    public void onDisable() {
        this.moveSpeed = this.getBaseMoveSpeed();
        this.level = 0;
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPBHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPBHop.mc.thePlayer.motionX = 0.0;
            NCPBHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMotion() {
        double xDist = NCPBHop.mc.thePlayer.posX - NCPBHop.mc.thePlayer.prevPosX;
        double zDist = NCPBHop.mc.thePlayer.posZ - NCPBHop.mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
        if (MovementUtils.isMoving()) {
            NCPBHop.mc.thePlayer.motionX *= (double)1.02f;
            NCPBHop.mc.thePlayer.motionZ *= (double)1.02f;
        }
        if (NCPBHop.mc.thePlayer.onGround && MovementUtils.isMoving()) {
            this.level = 2;
        }
        if (this.round(NCPBHop.mc.thePlayer.posY - (double)((int)NCPBHop.mc.thePlayer.posY)) == this.round(0.138)) {
            EntityPlayerSP thePlayer = NCPBHop.mc.thePlayer;
            thePlayer.motionY -= 0.08;
            event.setY(event.getY() - 0.09316090325960147);
            thePlayer.posY -= 0.09316090325960147;
        }
        if (this.level == 1 && (NCPBHop.mc.thePlayer.moveForward != 0.0f || NCPBHop.mc.thePlayer.moveStrafing != 0.0f)) {
            this.level = 2;
            this.moveSpeed = 1.35 * this.getBaseMoveSpeed() - 0.01;
        } else if (this.level == 2) {
            this.level = 3;
            NCPBHop.mc.thePlayer.motionY = 0.3994f;
            event.setY(0.3994f);
            this.moveSpeed *= 2.149;
        } else if (this.level == 3) {
            this.level = 4;
            double difference = 0.66 * (this.lastDist - this.getBaseMoveSpeed());
            this.moveSpeed = this.lastDist - difference;
        } else {
            if (NCPBHop.mc.theWorld.getCollidingBoundingBoxes((Entity)NCPBHop.mc.thePlayer, NCPBHop.mc.thePlayer.getEntityBoundingBox().offset(0.0, NCPBHop.mc.thePlayer.motionY, 0.0)).size() > 0 || NCPBHop.mc.thePlayer.isCollidedVertically) {
                this.level = 1;
            }
            this.moveSpeed = this.lastDist - this.lastDist / 159.0;
        }
        this.moveSpeed = Math.max(this.moveSpeed, this.getBaseMoveSpeed());
        MovementInput movementInput = NCPBHop.mc.thePlayer.movementInput;
        float forward = movementInput.moveForward;
        float strafe = movementInput.moveStrafe;
        float yaw = NCPBHop.mc.thePlayer.rotationYaw;
        if (forward == 0.0f && strafe == 0.0f) {
            event.setX(0.0);
            event.setZ(0.0);
        } else if (forward != 0.0f) {
            if (strafe >= 1.0f) {
                yaw += (float)(forward > 0.0f ? -45 : 45);
                strafe = 0.0f;
            } else if (strafe <= -1.0f) {
                yaw += (float)(forward > 0.0f ? 45 : -45);
                strafe = 0.0f;
            }
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        double mx2 = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz2 = Math.sin(Math.toRadians(yaw + 90.0f));
        event.setX((double)forward * this.moveSpeed * mx2 + (double)strafe * this.moveSpeed * mz2);
        event.setZ((double)forward * this.moveSpeed * mz2 - (double)strafe * this.moveSpeed * mx2);
        NCPBHop.mc.thePlayer.stepHeight = 0.6f;
        if (forward == 0.0f && strafe == 0.0f) {
            event.setX(0.0);
            event.setZ(0.0);
        }
    }

    private double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        if (NCPBHop.mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(NCPBHop.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    private double round(double value) {
        BigDecimal bigDecimal = new BigDecimal(value);
        bigDecimal = bigDecimal.setScale(3, RoundingMode.HALF_UP);
        return bigDecimal.doubleValue();
    }
}

