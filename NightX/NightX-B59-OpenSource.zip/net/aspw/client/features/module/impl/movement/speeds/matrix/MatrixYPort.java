/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.matrix;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class MatrixYPort
extends SpeedMode {
    public MatrixYPort() {
        super("MatrixYPort");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.thePlayer;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            EntityPlayerSP entityPlayerSP2 = SpeedMode.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP2);
            if (entityPlayerSP2.onGround) {
                EntityPlayerSP entityPlayerSP3 = SpeedMode.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP3);
                entityPlayerSP3.jump();
            }
            SpeedMode.mc.timer.timerSpeed = 10.0f;
        } else {
            SpeedMode.mc.timer.timerSpeed = 1.0f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
        SpeedMode.mc.timer.timerSpeed = 1.0f;
    }
}

