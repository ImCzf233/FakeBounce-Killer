/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACLowHop3
extends SpeedMode {
    private boolean firstJump;
    private boolean waitForGround;

    public AACLowHop3() {
        super("AACLowHop3");
    }

    @Override
    public void onEnable() {
        this.firstJump = true;
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving()) {
            if (AACLowHop3.mc.thePlayer.hurtTime <= 0) {
                if (AACLowHop3.mc.thePlayer.onGround) {
                    this.waitForGround = false;
                    if (!this.firstJump) {
                        this.firstJump = true;
                    }
                    AACLowHop3.mc.thePlayer.jump();
                    AACLowHop3.mc.thePlayer.motionY = 0.41;
                } else {
                    if (this.waitForGround) {
                        return;
                    }
                    if (AACLowHop3.mc.thePlayer.isCollidedHorizontally) {
                        return;
                    }
                    this.firstJump = false;
                    AACLowHop3.mc.thePlayer.motionY -= 0.0149;
                }
                if (!AACLowHop3.mc.thePlayer.isCollidedHorizontally) {
                    MovementUtils.forward(this.firstJump ? 0.0016 : 0.001799);
                }
            } else {
                this.firstJump = true;
                this.waitForGround = true;
            }
        }
        double speed2 = MovementUtils.getSpeed();
        AACLowHop3.mc.thePlayer.motionX = -(Math.sin(MovementUtils.getDirection()) * speed2);
        AACLowHop3.mc.thePlayer.motionZ = Math.cos(MovementUtils.getDirection()) * speed2;
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

