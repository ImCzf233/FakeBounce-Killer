/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPOnGround
extends SpeedMode {
    public NCPOnGround() {
        super("NCPOnGround");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        if ((double)NCPOnGround.mc.thePlayer.fallDistance > 3.994) {
            return;
        }
        if (NCPOnGround.mc.thePlayer.isInWater() || NCPOnGround.mc.thePlayer.isOnLadder() || NCPOnGround.mc.thePlayer.isCollidedHorizontally) {
            return;
        }
        NCPOnGround.mc.thePlayer.posY -= (double)0.3993f;
        NCPOnGround.mc.thePlayer.motionY = -1000.0;
        NCPOnGround.mc.thePlayer.distanceWalkedModified = 44.0f;
        NCPOnGround.mc.timer.timerSpeed = 1.0f;
        if (NCPOnGround.mc.thePlayer.onGround) {
            NCPOnGround.mc.thePlayer.posY += (double)0.3993f;
            NCPOnGround.mc.thePlayer.motionY = 0.3993f;
            NCPOnGround.mc.thePlayer.distanceWalkedOnStepModified = 44.0f;
            NCPOnGround.mc.thePlayer.motionX *= (double)1.59f;
            NCPOnGround.mc.thePlayer.motionZ *= (double)1.59f;
            NCPOnGround.mc.timer.timerSpeed = 1.199f;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPOnGround.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPOnGround.mc.thePlayer.motionX = 0.0;
            NCPOnGround.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

