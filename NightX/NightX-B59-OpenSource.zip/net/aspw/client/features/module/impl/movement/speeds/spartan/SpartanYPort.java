/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.spartan;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class SpartanYPort
extends SpeedMode {
    private int airMoves;

    public SpartanYPort() {
        super("SpartanYPort");
    }

    @Override
    public void onMotion() {
        if (!SpartanYPort.mc.gameSettings.keyBindJump.isKeyDown() && MovementUtils.isMoving()) {
            if (SpartanYPort.mc.thePlayer.onGround) {
                SpartanYPort.mc.thePlayer.jump();
                this.airMoves = 0;
            } else {
                SpartanYPort.mc.timer.timerSpeed = 1.08f;
                if (this.airMoves >= 3) {
                    SpartanYPort.mc.thePlayer.jumpMovementFactor = 0.0275f;
                }
                if (this.airMoves >= 4 && (double)(this.airMoves % 2) == 0.0) {
                    SpartanYPort.mc.thePlayer.motionY = (double)-0.32f - 0.009 * Math.random();
                    SpartanYPort.mc.thePlayer.jumpMovementFactor = 0.0238f;
                }
                ++this.airMoves;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

