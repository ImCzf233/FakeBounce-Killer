/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.effect.EntityLightningBolt
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

@ModuleInfo(name="MoreParticles", spacedName="More Particles", description="", category=ModuleCategory.OTHER)
public final class MoreParticles
extends Module {
    private final ListValue modeValue;
    private final IntegerValue timesValue;
    private final BoolValue soundValue;
    private final int blockState;

    public MoreParticles() {
        String[] stringArray = new String[]{"Thunder", "Blood", "Fire", "Criticals", "Sharpness"};
        this.modeValue = new ListValue("Mode", stringArray, "Blood");
        this.timesValue = new IntegerValue("Multi", 1, 1, 10);
        this.soundValue = new BoolValue("Sound", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ MoreParticles this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)MoreParticles.access$getModeValue$p(this.this$0).get()), (String)"thunder", (boolean)true);
            }
        }));
        this.blockState = Block.getStateId((IBlockState)Blocks.redstone_block.getDefaultState());
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (EntityUtils.isSelected(event.getTargetEntity(), true)) {
            Entity entity = event.getTargetEntity();
            if (entity == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.EntityLivingBase");
            }
            this.displayEffectFor((EntityLivingBase)entity);
        }
    }

    private final void displayEffectFor(EntityLivingBase entity) {
        int n = ((Number)this.timesValue.get()).intValue();
        int n2 = 0;
        while (n2 < n) {
            int n3;
            int it = n3 = n2++;
            boolean bl = false;
            String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
            switch (string) {
                case "thunder": {
                    MinecraftInstance.mc.getNetHandler().handleSpawnGlobalEntity(new S2CPacketSpawnGlobalEntity((Entity)new EntityLightningBolt((World)MinecraftInstance.mc.theWorld, entity.posX, entity.posY, entity.posZ)));
                    if (!((Boolean)this.soundValue.get()).booleanValue()) break;
                    MinecraftInstance.mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.create((ResourceLocation)new ResourceLocation("random.explode"), (float)1.0f));
                    MinecraftInstance.mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.create((ResourceLocation)new ResourceLocation("ambient.weather.thunder"), (float)1.0f));
                    break;
                }
                case "blood": {
                    int n4 = 10;
                    int n5 = 0;
                    while (n5 < n4) {
                        int n6;
                        int it2 = n6 = n5++;
                        boolean bl2 = false;
                        int[] nArray = new int[]{this.blockState};
                        MinecraftInstance.mc.effectRenderer.spawnEffectParticle(EnumParticleTypes.BLOCK_CRACK.getParticleID(), entity.posX, entity.posY + (double)(entity.height / (float)2), entity.posZ, entity.motionX + (double)RandomUtils.nextFloat(-0.5f, 0.5f), entity.motionY + (double)RandomUtils.nextFloat(-0.5f, 0.5f), entity.motionZ + (double)RandomUtils.nextFloat(-0.5f, 0.5f), nArray);
                    }
                    break;
                }
                case "fire": {
                    MinecraftInstance.mc.effectRenderer.emitParticleAtEntity((Entity)entity, EnumParticleTypes.LAVA);
                    break;
                }
                case "criticals": {
                    MinecraftInstance.mc.effectRenderer.emitParticleAtEntity((Entity)entity, EnumParticleTypes.CRIT);
                    break;
                }
                case "sharpness": {
                    MinecraftInstance.mc.effectRenderer.emitParticleAtEntity((Entity)entity, EnumParticleTypes.CRIT_MAGIC);
                }
            }
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(MoreParticles $this) {
        return $this.modeValue;
    }
}

