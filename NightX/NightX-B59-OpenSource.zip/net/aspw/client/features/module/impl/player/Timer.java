/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;

@ModuleInfo(name="Timer", description="", category=ModuleCategory.PLAYER)
public final class Timer
extends Module {
    private final FloatValue speedValue = new FloatValue("Speed", 2.0f, 0.1f, 10.0f, "x");
    private final BoolValue onMoveValue = new BoolValue("OnMove", false);
    private final BoolValue autoDisableValue = new BoolValue("AutoDisable", false);

    @Override
    public String getTag() {
        return "" + ((Number)this.speedValue.get()).floatValue() + 'x';
    }

    @Override
    public void onDisable() {
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.theWorld == null) {
            return;
        }
        if (MovementUtils.isMoving() || !((Boolean)this.onMoveValue.get()).booleanValue()) {
            MinecraftInstance.mc.timer.timerSpeed = ((Number)this.speedValue.get()).floatValue();
            return;
        }
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getWorldClient() != null) {
            return;
        }
        if (((Boolean)this.autoDisableValue.get()).booleanValue()) {
            this.setState(false);
        }
    }
}

