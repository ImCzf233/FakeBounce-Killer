/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.Vec3
 *  net.minecraft.util.Vec3i
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;

public class MineplexGround
extends SpeedMode {
    private boolean spoofSlot;
    private float speed = 0.0f;

    public MineplexGround() {
        super("MineplexGround");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving() || !MineplexGround.mc.thePlayer.onGround || MineplexGround.mc.thePlayer.inventory.getCurrentItem() == null || MineplexGround.mc.thePlayer.isUsingItem()) {
            return;
        }
        this.spoofSlot = false;
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = MineplexGround.mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null) continue;
            mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(i - 36));
            this.spoofSlot = true;
            break;
        }
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || !MineplexGround.mc.thePlayer.onGround || MineplexGround.mc.thePlayer.isUsingItem()) {
            this.speed = 0.0f;
            return;
        }
        if (!this.spoofSlot && MineplexGround.mc.thePlayer.inventory.getCurrentItem() != null) {
            return;
        }
        BlockPos blockPos = new BlockPos(MineplexGround.mc.thePlayer.posX, MineplexGround.mc.thePlayer.getEntityBoundingBox().minY - 1.0, MineplexGround.mc.thePlayer.posZ);
        Vec3 vec = new Vec3((Vec3i)blockPos).addVector((double)0.4f, (double)0.4f, (double)0.4f).add(new Vec3(EnumFacing.UP.getDirectionVec()));
        MineplexGround.mc.playerController.onPlayerRightClick(MineplexGround.mc.thePlayer, MineplexGround.mc.theWorld, null, blockPos, EnumFacing.UP, new Vec3(vec.xCoord * (double)0.4f, vec.yCoord * (double)0.4f, vec.zCoord * (double)0.4f));
        float targetSpeed = ((Float)Client.moduleManager.getModule(Speed.class).mineplexGroundSpeedValue.get()).floatValue();
        if (targetSpeed > this.speed) {
            this.speed += targetSpeed / 8.0f;
        }
        if (this.speed >= targetSpeed) {
            this.speed = targetSpeed;
        }
        MovementUtils.strafe(this.speed);
        if (!this.spoofSlot) {
            mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(MineplexGround.mc.thePlayer.inventory.currentItem));
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        this.speed = 0.0f;
        mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(MineplexGround.mc.thePlayer.inventory.currentItem));
    }
}

