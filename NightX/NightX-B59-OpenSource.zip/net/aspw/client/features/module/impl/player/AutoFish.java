/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemFishingRod
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.minecraft.item.ItemFishingRod;

@ModuleInfo(name="AutoFish", spacedName="Auto Fish", description="", category=ModuleCategory.PLAYER)
public final class AutoFish
extends Module {
    private final MSTimer rodOutTimer = new MSTimer();

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer.getHeldItem() == null || !(MinecraftInstance.mc.thePlayer.getHeldItem().getItem() instanceof ItemFishingRod)) {
            return;
        }
        if (this.rodOutTimer.hasTimePassed(500L) && MinecraftInstance.mc.thePlayer.fishEntity == null || MinecraftInstance.mc.thePlayer.fishEntity != null && MinecraftInstance.mc.thePlayer.fishEntity.field_70159_w == 0.0 && MinecraftInstance.mc.thePlayer.fishEntity.field_70179_y == 0.0 && !(MinecraftInstance.mc.thePlayer.fishEntity.field_70181_x == 0.0)) {
            MinecraftInstance.mc.rightClickMouse();
            this.rodOutTimer.reset();
        }
    }
}

