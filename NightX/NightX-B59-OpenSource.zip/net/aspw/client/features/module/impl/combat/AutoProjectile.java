/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.BowAura;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="AutoProjectile", spacedName="Auto Projectile", description="", category=ModuleCategory.COMBAT)
public final class AutoProjectile
extends Module {
    private final BoolValue waitForBowAimbot = new BoolValue("WaitForBowAimAssist", true);

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        BowAura bowAura = Client.INSTANCE.getModuleManager().get(BowAura.class);
        if (bowAura == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.combat.BowAura");
        }
        BowAura bowAimbot = bowAura;
        if (MinecraftInstance.mc.thePlayer.isUsingItem()) {
            ItemStack itemStack = MinecraftInstance.mc.thePlayer.getHeldItem();
            if ((itemStack == null ? null : itemStack.getItem()).equals(Items.bow) && MinecraftInstance.mc.thePlayer.getItemInUseDuration() > 20 && (!((Boolean)this.waitForBowAimbot.get()).booleanValue() || !bowAimbot.getState() || bowAimbot.hasTarget())) {
                MinecraftInstance.mc.thePlayer.stopUsingItem();
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            }
        }
    }
}

