/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.IntegerValue;

@ModuleInfo(name="Tweaks", description="", category=ModuleCategory.OTHER)
public final class Tweaks
extends Module {
    private final IntegerValue speedValue = new IntegerValue("Sneak-Speed", 0, 0, 20);
    private final TickTimer tickTimer = new TickTimer();

    @Override
    public String getTag() {
        return String.valueOf(((Number)this.speedValue.get()).intValue());
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.tickTimer.update();
        if (this.tickTimer.hasTimePassed(1 + ((Number)this.speedValue.get()).intValue())) {
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = true;
        }
        if (this.tickTimer.hasTimePassed(2 + ((Number)this.speedValue.get()).intValue())) {
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
            this.tickTimer.reset();
        }
    }

    @Override
    public void onEnable() {
        this.tickTimer.reset();
    }

    @Override
    public void onDisable() {
        MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
    }
}

