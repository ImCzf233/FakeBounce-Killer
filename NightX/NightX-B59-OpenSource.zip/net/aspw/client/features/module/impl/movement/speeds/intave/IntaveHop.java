/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.intave;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class IntaveHop
extends SpeedMode {
    public IntaveHop() {
        super("IntaveHop");
    }

    @Override
    public void onUpdate() {
        SpeedMode.mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown((KeyBinding)SpeedMode.mc.gameSettings.keyBindJump);
        if (MovementUtils.isMoving()) {
            if (SpeedMode.mc.thePlayer.onGround) {
                SpeedMode.mc.gameSettings.keyBindJump.pressed = false;
                SpeedMode.mc.timer.timerSpeed = 1.0f;
                SpeedMode.mc.thePlayer.jump();
            }
            if (SpeedMode.mc.thePlayer.motionY > 0.003) {
                EntityPlayerSP entityPlayerSP = SpeedMode.mc.thePlayer;
                entityPlayerSP.motionX *= 1.0014;
                entityPlayerSP = SpeedMode.mc.thePlayer;
                entityPlayerSP.motionZ *= 1.0016;
                SpeedMode.mc.timer.timerSpeed = 1.07f;
            }
        }
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        super.onEnable();
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

