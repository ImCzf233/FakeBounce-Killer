/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.io.FilesKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.command.impl;

import java.io.File;
import java.io.IOException;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.Config;
import net.aspw.client.visual.hud.element.elements.Notification;

public final class ThemeCommand
extends Command {
    public ThemeCommand() {
        boolean $i$f$emptyArray = false;
        super("theme", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            if (StringsKt.equals((String)args[1], (String)"load", (boolean)true)) {
                if (args.length > 2) {
                    File themeFile = new File(Client.INSTANCE.getFileManager().themesDir, args[2]);
                    if (themeFile.exists()) {
                        try {
                            Client.INSTANCE.setStarting(true);
                            Client.INSTANCE.getHud().clearElements();
                            Client.INSTANCE.setStarting(false);
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.chat("\u00a76Theme updated successfully!");
                            Client.INSTANCE.getHud().addNotification(new Notification("Theme updated successfully!", Notification.Type.SUCCESS));
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                        return;
                    }
                    return;
                }
                this.chatSyntax("theme load <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"save", (boolean)true)) {
                if (args.length > 2) {
                    File themeFile = new File(Client.INSTANCE.getFileManager().themesDir, args[2]);
                    try {
                        if (themeFile.exists()) {
                            themeFile.delete();
                        }
                        themeFile.createNewFile();
                        String settingsTheme = new Config(Client.INSTANCE.getHud()).toJson();
                        FilesKt.writeText$default((File)themeFile, (String)settingsTheme, null, (int)2, null);
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.chat("\u00a76Successfully saved new theme!");
                        Client.INSTANCE.getHud().addNotification(new Notification("Config saved successfully!", Notification.Type.SUCCESS));
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    return;
                }
                this.chatSyntax("theme save <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"delete", (boolean)true)) {
                if (args.length > 2) {
                    File themeFile = new File(Client.INSTANCE.getFileManager().themesDir, args[2]);
                    if (themeFile.exists()) {
                        themeFile.delete();
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.chat("\u00a76Theme deleted successfully!");
                        Client.INSTANCE.getHud().addNotification(new Notification("Config deleted successfully!", Notification.Type.SUCCESS));
                        return;
                    }
                    return;
                }
                this.chatSyntax("theme delete <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"list", (boolean)true)) {
                this.chat("\u00a7cThemes:");
                File[] fileArray = this.getLocalThemes();
                if (fileArray == null) {
                    return;
                }
                for (File file : fileArray) {
                    this.chat(Intrinsics.stringPlus((String)"", (Object)file.getName()));
                }
                return;
            }
        }
        this.chatSyntax("theme <load/save/list/delete>");
    }

    private final File[] getLocalThemes() {
        return Client.INSTANCE.getFileManager().themesDir.listFiles();
    }
}

