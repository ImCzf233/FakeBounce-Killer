/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.features.command.impl;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.Module;
import net.aspw.client.visual.hud.element.elements.Notification;
import org.lwjgl.input.Keyboard;

public final class BindCommand
extends Command {
    public BindCommand() {
        boolean $i$f$emptyArray = false;
        super("bind", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 2) {
            Module module = Client.INSTANCE.getModuleManager().getModule(args[1]);
            if (module == null) {
                this.chat("Module \u00a7a\u00a7l" + args[1] + "\u00a73 not found.");
                return;
            }
            String string = args[2];
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toUpperCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toUpperCase(locale)");
            int key = Keyboard.getKeyIndex((String)string2);
            module.setKeyBind(key);
            this.chat("Bound module \u00a7a\u00a7l" + module.getName() + "\u00a73 to key \u00a7a\u00a7l" + Keyboard.getKeyName((int)key) + "\u00a73.");
            Client.INSTANCE.getHud().addNotification(new Notification("Bound " + module.getName() + " to " + Keyboard.getKeyName((int)key), Notification.Type.SUCCESS));
            return;
        }
        String[] stringArray = new String[]{"<module> <key>", "<module> none"};
        this.chatSyntax(stringArray);
    }
}

