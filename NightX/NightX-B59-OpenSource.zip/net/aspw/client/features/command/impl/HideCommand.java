/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.command.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;

public final class HideCommand
extends Command {
    public HideCommand() {
        boolean $i$f$emptyArray = false;
        super("hide", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            if (StringsKt.equals((String)args[1], (String)"list", (boolean)true)) {
                Iterator $this$filterTo$iv$iv;
                this.chat("\u00a7c\u00a7lHidden");
                Iterable $this$filter$iv = Client.INSTANCE.getModuleManager().getModules();
                boolean $i$f$filter = false;
                Iterable iterable = $this$filter$iv;
                Collection destination$iv$iv = new ArrayList();
                boolean $i$f$filterTo = false;
                Iterator iterator = $this$filterTo$iv$iv.iterator();
                while (iterator.hasNext()) {
                    Object element$iv$iv = iterator.next();
                    Module it = (Module)element$iv$iv;
                    boolean bl = false;
                    if (!(!it.getArray())) continue;
                    destination$iv$iv.add(element$iv$iv);
                }
                Iterable $this$forEach$iv = (List)destination$iv$iv;
                boolean $i$f$forEach = false;
                for (Object element$iv : $this$forEach$iv) {
                    Module it = (Module)element$iv;
                    boolean bl = false;
                    ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a76> \u00a7c", (Object)it.getName()));
                }
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"clear", (boolean)true)) {
                for (Module module : Client.INSTANCE.getModuleManager().getModules()) {
                    module.setArray(true);
                }
                this.chat("Cleared hidden modules.");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"reset", (boolean)true)) {
                for (Module module : Client.INSTANCE.getModuleManager().getModules()) {
                    module.setArray(module.getClass().getAnnotation(ModuleInfo.class).array());
                }
                this.chat("Reset hidden modules.");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"category", (boolean)true)) {
                Object v0;
                block15: {
                    if (args.length < 3) {
                        this.chatSyntax("hide category <name>");
                        return;
                    }
                    for (Object element$iv : (Iterable)Client.INSTANCE.getModuleManager().getModules()) {
                        Module it = (Module)element$iv;
                        boolean bl = false;
                        if (!StringsKt.equals((String)it.getCategory().getDisplayName(), (String)args[2], (boolean)true)) continue;
                        v0 = element$iv;
                        break block15;
                    }
                    v0 = null;
                }
                if (v0 != null) {
                    Iterable $this$filter$iv = Client.INSTANCE.getModuleManager().getModules();
                    boolean $i$f$filter = false;
                    Iterable $this$filterTo$iv$iv = $this$filter$iv;
                    Collection destination$iv$iv = new ArrayList();
                    boolean $i$f$filterTo = false;
                    Iterator bl = $this$filterTo$iv$iv.iterator();
                    while (bl.hasNext()) {
                        Object element$iv$iv = bl.next();
                        Module it = (Module)element$iv$iv;
                        boolean bl2 = false;
                        if (!StringsKt.equals((String)it.getCategory().getDisplayName(), (String)args[2], (boolean)true)) continue;
                        destination$iv$iv.add(element$iv$iv);
                    }
                    Iterable $this$forEach$iv = (List)destination$iv$iv;
                    boolean $i$f$forEach = false;
                    for (Object element$iv : $this$forEach$iv) {
                        Module it = (Module)element$iv;
                        boolean bl3 = false;
                        it.setArray(false);
                    }
                    this.chat("All modules in category \u00a77" + args[2] + "\u00a73 is now \u00a7a\u00a7lhidden.");
                    return;
                }
                this.chat("Couldn't find any category named \u00a77" + args[2] + "\u00a73!");
                return;
            }
            Module module = Client.INSTANCE.getModuleManager().getModule(args[1]);
            if (module == null) {
                this.chat("Module \u00a7a\u00a7l" + args[1] + "\u00a73 not found.");
                return;
            }
            module.setArray(!module.getArray());
            this.chat("Module \u00a7a\u00a7l" + module.getName() + "\u00a73 is now \u00a7a\u00a7l" + (module.getArray() ? "visible" : "invisible") + "\u00a73 on the array list.");
            return;
        }
        this.chatSyntax("hide <module/list/clear/reset/category>");
    }
}

