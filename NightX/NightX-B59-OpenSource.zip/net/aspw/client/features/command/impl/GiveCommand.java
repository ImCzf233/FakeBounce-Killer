/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C10PacketCreativeInventoryAction
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.item.ItemUtils;
import net.aspw.client.util.misc.StringUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;

public final class GiveCommand
extends Command {
    public GiveCommand() {
        String[] stringArray = new String[]{"item", "i", "get"};
        super("give", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (MinecraftInstance.mc.playerController.isNotCreative()) {
            this.chat("\u00a7c\u00a7lError: \u00a73You need to be in creative mode.");
            return;
        }
        if (args.length > 1) {
            int i;
            ItemStack itemStack = ItemUtils.createItem(StringUtils.toCompleteString(args, 1));
            if (itemStack == null) {
                this.chatSyntaxError();
                return;
            }
            int emptySlot = -1;
            int n = 36;
            while (n < 45) {
                if (MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(i = n++).getStack() != null) continue;
                emptySlot = i;
                break;
            }
            if (emptySlot == -1) {
                n = 9;
                while (n < 45) {
                    if (MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(i = n++).getStack() != null) continue;
                    emptySlot = i;
                    break;
                }
            }
            if (emptySlot != -1) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C10PacketCreativeInventoryAction(emptySlot, itemStack));
                this.chat("\u00a77Given [\u00a78" + itemStack.getDisplayName() + "\u00a77] * \u00a78" + itemStack.stackSize + "\u00a77 to \u00a78" + MinecraftInstance.mc.getSession().getUsername() + "\u00a77.");
            } else {
                this.chat("Your inventory is full.");
            }
            return;
        }
        this.chatSyntax("give <item> [amount] [data] [datatag]");
    }
}

