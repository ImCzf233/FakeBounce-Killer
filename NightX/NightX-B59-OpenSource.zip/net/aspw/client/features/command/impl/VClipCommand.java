/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 */
package net.aspw.client.features.command.impl;

import java.util.ArrayList;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.pathfinder.Vec3;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class VClipCommand
extends Command {
    public VClipCommand() {
        boolean $i$f$emptyArray = false;
        super("vclip", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            try {
                double y = Double.parseDouble(args[1]);
                Entity entity = MinecraftInstance.mc.thePlayer.isRiding() ? MinecraftInstance.mc.thePlayer.ridingEntity : (Entity)MinecraftInstance.mc.thePlayer;
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                new Thread(() -> VClipCommand.execute$lambda-0(entity, y)).start();
                Client.INSTANCE.getHud().addNotification(new Notification("Successfully Teleported!", Notification.Type.SUCCESS));
            }
            catch (NumberFormatException ex) {
                this.chatSyntaxError();
            }
            return;
        }
        this.chatSyntax("vclip <value>");
    }

    private static final void execute$lambda-0(Entity $entity, double $y) {
        ArrayList<Vec3> arrayList = MainPathFinder.computePath(new Vec3(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ), new Vec3($entity.posX, $entity.posY + $y, $entity.posZ));
        Intrinsics.checkNotNullExpressionValue(arrayList, (String)"computePath(\n           \u2026sZ)\n                    )");
        ArrayList<Vec3> path = arrayList;
        for (Vec3 point : path) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true)));
        }
        MinecraftInstance.mc.thePlayer.setPosition($entity.posX, $entity.posY + $y, $entity.posZ);
    }
}

