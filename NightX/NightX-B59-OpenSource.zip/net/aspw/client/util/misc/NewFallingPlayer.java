/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.util.misc;

import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public final class NewFallingPlayer
extends MinecraftInstance {
    private double x;
    private double y;
    private double z;
    private double motionX;
    private double motionY;
    private double motionZ;
    private final float yaw;
    private float strafe;
    private float forward;
    private final float jumpMovementFactor;

    public NewFallingPlayer(double x, double y, double z, double motionX, double motionY, double motionZ, float yaw, float strafe, float forward, float jumpMovementFactor) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.motionX = motionX;
        this.motionY = motionY;
        this.motionZ = motionZ;
        this.yaw = yaw;
        this.strafe = strafe;
        this.forward = forward;
        this.jumpMovementFactor = jumpMovementFactor;
    }

    public /* synthetic */ NewFallingPlayer(double d, double d2, double d3, double d4, double d5, double d6, float f, float f2, float f3, float f4, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 0x200) != 0) {
            f4 = 0.02f;
        }
        this(d, d2, d3, d4, d5, d6, f, f2, f3, f4);
    }

    public NewFallingPlayer(EntityPlayer player) {
        Intrinsics.checkNotNullParameter((Object)player, (String)"player");
        this(player.posX, player.posY, player.posZ, player.motionX, player.motionY, player.motionZ, player.rotationYaw, player.moveStrafing, player.moveForward, player.jumpMovementFactor);
    }

    private final void calculateForTick() {
        this.strafe *= 0.98f;
        this.forward *= 0.98f;
        float v = this.strafe * this.strafe + this.forward * this.forward;
        if (v >= 1.0E-4f) {
            if ((v = MathHelper.sqrt_float((float)v)) < 1.0f) {
                v = 1.0f;
            }
            float fixedJumpFactor = this.jumpMovementFactor;
            if (MinecraftInstance.mc.thePlayer.isSprinting()) {
                fixedJumpFactor = (float)((double)fixedJumpFactor * 1.3);
            }
            v = fixedJumpFactor / v;
            this.strafe *= v;
            this.forward *= v;
            float f1 = MathHelper.sin((float)(this.yaw * (float)Math.PI / 180.0f));
            float f2 = MathHelper.cos((float)(this.yaw * (float)Math.PI / 180.0f));
            this.motionX += (double)(this.strafe * f2 - this.forward * f1);
            this.motionZ += (double)(this.forward * f2 + this.strafe * f1);
        }
        this.motionY -= 0.08;
        this.motionX *= 0.91;
        this.motionY *= (double)0.98f;
        this.motionZ *= 0.91;
        this.x += this.motionX;
        this.y += this.motionY;
        this.z += this.motionZ;
    }

    public final BlockPos findCollision(int ticks) {
        int n = 0;
        while (n < ticks) {
            BlockPos blockPos;
            int i = n++;
            Vec3 start = new Vec3(this.x, this.y, this.z);
            this.calculateForTick();
            Vec3 end = new Vec3(this.x, this.y, this.z);
            BlockPos raytracedBlock = null;
            float w = MinecraftInstance.mc.thePlayer.width / 2.0f;
            BlockPos it = blockPos = this.rayTrace(start, end);
            boolean bl = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector((double)w, 0.0, (double)w);
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(w.toDouble(), 0.0, w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl2 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector(-((double)w), 0.0, (double)w);
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(-w.toDouble(), 0.0, w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl3 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector((double)w, 0.0, -((double)w));
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(w.toDouble(), 0.0, -w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl4 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector(-((double)w), 0.0, -((double)w));
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(-w.toDouble(), 0.0, -w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl5 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector((double)w, 0.0, (double)(w / 2.0f));
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(w.toDoub\u20260.0, (w / 2f).toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl6 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector(-((double)w), 0.0, (double)(w / 2.0f));
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector(-w.toDou\u20260.0, (w / 2f).toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl7 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector((double)(w / 2.0f), 0.0, (double)w);
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector((w / 2f)\u2026ble(), 0.0, w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl8 = false;
            raytracedBlock = it;
            if (blockPos != null) {
                return raytracedBlock;
            }
            blockPos = start.addVector((double)(w / 2.0f), 0.0, -((double)w));
            Intrinsics.checkNotNullExpressionValue((Object)blockPos, (String)"start.addVector((w / 2f)\u2026le(), 0.0, -w.toDouble())");
            it = blockPos = this.rayTrace((Vec3)blockPos, end);
            boolean bl9 = false;
            raytracedBlock = it;
            if (blockPos == null) continue;
            return raytracedBlock;
        }
        return null;
    }

    private final BlockPos rayTrace(Vec3 start, Vec3 end) {
        MovingObjectPosition result = MinecraftInstance.mc.theWorld.rayTraceBlocks(start, end, true);
        return result != null && result.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && result.sideHit == EnumFacing.UP ? result.getBlockPos() : null;
    }
}

