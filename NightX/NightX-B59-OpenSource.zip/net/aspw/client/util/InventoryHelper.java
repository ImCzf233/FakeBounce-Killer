/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.client.C16PacketClientStatus
 *  net.minecraft.network.play.client.C16PacketClientStatus$EnumState
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 */
package net.aspw.client.util;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.ClickWindowEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public final class InventoryHelper
extends MinecraftInstance
implements Listenable {
    public static final InventoryHelper INSTANCE = new InventoryHelper();
    private static final MSTimer CLICK_TIMER = new MSTimer();
    private static final List<Block> BLOCK_BLACKLIST;

    private InventoryHelper() {
    }

    public final MSTimer getCLICK_TIMER() {
        return CLICK_TIMER;
    }

    public final List<Block> getBLOCK_BLACKLIST() {
        return BLOCK_BLACKLIST;
    }

    public final boolean isBlockListBlock(ItemBlock itemBlock) {
        Intrinsics.checkNotNullParameter((Object)itemBlock, (String)"itemBlock");
        Block block = itemBlock.getBlock();
        return BLOCK_BLACKLIST.contains(block) || !block.isFullCube();
    }

    @EventTarget
    public final void onClickWindow(ClickWindowEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        CLICK_TIMER.reset();
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C08PacketPlayerBlockPlacement) {
            CLICK_TIMER.reset();
        }
    }

    public final void openPacket() {
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
    }

    public final void closePacket() {
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0DPacketCloseWindow());
    }

    public final boolean isPositivePotionEffect(int id) {
        return id == Potion.regeneration.id || id == Potion.moveSpeed.id || id == Potion.heal.id || id == Potion.nightVision.id || id == Potion.jump.id || id == Potion.invisibility.id || id == Potion.resistance.id || id == Potion.waterBreathing.id || id == Potion.absorption.id || id == Potion.digSpeed.id || id == Potion.damageBoost.id || id == Potion.healthBoost.id || id == Potion.fireResistance.id;
    }

    public final boolean isPositivePotion(ItemPotion item, ItemStack stack) {
        Intrinsics.checkNotNullParameter((Object)item, (String)"item");
        Intrinsics.checkNotNullParameter((Object)stack, (String)"stack");
        List list = item.getEffects(stack);
        Intrinsics.checkNotNullExpressionValue((Object)list, (String)"item.getEffects(stack)");
        Iterable $this$forEach$iv = list;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            PotionEffect it = (PotionEffect)element$iv;
            boolean bl = false;
            if (!INSTANCE.isPositivePotionEffect(it.getPotionID())) continue;
            return true;
        }
        return false;
    }

    @Override
    public boolean handleEvents() {
        return true;
    }

    static {
        Object[] objectArray = new Block[]{Blocks.enchanting_table, (Block)Blocks.chest, Blocks.ender_chest, Blocks.trapped_chest, Blocks.anvil, (Block)Blocks.sand, Blocks.web, Blocks.torch, Blocks.crafting_table, Blocks.furnace, Blocks.waterlily, Blocks.dispenser, Blocks.stone_pressure_plate, Blocks.wooden_pressure_plate, Blocks.noteblock, Blocks.dropper, Blocks.tnt, Blocks.standing_banner, Blocks.wall_banner, Blocks.redstone_torch, Blocks.gravel, (Block)Blocks.cactus, Blocks.bed, Blocks.lever, Blocks.standing_sign, Blocks.wall_sign, Blocks.jukebox, Blocks.oak_fence, Blocks.spruce_fence, Blocks.birch_fence, Blocks.jungle_fence, Blocks.dark_oak_fence, Blocks.oak_fence_gate, Blocks.spruce_fence_gate, Blocks.birch_fence_gate, Blocks.jungle_fence_gate, Blocks.dark_oak_fence_gate, Blocks.nether_brick_fence, Blocks.trapdoor, Blocks.melon_block, Blocks.brewing_stand, (Block)Blocks.cauldron, (Block)Blocks.skull, (Block)Blocks.hopper, Blocks.carpet, (Block)Blocks.redstone_wire, Blocks.light_weighted_pressure_plate, Blocks.heavy_weighted_pressure_plate, (Block)Blocks.daylight_detector};
        BLOCK_BLACKLIST = CollectionsKt.listOf((Object[])objectArray);
    }
}

