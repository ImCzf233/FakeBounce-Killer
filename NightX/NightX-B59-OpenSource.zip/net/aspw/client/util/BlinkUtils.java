/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.IntRange
 *  kotlin.text.StringsKt
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.util;

import java.math.BigInteger;
import java.util.LinkedList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import kotlin.text.StringsKt;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import org.jetbrains.annotations.Nullable;

public final class BlinkUtils
extends MinecraftInstance {
    public static final BlinkUtils INSTANCE = new BlinkUtils();
    private static final LinkedList<Packet<INetHandlerPlayServer>> playerBuffer = new LinkedList();
    public static final int MisMatch_Type = -302;
    private static boolean movingPacketStat;
    private static boolean transactionStat;
    private static boolean keepAliveStat;
    private static boolean actionStat;
    private static boolean abilitiesStat;
    private static boolean invStat;
    private static boolean interactStat;
    private static boolean otherPacket;
    private static boolean[] packetToggleStat;

    private BlinkUtils() {
    }

    public final boolean getMovingPacketStat() {
        return movingPacketStat;
    }

    public final void setMovingPacketStat(boolean bl) {
        movingPacketStat = bl;
    }

    public final boolean getTransactionStat() {
        return transactionStat;
    }

    public final void setTransactionStat(boolean bl) {
        transactionStat = bl;
    }

    public final boolean getKeepAliveStat() {
        return keepAliveStat;
    }

    public final void setKeepAliveStat(boolean bl) {
        keepAliveStat = bl;
    }

    public final boolean getActionStat() {
        return actionStat;
    }

    public final void setActionStat(boolean bl) {
        actionStat = bl;
    }

    public final boolean getAbilitiesStat() {
        return abilitiesStat;
    }

    public final void setAbilitiesStat(boolean bl) {
        abilitiesStat = bl;
    }

    public final boolean getInvStat() {
        return invStat;
    }

    public final void setInvStat(boolean bl) {
        invStat = bl;
    }

    public final boolean getInteractStat() {
        return interactStat;
    }

    public final void setInteractStat(boolean bl) {
        interactStat = bl;
    }

    public final boolean getOtherPacket() {
        return otherPacket;
    }

    public final void setOtherPacket(boolean bl) {
        otherPacket = bl;
    }

    public final void releasePacket(@Nullable String packetType, boolean onlySelected, int amount, int minBuff) {
        int count = 0;
        if (packetType == null) {
            count = -1;
            for (Packet packet : playerBuffer) {
                String string = packet.getClass().getSimpleName();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"packets.javaClass.simpleName");
                int n = new BigInteger(StringsKt.substring((String)string, (IntRange)new IntRange(1, 2)), 16).intValue();
                if (!packetToggleStat[n] && onlySelected) continue;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)packet);
            }
        } else {
            LinkedList<Packet> tempBuffer = new LinkedList<Packet>();
            for (Packet packet : playerBuffer) {
                String className = packet.getClass().getSimpleName();
                if (!StringsKt.equals((String)className, (String)packetType, (boolean)true)) continue;
                tempBuffer.add(packet);
            }
            while (tempBuffer.size() > minBuff && (count < amount || amount <= 0)) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)tempBuffer.pop()));
                int n = count;
                count = n + 1;
            }
        }
        this.clearPacket(packetType, onlySelected, count);
    }

    public static /* synthetic */ void releasePacket$default(BlinkUtils blinkUtils, String string, boolean bl, int n, int n2, int n3, Object object) {
        if ((n3 & 1) != 0) {
            string = null;
        }
        if ((n3 & 2) != 0) {
            bl = false;
        }
        if ((n3 & 4) != 0) {
            n = -1;
        }
        if ((n3 & 8) != 0) {
            n2 = 0;
        }
        blinkUtils.releasePacket(string, bl, n, n2);
    }

    public final void clearPacket(@Nullable String packetType, boolean onlySelected, int amount) {
        if (packetType == null) {
            LinkedList<Packet> tempBuffer = new LinkedList<Packet>();
            for (Packet packet : playerBuffer) {
                String string = packet.getClass().getSimpleName();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"packets.javaClass.simpleName");
                int n = new BigInteger(StringsKt.substring((String)string, (IntRange)new IntRange(1, 2)), 16).intValue();
                if (packetToggleStat[n] || !onlySelected) continue;
                tempBuffer.add(packet);
            }
            playerBuffer.clear();
            for (Packet packet : tempBuffer) {
                playerBuffer.add((Packet<INetHandlerPlayServer>)packet);
            }
        } else {
            int count = 0;
            LinkedList<Packet> tempBuffer = new LinkedList<Packet>();
            for (Packet packet : playerBuffer) {
                String className = packet.getClass().getSimpleName();
                if (!StringsKt.equals((String)className, (String)packetType, (boolean)true)) {
                    tempBuffer.add(packet);
                    continue;
                }
                int n = count;
                if ((count = n + 1) <= amount) continue;
                tempBuffer.add(packet);
            }
            playerBuffer.clear();
            for (Packet packet : tempBuffer) {
                playerBuffer.add((Packet<INetHandlerPlayServer>)packet);
            }
        }
    }

    public static /* synthetic */ void clearPacket$default(BlinkUtils blinkUtils, String string, boolean bl, int n, int n2, Object object) {
        if ((n2 & 1) != 0) {
            string = null;
        }
        if ((n2 & 2) != 0) {
            bl = false;
        }
        if ((n2 & 4) != 0) {
            n = -1;
        }
        blinkUtils.clearPacket(string, bl, n);
    }

    private final boolean isBlacklisted(String packetType) {
        boolean bl;
        switch (packetType) {
            case "C01PacketEncryptionResponse": 
            case "C00PacketLoginStart": 
            case "C00PacketServerQuery": 
            case "C00Handshake": 
            case "C01PacketPing": 
            case "C01PacketChatMessage": {
                bl = true;
                break;
            }
            default: {
                bl = false;
            }
        }
        return bl;
    }

    static /* synthetic */ boolean isBlacklisted$default(BlinkUtils blinkUtils, String string, int n, Object object) {
        if ((n & 1) != 0) {
            string = "";
        }
        return blinkUtils.isBlacklisted(string);
    }

    public final void setBlinkState(boolean off, boolean release, boolean all, boolean packetMoving, boolean packetTransaction, boolean packetKeepAlive, boolean packetAction, boolean packetAbilities, boolean packetInventory, boolean packetInteract, boolean other) {
        if (release) {
            BlinkUtils.releasePacket$default(this, null, false, 0, 0, 15, null);
        }
        movingPacketStat = packetMoving && !off || all;
        transactionStat = packetTransaction && !off || all;
        keepAliveStat = packetKeepAlive && !off || all;
        actionStat = packetAction && !off || all;
        abilitiesStat = packetAbilities && !off || all;
        invStat = packetInventory && !off || all;
        interactStat = packetInteract && !off || all;
        boolean bl = otherPacket = other && !off || all;
        if (all) {
            int n = 0;
            int n2 = packetToggleStat.length;
            while (n < n2) {
                int i = n++;
                BlinkUtils.packetToggleStat[i] = true;
            }
        } else {
            int n = 0;
            int n3 = packetToggleStat.length;
            while (n < n3) {
                int i = n++;
                switch (i) {
                    case 0: {
                        BlinkUtils.packetToggleStat[i] = keepAliveStat;
                        break;
                    }
                    case 1: 
                    case 17: 
                    case 18: 
                    case 20: 
                    case 21: 
                    case 23: 
                    case 24: 
                    case 25: {
                        BlinkUtils.packetToggleStat[i] = otherPacket;
                        break;
                    }
                    case 3: 
                    case 4: 
                    case 5: 
                    case 6: {
                        BlinkUtils.packetToggleStat[i] = movingPacketStat;
                        break;
                    }
                    case 15: {
                        BlinkUtils.packetToggleStat[i] = transactionStat;
                        break;
                    }
                    case 2: 
                    case 9: 
                    case 10: 
                    case 11: {
                        BlinkUtils.packetToggleStat[i] = actionStat;
                        break;
                    }
                    case 12: 
                    case 19: {
                        BlinkUtils.packetToggleStat[i] = abilitiesStat;
                        break;
                    }
                    case 13: 
                    case 14: 
                    case 16: 
                    case 22: {
                        BlinkUtils.packetToggleStat[i] = invStat;
                        break;
                    }
                    case 7: 
                    case 8: {
                        BlinkUtils.packetToggleStat[i] = interactStat;
                    }
                }
            }
        }
    }

    public static /* synthetic */ void setBlinkState$default(BlinkUtils blinkUtils, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5, boolean bl6, boolean bl7, boolean bl8, boolean bl9, boolean bl10, boolean bl11, int n, Object object) {
        if ((n & 1) != 0) {
            bl = false;
        }
        if ((n & 2) != 0) {
            bl2 = false;
        }
        if ((n & 4) != 0) {
            bl3 = false;
        }
        if ((n & 8) != 0) {
            bl4 = movingPacketStat;
        }
        if ((n & 0x10) != 0) {
            bl5 = transactionStat;
        }
        if ((n & 0x20) != 0) {
            bl6 = keepAliveStat;
        }
        if ((n & 0x40) != 0) {
            bl7 = actionStat;
        }
        if ((n & 0x80) != 0) {
            bl8 = abilitiesStat;
        }
        if ((n & 0x100) != 0) {
            bl9 = invStat;
        }
        if ((n & 0x200) != 0) {
            bl10 = interactStat;
        }
        if ((n & 0x400) != 0) {
            bl11 = otherPacket;
        }
        blinkUtils.setBlinkState(bl, bl2, bl3, bl4, bl5, bl6, bl7, bl8, bl9, bl10, bl11);
    }

    public final int bufferSize(@Nullable String packetType) {
        int n;
        if (packetType == null) {
            n = playerBuffer.size();
        } else {
            int packetCount = 0;
            boolean flag = false;
            for (Packet packet : playerBuffer) {
                String className = packet.getClass().getSimpleName();
                if (!StringsKt.equals((String)className, (String)packetType, (boolean)true)) continue;
                flag = true;
                int n2 = packetCount;
                packetCount = n2 + 1;
            }
            n = flag ? packetCount : -302;
        }
        return n;
    }

    public static /* synthetic */ int bufferSize$default(BlinkUtils blinkUtils, String string, int n, Object object) {
        if ((n & 1) != 0) {
            string = null;
        }
        return blinkUtils.bufferSize(string);
    }

    static {
        boolean[] blArray = new boolean[]{false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false};
        packetToggleStat = blArray;
        BlinkUtils.setBlinkState$default(INSTANCE, true, true, false, false, false, false, false, false, false, false, false, 2044, null);
        BlinkUtils.clearPacket$default(INSTANCE, null, false, 0, 7, null);
    }
}

