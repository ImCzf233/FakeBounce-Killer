/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.apache.logging.log4j.Logger
 */
package net.aspw.client.util.connection;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.util.Scanner;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.connection.LoginID;
import org.apache.logging.log4j.Logger;

public final class GetHWIDKt {
    public static final String getCurrentHWID() {
        String[] stringArray = new String[]{"wmic", "csproduct", "get", "uuid"};
        Process process2 = new ProcessBuilder(stringArray).start();
        process2.waitFor();
        Scanner scanner = new Scanner(process2.getInputStream(), "UTF-8").useDelimiter("\\A");
        String uuid = scanner.hasNext() ? scanner.next() : "";
        Intrinsics.checkNotNullExpressionValue((Object)uuid, (String)"uuid");
        int pos1 = StringsKt.indexOf$default((CharSequence)uuid, (String)"\n", (int)0, (boolean)false, (int)6, null) + 1;
        String string = uuid;
        int n = uuid.length() - 15;
        String string2 = string.substring(pos1, n);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
        LoginID.INSTANCE.setCurrentHWID(string2);
        string = uuid;
        n = uuid.length() - 15;
        string2 = string.substring(pos1, n);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
        return string2;
    }

    public static final String getHWID() {
        String[] stringArray = new String[]{"wmic", "csproduct", "get", "uuid"};
        Process process2 = new ProcessBuilder(stringArray).start();
        process2.waitFor();
        Scanner scanner = new Scanner(process2.getInputStream(), "UTF-8").useDelimiter("\\A");
        String uuid = scanner.hasNext() ? scanner.next() : "";
        Intrinsics.checkNotNullExpressionValue((Object)uuid, (String)"uuid");
        int pos1 = StringsKt.indexOf$default((CharSequence)uuid, (String)"\n", (int)0, (boolean)false, (int)6, null) + 1;
        ClientUtils.getLogger().info("Your HWID is:");
        Logger logger = ClientUtils.getLogger();
        String string = uuid;
        int n = uuid.length() - 15;
        String string2 = string.substring(pos1, n);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
        logger.info(string2);
        ClientUtils.getLogger().info("Copied to your clipboard!");
        Client.INSTANCE.getTipSoundManager().getHwidSound().asyncPlay(95.0f);
        String string3 = uuid;
        int n2 = uuid.length() - 15;
        String string4 = string3.substring(pos1, n2);
        Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
        StringSelection stringSelection = new StringSelection(string4);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, stringSelection);
        string3 = uuid;
        n2 = uuid.length() - 15;
        string4 = string3.substring(pos1, n2);
        Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
        return string4;
    }
}

