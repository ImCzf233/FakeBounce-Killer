/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.io.ConsoleKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 */
package net.aspw.client.util.connection;

import java.util.List;
import kotlin.io.ConsoleKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.connection.CheckConnection;
import net.aspw.client.util.connection.LoginID;
import net.aspw.client.util.connection.UserAPI;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.GuiMainMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;

public final class AuthenticateKt {
    public static final void authenticate(String authInfo, String username, String password, String hwid, String uid) {
        Intrinsics.checkNotNullParameter((Object)authInfo, (String)"authInfo");
        Intrinsics.checkNotNullParameter((Object)username, (String)"username");
        Intrinsics.checkNotNullParameter((Object)password, (String)"password");
        Intrinsics.checkNotNullParameter((Object)hwid, (String)"hwid");
        Intrinsics.checkNotNullParameter((Object)uid, (String)"uid");
        Object object = new char[]{'/'};
        List users = StringsKt.split$default((CharSequence)authInfo, (char[])object, (boolean)false, (int)0, (int)6, null);
        object = users.iterator();
        while (object.hasNext()) {
            String user = (String)object.next();
            UserAPI.INSTANCE.getUserList();
            char[] cArray = new char[]{':'};
            List userInfo = StringsKt.split$default((CharSequence)user, (char[])cArray, (boolean)false, (int)0, (int)6, null);
            if ((!userInfo.get(0).equals(username) || !userInfo.get(1).equals(password)) && !userInfo.get(3).equals(uid) || !userInfo.get(2).equals(hwid)) continue;
            CheckConnection.INSTANCE.connect();
            if (!CheckConnection.INSTANCE.getConnected()) {
                return;
            }
            LoginID.INSTANCE.setId((String)userInfo.get(0));
            LoginID.INSTANCE.setPassword((String)userInfo.get(1));
            LoginID.INSTANCE.setHwid((String)userInfo.get(2));
            LoginID.INSTANCE.setUid((String)userInfo.get(3));
            UserAPI.INSTANCE.setUserList("");
            LoginID.INSTANCE.setPremium(true);
            LoginID.INSTANCE.setLoggedIn(true);
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            ClientUtils.getLogger().info("Logged in with NightX Premium Account!");
            Minecraft.getMinecraft().displayGuiScreen((GuiScreen)new GuiMainMenu());
            CheckConnection.INSTANCE.setConnected(false);
            return;
        }
        ClientUtils.getLogger().info("Incorrect Username or Password or UID or HWID!");
    }

    public static final void main() {
        String responseFromPastebin = UserAPI.INSTANCE.getUserList();
        String usernameInput = ConsoleKt.readln();
        String passwordInput = ConsoleKt.readln();
        String hwidInput = ConsoleKt.readln();
        String uidInput = ConsoleKt.readln();
        AuthenticateKt.authenticate(responseFromPastebin, usernameInput, passwordInput, hwidInput, uidInput);
    }

    public static /* synthetic */ void main(String[] args) {
        AuthenticateKt.main();
    }
}

