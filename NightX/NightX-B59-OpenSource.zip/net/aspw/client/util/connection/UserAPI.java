/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  okhttp3.OkHttpClient
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 */
package net.aspw.client.util.connection;

import kotlin.jvm.internal.Intrinsics;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class UserAPI {
    public static final UserAPI INSTANCE = new UserAPI();
    private static String userList = "";

    private UserAPI() {
    }

    public final String getUserList() {
        return userList;
    }

    public final void setUserList(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        userList = string;
    }

    public final void getUserList() {
        OkHttpClient client = new OkHttpClient();
        String userUrl = "https://nightx.skidded.host/s/du1nu327um";
        Request userInfo = new Request.Builder().url(userUrl).build();
        Response response = client.newCall(userInfo).execute();
        if (response.isSuccessful()) {
            ResponseBody responseBody = response.body();
            String responseData = responseBody == null ? null : responseBody.string();
            userList = String.valueOf(responseData);
        }
    }
}

