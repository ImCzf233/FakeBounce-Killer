/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  okhttp3.OkHttpClient
 *  okhttp3.Request
 *  okhttp3.Request$Builder
 *  okhttp3.Response
 *  okhttp3.ResponseBody
 */
package net.aspw.client.util.connection;

import kotlin.jvm.internal.Intrinsics;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public final class UpdateChecker {
    public static final UpdateChecker INSTANCE = new UpdateChecker();
    private static String updateStatus = "";
    private static String availableStatus = "";
    private static String announcement = "";
    private static boolean isLatest;
    private static boolean isAvailable;

    private UpdateChecker() {
    }

    public final String getAnnouncement() {
        return announcement;
    }

    public final void setAnnouncement(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        announcement = string;
    }

    public final boolean isLatest() {
        return isLatest;
    }

    public final void setLatest(boolean bl) {
        isLatest = bl;
    }

    public final boolean isAvailable() {
        return isAvailable;
    }

    public final void setAvailable(boolean bl) {
        isAvailable = bl;
    }

    public final void isAvailable() {
        OkHttpClient client = new OkHttpClient();
        String pastebinUrl = "https://nightx.skidded.host/s/ugnbicznd5";
        Request request = new Request.Builder().url(pastebinUrl).build();
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            ResponseBody responseBody = response.body();
            String responseData = responseBody == null ? null : responseBody.string();
            availableStatus = String.valueOf(responseData);
            if (availableStatus.equals("True")) {
                isAvailable = true;
            }
        }
    }

    public final void checkAnnouncement() {
        OkHttpClient client = new OkHttpClient();
        String pastebinUrl = "https://nightx.skidded.host/s/xa0wuz9zrh";
        Request request = new Request.Builder().url(pastebinUrl).build();
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            ResponseBody responseBody = response.body();
            String responseData = responseBody == null ? null : responseBody.string();
            announcement = String.valueOf(responseData);
        }
    }

    public final void checkUpdate() {
        OkHttpClient client = new OkHttpClient();
        String pastebinUrl = "https://nightx.skidded.host/s/sek8ak7jjm";
        Request request = new Request.Builder().url(pastebinUrl).build();
        Response response = client.newCall(request).execute();
        if (response.isSuccessful()) {
            ResponseBody responseBody = response.body();
            String responseData = responseBody == null ? null : responseBody.string();
            updateStatus = String.valueOf(responseData);
            if (updateStatus.equals("Release B59")) {
                isLatest = true;
            }
        }
    }
}

