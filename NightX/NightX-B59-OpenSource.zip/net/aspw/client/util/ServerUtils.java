/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiMultiplayer
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.multiplayer.GuiConnecting
 *  net.minecraft.client.multiplayer.ServerData
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.util;

import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.visual.client.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.entity.Entity;

public final class ServerUtils
extends MinecraftInstance {
    public static ServerData serverData;

    public static void connectToLastServer() {
        if (serverData == null) {
            return;
        }
        mc.displayGuiScreen((GuiScreen)new GuiConnecting((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()), mc, serverData));
    }

    public static String getRemoteIp() {
        ServerData serverData;
        if (ServerUtils.mc.theWorld == null) {
            return "Undefined";
        }
        String serverIp = "Singleplayer";
        if (ServerUtils.mc.theWorld.isRemote && (serverData = mc.getCurrentServerData()) != null) {
            serverIp = serverData.serverIP;
        }
        return serverIp;
    }

    public static boolean isHypixelLobby() {
        if (ServerUtils.mc.theWorld == null) {
            return false;
        }
        String target = "CLICK TO PLAY";
        for (Entity entity : ServerUtils.mc.theWorld.loadedEntityList) {
            if (!entity.getName().startsWith("\u00a7e\u00a7l") || !entity.getName().equals("\u00a7e\u00a7l" + target)) continue;
            return true;
        }
        return false;
    }
}

