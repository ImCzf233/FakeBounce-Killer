/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 */
package net.aspw.client.util.extensions;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;

public final class ColorExtensionKt {
    public static final Color darker(Color $this$darker, float factor) {
        Intrinsics.checkNotNullParameter((Object)$this$darker, (String)"<this>");
        return new Color((float)$this$darker.getRed() / 255.0f * RangesKt.coerceIn((float)factor, (float)0.0f, (float)1.0f), (float)$this$darker.getGreen() / 255.0f * RangesKt.coerceIn((float)factor, (float)0.0f, (float)1.0f), (float)$this$darker.getBlue() / 255.0f * RangesKt.coerceIn((float)factor, (float)0.0f, (float)1.0f), (float)$this$darker.getAlpha() / 255.0f);
    }

    public static final Color setAlpha(Color $this$setAlpha, float factor) {
        Intrinsics.checkNotNullParameter((Object)$this$setAlpha, (String)"<this>");
        return new Color((float)$this$setAlpha.getRed() / 255.0f, (float)$this$setAlpha.getGreen() / 255.0f, (float)$this$setAlpha.getBlue() / 255.0f, RangesKt.coerceIn((float)factor, (float)0.0f, (float)1.0f));
    }

    public static final Color setAlpha(Color $this$setAlpha, int factor) {
        Intrinsics.checkNotNullParameter((Object)$this$setAlpha, (String)"<this>");
        return new Color($this$setAlpha.getRed(), $this$setAlpha.getGreen(), $this$setAlpha.getBlue(), RangesKt.coerceIn((int)factor, (int)0, (int)255));
    }
}

