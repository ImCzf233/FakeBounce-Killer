/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 */
package net.aspw.client.util;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public final class WorldUtils {
    private static final Minecraft MC = Minecraft.getMinecraft();

    public static boolean isAir(BlockPos blockPos) {
        return WorldUtils.MC.theWorld.getBlockState(blockPos).getBlock() == Blocks.air;
    }

    public static double distanceToGround() {
        double playerY = WorldUtils.MC.thePlayer.posY;
        return playerY - (double)WorldUtils.getBlockBellow().getY() - 1.0;
    }

    public static double distanceToGround(Vec3 vec3) {
        double playerY = vec3.yCoord;
        return playerY - (double)WorldUtils.getBlockBellow(vec3).getY() - 1.0;
    }

    public static BlockPos getBlockBellow(Vec3 playerPos) {
        while (playerPos.yCoord > 0.0) {
            BlockPos blockPos = new BlockPos(playerPos);
            if (!WorldUtils.isAir(blockPos)) {
                return blockPos;
            }
            playerPos = playerPos.addVector(0.0, -1.0, 0.0);
        }
        return BlockPos.ORIGIN;
    }

    public static BlockPos getBlockBellow() {
        Vec3 playerPos = WorldUtils.MC.thePlayer.getPositionEyes(1.0f);
        while (playerPos.yCoord > 0.0) {
            BlockPos blockPos = new BlockPos(playerPos);
            if (!WorldUtils.isAir(blockPos)) {
                return blockPos;
            }
            playerPos = playerPos.addVector(0.0, -1.0, 0.0);
        }
        return BlockPos.ORIGIN;
    }

    public static boolean isStandAble(BlockPos blockPos) {
        return !WorldUtils.canCollide(blockPos) && !WorldUtils.canCollide(blockPos.add(0, 1, 0));
    }

    public static boolean canCollide(BlockPos blockPos) {
        IBlockState blockState = WorldUtils.MC.theWorld.getBlockState(blockPos);
        return blockState.getBlock().getCollisionBoundingBox((World)WorldUtils.MC.theWorld, blockPos, blockState) != null;
    }
}

