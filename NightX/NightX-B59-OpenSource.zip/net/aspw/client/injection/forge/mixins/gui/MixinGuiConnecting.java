/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiDisconnected
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.multiplayer.GuiConnecting
 *  net.minecraft.client.multiplayer.ServerData
 *  net.minecraft.client.network.NetHandlerLoginClient
 *  net.minecraft.network.EnumConnectionState
 *  net.minecraft.network.INetHandler
 *  net.minecraft.network.NetworkManager
 *  net.minecraft.network.Packet
 *  net.minecraft.network.handshake.client.C00Handshake
 *  net.minecraft.network.login.client.C00PacketLoginStart
 *  net.minecraft.util.ChatComponentTranslation
 *  net.minecraft.util.IChatComponent
 *  org.apache.logging.log4j.Logger
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import net.aspw.client.util.ServerUtils;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.INetHandler;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiConnecting.class})
public abstract class MixinGuiConnecting
extends GuiScreen {
    @Shadow
    @Final
    private static Logger field_146370_f;
    @Shadow
    @Final
    private static AtomicInteger field_146372_a;
    @Shadow
    private NetworkManager field_146371_g;
    @Shadow
    private boolean field_146373_h;
    @Shadow
    @Final
    private GuiScreen field_146374_i;

    @Inject(method={"connect"}, at={@At(value="HEAD")})
    private void headConnect(String ip, int port, CallbackInfo callbackInfo) {
        ServerUtils.serverData = new ServerData("", ip + ":" + port, false);
    }

    @Overwrite
    private void func_146367_a(String ip, int port) {
        field_146370_f.info("Authenticating to " + ip + ", " + port);
        new Thread(() -> {
            InetAddress inetaddress = null;
            try {
                if (this.field_146373_h) {
                    return;
                }
                inetaddress = InetAddress.getByName(ip);
                this.field_146371_g = NetworkManager.createNetworkManagerAndConnect((InetAddress)inetaddress, (int)port, (boolean)this.mc.gameSettings.isUsingNativeTransport());
                this.field_146371_g.setNetHandler((INetHandler)new NetHandlerLoginClient(this.field_146371_g, this.mc, this.field_146374_i));
                this.field_146371_g.sendPacket((Packet)new C00Handshake(47, ip, port, EnumConnectionState.LOGIN, true));
                this.field_146371_g.sendPacket((Packet)new C00PacketLoginStart(this.mc.getSession().getProfile()));
            }
            catch (UnknownHostException unknownhostexception) {
                if (this.field_146373_h) {
                    return;
                }
                field_146370_f.error("Couldn't connect to server", (Throwable)unknownhostexception);
                this.mc.displayGuiScreen((GuiScreen)new GuiDisconnected(this.field_146374_i, "connect.failed", (IChatComponent)new ChatComponentTranslation("disconnect.genericReason", new Object[]{"Unknown host"})));
            }
            catch (Exception exception) {
                if (this.field_146373_h) {
                    return;
                }
                field_146370_f.error("Couldn't connect to server", (Throwable)exception);
                String s = exception.toString();
                if (inetaddress != null) {
                    String s1 = inetaddress + ":" + port;
                    s = s.replaceAll(s1, "");
                }
                this.mc.displayGuiScreen((GuiScreen)new GuiDisconnected(this.field_146374_i, "connect.failed", (IChatComponent)new ChatComponentTranslation("disconnect.genericReason", new Object[]{s})));
            }
        }, "Server Connector #" + field_146372_a.incrementAndGet()).start();
    }

    @Overwrite
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        this.drawDefaultBackground();
        String ip = "Unknown";
        ServerData serverData = this.mc.getCurrentServerData();
        if (serverData != null) {
            ip = serverData.serverIP;
        }
        this.func_73732_a(this.fontRendererObj, "Logging in to", scaledResolution.getScaledWidth() / 2, scaledResolution.getScaledHeight() / 4 + 102, 0xFFFFFF);
        this.func_73732_a(this.fontRendererObj, "\u00a77" + ip, scaledResolution.getScaledWidth() / 2, scaledResolution.getScaledHeight() / 4 + 115, 0xFFFFFF);
        Fonts.minecraftFont.drawStringWithShadow("\u00a77Username: \u00a7d" + this.mc.getSession().getUsername(), 6.0f, 6.0f, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}

