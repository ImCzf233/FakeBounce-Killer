/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelSkeleton
 *  org.spongepowered.asm.mixin.Mixin
 */
package net.aspw.client.injection.forge.mixins.render;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelSkeleton;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={ModelSkeleton.class})
public class MixinModelSkeleton
extends ModelBiped {
    public void postRenderArm(float scale) {
        this.bipedRightArm.rotationPointX += 1.0f;
        this.bipedRightArm.postRender(scale);
        this.bipedRightArm.rotationPointX -= 1.0f;
    }
}

