/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.item.ItemStack
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 *  org.spongepowered.asm.mixin.injection.callback.LocalCapture
 */
package net.aspw.client.injection.forge.mixins.entity;

import java.util.Iterator;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.exploit.ViaVersionFix;
import net.aspw.client.features.module.impl.movement.AirJump;
import net.aspw.client.features.module.impl.movement.Jesus;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.AntiBlind;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.injection.forge.mixins.entity.MixinEntity;
import net.aspw.client.util.RotationUtils;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(value={EntityLivingBase.class})
public abstract class MixinEntityLivingBase
extends MixinEntity {
    @Shadow
    public int field_110158_av;
    @Shadow
    public boolean field_82175_bq;
    @Shadow
    public float field_70733_aJ;
    @Shadow
    protected boolean field_70703_bu;
    @Shadow
    public int field_70773_bE;
    @Shadow
    public float field_70761_aq;
    @Shadow
    public float field_70759_as;
    @Shadow
    public float field_70758_at;
    @Shadow
    public float field_70760_ar;
    @Shadow
    protected double field_70705_bn;

    @Shadow
    protected abstract float func_175134_bD();

    @Shadow
    public abstract PotionEffect func_70660_b(Potion var1);

    @Shadow
    public abstract boolean func_70644_a(Potion var1);

    @Shadow
    public void func_70636_d() {
    }

    @Shadow
    protected abstract void func_180433_a(double var1, boolean var3, Block var4, BlockPos var5);

    @Shadow
    public abstract float func_110143_aJ();

    @Shadow
    public abstract ItemStack func_70694_bm();

    @Shadow
    protected abstract void func_70629_bd();

    @Inject(method={"updatePotionEffects"}, at={@At(value="INVOKE", target="Lnet/minecraft/potion/PotionEffect;onUpdate(Lnet/minecraft/entity/EntityLivingBase;)Z")}, locals=LocalCapture.CAPTURE_FAILSOFT, cancellable=true)
    private void checkPotionEffect(CallbackInfo ci, Iterator<Integer> iterator, Integer integer, PotionEffect potioneffect) {
        if (potioneffect == null) {
            ci.cancel();
        }
    }

    @Overwrite
    protected float func_110146_f(float p_1101461, float p_1101462) {
        boolean flag;
        float rotationYaw = this.field_70177_z;
        SilentView silentView = Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class));
        if (((Boolean)silentView.getNormalRotationsValue().get()).booleanValue() && !((Boolean)silentView.getSilentValue().get()).booleanValue() && silentView.getState() && silentView.getPlayerYaw() != null && (EntityLivingBase)this instanceof EntityPlayerSP && (((Boolean)silentView.getModuleCheckValue().get()).booleanValue() && silentView.shouldRotate() || !((Boolean)silentView.getModuleCheckValue().get()).booleanValue())) {
            if (this.field_70733_aJ > 0.0f && !((Boolean)silentView.getBodyLockValue().get()).booleanValue()) {
                p_1101461 = silentView.getPlayerYaw().floatValue();
            }
            rotationYaw = silentView.getPlayerYaw().floatValue();
            this.field_70759_as = silentView.getPlayerYaw().floatValue();
        }
        float f = MathHelper.wrapAngleTo180_float((float)(p_1101461 - this.field_70761_aq));
        this.field_70761_aq += f * 0.24f;
        float f1 = MathHelper.wrapAngleTo180_float((float)(rotationYaw - this.field_70761_aq));
        boolean bl = flag = f1 < 90.0f || f1 >= 90.0f;
        if (!((Boolean)silentView.getSilentValue().get()).booleanValue() && ((Boolean)silentView.getBodyLockValue().get()).booleanValue() && silentView.getState() && silentView.getPlayerYaw() != null && (EntityLivingBase)this instanceof EntityPlayerSP && (((Boolean)silentView.getModuleCheckValue().get()).booleanValue() && silentView.shouldRotate() || !((Boolean)silentView.getModuleCheckValue().get()).booleanValue())) {
            f1 = 0.0f;
        }
        if (f1 < -78.0f) {
            f1 = -78.0f;
        }
        if (f1 >= 78.0f) {
            f1 = 78.0f;
        }
        this.field_70761_aq = rotationYaw - f1;
        if (f1 * f1 > 2500.0f) {
            this.field_70761_aq += f1 * 0.16f;
        }
        if (flag) {
            p_1101462 *= -1.2f;
        }
        return p_1101462;
    }

    @Overwrite
    protected void func_70664_aZ() {
        JumpEvent jumpEvent = new JumpEvent(this.func_175134_bD());
        Client.eventManager.callEvent(jumpEvent);
        if (jumpEvent.isCancelled()) {
            return;
        }
        this.field_70181_x = jumpEvent.getMotion();
        if (this.func_70644_a(Potion.jump)) {
            this.field_70181_x += (double)((float)(this.func_70660_b(Potion.jump).getAmplifier() + 1) * 0.1f);
        }
        if (this.func_70051_ag()) {
            KillAura killAura = Objects.requireNonNull(Client.moduleManager.getModule(KillAura.class));
            float yaw = this.field_70177_z;
            if (killAura.getState() && ((Boolean)killAura.getMovementFix().get()).booleanValue() && killAura.getTarget() != null) {
                yaw = RotationUtils.targetRotation != null ? RotationUtils.targetRotation.getYaw() : (RotationUtils.serverRotation != null ? RotationUtils.serverRotation.getYaw() : yaw);
            }
            float f = yaw * ((float)Math.PI / 180);
            this.field_70159_w -= (double)(MathHelper.sin((float)f) * 0.2f);
            this.field_70179_y += (double)(MathHelper.cos((float)f) * 0.2f);
        }
        this.field_70160_al = true;
    }

    @Inject(method={"onLivingUpdate"}, at={@At(value="FIELD", target="Lnet/minecraft/entity/EntityLivingBase;isJumping:Z", ordinal=1)})
    private void onJumpSection(CallbackInfo callbackInfo) {
        Jesus jesus;
        AirJump airJump = Objects.requireNonNull(Client.moduleManager.getModule(AirJump.class));
        if (airJump.getState() && this.field_70703_bu && this.field_70773_bE == 0) {
            this.func_70664_aZ();
            this.field_70773_bE = 10;
        }
        if ((jesus = Objects.requireNonNull(Client.moduleManager.getModule(Jesus.class))).getState() && !this.field_70703_bu && !this.func_70093_af() && this.func_70090_H() && ((String)jesus.modeValue.get()).equalsIgnoreCase("Swim")) {
            this.func_70629_bd();
        }
    }

    @Inject(method={"isPotionActive(Lnet/minecraft/potion/Potion;)Z"}, at={@At(value="HEAD")}, cancellable=true)
    private void isPotionActive(Potion p_isPotionActive_1_, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        AntiBlind antiBlind = Objects.requireNonNull(Client.moduleManager.getModule(AntiBlind.class));
        if ((p_isPotionActive_1_ == Potion.confusion || p_isPotionActive_1_ == Potion.blindness) && antiBlind.getState() && ((Boolean)antiBlind.getConfusionEffect().get()).booleanValue()) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
    }

    @ModifyConstant(method={"onLivingUpdate"}, constant={@Constant(doubleValue=0.005)})
    private double ViaVersion_MovementThreshold(double constant) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(ViaVersionFix.class)).getState()) {
            return 0.003;
        }
        return 0.005;
    }

    @Overwrite
    private int func_82166_i() {
        int speed2;
        int n = speed2 = (EntityLivingBase)this instanceof EntityPlayerSP ? 2 + (20 - (Integer)Animations.SpeedSwing.get() - 16) : 6;
        return this.func_70644_a(Potion.digSpeed) ? speed2 - (1 + this.func_70660_b(Potion.digSpeed).getAmplifier()) : (this.func_70644_a(Potion.digSlowdown) ? speed2 + (1 + this.func_70660_b(Potion.digSlowdown).getAmplifier()) * 2 : speed2);
    }
}

