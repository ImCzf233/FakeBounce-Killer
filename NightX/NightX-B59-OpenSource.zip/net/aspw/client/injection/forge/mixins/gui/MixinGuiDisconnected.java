/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.mojang.authlib.Agent
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication
 *  com.thealtening.AltService$EnumAltService
 *  com.thealtening.api.TheAltening
 *  com.thealtening.api.data.AccountData
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MinecraftAccount
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiDisconnected
 *  net.minecraft.client.gui.GuiMultiplayer
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.util.IChatComponent$Serializer
 *  net.minecraft.util.Session
 *  net.minecraftforge.fml.client.GuiModList
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.gui;

import com.google.gson.JsonObject;
import com.mojang.authlib.Agent;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import com.thealtening.AltService;
import com.thealtening.api.TheAltening;
import com.thealtening.api.data.AccountData;
import java.net.Proxy;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MinecraftAccount;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.injection.forge.mixins.gui.MixinGuiScreen;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.ServerUtils;
import net.aspw.client.util.SessionUtils;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.visual.client.GuiMainMenu;
import net.aspw.client.visual.client.GuiProxyManager;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.client.altmanager.menus.GuiLoginProgress;
import net.aspw.client.visual.client.altmanager.menus.GuiTheAltening;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.Session;
import net.minecraftforge.fml.client.GuiModList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiDisconnected.class})
public abstract class MixinGuiDisconnected
extends MixinGuiScreen {
    @Shadow
    private int field_175353_i;

    @Inject(method={"initGui"}, at={@At(value="RETURN")})
    private void initGui(CallbackInfo callbackInfo) {
        SessionUtils.handleConnection();
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l / 2 - 100, this.field_146295_m / 2 + this.field_175353_i / 2 + this.field_146289_q.FONT_HEIGHT + 22, 200, 20, "Reconnect to \u00a77" + ServerUtils.serverData.serverIP));
        this.field_146292_n.add(new GuiButton(3, this.field_146294_l / 2 - 100, this.field_146295_m / 2 + this.field_175353_i / 2 + this.field_146289_q.FONT_HEIGHT + 44, 100, 20, "Reconnect with Alt"));
        this.field_146292_n.add(new GuiButton(4, this.field_146294_l / 2 + 2, this.field_146295_m / 2 + this.field_175353_i / 2 + this.field_146289_q.FONT_HEIGHT + 44, 98, 20, "Random Cracked"));
        this.field_146292_n.add(new GuiButton(998, this.field_146294_l - 186, 7, 88, 20, "Alt Manager"));
        this.field_146292_n.add(new GuiButton(997, this.field_146294_l - 94, 7, 88, 20, "Mod List"));
        this.field_146292_n.add(new GuiButton(1000, 6, this.field_146295_m - 24, 70, 20, "Proxy"));
    }

    @Inject(method={"actionPerformed"}, at={@At(value="HEAD")})
    private void actionPerformed(GuiButton button, CallbackInfo callbackInfo) {
        switch (button.id) {
            case 1: {
                ServerUtils.connectToLastServer();
                break;
            }
            case 3: {
                List<MinecraftAccount> accounts;
                if (!GuiTheAltening.Companion.getApiKey().isEmpty()) {
                    String apiKey = GuiTheAltening.Companion.getApiKey();
                    TheAltening theAltening = new TheAltening(apiKey);
                    try {
                        AccountData account = theAltening.getAccountData();
                        GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.THEALTENING);
                        YggdrasilUserAuthentication yggdrasilUserAuthentication = new YggdrasilUserAuthentication(new YggdrasilAuthenticationService(Proxy.NO_PROXY, ""), Agent.MINECRAFT);
                        yggdrasilUserAuthentication.setUsername(account.getToken());
                        yggdrasilUserAuthentication.setPassword("NightX");
                        yggdrasilUserAuthentication.logIn();
                        this.field_146297_k.session = new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
                        Client.eventManager.callEvent(new SessionEvent());
                        ServerUtils.connectToLastServer();
                        break;
                    }
                    catch (Throwable throwable) {
                        ClientUtils.getLogger().error("Failed to login into random account from TheAltening.", throwable);
                    }
                }
                if ((accounts = Client.fileManager.accountsConfig.getAccounts()).isEmpty()) break;
                MinecraftAccount minecraftAccount = accounts.get(new Random().nextInt(accounts.size()));
                this.field_146297_k.displayGuiScreen((GuiScreen)new GuiLoginProgress(minecraftAccount, (Function0<Unit>)((Function0)() -> {
                    this.field_146297_k.addScheduledTask(() -> {
                        Client.eventManager.callEvent(new SessionEvent());
                        ServerUtils.connectToLastServer();
                    });
                    return null;
                }), (Function1<? super Exception, Unit>)((Function1)e -> {
                    this.field_146297_k.addScheduledTask(() -> {
                        JsonObject jsonObject = new JsonObject();
                        jsonObject.addProperty("text", e.getMessage());
                        this.field_146297_k.displayGuiScreen((GuiScreen)new GuiDisconnected((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()), e.getMessage(), IChatComponent.Serializer.jsonToComponent((String)jsonObject.toString())));
                    });
                    return null;
                }), (Function0<Unit>)((Function0)() -> null)));
                break;
            }
            case 4: {
                CrackedAccount crackedAccount = new CrackedAccount();
                Hud hud = Objects.requireNonNull(Client.moduleManager.getModule(Hud.class));
                crackedAccount.setName(RandomUtils.randomString(RandomUtils.nextInt(5, 16)));
                crackedAccount.update();
                if (((Boolean)hud.getFlagSoundValue().get()).booleanValue()) {
                    Client.tipSoundManager.getPopSound().asyncPlay(Client.moduleManager.getPopSoundPower());
                }
                this.field_146297_k.session = new Session(crackedAccount.getSession().getUsername(), crackedAccount.getSession().getUuid(), crackedAccount.getSession().getToken(), crackedAccount.getSession().getType());
                Client.eventManager.callEvent(new SessionEvent());
                break;
            }
            case 1000: {
                this.field_146297_k.displayGuiScreen((GuiScreen)new GuiProxyManager((GuiScreen)this));
                break;
            }
            case 998: {
                this.field_146297_k.displayGuiScreen((GuiScreen)new GuiAltManager((GuiScreen)this));
                break;
            }
            case 997: {
                this.field_146297_k.displayGuiScreen((GuiScreen)new GuiModList((GuiScreen)this));
            }
        }
    }

    @Inject(method={"drawScreen"}, at={@At(value="RETURN")})
    private void drawScreen(CallbackInfo callbackInfo) {
        Fonts.minecraftFont.drawStringWithShadow("\u00a77Username: \u00a7d" + this.field_146297_k.getSession().getUsername(), 6.0f, (float)(this.field_146295_m - 36), 0xFFFFFF);
    }
}

