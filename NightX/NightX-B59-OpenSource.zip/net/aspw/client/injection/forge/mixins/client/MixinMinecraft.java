/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.GuiMainMenu
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.multiplayer.PlayerControllerMP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.particle.EffectRenderer
 *  net.minecraft.client.renderer.EntityRenderer
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.client.resources.IResourceManager
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.stream.IStream
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  net.minecraftforge.client.MinecraftForgeClient
 *  org.apache.commons.lang3.SystemUtils
 *  org.lwjgl.Sys
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.Display
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  scala.Int
 */
package net.aspw.client.injection.forge.mixins.client;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.ClickBlockEvent;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.ScreenEvent;
import net.aspw.client.event.TickEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.impl.other.FastPlace;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.OptiFinePlus;
import net.aspw.client.injection.forge.mixins.accessors.MinecraftForgeClientAccessor;
import net.aspw.client.util.CPSCounter;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.client.GuiMainMenu;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.stream.IStream;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.MinecraftForgeClient;
import org.apache.commons.lang3.SystemUtils;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import scala.Int;

@Mixin(value={Minecraft.class})
public abstract class MixinMinecraft {
    @Shadow
    public GuiScreen field_71462_r;
    @Shadow
    public boolean field_71454_w;
    @Shadow
    public MovingObjectPosition field_71476_x;
    @Shadow
    public WorldClient field_71441_e;
    @Shadow
    public EntityPlayerSP field_71439_g;
    @Shadow
    public EffectRenderer field_71452_i;
    @Shadow
    public EntityRenderer field_71460_t;
    @Shadow
    public PlayerControllerMP field_71442_b;
    @Shadow
    public int field_71443_c;
    @Shadow
    public int field_71440_d;
    @Shadow
    public int field_71467_ac;
    @Shadow
    public GameSettings field_71474_y;
    @Shadow
    private Entity field_175622_Z;
    @Shadow
    private boolean field_71431_Q;
    @Shadow
    public int field_71429_W;
    private long lastFrame = this.getTime();

    @Shadow
    public abstract IResourceManager func_110442_L();

    @Shadow
    public abstract RenderManager func_175598_ae();

    @Inject(method={"run"}, at={@At(value="HEAD")})
    private void init(CallbackInfo callbackInfo) {
        if (this.field_71443_c < 1067) {
            this.field_71443_c = 1067;
        }
        if (this.field_71440_d < 622) {
            this.field_71440_d = 622;
        }
    }

    @Inject(method={"startGame"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/Minecraft;checkGLError(Ljava/lang/String;)V", ordinal=2, shift=At.Shift.AFTER)})
    private void startGame(CallbackInfo callbackInfo) {
        Client.INSTANCE.startClient();
    }

    @Inject(method={"loadWorld(Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/String;)V"}, at={@At(value="HEAD")})
    private void clearLoadedMaps(WorldClient worldClientIn, String loadingMessage, CallbackInfo ci) {
        if (worldClientIn != this.field_71441_e) {
            this.field_71460_t.getMapItemRenderer().clearLoadedMaps();
        }
    }

    @Inject(method={"createDisplay"}, at={@At(value="INVOKE", target="Lorg/lwjgl/opengl/Display;setTitle(Ljava/lang/String;)V", shift=At.Shift.AFTER)})
    private void createDisplay(CallbackInfo callbackInfo) {
        Display.setTitle((String)"Launching...");
    }

    @Inject(method={"loadWorld(Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/String;)V"}, at={@At(value="FIELD", target="Lnet/minecraft/client/Minecraft;theWorld:Lnet/minecraft/client/multiplayer/WorldClient;", opcode=181, shift=At.Shift.AFTER)})
    private void clearRenderCache(CallbackInfo ci) {
        MinecraftForgeClient.getRenderPass();
        MinecraftForgeClientAccessor.getRegionCache().invalidateAll();
        MinecraftForgeClientAccessor.getRegionCache().cleanUp();
    }

    @Redirect(method={"runGameLoop"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/stream/IStream;func_152935_j()V"))
    private void skipTwitchCode1(IStream instance) {
    }

    @Redirect(method={"runGameLoop"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/stream/IStream;func_152922_k()V"))
    private void skipTwitchCode2(IStream instance) {
    }

    @Inject(method={"displayGuiScreen"}, at={@At(value="FIELD", target="Lnet/minecraft/client/Minecraft;currentScreen:Lnet/minecraft/client/gui/GuiScreen;", shift=At.Shift.AFTER)})
    private void displayGuiScreen(CallbackInfo callbackInfo) {
        if (this.field_71462_r instanceof net.minecraft.client.gui.GuiMainMenu || this.field_71462_r != null && this.field_71462_r.getClass().getSimpleName().equals("ModGuiMainMenu")) {
            this.field_71462_r = new GuiMainMenu();
            ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
            this.field_71462_r.setWorldAndResolution(Minecraft.getMinecraft(), scaledResolution.getScaledWidth(), scaledResolution.getScaledHeight());
            this.field_71454_w = false;
        }
        Client.eventManager.callEvent(new ScreenEvent(this.field_71462_r));
    }

    @Inject(method={"runGameLoop"}, at={@At(value="HEAD")})
    private void runGameLoop(CallbackInfo callbackInfo) {
        long currentTime = this.getTime();
        int deltaTime = (int)(currentTime - this.lastFrame);
        this.lastFrame = currentTime;
        RenderUtils.deltaTime = deltaTime;
    }

    public long getTime() {
        return Sys.getTime() * 1000L / Sys.getTimerResolution();
    }

    @Inject(method={"runTick"}, at={@At(value="FIELD", target="Lnet/minecraft/client/Minecraft;joinPlayerCounter:I", shift=At.Shift.BEFORE)})
    private void onTick(CallbackInfo callbackInfo) {
        Client.eventManager.callEvent(new TickEvent());
    }

    @Inject(method={"runTick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/Minecraft;dispatchKeypresses()V", shift=At.Shift.AFTER)})
    private void onKey(CallbackInfo callbackInfo) {
        if (Keyboard.getEventKeyState() && this.field_71462_r == null) {
            Client.eventManager.callEvent(new KeyEvent(Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey()));
        }
    }

    @Inject(method={"sendClickBlockToController"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/MovingObjectPosition;getBlockPos()Lnet/minecraft/util/BlockPos;")})
    private void onClickBlock(CallbackInfo callbackInfo) {
        if (this.field_71429_W == 0 && this.field_71441_e.getBlockState(this.field_71476_x.getBlockPos()).getBlock().getMaterial() != Material.air) {
            Client.eventManager.callEvent(new ClickBlockEvent(this.field_71476_x.getBlockPos(), this.field_71476_x.sideHit));
        }
    }

    @Inject(method={"shutdown"}, at={@At(value="HEAD")})
    private void shutdown(CallbackInfo callbackInfo) {
        Client.INSTANCE.stopClient();
    }

    @Inject(method={"clickMouse"}, at={@At(value="HEAD")})
    private void clickMouse(CallbackInfo callbackInfo) {
        CPSCounter.registerClick(CPSCounter.MouseButton.LEFT);
        if (Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class)).getState() && ((Boolean)Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class)).noHitDelay.get()).booleanValue()) {
            this.field_71429_W = 0;
        } else if (this.field_71429_W <= 10 && this.field_71476_x == null) {
            this.field_71429_W = 10;
        }
    }

    @Inject(method={"middleClickMouse"}, at={@At(value="HEAD")})
    private void middleClickMouse(CallbackInfo ci) {
        CPSCounter.registerClick(CPSCounter.MouseButton.MIDDLE);
    }

    @Inject(method={"rightClickMouse"}, at={@At(value="FIELD", target="Lnet/minecraft/client/Minecraft;rightClickDelayTimer:I", shift=At.Shift.AFTER)})
    private void rightClickMouse(CallbackInfo callbackInfo) {
        CPSCounter.registerClick(CPSCounter.MouseButton.RIGHT);
        FastPlace fastPlace = Objects.requireNonNull(Client.moduleManager.getModule(FastPlace.class));
        if (fastPlace.getState()) {
            this.field_71467_ac = (Integer)fastPlace.getSpeedValue().get();
        }
    }

    @Inject(method={"loadWorld(Lnet/minecraft/client/multiplayer/WorldClient;Ljava/lang/String;)V"}, at={@At(value="HEAD")})
    private void loadWorld(WorldClient p_loadWorld_1_, String p_loadWorld_2_, CallbackInfo callbackInfo) {
        Client.eventManager.callEvent(new WorldEvent(p_loadWorld_1_));
        if (Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class)).getState() && ((Boolean)Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class)).fixMemoryLeaks.get()).booleanValue()) {
            Runtime.getRuntime().gc();
        }
    }

    @Inject(method={"toggleFullscreen"}, at={@At(value="INVOKE", target="Lorg/lwjgl/opengl/Display;setFullscreen(Z)V", remap=false)})
    private void resolveScreenState(CallbackInfo ci) {
        if (!this.field_71431_Q && SystemUtils.IS_OS_WINDOWS) {
            Display.setResizable((boolean)false);
            Display.setResizable((boolean)true);
        }
    }

    @Redirect(method={"dispatchKeypresses"}, at=@At(value="INVOKE", target="Lorg/lwjgl/input/Keyboard;getEventCharacter()C", remap=false))
    private char resolveForeignKeyboards() {
        return (char)(Keyboard.getEventCharacter() + 256);
    }

    @Overwrite
    private void func_147115_a(boolean leftClick) {
        if (!leftClick) {
            this.field_71429_W = 0;
        }
        if (this.field_71429_W <= 0) {
            if (leftClick && this.field_71476_x != null && this.field_71476_x.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                BlockPos blockPos = this.field_71476_x.getBlockPos();
                if (!((Boolean)Animations.oldAnimations.get()).booleanValue() && this.field_71439_g.isUsingItem()) {
                    return;
                }
                if (((Boolean)Animations.oldAnimations.get()).booleanValue() && this.field_71439_g.isUsingItem()) {
                    this.field_71439_g.swingItem();
                    return;
                }
                if (this.field_71429_W == 0) {
                    Client.eventManager.callEvent(new ClickBlockEvent(blockPos, this.field_71476_x.sideHit));
                }
                if (this.field_71441_e.getBlockState(blockPos).getBlock().getMaterial() != Material.air && this.field_71442_b.onPlayerDamageBlock(blockPos, this.field_71476_x.sideHit)) {
                    this.field_71452_i.addBlockHitEffects(blockPos, this.field_71476_x.sideHit);
                    this.field_71439_g.swingItem();
                }
            } else {
                this.field_71442_b.resetBlockRemoving();
            }
        }
    }

    @ModifyConstant(method={"getLimitFramerate"}, constant={@Constant(intValue=30)})
    public int getLimitFramerate(int constant) {
        return Int.MaxValue();
    }
}

