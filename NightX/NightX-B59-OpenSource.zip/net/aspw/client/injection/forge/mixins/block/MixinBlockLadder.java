/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockLadder
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 */
package net.aspw.client.injection.forge.mixins.block;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.exploit.ViaVersionFix;
import net.aspw.client.injection.forge.mixins.block.MixinBlock;
import net.minecraft.block.BlockLadder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value={BlockLadder.class})
public abstract class MixinBlockLadder
extends MixinBlock {
    @ModifyConstant(method={"setBlockBoundsBasedOnState"}, constant={@Constant(floatValue=0.125f)})
    private float ViaVersion_LadderBB(float constant) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(ViaVersionFix.class)).getState()) {
            return 0.1875f;
        }
        return 0.125f;
    }
}

