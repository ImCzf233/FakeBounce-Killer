/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public final class StepEvent
extends Event {
    private float stepHeight;

    public StepEvent(float stepHeight) {
        this.stepHeight = stepHeight;
    }

    public final float getStepHeight() {
        return this.stepHeight;
    }

    public final void setStepHeight(float f) {
        this.stepHeight = f;
    }
}

