/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.WorldClient
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;
import net.minecraft.client.multiplayer.WorldClient;
import org.jetbrains.annotations.Nullable;

public final class WorldEvent
extends Event {
    private final WorldClient worldClient;

    public WorldEvent(@Nullable WorldClient worldClient) {
        this.worldClient = worldClient;
    }

    public final WorldClient getWorldClient() {
        return this.worldClient;
    }
}

