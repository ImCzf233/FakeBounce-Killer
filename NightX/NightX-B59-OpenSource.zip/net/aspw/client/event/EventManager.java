/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.event;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.aspw.client.event.EventHook;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;

public final class EventManager {
    private final HashMap<Class<? extends Event>, List<EventHook>> registry = new HashMap();

    public final void registerListener(Listenable listener) {
        Intrinsics.checkNotNullParameter((Object)listener, (String)"listener");
        Method[] methodArray = listener.getClass().getDeclaredMethods();
        Intrinsics.checkNotNullExpressionValue((Object)methodArray, (String)"listener.javaClass.declaredMethods");
        Method[] methodArray2 = methodArray;
        int n = 0;
        int n2 = methodArray2.length;
        while (n < n2) {
            Class<?> eventClass;
            Method method = methodArray2[n];
            ++n;
            if (!method.isAnnotationPresent(EventTarget.class) || method.getParameterTypes().length != 1) continue;
            if (!method.isAccessible()) {
                method.setAccessible(true);
            }
            if (method.getParameterTypes()[0] == null) {
                throw new NullPointerException("null cannot be cast to non-null type java.lang.Class<out net.aspw.client.event.Event>");
            }
            EventTarget eventTarget = method.getAnnotation(EventTarget.class);
            Object object = ((Map)this.registry).get(eventClass);
            if (object == null) {
                boolean bl = false;
                object = new ArrayList();
            }
            List invokableEventTargets = (List)object;
            try {
                Intrinsics.checkNotNullExpressionValue((Object)method, (String)"method");
                int n3 = eventTarget.priority();
                Intrinsics.checkNotNullExpressionValue((Object)eventTarget, (String)"eventTarget");
                invokableEventTargets.add(new EventHook(listener, method, n3, eventTarget));
            }
            catch (Exception e) {
                e.printStackTrace();
                Intrinsics.checkNotNullExpressionValue((Object)method, (String)"method");
                Intrinsics.checkNotNullExpressionValue((Object)eventTarget, (String)"eventTarget");
                invokableEventTargets.add(new EventHook(listener, method, eventTarget));
            }
            List $this$sortBy$iv = invokableEventTargets;
            boolean $i$f$sortBy = false;
            if ($this$sortBy$iv.size() > 1) {
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EventHook it = (EventHook)a;
                        boolean bl = false;
                        Comparable comparable = Integer.valueOf(it.getPriority());
                        it = (EventHook)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Integer.valueOf(it.getPriority()));
                    }
                });
            }
            this.registry.put(eventClass, invokableEventTargets);
        }
    }

    /*
     * WARNING - void declaration
     */
    public final void callEvent(Event event) {
        void $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        List<EventHook> list = this.registry.get(event.getClass());
        if (list == null) {
            return;
        }
        List<EventHook> targets = list;
        Iterable $this$filter$iv = targets;
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            EventHook it = (EventHook)element$iv$iv;
            boolean bl = false;
            if (!(it.getEventClass().handleEvents() || it.isIgnoreCondition())) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEach$iv = (List)destination$iv$iv;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            EventHook it = (EventHook)element$iv;
            boolean bl = false;
            try {
                Object element$iv$iv;
                element$iv$iv = new Object[]{event};
                it.getMethod().invoke(it.getEventClass(), element$iv$iv);
            }
            catch (Throwable throwable) {
                throwable.printStackTrace();
            }
        }
    }
}

