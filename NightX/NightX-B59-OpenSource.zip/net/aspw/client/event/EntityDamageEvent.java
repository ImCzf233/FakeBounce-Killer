/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.event;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.minecraft.entity.Entity;

public final class EntityDamageEvent
extends Event {
    private final Entity damagedEntity;

    public EntityDamageEvent(Entity damagedEntity) {
        Intrinsics.checkNotNullParameter((Object)damagedEntity, (String)"damagedEntity");
        this.damagedEntity = damagedEntity;
    }

    public final Entity getDamagedEntity() {
        return this.damagedEntity;
    }
}

