/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public final class ActionEvent
extends Event {
    private boolean sprinting;
    private boolean sneaking;

    public ActionEvent(boolean sprinting, boolean sneaking) {
        this.sprinting = sprinting;
        this.sneaking = sneaking;
    }

    public final boolean getSprinting() {
        return this.sprinting;
    }

    public final void setSprinting(boolean bl) {
        this.sprinting = bl;
    }

    public final boolean getSneaking() {
        return this.sneaking;
    }

    public final void setSneaking(boolean bl) {
        this.sneaking = bl;
    }
}

