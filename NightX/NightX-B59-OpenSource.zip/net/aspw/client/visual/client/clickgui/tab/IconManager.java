/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.visual.client.clickgui.tab;

import kotlin.jvm.JvmField;
import net.minecraft.util.ResourceLocation;

public final class IconManager {
    public static final IconManager INSTANCE = new IconManager();
    @JvmField
    public static final ResourceLocation removeIcon = new ResourceLocation("client/notification/error.png");
    private static final ResourceLocation add = new ResourceLocation("client/clickgui/import.png");
    private static final ResourceLocation back = new ResourceLocation("client/clickgui/back.png");

    private IconManager() {
    }

    public final ResourceLocation getAdd() {
        return add;
    }

    public final ResourceLocation getBack() {
        return back;
    }
}

