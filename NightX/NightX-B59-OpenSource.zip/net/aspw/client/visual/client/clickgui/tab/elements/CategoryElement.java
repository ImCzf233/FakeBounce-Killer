/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client.clickgui.tab.elements;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.aspw.client.Client;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.elements.ModuleElement;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;
import net.aspw.client.visual.font.Fonts;
import org.lwjgl.opengl.GL11;

public final class CategoryElement
extends MinecraftInstance {
    private final ModuleCategory category;
    private final String name;
    private boolean focused;
    private float scrollHeight;
    private float animScrollHeight;
    private float lastHeight;
    private final List<ModuleElement> moduleElements;

    /*
     * WARNING - void declaration
     */
    public CategoryElement(ModuleCategory category) {
        void $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter((Object)((Object)category), (String)"category");
        this.category = category;
        this.name = this.category.getDisplayName();
        this.moduleElements = new ArrayList();
        Iterable $this$filter$iv = Client.INSTANCE.getModuleManager().getModules();
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Module it = (Module)element$iv$iv;
            boolean bl = false;
            if (!(it.getCategory() == this.getCategory())) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        Iterable $this$forEach$iv = (List)destination$iv$iv;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Module it = (Module)element$iv;
            boolean bl = false;
            this.getModuleElements().add(new ModuleElement(it));
        }
    }

    public final ModuleCategory getCategory() {
        return this.category;
    }

    public final String getName() {
        return this.name;
    }

    public final boolean getFocused() {
        return this.focused;
    }

    public final void setFocused(boolean bl) {
        this.focused = bl;
    }

    public final List<ModuleElement> getModuleElements() {
        return this.moduleElements;
    }

    public final void drawLabel(int mouseX, int mouseY, float x, float y, float width, float height) {
        if (this.focused) {
            RenderUtils.originalRoundedRect(x + 3.0f, y + 3.0f, x + width - 3.0f, y + height - 3.0f, 3.0f, ColorManager.INSTANCE.getDropDown().getRGB());
        } else if (MouseUtils.mouseWithinBounds(mouseX, mouseY, x, y, x + width, y + height)) {
            RenderUtils.originalRoundedRect(x + 3.0f, y + 3.0f, x + width - 3.0f, y + height - 3.0f, 3.0f, ColorManager.INSTANCE.getBorder().getRGB());
        }
        Fonts.fontSFUI40.drawString(this.name, x + 10.0f, y + height / 2.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
    }

    public final void drawPanel(int mX, int mY, float x, float y, float width, float height, int wheel, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        int mouseX = mX;
        int mouseY = mY;
        this.lastHeight = 0.0f;
        for (ModuleElement me : this.moduleElements) {
            this.lastHeight += 40.0f + me.getAnimHeight();
        }
        if (this.lastHeight >= 10.0f) {
            this.lastHeight -= 10.0f;
        }
        this.handleScrolling(wheel, height);
        this.drawScroll(x, y + 50.0f, width, height);
        if ((float)mouseY < y + 50.0f || (float)mouseY >= y + height) {
            mouseY = -1;
        }
        RenderUtils.makeScissorBox(x, y + 50.0f, x + width, y + height);
        GL11.glEnable((int)3089);
        float startY = y + 50.0f;
        for (ModuleElement moduleElement : this.moduleElements) {
            if (startY + this.animScrollHeight > y + height || startY + this.animScrollHeight + 40.0f + moduleElement.getAnimHeight() < y + 50.0f) {
                startY += 40.0f + moduleElement.getAnimHeight();
                continue;
            }
            startY += moduleElement.drawElement(mouseX, mouseY, x, startY + this.animScrollHeight, width, 40.0f, accentColor);
        }
        GL11.glDisable((int)3089);
    }

    private final void handleScrolling(int wheel, float height) {
        if (wheel != 0) {
            this.scrollHeight = wheel > 0 ? (this.scrollHeight += 50.0f) : (this.scrollHeight -= 50.0f);
        }
        this.scrollHeight = this.lastHeight > height - 60.0f ? RangesKt.coerceIn((float)this.scrollHeight, (float)(-this.lastHeight + height - 60.0f), (float)0.0f) : 0.0f;
        this.animScrollHeight = AnimHelperKt.animSmooth(this.animScrollHeight, this.scrollHeight, 0.5f);
    }

    private final void drawScroll(float x, float y, float width, float height) {
        if (this.lastHeight > height - 60.0f) {
            float last = height - 60.0f - (height - 60.0f) * ((height - 60.0f) / this.lastHeight);
            float multiply = last * RangesKt.coerceIn((float)Math.abs(this.animScrollHeight / (-this.lastHeight + height - 60.0f)), (float)0.0f, (float)1.0f);
            RenderUtils.originalRoundedRect(x + width - 6.0f, y + 5.0f + multiply, x + width - 4.0f, y + 5.0f + (height - 60.0f) * ((height - 60.0f) / this.lastHeight) + multiply, 1.0f, 0x50FFFFFF);
        }
    }

    public final void handleMouseClick(int mX, int mY, int mouseButton, float x, float y, float width, float height) {
        int mouseX = mX;
        int mouseY = mY;
        if ((float)mouseY < y + 50.0f || (float)mouseY >= y + height) {
            mouseY = -1;
        }
        float startY = y + 50.0f;
        if (mouseButton == 0) {
            for (ModuleElement moduleElement : this.moduleElements) {
                moduleElement.handleClick(mouseX, mouseY, x, startY + this.animScrollHeight, width, 40.0f);
                startY += 40.0f + moduleElement.getAnimHeight();
            }
        }
    }

    public final void handleMouseRelease(int mX, int mY, int mouseButton, float x, float y, float width, float height) {
        int mouseX = mX;
        int mouseY = mY;
        if ((float)mouseY < y + 50.0f || (float)mouseY >= y + height) {
            mouseY = -1;
        }
        float startY = y + 50.0f;
        if (mouseButton == 0) {
            for (ModuleElement moduleElement : this.moduleElements) {
                moduleElement.handleRelease(mouseX, mouseY, x, startY + this.animScrollHeight, width, 40.0f);
                startY += 40.0f + moduleElement.getAnimHeight();
            }
        }
    }

    public final boolean handleKeyTyped(char keyTyped, int keyCode) {
        for (ModuleElement moduleElement : this.moduleElements) {
            if (!moduleElement.handleKeyTyped(keyTyped, keyCode)) continue;
            return true;
        }
        return false;
    }
}

