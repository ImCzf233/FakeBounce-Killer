/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.visual.client.clickgui.tab;

import java.awt.Color;

public final class ColorManager {
    public static final ColorManager INSTANCE = new ColorManager();
    private static final Color background = new Color(32, 32, 32);
    private static final Color textBox = new Color(31, 31, 31);
    private static final Color dropDown = new Color(45, 45, 45);
    private static final Color button = new Color(52, 52, 52);
    private static final Color moduleBackground = new Color(39, 39, 39);
    private static final Color unusedSlider = new Color(154, 154, 154);
    private static final Color border = new Color(25, 25, 25);
    private static final Color buttonOutline = new Color(59, 59, 59);

    private ColorManager() {
    }

    public final Color getBackground() {
        return background;
    }

    public final Color getTextBox() {
        return textBox;
    }

    public final Color getDropDown() {
        return dropDown;
    }

    public final Color getButton() {
        return button;
    }

    public final Color getModuleBackground() {
        return moduleBackground;
    }

    public final Color getUnusedSlider() {
        return unusedSlider;
    }

    public final Color getBorder() {
        return border;
    }

    public final Color getButtonOutline() {
        return buttonOutline;
    }
}

