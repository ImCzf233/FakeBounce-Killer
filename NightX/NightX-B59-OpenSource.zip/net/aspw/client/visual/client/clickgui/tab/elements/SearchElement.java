/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  kotlin.text.StringsKt
 *  net.minecraft.client.renderer.GlStateManager
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client.clickgui.tab.elements;

import java.awt.Color;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.render.Stencil;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.elements.CategoryElement;
import net.aspw.client.visual.client.clickgui.tab.elements.ModuleElement;
import net.aspw.client.visual.client.clickgui.tab.elements.SearchBox;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public final class SearchElement {
    private final float xPos;
    private final float yPos;
    private final float width;
    private final float height;
    private float scrollHeight;
    private float animScrollHeight;
    private float lastHeight;
    private final SearchBox searchBox;

    public SearchElement(float xPos, float yPos, float width, float height) {
        this.xPos = xPos;
        this.yPos = yPos;
        this.width = width;
        this.height = height;
        this.searchBox = new SearchBox(0, (int)this.xPos + 2, (int)this.yPos + 2, (int)this.width - 4, (int)this.height - 2);
    }

    public final float getXPos() {
        return this.xPos;
    }

    public final float getYPos() {
        return this.yPos;
    }

    public final float getWidth() {
        return this.width;
    }

    public final float getHeight() {
        return this.height;
    }

    public final boolean drawBox(int mouseX, int mouseY, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        RenderUtils.originalRoundedRect(this.xPos - 0.5f, this.yPos - 0.5f, this.xPos + this.width + 0.5f, this.yPos + this.height + 0.5f, 4.0f, ColorManager.INSTANCE.getButtonOutline().getRGB());
        Stencil.write(true);
        RenderUtils.originalRoundedRect(this.xPos, this.yPos, this.xPos + this.width, this.yPos + this.height, 4.0f, ColorManager.INSTANCE.getTextBox().getRGB());
        Stencil.erase(true);
        if (this.searchBox.isFocused()) {
            RenderUtils.newDrawRect(this.xPos, this.yPos + this.height - 1.0f, this.xPos + this.width, this.yPos + this.height, accentColor.getRGB());
            this.searchBox.drawTextBox();
        } else if (this.searchBox.getText().length() <= 0) {
            this.searchBox.setText("Search...");
            this.searchBox.drawTextBox();
            this.searchBox.setText("");
        } else {
            this.searchBox.drawTextBox();
        }
        Stencil.dispose();
        GlStateManager.disableAlpha();
        GlStateManager.enableAlpha();
        return this.searchBox.getText().length() > 0;
    }

    public final void drawPanel(int mX, int mY, float x, float y, float w, float h, int wheel, List<CategoryElement> ces, Color accentColor) {
        Intrinsics.checkNotNullParameter(ces, (String)"ces");
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        int mouseX = mX;
        int mouseY = mY;
        this.lastHeight = 0.0f;
        for (CategoryElement ce : ces) {
            for (ModuleElement me : ce.getModuleElements()) {
                String string = me.getModule().getName();
                String string2 = this.searchBox.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"searchBox.text");
                if (!StringsKt.startsWith((String)string, (String)string2, (boolean)true)) continue;
                this.lastHeight += me.getAnimHeight() + 40.0f;
            }
        }
        if (this.lastHeight >= 10.0f) {
            this.lastHeight -= 10.0f;
        }
        this.handleScrolling(wheel, h);
        this.drawScroll(x, y + 40.0f, w, h);
        float startY = y + 40.0f;
        if ((float)mouseY < startY || (float)mouseY >= y + h) {
            mouseY = -1;
        }
        RenderUtils.makeScissorBox(x, startY, x + w, y + h);
        GL11.glEnable((int)3089);
        for (CategoryElement ce : ces) {
            for (ModuleElement me : ce.getModuleElements()) {
                String string = me.getModule().getName();
                String string3 = this.searchBox.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"searchBox.text");
                if (!StringsKt.startsWith((String)string, (String)string3, (boolean)true)) continue;
                if (startY + this.animScrollHeight > y + h || startY + this.animScrollHeight + 40.0f + me.getAnimHeight() < y + 50.0f) {
                    startY += 40.0f + me.getAnimHeight();
                    continue;
                }
                startY += me.drawElement(mouseX, mouseY, x, startY + this.animScrollHeight, w, 40.0f, accentColor);
            }
        }
        GL11.glDisable((int)3089);
    }

    private final void handleScrolling(int wheel, float height) {
        if (wheel != 0) {
            this.scrollHeight = wheel > 0 ? (this.scrollHeight += 50.0f) : (this.scrollHeight -= 50.0f);
        }
        this.scrollHeight = this.lastHeight > height - 60.0f ? RangesKt.coerceIn((float)this.scrollHeight, (float)(-this.lastHeight + height - (float)60), (float)0.0f) : 0.0f;
        this.animScrollHeight = AnimHelperKt.animSmooth(this.animScrollHeight, this.scrollHeight, 0.5f);
    }

    private final void drawScroll(float x, float y, float width, float height) {
        if (this.lastHeight > height - 60.0f) {
            float last = height - 60.0f - (height - 60.0f) * ((height - 60.0f) / this.lastHeight);
            float multiply = last * RangesKt.coerceIn((float)Math.abs(this.animScrollHeight / (-this.lastHeight + height - (float)60)), (float)0.0f, (float)1.0f);
            RenderUtils.originalRoundedRect(x + width - 6.0f, y + 5.0f + multiply, x + width - 4.0f, y + 5.0f + (height - 60.0f) * ((height - 60.0f) / this.lastHeight) + multiply, 1.0f, 0x50FFFFFF);
        }
    }

    public final void handleMouseClick(int mX, int mY, int mouseButton, float x, float y, float w, float h, List<CategoryElement> ces) {
        Intrinsics.checkNotNullParameter(ces, (String)"ces");
        if (MouseUtils.mouseWithinBounds(mX, mY, x - 200.0f, y - 20.0f, x - 170.0f, y)) {
            this.searchBox.setText("");
            return;
        }
        int mouseX = mX;
        int mouseY = mY;
        this.searchBox.mouseClicked(mouseX, mouseY, mouseButton);
        if (this.searchBox.getText().length() <= 0) {
            return;
        }
        if ((float)mouseY < y + 40.0f || (float)mouseY >= y + h) {
            mouseY = -1;
        }
        float startY = y + 40.0f;
        for (CategoryElement ce : ces) {
            for (ModuleElement me : ce.getModuleElements()) {
                String string = me.getModule().getName();
                String string2 = this.searchBox.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"searchBox.text");
                if (!StringsKt.startsWith((String)string, (String)string2, (boolean)true)) continue;
                me.handleClick(mouseX, mouseY, x, startY + this.animScrollHeight, w, 40.0f);
                startY += 40.0f + me.getAnimHeight();
            }
        }
    }

    public final void handleMouseRelease(int mX, int mY, int mouseButton, float x, float y, float w, float h, List<CategoryElement> ces) {
        Intrinsics.checkNotNullParameter(ces, (String)"ces");
        int mouseX = mX;
        int mouseY = mY;
        if (this.searchBox.getText().length() <= 0) {
            return;
        }
        if ((float)mouseY < y + 40.0f || (float)mouseY >= y + h) {
            mouseY = -1;
        }
        float startY = y + 40.0f;
        for (CategoryElement ce : ces) {
            for (ModuleElement me : ce.getModuleElements()) {
                String string = me.getModule().getName();
                String string2 = this.searchBox.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"searchBox.text");
                if (!StringsKt.startsWith((String)string, (String)string2, (boolean)true)) continue;
                me.handleRelease(mouseX, mouseY, x, startY + this.animScrollHeight, w, 40.0f);
                startY += 40.0f + me.getAnimHeight();
            }
        }
    }

    public final boolean handleTyping(char typedChar, int keyCode, float x, float y, float w, float h, List<CategoryElement> ces) {
        Intrinsics.checkNotNullParameter(ces, (String)"ces");
        this.searchBox.textboxKeyTyped(typedChar, keyCode);
        if (this.searchBox.getText().length() <= 0) {
            return false;
        }
        for (CategoryElement ce : ces) {
            for (ModuleElement me : ce.getModuleElements()) {
                String string = me.getModule().getName();
                String string2 = this.searchBox.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"searchBox.text");
                if (!StringsKt.startsWith((String)string, (String)string2, (boolean)true) || !me.handleKeyTyped(typedChar, keyCode)) continue;
                return true;
            }
        }
        return false;
    }

    public final boolean isTyping() {
        return this.searchBox.getText().length() > 0;
    }
}

