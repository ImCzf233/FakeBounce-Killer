/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  me.liuli.elixir.account.MinecraftAccount
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 */
package net.aspw.client.visual.client.altmanager.menus;

import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import me.liuli.elixir.account.MinecraftAccount;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

public final class GuiLoginProgress
extends GuiScreen {
    public GuiLoginProgress(MinecraftAccount minecraftAccount, Function0<Unit> success, Function1<? super Exception, Unit> error, Function0<Unit> done) {
        Intrinsics.checkNotNullParameter((Object)minecraftAccount, (String)"minecraftAccount");
        Intrinsics.checkNotNullParameter(success, (String)"success");
        Intrinsics.checkNotNullParameter(error, (String)"error");
        Intrinsics.checkNotNullParameter(done, (String)"done");
        GuiAltManager.Companion.login(minecraftAccount, success, error, done);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        new ScaledResolution(Minecraft.getMinecraft());
        this.drawDefaultBackground();
        this.func_73732_a(this.mc.fontRendererObj, "Logging in...", this.width / 2, this.height / 2 - 60, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}

