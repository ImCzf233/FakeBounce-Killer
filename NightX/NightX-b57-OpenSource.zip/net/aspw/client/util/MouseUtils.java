/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  net.minecraftforge.client.event.MouseEvent
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.ObfuscationReflectionHelper
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.util;

import java.nio.ByteBuffer;
import kotlin.jvm.JvmStatic;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.Event;
import org.lwjgl.input.Mouse;

public final class MouseUtils {
    public static final MouseUtils INSTANCE = new MouseUtils();

    private MouseUtils() {
    }

    @JvmStatic
    public static final boolean mouseWithinBounds(int mouseX, int mouseY, float x, float y, float x2, float y2) {
        return (float)mouseX >= x && (float)mouseX < x2 && (float)mouseY >= y && (float)mouseY < y2;
    }

    public final void setMouseButtonState(int mouseButton, boolean held) {
        MouseEvent m = new MouseEvent();
        String[] stringArray = new String[]{"button"};
        ObfuscationReflectionHelper.setPrivateValue(MouseEvent.class, (Object)m, (Object)mouseButton, (String[])stringArray);
        stringArray = new String[]{"buttonstate"};
        ObfuscationReflectionHelper.setPrivateValue(MouseEvent.class, (Object)m, (Object)held, (String[])stringArray);
        MinecraftForge.EVENT_BUS.post((Event)m);
        String[] stringArray2 = new String[]{"buttons"};
        ByteBuffer buttons = (ByteBuffer)ObfuscationReflectionHelper.getPrivateValue(Mouse.class, null, (String[])stringArray2);
        buttons.put(mouseButton, (byte)(held ? 1 : 0));
        stringArray2 = new String[]{"buttons"};
        ObfuscationReflectionHelper.setPrivateValue(Mouse.class, null, (Object)buttons, (String[])stringArray2);
    }
}

