/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 */
package net.aspw.client.util.connection;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public final class CheckConnection {
    public static final CheckConnection INSTANCE = new CheckConnection();
    private static boolean connected;

    private CheckConnection() {
    }

    public final boolean getConnected() {
        return connected;
    }

    public final void setConnected(boolean bl) {
        connected = bl;
    }

    public final void connect() {
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpGet request = new HttpGet("https://sites.google.com/view/nightx-plus");
            CloseableHttpResponse response = httpClient.execute((HttpUriRequest)request);
            connected = true;
            response.close();
            httpClient.close();
        }
        catch (Exception e) {
            e.printStackTrace();
            connected = false;
        }
    }
}

