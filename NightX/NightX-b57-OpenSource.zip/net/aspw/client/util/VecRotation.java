/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.util;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.Rotation;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;

public final class VecRotation {
    private final Vec3 vec;
    private final Rotation rotation;

    public VecRotation(Vec3 vec, Rotation rotation) {
        Intrinsics.checkNotNullParameter((Object)vec, (String)"vec");
        Intrinsics.checkNotNullParameter((Object)rotation, (String)"rotation");
        this.vec = vec;
        this.rotation = rotation;
    }

    public final Vec3 getVec() {
        return this.vec;
    }

    public final Rotation getRotation() {
        return this.rotation;
    }

    public final Vec3 component1() {
        return this.vec;
    }

    public final Rotation component2() {
        return this.rotation;
    }

    public final VecRotation copy(Vec3 vec, Rotation rotation) {
        Intrinsics.checkNotNullParameter((Object)vec, (String)"vec");
        Intrinsics.checkNotNullParameter((Object)rotation, (String)"rotation");
        return new VecRotation(vec, rotation);
    }

    public static /* synthetic */ VecRotation copy$default(VecRotation vecRotation, Vec3 vec3, Rotation rotation, int n, Object object) {
        if ((n & 1) != 0) {
            vec3 = vecRotation.vec;
        }
        if ((n & 2) != 0) {
            rotation = vecRotation.rotation;
        }
        return vecRotation.copy(vec3, rotation);
    }

    public String toString() {
        return "VecRotation(vec=" + this.vec + ", rotation=" + this.rotation + ')';
    }

    public int hashCode() {
        int result = this.vec.hashCode();
        result = result * 31 + this.rotation.hashCode();
        return result;
    }

    public boolean equals(@Nullable Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof VecRotation)) {
            return false;
        }
        VecRotation vecRotation = (VecRotation)other;
        if (!this.vec.equals(vecRotation.vec)) {
            return false;
        }
        return ((Object)this.rotation).equals(vecRotation.rotation);
    }
}

