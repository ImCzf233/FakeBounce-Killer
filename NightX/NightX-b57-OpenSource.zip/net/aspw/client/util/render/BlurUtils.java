/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.WorldRenderer
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.client.shader.Framebuffer
 *  net.minecraft.client.shader.Shader
 *  net.minecraft.client.shader.ShaderGroup
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.util.render;

import kotlin.Unit;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.render.Stencil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.Shader;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.util.ResourceLocation;

public final class BlurUtils
extends MinecraftInstance {
    public static final BlurUtils INSTANCE = new BlurUtils();
    private static final ShaderGroup shaderGroup = new ShaderGroup(MinecraftInstance.mc.getTextureManager(), MinecraftInstance.mc.getResourceManager(), MinecraftInstance.mc.getFramebuffer(), new ResourceLocation("shaders/post/blurArea.json"));
    private static final Framebuffer framebuffer = BlurUtils.shaderGroup.mainFramebuffer;
    private static final Framebuffer frbuffer = shaderGroup.getFramebufferRaw("result");
    private static int lastFactor;
    private static int lastWidth;
    private static int lastHeight;
    private static float lastX;
    private static float lastY;
    private static float lastW;
    private static float lastH;
    private static float lastStrength;

    private BlurUtils() {
    }

    private final void setupFramebuffers() {
        try {
            shaderGroup.createBindFramebuffers(MinecraftInstance.mc.displayWidth, MinecraftInstance.mc.displayHeight);
        }
        catch (Exception e) {
            ClientUtils.getLogger().error("Exception caught while setting up shader group", (Throwable)e);
        }
    }

    private final void setValues(float strength, float x, float y, float w, float h, float width, float height, boolean force) {
        if (!force && strength == lastStrength && lastX == x && lastY == y && lastW == w && lastH == h) {
            return;
        }
        lastStrength = strength;
        lastX = x;
        lastY = y;
        lastW = w;
        lastH = h;
        int n = 0;
        while (n < 2) {
            int i = n++;
            ((Shader)BlurUtils.shaderGroup.listShaders.get(i)).getShaderManager().getShaderUniform("Radius").set(strength);
            ((Shader)BlurUtils.shaderGroup.listShaders.get(i)).getShaderManager().getShaderUniform("BlurXY").set(x, height - y - h);
            ((Shader)BlurUtils.shaderGroup.listShaders.get(i)).getShaderManager().getShaderUniform("BlurCoord").set(w, h);
        }
    }

    static /* synthetic */ void setValues$default(BlurUtils blurUtils, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean bl, int n, Object object) {
        if ((n & 0x80) != 0) {
            bl = false;
        }
        blurUtils.setValues(f, f2, f3, f4, f5, f6, f7, bl);
    }

    @JvmStatic
    public static final void blur(float posX, float posY, float posXEnd, float posYEnd, float blurStrength2, boolean displayClipMask, Function0<Unit> triggerMethod) {
        int height;
        int width;
        ScaledResolution sc;
        int scaleFactor;
        float z;
        Intrinsics.checkNotNullParameter(triggerMethod, (String)"triggerMethod");
        if (!OpenGlHelper.isFramebufferEnabled()) {
            return;
        }
        float x = posX;
        float y = posY;
        float x2 = posXEnd;
        float y2 = posYEnd;
        if (x > x2) {
            z = x;
            x = x2;
            x2 = z;
        }
        if (y > y2) {
            z = y;
            y2 = y = y2;
        }
        if (INSTANCE.sizeHasChanged(scaleFactor = (sc = new ScaledResolution(MinecraftInstance.mc)).getScaleFactor(), width = sc.getScaledWidth(), height = sc.getScaledHeight())) {
            INSTANCE.setupFramebuffers();
            INSTANCE.setValues(blurStrength2, x, y, x2 - x, y2 - y, width, height, true);
        }
        lastFactor = scaleFactor;
        lastWidth = width;
        lastHeight = height;
        BlurUtils.setValues$default(INSTANCE, blurStrength2, x, y, x2 - x, y2 - y, width, height, false, 128, null);
        framebuffer.bindFramebuffer(true);
        shaderGroup.loadShaderGroup(MinecraftInstance.mc.timer.renderPartialTicks);
        MinecraftInstance.mc.getFramebuffer().bindFramebuffer(true);
        Stencil.write(displayClipMask);
        triggerMethod.invoke();
        Stencil.erase(true);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc((int)770, (int)771);
        GlStateManager.pushMatrix();
        GlStateManager.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)false);
        GlStateManager.disableDepth();
        GlStateManager.depthMask((boolean)false);
        GlStateManager.enableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.disableAlpha();
        frbuffer.bindFramebufferTexture();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        double f2 = (double)BlurUtils.frbuffer.framebufferWidth / (double)BlurUtils.frbuffer.framebufferTextureWidth;
        double f3 = (double)BlurUtils.frbuffer.framebufferHeight / (double)BlurUtils.frbuffer.framebufferTextureHeight;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        worldrenderer.pos(0.0, (double)height, 0.0).tex(0.0, 0.0).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos((double)width, (double)height, 0.0).tex(f2, 0.0).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos((double)width, 0.0, 0.0).tex(f2, f3).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos(0.0, 0.0, 0.0).tex(0.0, f3).color(255, 255, 255, 255).endVertex();
        tessellator.draw();
        frbuffer.unbindFramebufferTexture();
        GlStateManager.enableDepth();
        GlStateManager.depthMask((boolean)true);
        GlStateManager.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        GlStateManager.popMatrix();
        GlStateManager.disableBlend();
        Stencil.dispose();
        GlStateManager.enableAlpha();
    }

    @JvmStatic
    public static final void blurArea(float x, float y, float x2, float y2, float blurStrength2) {
        BlurUtils.blur(x, y, x2, y2, blurStrength2, false, (Function0<Unit>)((Function0)new Function0<Unit>(x, y, x2, y2){
            final /* synthetic */ float $x;
            final /* synthetic */ float $y;
            final /* synthetic */ float $x2;
            final /* synthetic */ float $y2;
            {
                this.$x = $x;
                this.$y = $y;
                this.$x2 = $x2;
                this.$y2 = $y2;
                super(0);
            }

            public final void invoke() {
                GlStateManager.enableBlend();
                GlStateManager.disableTexture2D();
                GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)1, (int)0);
                RenderUtils.quickDrawRect(this.$x, this.$y, this.$x2, this.$y2);
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
            }
        }));
    }

    @JvmStatic
    public static final void blurAreaRounded(float x, float y, float x2, float y2, float rad, float blurStrength2) {
        BlurUtils.blur(x, y, x2, y2, blurStrength2, false, (Function0<Unit>)((Function0)new Function0<Unit>(x, y, x2, y2, rad){
            final /* synthetic */ float $x;
            final /* synthetic */ float $y;
            final /* synthetic */ float $x2;
            final /* synthetic */ float $y2;
            final /* synthetic */ float $rad;
            {
                this.$x = $x;
                this.$y = $y;
                this.$x2 = $x2;
                this.$y2 = $y2;
                this.$rad = $rad;
                super(0);
            }

            public final void invoke() {
                GlStateManager.enableBlend();
                GlStateManager.disableTexture2D();
                GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)1, (int)0);
                RenderUtils.fastRoundedRect(this.$x, this.$y, this.$x2, this.$y2, this.$rad);
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
            }
        }));
    }

    public final boolean sizeHasChanged(int scaleFactor, int width, int height) {
        return lastFactor != scaleFactor || lastWidth != width || lastHeight != height;
    }

    static {
        lastStrength = 5.0f;
    }
}

