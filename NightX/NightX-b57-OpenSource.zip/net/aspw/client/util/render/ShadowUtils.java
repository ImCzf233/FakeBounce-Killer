/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.Tessellator
 *  net.minecraft.client.renderer.WorldRenderer
 *  net.minecraft.client.renderer.vertex.DefaultVertexFormats
 *  net.minecraft.client.shader.Framebuffer
 *  net.minecraft.client.shader.Shader
 *  net.minecraft.client.shader.ShaderGroup
 *  net.minecraft.util.ResourceLocation
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.util.render;

import java.io.IOException;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.Stencil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.Shader;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.util.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

public final class ShadowUtils
extends MinecraftInstance {
    public static final ShadowUtils INSTANCE = new ShadowUtils();
    private static Framebuffer initFramebuffer;
    private static Framebuffer frameBuffer;
    private static Framebuffer resultBuffer;
    private static ShaderGroup shaderGroup;
    private static int lastWidth;
    private static int lastHeight;
    private static float lastStrength;
    private static final ResourceLocation blurDirectory;

    private ShadowUtils() {
    }

    public final Framebuffer getResultBuffer() {
        return resultBuffer;
    }

    public final void setResultBuffer(@Nullable Framebuffer framebuffer) {
        resultBuffer = framebuffer;
    }

    public final void initShaderIfRequired(ScaledResolution sc, float strength) throws IOException {
        int i;
        int n;
        Intrinsics.checkNotNullParameter((Object)sc, (String)"sc");
        int width = sc.getScaledWidth();
        int height = sc.getScaledHeight();
        int factor = sc.getScaleFactor();
        if (lastWidth != width || lastHeight != height || initFramebuffer == null || frameBuffer == null || shaderGroup == null) {
            Framebuffer framebuffer = initFramebuffer = new Framebuffer(width * factor, height * factor, true);
            Intrinsics.checkNotNull((Object)framebuffer);
            framebuffer.setFramebufferColor(0.0f, 0.0f, 0.0f, 0.0f);
            Framebuffer framebuffer2 = initFramebuffer;
            Intrinsics.checkNotNull((Object)framebuffer2);
            framebuffer2.setFramebufferFilter(9729);
            ShaderGroup shaderGroup = ShadowUtils.shaderGroup = new ShaderGroup(MinecraftInstance.mc.getTextureManager(), MinecraftInstance.mc.getResourceManager(), initFramebuffer, blurDirectory);
            Intrinsics.checkNotNull((Object)shaderGroup);
            shaderGroup.createBindFramebuffers(width * factor, height * factor);
            ShaderGroup shaderGroup2 = ShadowUtils.shaderGroup;
            Intrinsics.checkNotNull((Object)shaderGroup2);
            frameBuffer = shaderGroup2.mainFramebuffer;
            ShaderGroup shaderGroup3 = ShadowUtils.shaderGroup;
            Intrinsics.checkNotNull((Object)shaderGroup3);
            resultBuffer = shaderGroup3.getFramebufferRaw("braindead");
            lastWidth = width;
            lastHeight = height;
            lastStrength = strength;
            n = 0;
            while (n < 2) {
                i = n++;
                ShaderGroup shaderGroup4 = ShadowUtils.shaderGroup;
                Intrinsics.checkNotNull((Object)shaderGroup4);
                ((Shader)shaderGroup4.listShaders.get(i)).getShaderManager().getShaderUniform("Radius").set(strength);
            }
        }
        if (!(lastStrength == strength)) {
            lastStrength = strength;
            n = 0;
            while (n < 2) {
                i = n++;
                ShaderGroup shaderGroup = ShadowUtils.shaderGroup;
                Intrinsics.checkNotNull((Object)shaderGroup);
                ((Shader)shaderGroup.listShaders.get(i)).getShaderManager().getShaderUniform("Radius").set(strength);
            }
        }
    }

    public final void shadow(float strength, Function0<Unit> drawMethod, Function0<Unit> cutMethod) {
        Intrinsics.checkNotNullParameter(drawMethod, (String)"drawMethod");
        Intrinsics.checkNotNullParameter(cutMethod, (String)"cutMethod");
        if (!OpenGlHelper.isFramebufferEnabled()) {
            return;
        }
        ScaledResolution sc = new ScaledResolution(MinecraftInstance.mc);
        int width = sc.getScaledWidth();
        int height = sc.getScaledHeight();
        this.initShaderIfRequired(sc, strength);
        if (initFramebuffer == null) {
            return;
        }
        if (resultBuffer == null) {
            return;
        }
        if (frameBuffer == null) {
            return;
        }
        MinecraftInstance.mc.getFramebuffer().unbindFramebuffer();
        Framebuffer framebuffer = initFramebuffer;
        Intrinsics.checkNotNull((Object)framebuffer);
        framebuffer.framebufferClear();
        Framebuffer framebuffer2 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer2);
        framebuffer2.framebufferClear();
        Framebuffer framebuffer3 = initFramebuffer;
        Intrinsics.checkNotNull((Object)framebuffer3);
        framebuffer3.bindFramebuffer(true);
        drawMethod.invoke();
        Framebuffer framebuffer4 = frameBuffer;
        Intrinsics.checkNotNull((Object)framebuffer4);
        framebuffer4.bindFramebuffer(true);
        ShaderGroup shaderGroup = ShadowUtils.shaderGroup;
        Intrinsics.checkNotNull((Object)shaderGroup);
        shaderGroup.loadShaderGroup(MinecraftInstance.mc.timer.renderPartialTicks);
        MinecraftInstance.mc.getFramebuffer().bindFramebuffer(true);
        Framebuffer framebuffer5 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer5);
        double d = framebuffer5.framebufferWidth;
        Framebuffer framebuffer6 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer6);
        double fr_width = d / (double)framebuffer6.framebufferTextureWidth;
        Framebuffer framebuffer7 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer7);
        double d2 = framebuffer7.framebufferHeight;
        Framebuffer framebuffer8 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer8);
        double fr_height = d2 / (double)framebuffer8.framebufferTextureHeight;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        GL11.glPushMatrix();
        GlStateManager.disableLighting();
        GlStateManager.disableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.depthMask((boolean)false);
        GlStateManager.colorMask((boolean)true, (boolean)true, (boolean)true, (boolean)true);
        Stencil.write(false);
        cutMethod.invoke();
        Stencil.erase(false);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc((int)770, (int)771);
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Framebuffer framebuffer9 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer9);
        framebuffer9.bindFramebufferTexture();
        GL11.glTexParameteri((int)3553, (int)10242, (int)33071);
        GL11.glTexParameteri((int)3553, (int)10243, (int)33071);
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX_COLOR);
        worldrenderer.pos(0.0, (double)height, 0.0).tex(0.0, 0.0).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos((double)width, (double)height, 0.0).tex(fr_width, 0.0).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos((double)width, 0.0, 0.0).tex(fr_width, fr_height).color(255, 255, 255, 255).endVertex();
        worldrenderer.pos(0.0, 0.0, 0.0).tex(0.0, fr_height).color(255, 255, 255, 255).endVertex();
        tessellator.draw();
        Framebuffer framebuffer10 = resultBuffer;
        Intrinsics.checkNotNull((Object)framebuffer10);
        framebuffer10.unbindFramebufferTexture();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableDepth();
        GlStateManager.depthMask((boolean)true);
        Stencil.dispose();
        GL11.glPopMatrix();
        GlStateManager.resetColor();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)1, (int)0);
    }

    static {
        blurDirectory = new ResourceLocation("client/shader/shadow.json");
    }
}

