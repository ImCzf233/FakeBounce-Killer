/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.util;

import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;

public final class MovementUtilsFix
extends MinecraftInstance {
    public static final MovementUtilsFix INSTANCE = new MovementUtilsFix();

    private MovementUtilsFix() {
    }

    public final double getDirection() {
        float rotationYaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
        if (Minecraft.getMinecraft().thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.getMinecraft().thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.getMinecraft().thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.getMinecraft().thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (Minecraft.getMinecraft().thePlayer.moveStrafing < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    private final double getFunDirection() {
        float rotationYaw = MinecraftInstance.mc.thePlayer.rotationYaw;
        if (MinecraftInstance.mc.thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (MinecraftInstance.mc.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (MinecraftInstance.mc.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (MinecraftInstance.mc.thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= (float)70 * forward;
        }
        if (MinecraftInstance.mc.thePlayer.moveStrafing < 0.0f) {
            rotationYaw += (float)70 * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public final double defaultSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public final void theStrafe(double speed2) {
        if (!MovementUtils.isMoving()) {
            return;
        }
        MinecraftInstance.mc.thePlayer.motionX = (double)(-MathHelper.sin((float)((float)this.getFunDirection()))) * speed2;
        MinecraftInstance.mc.thePlayer.motionZ = (double)MathHelper.cos((float)((float)this.getFunDirection())) * speed2;
    }

    public final float getMovingYaw() {
        return (float)(this.getDirection() * (double)180.0f / Math.PI);
    }
}

