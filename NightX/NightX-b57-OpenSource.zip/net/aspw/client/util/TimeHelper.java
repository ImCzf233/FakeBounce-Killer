/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.util;

public class TimeHelper {
    private long prevMS;

    public void reset() {
        this.prevMS = this.getTime();
    }

    private long getTime() {
        return System.nanoTime() / 1000000L;
    }

    public long getMs() {
        return this.getDelay() / 1000000L - this.prevMS;
    }

    public long getDelay() {
        return System.nanoTime();
    }
}

