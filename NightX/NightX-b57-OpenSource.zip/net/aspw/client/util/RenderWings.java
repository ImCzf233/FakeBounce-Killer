/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class RenderWings
extends ModelBase {
    private final ResourceLocation location = new ResourceLocation("client/models/wing.png");
    private final ModelRenderer wing;
    private final ModelRenderer wingTip;
    private final boolean playerUsesFullHeight;

    public RenderWings() {
        this.playerUsesFullHeight = true;
        this.setTextureOffset("wing.bone", 0, 0);
        this.setTextureOffset("wing.skin", -10, 8);
        this.setTextureOffset("wingtip.bone", 0, 5);
        this.setTextureOffset("wingtip.skin", -10, 18);
        this.wing = new ModelRenderer((ModelBase)this, "wing");
        this.wing.setTextureSize(30, 30);
        this.wing.setRotationPoint(-2.0f, 0.0f, 0.0f);
        this.wing.addBox("bone", -10.0f, -1.0f, -1.0f, 10, 2, 2);
        this.wing.addBox("skin", -10.0f, 0.0f, 0.5f, 10, 0, 10);
        this.wingTip = new ModelRenderer((ModelBase)this, "wingtip");
        this.wingTip.setTextureSize(30, 30);
        this.wingTip.setRotationPoint(-10.0f, 0.0f, 0.0f);
        this.wingTip.addBox("bone", -10.0f, -0.5f, -0.5f, 10, 1, 1);
        this.wingTip.addBox("skin", -10.0f, 0.0f, 0.5f, 10, 0, 10);
        this.wing.addChild(this.wingTip);
    }

    public final void renderWings(float partialTicks) {
        double scale = 1.0;
        double rotate = this.interpolate(Minecraft.getMinecraft().thePlayer.prevRenderYawOffset, Minecraft.getMinecraft().thePlayer.renderYawOffset, partialTicks);
        GL11.glPushMatrix();
        GL11.glScaled((double)(-scale), (double)(-scale), (double)scale);
        GL11.glRotated((double)(180.0 + rotate), (double)0.0, (double)1.0, (double)0.0);
        GL11.glTranslated((double)0.0, (double)(-(this.playerUsesFullHeight ? 1.45 : 1.25 / scale)), (double)0.0);
        GL11.glTranslated((double)0.0, (double)0.0, (double)(0.2 / scale));
        if (Minecraft.getMinecraft().thePlayer.isSneaking()) {
            GL11.glTranslated((double)0.0, (double)(0.125 / scale), (double)0.0);
        }
        GL11.glColor3f((float)0.9f, (float)0.9f, (float)0.9f);
        Minecraft.getMinecraft().getTextureManager().bindTexture(this.location);
        int n = 0;
        while (n < 2) {
            int j = n++;
            GL11.glEnable((int)2884);
            float f11 = (float)(System.currentTimeMillis() % 1000L) / 1000.0f * (float)Math.PI * 2.0f;
            this.wing.rotateAngleX = (float)Math.toRadians(-10.0) - (float)Math.cos(f11) * -0.6f;
            this.wing.rotateAngleY = (float)Math.toRadians(30.0) + (float)Math.sin(f11) * 0.2f;
            this.wing.rotateAngleZ = (float)Math.toRadians(30.0);
            this.wingTip.rotateAngleZ = -((float)(Math.sin(f11 + 1.2f) + 1.1)) * 0.75f;
            this.wing.render(0.0525f);
            GL11.glScalef((float)-1.0f, (float)1.0f, (float)1.0f);
            if (j != 0) continue;
            GL11.glCullFace((int)1028);
        }
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2884);
        GL11.glColor3f((float)255.0f, (float)255.0f, (float)255.0f);
        GL11.glPopMatrix();
    }

    private final double interpolate(float yaw1, float yaw2, float percent) {
        double f = (double)(yaw1 + (yaw2 - yaw1) * percent) % 360.0;
        if (f < 0.0) {
            f += 360.0;
        }
        return f;
    }
}

