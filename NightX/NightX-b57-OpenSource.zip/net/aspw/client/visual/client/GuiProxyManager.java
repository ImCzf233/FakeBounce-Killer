/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.visual.client;

import java.net.Proxy;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.api.ProxyManager;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public final class GuiProxyManager
extends GuiScreen {
    private final GuiScreen prevGui;
    private GuiTextField textField;
    private GuiButton type;
    private GuiButton stat;

    public GuiProxyManager(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
    }

    public void initGui() {
        GuiButton it;
        GuiButton guiButton;
        Keyboard.enableRepeatEvents((boolean)true);
        this.textField = new GuiTextField(3, (FontRenderer)Fonts.fontSFUI40, this.width / 2 - 96, 60, 200, 20);
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.setText(ProxyManager.INSTANCE.getProxy());
        GuiTextField guiTextField2 = this.textField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.setMaxStringLength(Integer.MAX_VALUE);
        GuiButton guiButton2 = guiButton = new GuiButton(1, this.width / 2 - 100, this.height / 4 + 96, "");
        List list = this.buttonList;
        boolean bl = false;
        this.type = it;
        list.add(guiButton);
        it = guiButton = new GuiButton(2, this.width / 2 - 100, this.height / 4 + 120, "");
        list = this.buttonList;
        boolean bl2 = false;
        this.stat = it;
        list.add(guiButton);
        this.buttonList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 144, "Done"));
        this.updateButtonStat();
    }

    private final void updateButtonStat() {
        GuiButton guiButton = this.type;
        if (guiButton == null) {
            guiButton = null;
        }
        guiButton.displayString = Intrinsics.stringPlus((String)"Type: \u00a7a", (Object)ProxyManager.INSTANCE.getProxyType().name());
        GuiButton guiButton2 = this.stat;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        guiButton2.displayString = Intrinsics.stringPlus((String)"Status: ", (Object)(ProxyManager.INSTANCE.isEnable() ? "\u00a7aEnabled" : "\u00a7cDisabled"));
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.width, this.height);
        Fonts.fontLarge.drawCenteredString("Proxy Manager", (float)this.width / 2.0f, 12.0f, 0xFFFFFF);
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.drawTextBox();
        GuiTextField guiTextField2 = this.textField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        String string = guiTextField2.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"textField.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField3 = this.textField;
            if (guiTextField3 == null) {
                guiTextField3 = null;
            }
            if (!guiTextField3.isFocused()) {
                this.func_73731_b(Fonts.fontSFUI40, "\u00a77Proxy : Port", this.width / 2 - 92, 66, 0xFFFFFF);
            }
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        block0 : switch (button.id) {
            case 0: {
                GuiTextField guiTextField = this.textField;
                if (guiTextField == null) {
                    guiTextField = null;
                }
                String string = guiTextField.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"textField.text");
                ProxyManager.INSTANCE.setProxy(string);
                this.mc.displayGuiScreen(this.prevGui);
                break;
            }
            case 1: {
                switch (WhenMappings.$EnumSwitchMapping$0[ProxyManager.INSTANCE.getProxyType().ordinal()]) {
                    case 1: {
                        ProxyManager.INSTANCE.setProxyType(Proxy.Type.HTTP);
                        break block0;
                    }
                    case 2: {
                        ProxyManager.INSTANCE.setProxyType(Proxy.Type.SOCKS);
                        break block0;
                    }
                }
                throw new IllegalStateException("Proxy type is not supported!");
            }
            case 2: {
                ProxyManager.INSTANCE.setEnable(!ProxyManager.INSTANCE.isEnable());
            }
        }
        this.updateButtonStat();
    }

    public void onGuiClosed() {
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        String string = guiTextField.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"textField.text");
        ProxyManager.INSTANCE.setProxy(string);
    }

    protected void keyTyped(char typedChar, int keyCode) {
        if (1 == keyCode) {
            this.mc.displayGuiScreen(this.prevGui);
            return;
        }
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        if (guiTextField.isFocused()) {
            GuiTextField guiTextField2 = this.textField;
            if (guiTextField2 == null) {
                guiTextField2 = null;
            }
            guiTextField2.textboxKeyTyped(typedChar, keyCode);
        }
        super.keyTyped(typedChar, keyCode);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void updateScreen() {
        GuiTextField guiTextField = this.textField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.updateCursorCounter();
        super.updateScreen();
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[Proxy.Type.values().length];
            nArray[Proxy.Type.SOCKS.ordinal()] = 1;
            nArray[Proxy.Type.HTTP.ordinal()] = 2;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

