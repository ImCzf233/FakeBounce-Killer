/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thealtening.AltService$EnumAltService
 *  kotlin.Unit
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Regex
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MicrosoftAccount
 *  me.liuli.elixir.account.MicrosoftAccount$Companion
 *  me.liuli.elixir.account.MicrosoftAccount$OAuthHandler
 *  me.liuli.elixir.account.MinecraftAccount
 *  me.liuli.elixir.account.MojangAccount
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Session
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.visual.client.altmanager.menus;

import com.thealtening.AltService;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.util.List;
import kotlin.Unit;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MicrosoftAccount;
import me.liuli.elixir.account.MinecraftAccount;
import me.liuli.elixir.account.MojangAccount;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.TabUtils;
import net.aspw.client.util.misc.MiscUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.elements.GuiPasswordField;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.lwjgl.input.Keyboard;

public final class GuiDirectLogin
extends GuiScreen {
    private final GuiAltManager prevGui;
    private final boolean directLogin;
    private GuiButton addButton;
    private GuiButton clipboardButton;
    private GuiTextField username;
    private GuiTextField password;
    private String status;

    public GuiDirectLogin(GuiAltManager prevGui, boolean directLogin) {
        Intrinsics.checkNotNullParameter((Object)((Object)prevGui), (String)"prevGui");
        this.prevGui = prevGui;
        this.directLogin = directLogin;
        this.status = "\u00a77Waiting...";
    }

    public /* synthetic */ GuiDirectLogin(GuiAltManager guiAltManager, boolean bl, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 2) != 0) {
            bl = false;
        }
        this(guiAltManager, bl);
    }

    public final boolean getDirectLogin() {
        return this.directLogin;
    }

    public void initGui() {
        GuiButton it;
        Object object;
        Keyboard.enableRepeatEvents((boolean)true);
        GuiButton guiButton = object = new GuiButton(2, this.width / 2 - 100, 113, "Clipboard");
        List list = this.buttonList;
        boolean bl = false;
        this.clipboardButton = it;
        list.add(object);
        this.buttonList.add(new GuiButton(3, this.width / 2 - 100, 143, "Login with Microsoft"));
        it = object = new GuiButton(1, this.width / 2 - 100, this.height - 54, 98, 20, this.directLogin ? "Login" : "Add");
        list = this.buttonList;
        boolean bl2 = false;
        this.addButton = it;
        list.add(object);
        this.buttonList.add(new GuiButton(0, this.width / 2 + 2, this.height - 54, 98, 20, "Done"));
        this.username = new GuiTextField(2, (FontRenderer)Fonts.fontSFUI40, this.width / 2 - 100, 60, 200, 20);
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.setFocused(true);
        GuiTextField guiTextField2 = this.username;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.setMaxStringLength(Integer.MAX_VALUE);
        object = Fonts.fontSFUI40;
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"fontSFUI40");
        this.password = new GuiPasswordField(3, (FontRenderer)object, this.width / 2 - 100, 85, 200, 20);
        GuiTextField guiTextField3 = this.password;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        guiTextField3.setMaxStringLength(Integer.MAX_VALUE);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        GuiTextField guiTextField;
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/altmanager.png"), 0, 0, this.width, this.height);
        RenderUtils.drawRect(30.0f, 30.0f, (float)this.width - 30.0f, (float)this.height - 30.0f, Integer.MIN_VALUE);
        Fonts.fontSFUI40.drawCenteredString(this.directLogin ? "Direct Login" : "Add Account", (float)this.width / 2.0f, 34.0f, 0xFFFFFF);
        Fonts.fontSFUI40.drawCenteredString("\u00a77Login with Mojang", (float)this.width / 2.0f, 47.0f, 0xFFFFFF);
        Fonts.fontSFUI35.drawCenteredString(this.status, (float)this.width / 2.0f, (float)this.height - 64.0f, 0xFFFFFF);
        GuiTextField guiTextField2 = this.username;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.drawTextBox();
        GuiTextField guiTextField3 = this.password;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        guiTextField3.drawTextBox();
        GuiTextField guiTextField4 = this.username;
        if (guiTextField4 == null) {
            guiTextField4 = null;
        }
        String string = guiTextField4.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"username.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField5 = this.username;
            if (guiTextField5 == null) {
                guiTextField5 = null;
            }
            if (!guiTextField5.isFocused()) {
                Fonts.fontSFUI40.drawCenteredString("\u00a77Username / E-Mail", this.width / 2 - 55, 66.0f, 0xFFFFFF);
            }
        }
        if ((guiTextField = this.password) == null) {
            guiTextField = null;
        }
        string = guiTextField.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"password.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField6 = this.password;
            if (guiTextField6 == null) {
                guiTextField6 = null;
            }
            if (!guiTextField6.isFocused()) {
                Fonts.fontSFUI40.drawCenteredString("\u00a77Password", this.width / 2 - 74, 91.0f, 0xFFFFFF);
            }
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (!button.enabled) {
            return;
        }
        switch (button.id) {
            case 0: {
                this.mc.displayGuiScreen((GuiScreen)this.prevGui);
                break;
            }
            case 1: {
                GuiTextField guiTextField = this.username;
                if (guiTextField == null) {
                    guiTextField = null;
                }
                String usernameText = guiTextField.getText();
                GuiTextField guiTextField2 = this.password;
                if (guiTextField2 == null) {
                    guiTextField2 = null;
                }
                String passwordText = guiTextField2.getText();
                Intrinsics.checkNotNullExpressionValue((Object)usernameText, (String)"usernameText");
                Intrinsics.checkNotNullExpressionValue((Object)passwordText, (String)"passwordText");
                this.checkAndAddAccount(usernameText, passwordText);
                break;
            }
            case 2: {
                try {
                    Object object = Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
                    if (object == null) {
                        throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
                    }
                    String clipboardData = (String)object;
                    CharSequence charSequence = clipboardData;
                    Regex regex = new Regex(":");
                    int n = 2;
                    List accountData = regex.split(charSequence, n);
                    if (!clipboardData.equals(":") || accountData.size() != 2) {
                        this.status = "\u00a7cInvalid clipboard data. (Use: E-Mail:Password)";
                        return;
                    }
                    this.checkAndAddAccount((String)accountData.get(0), (String)accountData.get(1));
                }
                catch (UnsupportedFlavorException e) {
                    this.status = "\u00a7cClipboard flavor unsupported!";
                    ClientUtils.getLogger().error("Failed to read data from clipboard.", (Throwable)e);
                }
                break;
            }
            case 3: {
                MicrosoftAccount.Companion.buildFromOpenBrowser$default((MicrosoftAccount.Companion)MicrosoftAccount.Companion, (MicrosoftAccount.OAuthHandler)new MicrosoftAccount.OAuthHandler(this){
                    final /* synthetic */ GuiDirectLogin this$0;
                    {
                        this.this$0 = $receiver;
                    }

                    public void authError(String error) {
                        Intrinsics.checkNotNullParameter((Object)error, (String)"error");
                        GuiDirectLogin.access$setStatus$p(this.this$0, Intrinsics.stringPlus((String)"\u00a7c", (Object)error));
                    }

                    public void authResult(MicrosoftAccount account) {
                        Intrinsics.checkNotNullParameter((Object)account, (String)"account");
                        if (Client.INSTANCE.getFileManager().accountsConfig.accountExists((MinecraftAccount)account)) {
                            GuiDirectLogin.access$setStatus$p(this.this$0, "\u00a7cThe account has already been added.");
                            return;
                        }
                        Client.INSTANCE.getFileManager().accountsConfig.addAccount((MinecraftAccount)account);
                        Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        GuiDirectLogin.access$setStatus$p(this.this$0, "\u00a7aThe account has been added.");
                        GuiDirectLogin.access$getPrevGui$p(this.this$0).setStatus(GuiDirectLogin.access$getStatus$p(this.this$0));
                        this.this$0.mc.displayGuiScreen((GuiScreen)GuiDirectLogin.access$getPrevGui$p(this.this$0));
                    }

                    public void openUrl(String url) {
                        Intrinsics.checkNotNullParameter((Object)url, (String)"url");
                        MiscUtils.showURL(url);
                    }
                }, null, (int)2, null);
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        GuiTextField guiTextField;
        switch (keyCode) {
            case 1: {
                this.mc.displayGuiScreen((GuiScreen)this.prevGui);
                return;
            }
            case 15: {
                GuiTextField guiTextField2;
                GuiTextField[] guiTextFieldArray = new GuiTextField[2];
                GuiTextField guiTextField3 = this.username;
                if (guiTextField3 == null) {
                    guiTextField3 = guiTextFieldArray[0] = null;
                }
                if ((guiTextField2 = this.password) == null) {
                    guiTextField2 = null;
                }
                guiTextFieldArray[1] = guiTextField2;
                TabUtils.tab(guiTextFieldArray);
                return;
            }
            case 28: {
                GuiButton guiButton = this.addButton;
                if (guiButton == null) {
                    guiButton = null;
                }
                this.actionPerformed(guiButton);
                return;
            }
        }
        GuiTextField guiTextField4 = this.username;
        if (guiTextField4 == null) {
            guiTextField4 = null;
        }
        if (guiTextField4.isFocused()) {
            GuiTextField guiTextField5 = this.username;
            if (guiTextField5 == null) {
                guiTextField5 = null;
            }
            guiTextField5.textboxKeyTyped(typedChar, keyCode);
        }
        if ((guiTextField = this.password) == null) {
            guiTextField = null;
        }
        if (guiTextField.isFocused()) {
            GuiTextField guiTextField6 = this.password;
            if (guiTextField6 == null) {
                guiTextField6 = null;
            }
            guiTextField6.textboxKeyTyped(typedChar, keyCode);
        }
        super.keyTyped(typedChar, keyCode);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.mouseClicked(mouseX, mouseY, mouseButton);
        GuiTextField guiTextField2 = this.password;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void updateScreen() {
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.updateCursorCounter();
        GuiTextField guiTextField2 = this.password;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.updateCursorCounter();
        super.updateScreen();
    }

    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    private final void checkAndAddAccount(String usernameText, String passwordText) {
        MinecraftAccount minecraftAccount;
        MinecraftAccount minecraftAccount2;
        if (((CharSequence)usernameText).length() == 0) {
            return;
        }
        if (((CharSequence)passwordText).length() == 0) {
            CrackedAccount crackedAccount = new CrackedAccount();
            crackedAccount.setName(usernameText);
            minecraftAccount2 = (MinecraftAccount)crackedAccount;
        } else {
            MojangAccount mojangAccount = new MojangAccount();
            mojangAccount.setEmail(usernameText);
            mojangAccount.setPassword(passwordText);
            minecraftAccount2 = minecraftAccount = (MinecraftAccount)mojangAccount;
        }
        if (Client.INSTANCE.getFileManager().accountsConfig.accountExists(minecraftAccount)) {
            this.status = "\u00a7cThe account has already been added.";
            return;
        }
        GuiButton guiButton = this.clipboardButton;
        if (guiButton == null) {
            guiButton = null;
        }
        guiButton.enabled = false;
        GuiButton guiButton2 = this.addButton;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        guiButton2.enabled = false;
        ThreadsKt.thread$default((boolean)false, (boolean)false, null, (String)"Account-Checking-Task", (int)0, (Function0)((Function0)new Function0<Unit>(minecraftAccount, this){
            final /* synthetic */ MinecraftAccount $minecraftAccount;
            final /* synthetic */ GuiDirectLogin this$0;
            {
                this.$minecraftAccount = $minecraftAccount;
                this.this$0 = $receiver;
                super(0);
            }

            public final void invoke() {
                try {
                    AltService.EnumAltService oldService = GuiAltManager.Companion.getAltService().getCurrentService();
                    if (oldService != AltService.EnumAltService.MOJANG) {
                        GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                    }
                    this.$minecraftAccount.update();
                }
                catch (Exception e) {
                    GuiDirectLogin.access$setStatus$p(this.this$0, Intrinsics.stringPlus((String)"\u00a7c", (Object)e.getMessage()));
                    GuiButton guiButton = GuiDirectLogin.access$getClipboardButton$p(this.this$0);
                    if (guiButton == null) {
                        guiButton = null;
                    }
                    guiButton.enabled = true;
                    GuiButton guiButton2 = GuiDirectLogin.access$getAddButton$p(this.this$0);
                    if (guiButton2 == null) {
                        guiButton2 = null;
                    }
                    guiButton2.enabled = true;
                    return;
                }
                if (this.this$0.getDirectLogin()) {
                    Minecraft.getMinecraft().session = new Session(this.$minecraftAccount.getSession().getUsername(), this.$minecraftAccount.getSession().getUuid(), this.$minecraftAccount.getSession().getToken(), "mojang");
                    Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)boolValue);
                    if (((Boolean)boolValue.get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    GuiDirectLogin.access$setStatus$p(this.this$0, "\u00a7aLogged successfully to " + this.this$0.mc.session.getUsername() + '.');
                } else {
                    Client.INSTANCE.getFileManager().accountsConfig.addAccount(this.$minecraftAccount);
                    Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                    Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)boolValue);
                    if (((Boolean)boolValue.get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    GuiDirectLogin.access$setStatus$p(this.this$0, "\u00a7aThe account has been added.");
                }
                GuiDirectLogin.access$getPrevGui$p(this.this$0).setStatus(GuiDirectLogin.access$getStatus$p(this.this$0));
                this.this$0.mc.displayGuiScreen((GuiScreen)GuiDirectLogin.access$getPrevGui$p(this.this$0));
            }
        }), (int)23, null);
    }

    public static final /* synthetic */ void access$setStatus$p(GuiDirectLogin $this, String string) {
        $this.status = string;
    }

    public static final /* synthetic */ GuiAltManager access$getPrevGui$p(GuiDirectLogin $this) {
        return $this.prevGui;
    }

    public static final /* synthetic */ String access$getStatus$p(GuiDirectLogin $this) {
        return $this.status;
    }

    public static final /* synthetic */ GuiButton access$getClipboardButton$p(GuiDirectLogin $this) {
        return $this.clipboardButton;
    }

    public static final /* synthetic */ GuiButton access$getAddButton$p(GuiDirectLogin $this) {
        return $this.addButton;
    }
}

