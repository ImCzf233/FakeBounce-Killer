/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.Agent
 *  com.mojang.authlib.exceptions.AuthenticationException
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication
 *  com.thealtening.AltService$EnumAltService
 *  com.thealtening.api.TheAltening
 *  com.thealtening.api.TheAltening$Asynchronous
 *  com.thealtening.api.data.AccountData
 *  kotlin.Unit
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Session
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.visual.client.altmanager.menus;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import com.thealtening.AltService;
import com.thealtening.api.TheAltening;
import com.thealtening.api.data.AccountData;
import java.net.Proxy;
import java.util.concurrent.CompletableFuture;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.misc.MiscUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.elements.GuiPasswordField;
import net.aspw.client.visual.font.Fonts;
import net.aspw.client.visual.font.GameFontRenderer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.lwjgl.input.Keyboard;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class GuiTheAltening
extends GuiScreen {
    public static final Companion Companion = new Companion(null);
    private final GuiAltManager prevGui;
    private GuiButton loginButton;
    private GuiButton generateButton;
    private GuiTextField apiKeyField;
    private GuiTextField tokenField;
    private String status;
    private static String apiKey = "";

    public GuiTheAltening(GuiAltManager prevGui) {
        Intrinsics.checkNotNullParameter((Object)((Object)prevGui), (String)"prevGui");
        this.prevGui = prevGui;
        this.status = "";
    }

    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        this.loginButton = new GuiButton(2, this.width / 2 - 100, 75, "Login");
        GuiButton guiButton = this.loginButton;
        if (guiButton == null) {
            guiButton = null;
        }
        this.buttonList.add(guiButton);
        this.generateButton = new GuiButton(1, this.width / 2 - 100, 140, "Generate");
        GuiButton guiButton2 = this.generateButton;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        this.buttonList.add(guiButton2);
        this.buttonList.add(new GuiButton(3, this.width / 2 - 100, this.height - 54, 98, 20, "Website"));
        this.buttonList.add(new GuiButton(0, this.width / 2 + 2, this.height - 54, 98, 20, "Done"));
        this.tokenField = new GuiTextField(666, (FontRenderer)Fonts.fontSFUI40, this.width / 2 - 100, 50, 200, 20);
        GuiTextField guiTextField = this.tokenField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.setFocused(true);
        GuiTextField guiTextField2 = this.tokenField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.setMaxStringLength(Integer.MAX_VALUE);
        GameFontRenderer gameFontRenderer = Fonts.fontSFUI40;
        Intrinsics.checkNotNullExpressionValue((Object)((Object)gameFontRenderer), (String)"fontSFUI40");
        this.apiKeyField = new GuiPasswordField(1337, gameFontRenderer, this.width / 2 - 100, 115, 200, 20);
        GuiTextField guiTextField3 = this.apiKeyField;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        guiTextField3.setMaxStringLength(18);
        GuiTextField guiTextField4 = this.apiKeyField;
        if (guiTextField4 == null) {
            guiTextField4 = null;
        }
        guiTextField4.setText(apiKey);
        super.initGui();
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/altmanager.png"), 0, 0, this.width, this.height);
        RenderUtils.drawRect(30.0f, 8.0f, (float)this.width - 30.0f, (float)this.height - 30.0f, Integer.MIN_VALUE);
        Fonts.fontLarge.drawCenteredString("The Altening", (float)this.width / 2.0f, 12.0f, 0xFFFFFF);
        Fonts.fontSFUI40.drawCenteredString(this.status, (float)this.width / 2.0f, 30.0f, 0xFFFFFF);
        GuiTextField guiTextField = this.apiKeyField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.drawTextBox();
        GuiTextField guiTextField2 = this.tokenField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.drawTextBox();
        Fonts.fontSFUI40.drawCenteredString("\u00a77Token:", (float)this.width / 2.0f - (float)84, 38.0f, 0xFFFFFF);
        Fonts.fontSFUI40.drawCenteredString("\u00a77API-Key:", (float)this.width / 2.0f - (float)78, 103.0f, 0xFFFFFF);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (!button.enabled) {
            return;
        }
        switch (button.id) {
            case 0: {
                this.mc.displayGuiScreen((GuiScreen)this.prevGui);
                break;
            }
            case 1: {
                GuiButton guiButton = this.loginButton;
                if (guiButton == null) {
                    guiButton = null;
                }
                guiButton.enabled = false;
                GuiButton guiButton2 = this.generateButton;
                if (guiButton2 == null) {
                    guiButton2 = null;
                }
                guiButton2.enabled = false;
                GuiTextField guiTextField = this.apiKeyField;
                if (guiTextField == null) {
                    guiTextField = null;
                }
                String string = guiTextField.getText();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"apiKeyField.text");
                apiKey = string;
                TheAltening altening = new TheAltening(apiKey);
                TheAltening.Asynchronous asynchronous = new TheAltening.Asynchronous(altening);
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                this.status = "\u00a7cGenerating account...";
                ((CompletableFuture)((CompletableFuture)asynchronous.getAccountData().thenAccept(arg_0 -> GuiTheAltening.actionPerformed$lambda-0(this, arg_0))).handle((arg_0, arg_1) -> GuiTheAltening.actionPerformed$lambda-1(this, arg_0, arg_1))).whenComplete((arg_0, arg_1) -> GuiTheAltening.actionPerformed$lambda-2(this, arg_0, arg_1));
                break;
            }
            case 2: {
                GuiButton guiButton = this.loginButton;
                if (guiButton == null) {
                    guiButton = null;
                }
                guiButton.enabled = false;
                GuiButton guiButton3 = this.generateButton;
                if (guiButton3 == null) {
                    guiButton3 = null;
                }
                guiButton3.enabled = false;
                new Thread(() -> GuiTheAltening.actionPerformed$lambda-3(this)).start();
                break;
            }
            case 3: {
                MiscUtils.showURL("https://thealtening.com");
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) {
        GuiTextField guiTextField;
        if (1 == keyCode) {
            this.mc.displayGuiScreen((GuiScreen)this.prevGui);
            return;
        }
        GuiTextField guiTextField2 = this.apiKeyField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        if (guiTextField2.isFocused()) {
            GuiTextField guiTextField3 = this.apiKeyField;
            if (guiTextField3 == null) {
                guiTextField3 = null;
            }
            guiTextField3.textboxKeyTyped(typedChar, keyCode);
        }
        if ((guiTextField = this.tokenField) == null) {
            guiTextField = null;
        }
        if (guiTextField.isFocused()) {
            GuiTextField guiTextField4 = this.tokenField;
            if (guiTextField4 == null) {
                guiTextField4 = null;
            }
            guiTextField4.textboxKeyTyped(typedChar, keyCode);
        }
        super.keyTyped(typedChar, keyCode);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        GuiTextField guiTextField = this.apiKeyField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.mouseClicked(mouseX, mouseY, mouseButton);
        GuiTextField guiTextField2 = this.tokenField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public void updateScreen() {
        GuiTextField guiTextField = this.apiKeyField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.updateCursorCounter();
        GuiTextField guiTextField2 = this.tokenField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.updateCursorCounter();
        super.updateScreen();
    }

    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
        GuiTextField guiTextField = this.apiKeyField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        String string = guiTextField.getText();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"apiKeyField.text");
        apiKey = string;
        super.onGuiClosed();
    }

    /*
     * WARNING - void declaration
     */
    private static final void actionPerformed$lambda-0(GuiTheAltening this$0, AccountData account) {
        GuiButton guiButton;
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
        Intrinsics.checkNotNull((Object)boolValue);
        if (((Boolean)boolValue.get()).booleanValue()) {
            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
        }
        this$0.status = Intrinsics.stringPlus((String)"\u00a7aGenerated account: \u00a7b\u00a7l", (Object)account.getUsername());
        try {
            String string;
            GuiTheAltening guiTheAltening;
            this$0.status = "\u00a7cSwitching Alt Service...";
            GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.THEALTENING);
            Hud hud2 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue2 = hud2 == null ? null : hud2.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue2);
            if (((Boolean)boolValue2.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            this$0.status = "\u00a7cLogging in...";
            YggdrasilUserAuthentication yggdrasilUserAuthentication = new YggdrasilUserAuthentication(new YggdrasilAuthenticationService(Proxy.NO_PROXY, ""), Agent.MINECRAFT);
            yggdrasilUserAuthentication.setUsername(account.getToken());
            yggdrasilUserAuthentication.setPassword("NightX");
            GuiTheAltening guiTheAltening2 = this$0;
            try {
                guiTheAltening = guiTheAltening2;
                yggdrasilUserAuthentication.logIn();
                this$0.mc.session = new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
                Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
                this$0.prevGui.setStatus("\u00a7aYour name is now \u00a7b\u00a7l" + yggdrasilUserAuthentication.getSelectedProfile().getName() + "\u00a7c.");
                this$0.mc.displayGuiScreen((GuiScreen)this$0.prevGui);
                string = "";
            }
            catch (AuthenticationException authenticationException) {
                void e;
                guiTheAltening = guiTheAltening2;
                GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                ClientUtils.getLogger().error("Failed to login.", (Throwable)e);
                string = Intrinsics.stringPlus((String)"\u00a7cFailed to login: ", (Object)e.getMessage());
            }
            guiTheAltening.status = string;
        }
        catch (Throwable throwable) {
            Hud hud3 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue3 = hud3 == null ? null : hud3.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue3);
            if (((Boolean)boolValue3.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            this$0.status = "\u00a7cFailed to login. Unknown error.";
            ClientUtils.getLogger().error("Failed to login.", throwable);
        }
        if ((guiButton = this$0.loginButton) == null) {
            guiButton = null;
        }
        guiButton.enabled = true;
        GuiButton guiButton2 = this$0.generateButton;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        guiButton2.enabled = true;
    }

    private static final Unit actionPerformed$lambda-1(GuiTheAltening this$0, Void $noName_0, Throwable err) {
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        this$0.status = "\u00a7cFailed to generate account.";
        ClientUtils.getLogger().error("Failed to generate account.", err);
        return Unit.INSTANCE;
    }

    private static final void actionPerformed$lambda-2(GuiTheAltening this$0, Unit $noName_0, Throwable $noName_1) {
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        GuiButton guiButton = this$0.loginButton;
        if (guiButton == null) {
            guiButton = null;
        }
        guiButton.enabled = true;
        GuiButton guiButton2 = this$0.generateButton;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        guiButton2.enabled = true;
    }

    /*
     * WARNING - void declaration
     */
    private static final void actionPerformed$lambda-3(GuiTheAltening this$0) {
        GuiButton guiButton;
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        try {
            String string;
            GuiTheAltening guiTheAltening;
            this$0.status = "\u00a7cSwitching Alt Service...";
            GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.THEALTENING);
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            this$0.status = "\u00a7cLogging in...";
            YggdrasilUserAuthentication yggdrasilUserAuthentication = new YggdrasilUserAuthentication(new YggdrasilAuthenticationService(Proxy.NO_PROXY, ""), Agent.MINECRAFT);
            GuiTextField guiTextField = this$0.tokenField;
            if (guiTextField == null) {
                guiTextField = null;
            }
            yggdrasilUserAuthentication.setUsername(guiTextField.getText());
            yggdrasilUserAuthentication.setPassword("NightX");
            GuiTheAltening guiTheAltening2 = this$0;
            try {
                guiTheAltening = guiTheAltening2;
                yggdrasilUserAuthentication.logIn();
                this$0.mc.session = new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
                Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
                this$0.prevGui.setStatus("\u00a7aYour name is now \u00a7b\u00a7l" + yggdrasilUserAuthentication.getSelectedProfile().getName() + "\u00a7c.");
                this$0.mc.displayGuiScreen((GuiScreen)this$0.prevGui);
                string = "\u00a7aYour name is now \u00a7b\u00a7l" + yggdrasilUserAuthentication.getSelectedProfile().getName() + "\u00a7c.";
            }
            catch (AuthenticationException authenticationException) {
                void e;
                guiTheAltening = guiTheAltening2;
                GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                ClientUtils.getLogger().error("Failed to login.", (Throwable)e);
                string = Intrinsics.stringPlus((String)"\u00a7cFailed to login: ", (Object)e.getMessage());
            }
            guiTheAltening.status = string;
        }
        catch (Throwable throwable) {
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            ClientUtils.getLogger().error("Failed to login.", throwable);
            this$0.status = "\u00a7cFailed to login. Unknown error.";
        }
        if ((guiButton = this$0.loginButton) == null) {
            guiButton = null;
        }
        guiButton.enabled = true;
        GuiButton guiButton2 = this$0.generateButton;
        if (guiButton2 == null) {
            guiButton2 = null;
        }
        guiButton2.enabled = true;
    }

    public static final class Companion {
        private Companion() {
        }

        public final String getApiKey() {
            return apiKey;
        }

        public final void setApiKey(String string) {
            Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
            apiKey = string;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

