/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package net.aspw.client.visual.client.clickgui.tab.value;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.Value;
import org.jetbrains.annotations.NotNull;

public abstract class ValueElement<T>
extends MinecraftInstance {
    private final Value<T> value;
    private float valueHeight;

    public ValueElement(Value<T> value) {
        Intrinsics.checkNotNullParameter(value, (String)"value");
        this.value = value;
        this.valueHeight = 20.0f;
    }

    public final Value<T> getValue() {
        return this.value;
    }

    public final float getValueHeight() {
        return this.valueHeight;
    }

    public final void setValueHeight(float f) {
        this.valueHeight = f;
    }

    public abstract float drawElement(int var1, int var2, float var3, float var4, float var5, @NotNull Color var6, @NotNull Color var7);

    public abstract void onClick(int var1, int var2, float var3, float var4, float var5);

    public void onRelease(int mouseX, int mouseY, float x, float y, float width) {
    }

    public boolean onKeyPress(char typed, int keyCode) {
        return false;
    }

    public final boolean isDisplayable() {
        return (Boolean)this.value.getCanDisplay().invoke();
    }
}

