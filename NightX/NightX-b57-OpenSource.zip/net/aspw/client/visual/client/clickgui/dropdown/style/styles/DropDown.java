/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.MathHelper
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.visual.client.clickgui.dropdown.style.styles;

import java.awt.Color;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BlockValue;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.FontValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.value.Value;
import net.aspw.client.visual.client.clickgui.dropdown.ClickGui;
import net.aspw.client.visual.client.clickgui.dropdown.Panel;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ButtonElement;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ModuleElement;
import net.aspw.client.visual.client.clickgui.dropdown.style.Style;
import net.aspw.client.visual.font.Fonts;
import net.aspw.client.visual.font.GameFontRenderer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Mouse;

public final class DropDown
extends Style {
    private boolean mouseDown;
    private boolean rightMouseDown;

    private final Color getCategoryColor(String categoryName) {
        String categoryName2 = categoryName;
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = categoryName2.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
        categoryName2 = string;
        if (categoryName2.equals("combat")) {
            return new Color(231, 75, 58, 255);
        }
        if (categoryName2.equals("player")) {
            return new Color(142, 69, 174, 255);
        }
        if (categoryName2.equals("movement")) {
            return new Color(46, 205, 111, 255);
        }
        if (categoryName2.equals("visual")) {
            return new Color(76, 143, 200, 255);
        }
        if (categoryName2.equals("exploit")) {
            return new Color(233, 215, 100, 255);
        }
        if (categoryName2.equals("targets")) {
            return new Color(251, 219, 94, 255);
        }
        return categoryName2.equals("other") ? new Color(244, 157, 19, 255) : Gui.Companion.generateColor();
    }

    @Override
    public void drawPanel(int mouseX, int mouseY, Panel panel) {
        Intrinsics.checkNotNullParameter((Object)panel, (String)"panel");
        float f = (float)panel.getX() - (float)3;
        float f2 = (float)panel.getY() - 1.0f;
        float f3 = (float)panel.getX() + (float)panel.getWidth() + (float)3;
        float f4 = panel.getY() + 22 + panel.getFade();
        String string = panel.getName();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"panel.name");
        RenderUtils.drawRect(f, f2, f3, f4, this.getCategoryColor(string).getRGB());
        RenderUtils.drawRect((float)(panel.getX() - 2), (float)panel.getY(), (float)(panel.getX() + panel.getWidth() + 2), (float)(panel.getY() + 21 + panel.getFade()), new Color(17, 17, 17).getRGB());
        RenderUtils.drawRect((float)panel.getX() + 1.0f, (float)panel.getY() + (float)19, (float)panel.getX() + (float)panel.getWidth() - 1.0f, (float)(panel.getY() + 18 + panel.getFade()), new Color(26, 26, 26).getRGB());
        GlStateManager.resetColor();
        string = panel.getName();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"panel.name");
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        Fonts.fontSFUI37.drawStringWithShadow(Intrinsics.stringPlus((String)"\u00a7l", (Object)string2), panel.getX() + 2, panel.getY() + 6, new Color(255, 255, 255, 255).getRGB());
        if (StringsKt.equals((String)panel.getName(), (String)"combat", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("J", panel.getX() + 38, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"movement", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("G", panel.getX() + 52, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"player", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("F", panel.getX() + 34, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"exploit", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("A", panel.getX() + 38, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"other", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("B", panel.getX() + 31, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"visual", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("H", panel.getX() + 33, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
        if (StringsKt.equals((String)panel.getName(), (String)"targets", (boolean)true)) {
            Fonts.icons.drawStringWithShadow("I", panel.getX() + 37, panel.getY() + 4, new Color(255, 255, 255, 255).getRGB());
        }
    }

    @Override
    public void drawButtonElement(int mouseX, int mouseY, ButtonElement buttonElement) {
        Intrinsics.checkNotNullParameter((Object)buttonElement, (String)"buttonElement");
        ClickGui.func_73734_a((int)(buttonElement.getX() - 1), (int)(buttonElement.getY() + 1), (int)(buttonElement.getX() + buttonElement.getWidth() + 1), (int)(buttonElement.getY() + buttonElement.getHeight() + 2), (int)this.hoverColor(buttonElement.getColor() != Integer.MAX_VALUE ? Gui.Companion.generateColor() : new Color(26, 26, 26), buttonElement.hoverTime).getRGB());
        GlStateManager.resetColor();
        String string = buttonElement.getDisplayName();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"buttonElement.displayName");
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        Fonts.fontSFUI37.drawString(string2, buttonElement.getX() + 3, buttonElement.getY() + 6, Color.WHITE.getRGB());
    }

    @Override
    public void drawModuleElement(int mouseX, int mouseY, ModuleElement moduleElement) {
        Intrinsics.checkNotNullParameter((Object)moduleElement, (String)"moduleElement");
        ClickGui.func_73734_a((int)(moduleElement.getX() + 1), (int)(moduleElement.getY() + 1), (int)(moduleElement.getX() + moduleElement.getWidth() - 1), (int)(moduleElement.getY() + moduleElement.getHeight() + 2), (int)this.hoverColor(new Color(26, 26, 26), moduleElement.hoverTime).getRGB());
        ClickGui.func_73734_a((int)(moduleElement.getX() + 1), (int)(moduleElement.getY() + 1), (int)(moduleElement.getX() + moduleElement.getWidth() - 1), (int)(moduleElement.getY() + moduleElement.getHeight() + 2), (int)this.hoverColor(new Color(this.getCategoryColor(moduleElement.getModule().getCategory().name()).getRed(), this.getCategoryColor(moduleElement.getModule().getCategory().name()).getGreen(), this.getCategoryColor(moduleElement.getModule().getCategory().name()).getBlue(), moduleElement.slowlyFade), moduleElement.hoverTime).getRGB());
        int guiColor = Gui.Companion.generateColor().getRGB();
        GlStateManager.resetColor();
        String string = moduleElement.getDisplayName();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"moduleElement.displayName");
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        Fonts.fontSFUI37.drawString(string2, moduleElement.getX() + 3, moduleElement.getY() + 7, new Color(200, 200, 200, 255).getRGB());
        List<Value<?>> moduleValues = moduleElement.getModule().getValues();
        if (!moduleValues.isEmpty()) {
            if (moduleElement.isShowSettings()) {
                Fonts.font72.drawString("-", moduleElement.getX() + moduleElement.getWidth() - 9, moduleElement.getY() + moduleElement.getHeight() / 10, new Color(124, 252, 0, 255).getRGB());
                int yPos = 2;
                for (Value value : moduleValues) {
                    float textWidth;
                    String text;
                    if (!((Boolean)value.getCanDisplay().invoke()).booleanValue()) continue;
                    if (value instanceof BoolValue) {
                        text = value.getName();
                        textWidth = Fonts.fontSFUI37.getStringWidth(text);
                        if (moduleElement.getSettingsWidth() < textWidth + (float)8) {
                            moduleElement.setSettingsWidth(textWidth + (float)8);
                        }
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 14), new Color(26, 26, 26).getRGB());
                        if (mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() && mouseY >= yPos + 2 && mouseY <= yPos + 14 && Mouse.isButtonDown((int)0) && moduleElement.isntPressed()) {
                            Value boolValue = value;
                            ((BoolValue)boolValue).set((Boolean)((BoolValue)boolValue).get() == false);
                        }
                        GlStateManager.resetColor();
                        Fonts.fontSFUI37.drawString(text, moduleElement.getWidth() + 6, yPos + 4, (Boolean)((BoolValue)value).get() != false ? guiColor : Integer.MAX_VALUE);
                        yPos += 12;
                        continue;
                    }
                    if (value instanceof ListValue) {
                        Value listValue = value;
                        String text2 = value.getName();
                        float textWidth2 = Fonts.fontSFUI37.getStringWidth(text2);
                        if (moduleElement.getSettingsWidth() < textWidth2 + (float)16) {
                            moduleElement.setSettingsWidth(textWidth2 + (float)16);
                        }
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 14), new Color(26, 26, 26).getRGB());
                        GlStateManager.resetColor();
                        Fonts.fontSFUI37.drawString(Intrinsics.stringPlus((String)"\u00a7c", (Object)text2), moduleElement.getWidth() + 6, yPos + 4, 0xFFFFFF);
                        Fonts.fontSFUI37.drawString(((ListValue)listValue).openList ? "-" : "+", (int)((float)moduleElement.getWidth() + moduleElement.getSettingsWidth() - (float)(((ListValue)listValue).openList ? 5 : 6)), yPos + 4, 0xFFFFFF);
                        if (mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() && mouseY >= yPos + 2 && mouseY <= yPos + 14 && Mouse.isButtonDown((int)0) && moduleElement.isntPressed()) {
                            ((ListValue)listValue).openList = !((ListValue)listValue).openList;
                        }
                        yPos += 12;
                        String[] stringArray = ((ListValue)listValue).getValues();
                        int n = 0;
                        int n2 = stringArray.length;
                        while (n < n2) {
                            String valueOfList = stringArray[n];
                            ++n;
                            float textWidth22 = Fonts.fontSFUI37.getStringWidth(Intrinsics.stringPlus((String)">", (Object)valueOfList));
                            if (moduleElement.getSettingsWidth() < textWidth22 + (float)12) {
                                moduleElement.setSettingsWidth(textWidth22 + (float)12);
                            }
                            if (!((ListValue)listValue).openList) continue;
                            RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 14), new Color(26, 26, 26).getRGB());
                            if (mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() && mouseY >= yPos + 2 && mouseY <= yPos + 14 && Mouse.isButtonDown((int)0) && moduleElement.isntPressed()) {
                                ((ListValue)listValue).set(valueOfList);
                            }
                            GlStateManager.resetColor();
                            Fonts.fontSFUI37.drawString(">", moduleElement.getWidth() + 6, yPos + 4, Integer.MAX_VALUE);
                            Locale locale2 = Locale.getDefault();
                            Intrinsics.checkNotNullExpressionValue((Object)locale2, (String)"getDefault()");
                            String string3 = valueOfList.toUpperCase(locale2);
                            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toUpperCase(locale)");
                            Fonts.fontSFUI37.drawString(string3, moduleElement.getWidth() + 14, yPos + 4, ((ListValue)listValue).get() != null && StringsKt.equals((String)((String)((ListValue)listValue).get()), (String)valueOfList, (boolean)true) ? guiColor : Integer.MAX_VALUE);
                            yPos += 12;
                        }
                        continue;
                    }
                    if (value instanceof FloatValue) {
                        Value floatValue = value;
                        String text3 = value.getName() + "\u00a7f: \u00a7c" + this.round(((Number)((FloatValue)floatValue).get()).floatValue());
                        float textWidth3 = Fonts.fontSFUI37.getStringWidth(text3);
                        if (moduleElement.getSettingsWidth() < textWidth3 + (float)8) {
                            moduleElement.setSettingsWidth(textWidth3 + (float)8);
                        }
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 24), new Color(26, 26, 26).getRGB());
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 8), (float)(yPos + 18), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() - (float)4, (float)(yPos + 19), Integer.MAX_VALUE);
                        float sliderValue = (float)moduleElement.getWidth() + (moduleElement.getSettingsWidth() - (float)12) * (((Number)((FloatValue)floatValue).get()).floatValue() - ((FloatValue)floatValue).getMinimum()) / (((FloatValue)floatValue).getMaximum() - ((FloatValue)floatValue).getMinimum());
                        RenderUtils.drawRect((float)8 + sliderValue, (float)(yPos + 15), sliderValue + (float)11, (float)(yPos + 21), guiColor);
                        if (mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() - (float)4 && mouseY >= yPos + 15 && mouseY <= yPos + 21 && Mouse.isButtonDown((int)0)) {
                            double i = MathHelper.clamp_double((double)((float)(mouseX - moduleElement.getWidth() - 8) / (moduleElement.getSettingsWidth() - (float)12)), (double)0.0, (double)1.0);
                            ((FloatValue)floatValue).set(Float.valueOf(this.round((float)((double)((FloatValue)floatValue).getMinimum() + (double)(((FloatValue)floatValue).getMaximum() - ((FloatValue)floatValue).getMinimum()) * i)).floatValue()));
                        }
                        GlStateManager.resetColor();
                        Fonts.fontSFUI37.drawString(text3, moduleElement.getWidth() + 6, yPos + 4, 0xFFFFFF);
                        yPos += 22;
                        continue;
                    }
                    if (value instanceof IntegerValue) {
                        Value integerValue = value;
                        String text4 = value.getName() + "\u00a7f: \u00a7c" + (value instanceof BlockValue ? BlockUtils.getBlockName(((Number)((IntegerValue)integerValue).get()).intValue()) + " (" + ((Number)((IntegerValue)integerValue).get()).intValue() + ')' : ((IntegerValue)integerValue).get());
                        float textWidth4 = Fonts.fontSFUI37.getStringWidth(text4);
                        if (moduleElement.getSettingsWidth() < textWidth4 + (float)8) {
                            moduleElement.setSettingsWidth(textWidth4 + (float)8);
                        }
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 24), new Color(26, 26, 26).getRGB());
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 8), (float)(yPos + 18), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() - (float)4, (float)(yPos + 19), Integer.MAX_VALUE);
                        float sliderValue = (float)moduleElement.getWidth() + (moduleElement.getSettingsWidth() - (float)12) * (float)(((Number)((IntegerValue)integerValue).get()).intValue() - ((IntegerValue)integerValue).getMinimum()) / (float)(((IntegerValue)integerValue).getMaximum() - ((IntegerValue)integerValue).getMinimum());
                        RenderUtils.drawRect((float)8 + sliderValue, (float)(yPos + 15), sliderValue + (float)11, (float)(yPos + 21), guiColor);
                        if (mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() && mouseY >= yPos + 15 && mouseY <= yPos + 21 && Mouse.isButtonDown((int)0)) {
                            double i = MathHelper.clamp_double((double)((float)(mouseX - moduleElement.getWidth() - 8) / (moduleElement.getSettingsWidth() - (float)12)), (double)0.0, (double)1.0);
                            ((IntegerValue)integerValue).set((int)((double)((IntegerValue)integerValue).getMinimum() + (double)(((IntegerValue)integerValue).getMaximum() - ((IntegerValue)integerValue).getMinimum()) * i));
                        }
                        GlStateManager.resetColor();
                        Fonts.fontSFUI37.drawString(text4, moduleElement.getWidth() + 6, yPos + 4, 0xFFFFFF);
                        yPos += 22;
                        continue;
                    }
                    if (value instanceof FontValue) {
                        Value fontValue = value;
                        FontRenderer fontRenderer = (FontRenderer)((FontValue)fontValue).get();
                        RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 14), new Color(26, 26, 26).getRGB());
                        String displayString = "Font: Unknown";
                        if (fontRenderer instanceof GameFontRenderer) {
                            FontRenderer liquidFontRenderer = fontRenderer;
                            displayString = "Font: " + ((GameFontRenderer)liquidFontRenderer).getDefaultFont().getFont().getName() + " - " + ((GameFontRenderer)liquidFontRenderer).getDefaultFont().getFont().getSize();
                        } else if (fontRenderer == Fonts.minecraftFont) {
                            displayString = "Font: Minecraft";
                        } else {
                            Object[] objects = Fonts.getFontDetails(fontRenderer);
                            if (objects != null) {
                                Object object = objects[1];
                                if (object == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Int");
                                }
                                displayString = objects[0] + ((Integer)object != -1 ? Intrinsics.stringPlus((String)" - ", (Object)objects[1]) : "");
                            }
                        }
                        Fonts.fontSFUI37.drawString(displayString, moduleElement.getWidth() + 6, yPos + 4, Color.WHITE.getRGB());
                        int stringWidth = Fonts.fontSFUI37.getStringWidth(displayString);
                        if (moduleElement.getSettingsWidth() < (float)(stringWidth + 8)) {
                            moduleElement.setSettingsWidth(stringWidth + 8);
                        }
                        if ((Mouse.isButtonDown((int)0) && !this.mouseDown || Mouse.isButtonDown((int)1) && !this.rightMouseDown) && mouseX >= moduleElement.getWidth() + 4 && (float)mouseX <= (float)moduleElement.getWidth() + moduleElement.getSettingsWidth() && mouseY >= yPos + 4 && mouseY <= yPos + 12) {
                            FontRenderer font;
                            int i;
                            List<FontRenderer> fonts = Fonts.getFonts();
                            if (Mouse.isButtonDown((int)0)) {
                                i = 0;
                                while (i < fonts.size()) {
                                    font = fonts.get(i);
                                    if (font == fontRenderer) {
                                        int n = i;
                                        if ((i = n + 1) >= fonts.size()) {
                                            i = 0;
                                        }
                                        FontValue fontValue2 = (FontValue)fontValue;
                                        FontRenderer fontRenderer2 = fonts.get(i);
                                        Intrinsics.checkNotNullExpressionValue((Object)fontRenderer2, (String)"fonts[i]");
                                        fontValue2.set(fontRenderer2);
                                        break;
                                    }
                                    int n = i;
                                    i = n + 1;
                                }
                            } else {
                                i = fonts.size() - 1;
                                while (i >= 0) {
                                    font = fonts.get(i);
                                    if (font == fontRenderer) {
                                        int n = i;
                                        if ((i = n + -1) >= fonts.size()) {
                                            i = 0;
                                        }
                                        if (i < 0) {
                                            i = fonts.size() - 1;
                                        }
                                        FontValue fontValue3 = (FontValue)fontValue;
                                        FontRenderer fontRenderer3 = fonts.get(i);
                                        Intrinsics.checkNotNullExpressionValue((Object)fontRenderer3, (String)"fonts[i]");
                                        fontValue3.set(fontRenderer3);
                                        break;
                                    }
                                    int n = i;
                                    i = n + -1;
                                }
                            }
                        }
                        yPos += 11;
                        continue;
                    }
                    text = value.getName() + "\u00a7f: \u00a7c" + value.get();
                    textWidth = Fonts.fontSFUI37.getStringWidth(text);
                    if (moduleElement.getSettingsWidth() < textWidth + (float)8) {
                        moduleElement.setSettingsWidth(textWidth + (float)8);
                    }
                    RenderUtils.drawRect((float)(moduleElement.getWidth() + 4), (float)(yPos + 2), (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), (float)(yPos + 14), new Color(26, 26, 26).getRGB());
                    GlStateManager.resetColor();
                    Fonts.fontSFUI37.drawString(text, moduleElement.getWidth() + 6, yPos + 4, 0xFFFFFF);
                    yPos += 12;
                }
                moduleElement.updatePressed();
                this.mouseDown = Mouse.isButtonDown((int)0);
                this.rightMouseDown = Mouse.isButtonDown((int)1);
                if (moduleElement.getSettingsWidth() > 0.0f && yPos > moduleElement.getY() + 4) {
                    RenderUtils.drawBorderedRect(moduleElement.getWidth() + 4, moduleElement.getY() + 6, (float)moduleElement.getWidth() + moduleElement.getSettingsWidth(), yPos + 2, 1.0f, new Color(26, 26, 26).getRGB(), 0);
                }
            } else {
                Fonts.font72.drawString("+", moduleElement.getX() + moduleElement.getWidth() - 10, moduleElement.getY() + moduleElement.getHeight() / 10, new Color(160, 160, 160, 120).getRGB());
            }
        }
    }

    private final BigDecimal round(float f) {
        BigDecimal bd = new BigDecimal(Float.toString(f));
        BigDecimal bigDecimal = bd.setScale(2, 4);
        Intrinsics.checkNotNullExpressionValue((Object)bigDecimal, (String)"bd.setScale(2, 4)");
        bd = bigDecimal;
        return bd;
    }

    private final Color hoverColor(Color color, int hover) {
        int r = color.getRed() - hover * 2;
        int g = color.getGreen() - hover * 2;
        int b = color.getBlue() - hover * 2;
        return new Color(Math.max(r, 0), Math.max(g, 0), Math.max(b, 0), color.getAlpha());
    }
}

