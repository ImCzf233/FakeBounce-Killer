/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiTextField
 */
package net.aspw.client.visual.client.clickgui.tab.elements;

import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;

public final class SearchBox
extends GuiTextField {
    public SearchBox(int componentId, int x, int y, int width, int height) {
        super(componentId, (FontRenderer)Fonts.fontSFUI40, x, y, width, height);
    }

    public boolean getEnableBackgroundDrawing() {
        return false;
    }
}

