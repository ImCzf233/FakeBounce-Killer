/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.ranges.RangesKt
 */
package net.aspw.client.visual.client.clickgui.tab.extensions;

import kotlin.ranges.RangesKt;
import net.aspw.client.features.api.GuiFastRender;
import net.aspw.client.util.AnimationUtils;
import net.aspw.client.util.render.RenderUtils;

public final class AnimHelperKt {
    public static final float animSmooth(float $this$animSmooth, float target, float speed2) {
        return (Boolean)GuiFastRender.fixValue.get() != false ? target : AnimationUtils.animate(target, $this$animSmooth, speed2 * (float)RenderUtils.deltaTime * 0.025f);
    }

    public static final float animLinear(float $this$animLinear, float speed2, float min, float max) {
        return ((Boolean)GuiFastRender.fixValue.get()).booleanValue() ? (speed2 < 0.0f ? min : max) : RangesKt.coerceIn((float)($this$animLinear + speed2), (float)min, (float)max);
    }
}

