/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.visual.client.clickgui.dropdown.style;

import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.visual.client.clickgui.dropdown.Panel;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ButtonElement;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ModuleElement;

public abstract class Style
extends MinecraftInstance {
    public abstract void drawPanel(int var1, int var2, Panel var3);

    public abstract void drawButtonElement(int var1, int var2, ButtonElement var3);

    public abstract void drawModuleElement(int var1, int var2, ModuleElement var3);
}

