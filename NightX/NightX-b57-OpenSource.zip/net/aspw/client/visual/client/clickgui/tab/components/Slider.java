/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.visual.client.clickgui.tab.components;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;

public final class Slider {
    private float smooth;
    private float value;

    public final void onDraw(float x, float y, float width, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        this.smooth = AnimHelperKt.animSmooth(this.smooth, this.value, 0.5f);
        RenderUtils.originalRoundedRect(x - 1.0f, y - 1.0f, x + width + 1.0f, y + 1.0f, 1.0f, ColorManager.INSTANCE.getUnusedSlider().getRGB());
        RenderUtils.originalRoundedRect(x - 1.0f, y - 1.0f, x + width * (this.smooth / 100.0f) + 1.0f, y + 1.0f, 1.0f, accentColor.getRGB());
        RenderUtils.drawFilledCircle(x + width * (this.smooth / 100.0f), y, 5.0f, Color.white);
        RenderUtils.drawFilledCircle(x + width * (this.smooth / 100.0f), y, 3.0f, ColorManager.INSTANCE.getBackground());
    }

    public final void setValue(float desired, float min, float max) {
        this.value = (desired - min) / (max - min) * 100.0f;
    }
}

