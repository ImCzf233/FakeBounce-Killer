/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client.clickgui.tab.value.impl;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;
import net.aspw.client.visual.client.clickgui.tab.value.ValueElement;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public final class ListElement
extends ValueElement<String> {
    public static final Companion Companion = new Companion(null);
    private final ListValue saveValue;
    private float expandHeight;
    private boolean expansion;
    private final float maxSubWidth;
    private static final ResourceLocation expanding = new ResourceLocation("client/clickgui/expand.png");

    /*
     * WARNING - void declaration
     */
    public ListElement(ListValue saveValue) {
        void $this$mapTo$iv$iv;
        void $this$map$iv;
        Intrinsics.checkNotNullParameter((Object)saveValue, (String)"saveValue");
        super(saveValue);
        this.saveValue = saveValue;
        String[] stringArray = this.saveValue.getValues();
        ListElement listElement = this;
        boolean $i$f$map = false;
        void var4_5 = $this$map$iv;
        Collection destination$iv$iv = new ArrayList(((void)$this$map$iv).length);
        boolean $i$f$mapTo = false;
        for (void item$iv$iv : $this$mapTo$iv$iv) {
            void it;
            void var11_12 = item$iv$iv;
            Collection collection = destination$iv$iv;
            boolean bl = false;
            collection.add(-Fonts.fontSFUI40.getStringWidth((String)it));
        }
        Number number = (Integer)CollectionsKt.firstOrNull((List)CollectionsKt.sorted((Iterable)((List)destination$iv$iv)));
        if (number == null) {
            number = Float.valueOf(0.0f);
        }
        listElement.maxSubWidth = -((Number)number).floatValue() + 20.0f;
    }

    public final ListValue getSaveValue() {
        return this.saveValue;
    }

    @Override
    public float drawElement(int mouseX, int mouseY, float x, float y, float width, Color bgColor, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)bgColor, (String)"bgColor");
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        this.expandHeight = AnimHelperKt.animSmooth(this.expandHeight, this.expansion ? 16.0f * ((float)this.saveValue.getValues().length - 1.0f) : 0.0f, 0.5f);
        float percent = this.expandHeight / (16.0f * ((float)this.saveValue.getValues().length - 1.0f));
        Fonts.fontSFUI40.drawString(this.getValue().getName(), x + 10.0f, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        RenderUtils.originalRoundedRect(x + width - 18.0f - this.maxSubWidth, y + 2.0f, x + width - 10.0f, y + 18.0f + this.expandHeight, 4.0f, ColorManager.INSTANCE.getButton().getRGB());
        GlStateManager.resetColor();
        GL11.glPushMatrix();
        GL11.glTranslatef((float)(x + width - 20.0f), (float)(y + 10.0f), (float)0.0f);
        GL11.glPushMatrix();
        GL11.glRotatef((float)(180.0f * percent), (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderUtils.drawImage(expanding, -4, -4, 8, 8);
        GL11.glPopMatrix();
        GL11.glPopMatrix();
        Fonts.fontSFUI40.drawString((String)this.getValue().get(), x + width - 14.0f - this.maxSubWidth, y + 6.0f, -1);
        GL11.glPushMatrix();
        GlStateManager.translate((float)(x + width - 14.0f - this.maxSubWidth), (float)(y + 7.0f), (float)0.0f);
        GlStateManager.scale((float)percent, (float)percent, (float)percent);
        float vertHeight = 0.0f;
        if (percent > 0.0f) {
            for (String subV : this.getUnusedValues()) {
                Fonts.fontSFUI40.drawString(subV, 0.0f, (16.0f + vertHeight) * percent - 1.0f, new Color(0.5f, 0.5f, 0.5f, RangesKt.coerceIn((float)percent, (float)0.0f, (float)1.0f)).getRGB());
                vertHeight += 16.0f;
            }
        }
        GL11.glPopMatrix();
        this.setValueHeight(20.0f + this.expandHeight);
        return this.getValueHeight();
    }

    @Override
    public void onClick(int mouseX, int mouseY, float x, float y, float width) {
        if (this.isDisplayable() && MouseUtils.mouseWithinBounds(mouseX, mouseY, x, y + 2.0f, x + width, y + 18.0f)) {
            boolean bl = this.expansion = !this.expansion;
        }
        if (this.expansion) {
            float vertHeight = 0.0f;
            for (String subV : this.getUnusedValues()) {
                if (MouseUtils.mouseWithinBounds(mouseX, mouseY, x + width - 14.0f - this.maxSubWidth, y + 18.0f + vertHeight, x + width - 10.0f, y + 34.0f + vertHeight)) {
                    this.getValue().set(subV);
                    this.expansion = false;
                    break;
                }
                vertHeight += 16.0f;
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    public final List<String> getUnusedValues() {
        void $this$filterTo$iv$iv;
        String[] $this$filter$iv = this.saveValue.getValues();
        boolean $i$f$filter = false;
        String[] stringArray = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (void element$iv$iv : $this$filterTo$iv$iv) {
            void it = element$iv$iv;
            boolean bl = false;
            if (!(!it.equals(this.getValue().get()))) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        return (List)destination$iv$iv;
    }

    public static final class Companion {
        private Companion() {
        }

        public final ResourceLocation getExpanding() {
            return expanding;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

