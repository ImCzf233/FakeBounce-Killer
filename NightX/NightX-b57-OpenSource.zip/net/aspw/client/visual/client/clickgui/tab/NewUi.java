/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.MathHelper
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.visual.client.clickgui.tab;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.aspw.client.features.api.GuiFastRender;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.util.AnimationUtils;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.render.Stencil;
import net.aspw.client.visual.client.clickgui.tab.IconManager;
import net.aspw.client.visual.client.clickgui.tab.elements.CategoryElement;
import net.aspw.client.visual.client.clickgui.tab.elements.ModuleElement;
import net.aspw.client.visual.client.clickgui.tab.elements.SearchElement;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class NewUi
extends GuiScreen {
    private static NewUi instance;
    public final List<CategoryElement> categoryElements = new ArrayList<CategoryElement>();
    private float startYAnim = (float)this.height / 2.0f;
    private float endYAnim = (float)this.height / 2.0f;
    private float fading = 0.0f;
    private SearchElement searchElement;

    private NewUi() {
        for (ModuleCategory c : ModuleCategory.values()) {
            this.categoryElements.add(new CategoryElement(c));
        }
        this.categoryElements.get(0).setFocused(true);
    }

    public static final NewUi getInstance() {
        return instance == null ? (instance = new NewUi()) : instance;
    }

    public static void resetInstance() {
        instance = new NewUi();
    }

    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        for (CategoryElement ce : this.categoryElements) {
            for (ModuleElement me : ce.getModuleElements()) {
                if (!me.listeningKeybind()) continue;
                me.resetState();
            }
        }
        this.searchElement = new SearchElement(36.0f, 38.0f, 190.0f, 20.0f);
        super.initGui();
    }

    public void onGuiClosed() {
        for (CategoryElement ce : this.categoryElements) {
            if (!ce.getFocused()) continue;
            ce.handleMouseRelease(-1, -1, 0, 0.0f, 0.0f, 0.0f, 0.0f);
        }
        Keyboard.enableRepeatEvents((boolean)false);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drawFullSized(mouseX, mouseY, partialTicks, Gui.generateColor());
    }

    private void drawFullSized(int mouseX, int mouseY, float partialTicks, Color accentColor) {
        RenderUtils.drawGradientRect(0, 0, this.width, this.height, -1072689136, -804253680);
        RenderUtils.drawRoundedRect(31.0f, 31.0f, (float)this.width - 31.0f, (float)this.height - 31.0f, 8.0f, new Color(5, 5, 5, 170).getRGB());
        this.fading = MouseUtils.mouseWithinBounds(mouseX, mouseY, (float)this.width - 54.0f, 30.0f, (float)this.width - 30.0f, 50.0f) ? (this.fading += 0.2f * (float)RenderUtils.deltaTime * 0.045f) : (this.fading -= 0.2f * (float)RenderUtils.deltaTime * 0.045f);
        this.fading = MathHelper.clamp_float((float)this.fading, (float)0.0f, (float)2.0f);
        GlStateManager.disableAlpha();
        RenderUtils.drawImage(IconManager.removeIcon, this.width - 49, 34, 16, 16);
        GlStateManager.enableAlpha();
        Stencil.write(true);
        Stencil.erase(true);
        Stencil.dispose();
        if (this.searchElement.isTyping()) {
            Fonts.fontSFUI40.drawStringWithShadow("Search", 242.0f, (float)Fonts.fontSFUI35.FONT_HEIGHT + 30.0f, -1);
        } else {
            Fonts.fontSFUI40.drawStringWithShadow("Modules", 242.0f, (float)Fonts.fontSFUI35.FONT_HEIGHT + 30.0f, -1);
        }
        if (this.searchElement.drawBox(mouseX, mouseY, accentColor)) {
            this.searchElement.drawPanel(mouseX, mouseY, 230.0f, 50.0f, this.width - 260, this.height - 80, Mouse.getDWheel(), this.categoryElements, accentColor);
            return;
        }
        float elementHeight = 24.0f;
        float startY = 60.0f;
        for (CategoryElement ce : this.categoryElements) {
            ce.drawLabel(mouseX, mouseY, 30.0f, startY, 200.0f, 24.0f);
            if (ce.getFocused()) {
                float f = (Boolean)GuiFastRender.fixValue.get() != false ? startY + 6.0f : (this.startYAnim = AnimationUtils.animate(startY + 6.0f, this.startYAnim, (this.startYAnim - (startY + 5.0f) > 0.0f ? 0.65f : 0.55f) * (float)RenderUtils.deltaTime * 0.025f));
                this.endYAnim = (Boolean)GuiFastRender.fixValue.get() != false ? startY + 24.0f - 6.0f : AnimationUtils.animate(startY + 24.0f - 6.0f, this.endYAnim, (this.endYAnim - (startY + 24.0f - 5.0f) < 0.0f ? 0.65f : 0.55f) * (float)RenderUtils.deltaTime * 0.025f);
                ce.drawPanel(mouseX, mouseY, 230.0f, 0.0f, this.width - 260, this.height - 40, Mouse.getDWheel(), accentColor);
                ce.drawPanel(mouseX, mouseY, 230.0f, 0.0f, this.width - 260, this.height - 40, Mouse.getDWheel(), accentColor);
            }
            startY += 24.0f;
        }
        RenderUtils.originalRoundedRect(32.0f, this.startYAnim, 34.0f, this.endYAnim, 1.0f, accentColor.getRGB());
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, (float)this.width - 54.0f, 30.0f, (float)this.width - 30.0f, 50.0f)) {
            this.mc.displayGuiScreen(null);
            return;
        }
        float elementHeight = 24.0f;
        float startY = 60.0f;
        this.searchElement.handleMouseClick(mouseX, mouseY, mouseButton, 230.0f, 50.0f, this.width - 260, this.height - 80, this.categoryElements);
        if (!this.searchElement.isTyping()) {
            for (CategoryElement ce : this.categoryElements) {
                if (ce.getFocused()) {
                    ce.handleMouseClick(mouseX, mouseY, mouseButton, 230.0f, 0.0f, this.width - 260, this.height - 40);
                }
                if (MouseUtils.mouseWithinBounds(mouseX, mouseY, 30.0f, startY, 230.0f, startY + 24.0f) && !this.searchElement.isTyping()) {
                    this.categoryElements.forEach(e -> e.setFocused(false));
                    ce.setFocused(true);
                    return;
                }
                startY += 24.0f;
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        for (CategoryElement ce : this.categoryElements) {
            if (!ce.getFocused() || !ce.handleKeyTyped(typedChar, keyCode)) continue;
            return;
        }
        if (this.searchElement.handleTyping(typedChar, keyCode, 230.0f, 50.0f, this.width - 260, this.height - 80, this.categoryElements)) {
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    protected void mouseReleased(int mouseX, int mouseY, int state) {
        this.searchElement.handleMouseRelease(mouseX, mouseY, state, 230.0f, 50.0f, this.width - 260, this.height - 80, this.categoryElements);
        if (!this.searchElement.isTyping()) {
            for (CategoryElement ce : this.categoryElements) {
                if (!ce.getFocused()) continue;
                ce.handleMouseRelease(mouseX, mouseY, state, 230.0f, 50.0f, this.width - 260, this.height - 80);
            }
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    public boolean doesGuiPauseGame() {
        return false;
    }
}

