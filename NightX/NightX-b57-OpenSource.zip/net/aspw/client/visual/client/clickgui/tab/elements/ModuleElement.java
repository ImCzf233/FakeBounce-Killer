/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client.clickgui.tab.elements;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.aspw.client.features.module.Module;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.BlendUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.render.Stencil;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.value.Value;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.components.ToggleSwitch;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;
import net.aspw.client.visual.client.clickgui.tab.value.ValueElement;
import net.aspw.client.visual.client.clickgui.tab.value.impl.BooleanElement;
import net.aspw.client.visual.client.clickgui.tab.value.impl.FloatElement;
import net.aspw.client.visual.client.clickgui.tab.value.impl.IntElement;
import net.aspw.client.visual.client.clickgui.tab.value.impl.ListElement;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public final class ModuleElement
extends MinecraftInstance {
    public static final Companion Companion = new Companion(null);
    private final Module module;
    private final ToggleSwitch toggleSwitch;
    private final List<ValueElement<?>> valueElements;
    private float animHeight;
    private float fadeKeybind;
    private float animPercent;
    private boolean listeningToKey;
    private boolean expanded;
    private static final ResourceLocation expandIcon = new ResourceLocation("client/clickgui/expand.png");

    public ModuleElement(Module module) {
        Intrinsics.checkNotNullParameter((Object)module, (String)"module");
        this.module = module;
        this.toggleSwitch = new ToggleSwitch();
        this.valueElements = new ArrayList();
        for (Value<?> value : this.module.getValues()) {
            if (value instanceof BoolValue) {
                this.valueElements.add(new BooleanElement((BoolValue)value));
            }
            if (value instanceof ListValue) {
                this.valueElements.add(new ListElement((ListValue)value));
            }
            if (value instanceof IntegerValue) {
                this.valueElements.add(new IntElement((IntegerValue)value));
            }
            if (!(value instanceof FloatValue)) continue;
            this.valueElements.add(new FloatElement((FloatValue)value));
        }
    }

    public final Module getModule() {
        return this.module;
    }

    public final float getAnimHeight() {
        return this.animHeight;
    }

    public final void setAnimHeight(float f) {
        this.animHeight = f;
    }

    public final boolean getExpanded() {
        return this.expanded;
    }

    public final void setExpanded(boolean bl) {
        this.expanded = bl;
    }

    public final float drawElement(int mouseX, int mouseY, float x, float y, float width, float height, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        this.animPercent = AnimHelperKt.animSmooth(this.animPercent, this.expanded ? 100.0f : 0.0f, 0.5f);
        float expectedHeight = 0.0f;
        for (ValueElement<?> ve : this.valueElements) {
            if (!ve.isDisplayable()) continue;
            expectedHeight += ve.getValueHeight();
        }
        this.animHeight = this.animPercent / 100.0f * (expectedHeight + 10.0f);
        Stencil.write(true);
        RenderUtils.originalRoundedRect(x + 10.0f, y + 5.0f, x + width - 10.0f, y + height + this.animHeight - 5.0f, 4.0f, ColorManager.INSTANCE.getModuleBackground().getRGB());
        Stencil.erase(true);
        RenderUtils.newDrawRect(x + 10.0f, y + height - 5.0f, x + width - 10.0f, y + height - 4.5f, -13619152);
        Fonts.fontSFUI40.drawString(this.module.getName(), x + 20.0f, y + height / 2.0f - (float)Fonts.fontSFUI35.FONT_HEIGHT + 3.0f, -1);
        String keyName = this.listeningToKey ? "Press key (esc to none)" : Keyboard.getKeyName((int)this.module.getKeyBind());
        float f = x + 25.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName());
        float f2 = y + height / 2.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT + 2.0f;
        float f3 = x + 35.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName());
        Intrinsics.checkNotNullExpressionValue((Object)keyName, (String)"keyName");
        this.fadeKeybind = MouseUtils.mouseWithinBounds(mouseX, mouseY, f, f2, f3 + (float)Fonts.fontTiny.getStringWidth(keyName), y + height / 2.0f) ? RangesKt.coerceIn((float)(this.fadeKeybind + 0.1f * (float)RenderUtils.deltaTime * 0.025f), (float)0.0f, (float)1.0f) : RangesKt.coerceIn((float)(this.fadeKeybind - 0.1f * (float)RenderUtils.deltaTime * 0.025f), (float)0.0f, (float)1.0f);
        RenderUtils.originalRoundedRect(x + 25.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName()), y + height / 2.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT + 2.0f, x + 35.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName()) + (float)Fonts.fontTiny.getStringWidth(keyName), y + height / 2.0f, 2.0f, BlendUtils.blend(new Color(-12237499), new Color(-13290187), this.fadeKeybind).getRGB());
        Fonts.fontTiny.drawString(keyName, x + 30.5f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName()), y + height / 2.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT + 5.5f, -1);
        this.toggleSwitch.setState(this.module.getState());
        if (this.module.getValues().size() > 0) {
            RenderUtils.newDrawRect(x + width - 40.0f, y + 5.0f, x + width - 39.5f, y + height - 5.0f, -13619152);
            GlStateManager.resetColor();
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(x + width - 25.0f), (float)(y + height / 2.0f), (float)0.0f);
            GL11.glPushMatrix();
            GL11.glRotatef((float)(180.0f * (this.animHeight / (expectedHeight + 10.0f))), (float)0.0f, (float)0.0f, (float)1.0f);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            RenderUtils.drawImage(expandIcon, -4, -4, 8, 8);
            GL11.glPopMatrix();
            GL11.glPopMatrix();
            this.toggleSwitch.onDraw(x + width - 70.0f, y + height / 2.0f - 5.0f, 20.0f, 10.0f, new Color(-14342875), accentColor);
        } else {
            this.toggleSwitch.onDraw(x + width - 40.0f, y + height / 2.0f - 5.0f, 20.0f, 10.0f, new Color(-14342875), accentColor);
        }
        if (this.expanded || this.animHeight > 0.0f) {
            float startYPos = y + height;
            for (ValueElement<?> ve : this.valueElements) {
                if (!ve.isDisplayable()) continue;
                startYPos += ve.drawElement(mouseX, mouseY, x + 10.0f, startYPos, width - 20.0f, new Color(-14342875), accentColor);
            }
        }
        Stencil.dispose();
        return height + this.animHeight;
    }

    public final void handleClick(int mouseX, int mouseY, float x, float y, float width, float height) {
        if (this.listeningToKey) {
            this.resetState();
            return;
        }
        String keyName = this.listeningToKey ? "Press key (esc to none)" : Keyboard.getKeyName((int)this.module.getKeyBind());
        float f = x + 25.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName());
        float f2 = y + height / 2.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT + 2.0f;
        float f3 = x + 35.0f + (float)Fonts.fontSFUI40.getStringWidth(this.module.getName());
        Intrinsics.checkNotNullExpressionValue((Object)keyName, (String)"keyName");
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, f, f2, f3 + (float)Fonts.fontTiny.getStringWidth(keyName), y + height / 2.0f)) {
            this.listeningToKey = true;
            return;
        }
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, x + width - (this.module.getValues().size() > 0 ? 70.0f : 40.0f), y, x + width - (this.module.getValues().size() > 0 ? 50.0f : 20.0f), y + height)) {
            this.module.toggle();
        }
        if (this.module.getValues().size() > 0 && MouseUtils.mouseWithinBounds(mouseX, mouseY, x + width - 40.0f, y, x + width - 10.0f, y + height)) {
            boolean bl = this.expanded = !this.expanded;
        }
        if (this.expanded) {
            float startY = y + height;
            for (ValueElement<?> ve : this.valueElements) {
                if (!ve.isDisplayable()) continue;
                ve.onClick(mouseX, mouseY, x + 10.0f, startY, width - 20.0f);
                startY += ve.getValueHeight();
            }
        }
    }

    public final void handleRelease(int mouseX, int mouseY, float x, float y, float width, float height) {
        if (this.expanded) {
            float startY = y + height;
            for (ValueElement<?> ve : this.valueElements) {
                if (!ve.isDisplayable()) continue;
                ve.onRelease(mouseX, mouseY, x + 10.0f, startY, width - 20.0f);
                startY += ve.getValueHeight();
            }
        }
    }

    public final boolean handleKeyTyped(char typed, int code) {
        if (this.listeningToKey) {
            if (code == 1) {
                this.module.setKeyBind(0);
                this.listeningToKey = false;
            } else {
                this.module.setKeyBind(code);
                this.listeningToKey = false;
            }
            return true;
        }
        if (this.expanded) {
            for (ValueElement<?> ve : this.valueElements) {
                if (!ve.isDisplayable() || !ve.onKeyPress(typed, code)) continue;
                return true;
            }
        }
        return false;
    }

    public final boolean listeningKeybind() {
        return this.listeningToKey;
    }

    public final void resetState() {
        this.listeningToKey = false;
    }

    public static final class Companion {
        private Companion() {
        }

        protected final ResourceLocation getExpandIcon() {
            return expandIcon;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

