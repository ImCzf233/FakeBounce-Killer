/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 */
package net.aspw.client.visual.client.clickgui.tab.value.impl;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.client.clickgui.tab.ColorManager;
import net.aspw.client.visual.client.clickgui.tab.components.Slider;
import net.aspw.client.visual.client.clickgui.tab.value.ValueElement;
import net.aspw.client.visual.font.Fonts;

public final class IntElement
extends ValueElement<Integer> {
    private final IntegerValue savedValue;
    private final Slider slider;
    private boolean dragged;

    public IntElement(IntegerValue savedValue) {
        Intrinsics.checkNotNullParameter((Object)savedValue, (String)"savedValue");
        super(savedValue);
        this.savedValue = savedValue;
        this.slider = new Slider();
    }

    public final IntegerValue getSavedValue() {
        return this.savedValue;
    }

    @Override
    public float drawElement(int mouseX, int mouseY, float x, float y, float width, Color bgColor, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)bgColor, (String)"bgColor");
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        float valueDisplay = 30.0f + (float)Fonts.fontSFUI40.getStringWidth(this.savedValue.getMaximum() + this.savedValue.getSuffix());
        int maxLength = Fonts.fontSFUI40.getStringWidth(this.savedValue.getMaximum() + this.savedValue.getSuffix());
        int minLength = Fonts.fontSFUI40.getStringWidth(this.savedValue.getMinimum() + this.savedValue.getSuffix());
        int nameLength = Fonts.fontSFUI40.getStringWidth(this.getValue().getName());
        float sliderWidth = width - 50.0f - (float)nameLength - (float)maxLength - (float)minLength - valueDisplay;
        float startPoint = x + width - 20.0f - sliderWidth - (float)maxLength - valueDisplay;
        if (this.dragged) {
            this.savedValue.set(RangesKt.coerceIn((int)((int)((float)this.savedValue.getMinimum() + (float)(this.savedValue.getMaximum() - this.savedValue.getMinimum()) / sliderWidth * ((float)mouseX - startPoint))), (int)this.savedValue.getMinimum(), (int)this.savedValue.getMaximum()));
        }
        int currLength = Fonts.fontSFUI40.getStringWidth(((Number)this.savedValue.get()).intValue() + this.savedValue.getSuffix());
        Fonts.fontSFUI40.drawString(this.getValue().getName(), x + 10.0f, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        Fonts.fontSFUI40.drawString(this.savedValue.getMaximum() + this.savedValue.getSuffix(), x + width - 10.0f - (float)maxLength - valueDisplay, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        Fonts.fontSFUI40.drawString(this.savedValue.getMinimum() + this.savedValue.getSuffix(), x + width - 30.0f - sliderWidth - (float)maxLength - (float)minLength - valueDisplay, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        this.slider.setValue(RangesKt.coerceIn((int)((Number)this.savedValue.get()).intValue(), (int)this.savedValue.getMinimum(), (int)this.savedValue.getMaximum()), this.savedValue.getMinimum(), this.savedValue.getMaximum());
        this.slider.onDraw(x + width - 20.0f - sliderWidth - (float)maxLength - valueDisplay, y + 10.0f, sliderWidth, accentColor);
        RenderUtils.originalRoundedRect(x + width - 5.0f - valueDisplay, y + 2.0f, x + width - 10.0f, y + 18.0f, 4.0f, ColorManager.INSTANCE.getButton().getRGB());
        RenderUtils.customRounded(x + width - 18.0f, y + 2.0f, x + width - 10.0f, y + 18.0f, 0.0f, 4.0f, 4.0f, 0.0f, ColorManager.INSTANCE.getButtonOutline().getRGB());
        RenderUtils.customRounded(x + width - 5.0f - valueDisplay, y + 2.0f, x + width + 3.0f - valueDisplay, y + (float)18, 4.0f, 0.0f, 0.0f, 4.0f, ColorManager.INSTANCE.getButtonOutline().getRGB());
        Fonts.fontSFUI40.drawString(((Number)this.savedValue.get()).intValue() + this.savedValue.getSuffix(), x + width + 6.0f - valueDisplay, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        Fonts.fontSFUI40.drawString("-", x + width - 3.0f - valueDisplay, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        Fonts.fontSFUI40.drawString("+", x + width - 17.0f, y + 10.0f - (float)Fonts.fontSFUI40.FONT_HEIGHT / 2.0f + 2.0f, -1);
        return this.getValueHeight();
    }

    @Override
    public void onClick(int mouseX, int mouseY, float x, float y, float width) {
        float endPoint;
        float valueDisplay = 30.0f + (float)Fonts.fontSFUI40.getStringWidth(this.savedValue.getMaximum() + this.savedValue.getSuffix());
        int maxLength = Fonts.fontSFUI40.getStringWidth(this.savedValue.getMaximum() + this.savedValue.getSuffix());
        int minLength = Fonts.fontSFUI40.getStringWidth(this.savedValue.getMinimum() + this.savedValue.getSuffix());
        int nameLength = Fonts.fontSFUI40.getStringWidth(this.getValue().getName());
        float sliderWidth = width - 50.0f - (float)nameLength - (float)maxLength - (float)minLength - valueDisplay;
        float startPoint = x + width - 30.0f - sliderWidth - valueDisplay - (float)maxLength;
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, startPoint, y + 5.0f, endPoint = x + width - 10.0f - valueDisplay - (float)maxLength, y + 15.0f)) {
            this.dragged = true;
        }
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, x + width - 5.0f - valueDisplay, y + 2.0f, x + width + 3.0f - valueDisplay, y + 18.0f)) {
            this.savedValue.set(RangesKt.coerceIn((int)(((Number)this.savedValue.get()).intValue() - 1), (int)this.savedValue.getMinimum(), (int)this.savedValue.getMaximum()));
        }
        if (MouseUtils.mouseWithinBounds(mouseX, mouseY, x + width - 18.0f, y + 2.0f, x + width - 10.0f, y + 18.0f)) {
            this.savedValue.set(RangesKt.coerceIn((int)(((Number)this.savedValue.get()).intValue() + 1), (int)this.savedValue.getMinimum(), (int)this.savedValue.getMaximum()));
        }
    }

    @Override
    public void onRelease(int mouseX, int mouseY, float x, float y, float width) {
        if (this.dragged) {
            this.dragged = false;
        }
    }
}

