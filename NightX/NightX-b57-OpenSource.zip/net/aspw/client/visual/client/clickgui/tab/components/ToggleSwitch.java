/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.visual.client.clickgui.tab.components;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.render.BlendUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.client.clickgui.tab.extensions.AnimHelperKt;

public final class ToggleSwitch {
    private float smooth;
    private boolean state;

    public final boolean getState() {
        return this.state;
    }

    public final void setState(boolean bl) {
        this.state = bl;
    }

    public final void onDraw(float x, float y, float width, float height, Color bgColor, Color accentColor) {
        Intrinsics.checkNotNullParameter((Object)bgColor, (String)"bgColor");
        Intrinsics.checkNotNullParameter((Object)accentColor, (String)"accentColor");
        this.smooth = AnimHelperKt.animLinear(this.smooth, (this.state ? 0.2f : -0.2f) * (float)RenderUtils.deltaTime * 0.045f, 0.0f, 1.0f);
        Object[] objectArray = new float[]{0.0f, 1.0f};
        float[] fArray = objectArray;
        objectArray = new Color[2];
        objectArray[0] = (float)new Color(160, 160, 160);
        objectArray[1] = (float)accentColor;
        Color borderColor = BlendUtils.blendColors(fArray, (Color[])objectArray, this.smooth);
        Object[] objectArray2 = new float[]{0.0f, 1.0f};
        float[] fArray2 = objectArray2;
        objectArray2 = new Color[2];
        objectArray2[0] = (float)bgColor;
        objectArray2[1] = (float)accentColor;
        Color mainColor = BlendUtils.blendColors(fArray2, (Color[])objectArray2, this.smooth);
        Object[] objectArray3 = new float[]{0.0f, 1.0f};
        float[] fArray3 = objectArray3;
        objectArray3 = new Color[2];
        objectArray3[0] = (float)new Color(160, 160, 160);
        objectArray3[1] = (float)bgColor;
        Color switchColor = BlendUtils.blendColors(fArray3, (Color[])objectArray3, this.smooth);
        RenderUtils.originalRoundedRect(x - 0.5f, y - 0.5f, x + width + 0.5f, y + height + 0.5f, (height + 1.0f) / 2.0f, borderColor.getRGB());
        RenderUtils.originalRoundedRect(x, y, x + width, y + height, height / 2.0f, mainColor.getRGB());
        RenderUtils.drawFilledCircle(x + (1.0f - this.smooth) * (2.0f + (height - 4.0f) / 2.0f) + this.smooth * (width - 2.0f - (height - 4.0f) / 2.0f), y + 2.0f + (height - 4.0f) / 2.0f, (height - 4.0f) / 2.0f, switchColor);
    }
}

