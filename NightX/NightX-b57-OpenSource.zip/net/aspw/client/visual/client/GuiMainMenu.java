/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.Agent
 *  com.mojang.authlib.exceptions.AuthenticationException
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication
 *  com.thealtening.AltService$EnumAltService
 *  com.thealtening.api.TheAltening
 *  com.thealtening.api.TheAltening$Asynchronous
 *  com.thealtening.api.data.AccountData
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiMultiplayer
 *  net.minecraft.client.gui.GuiOptions
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiSelectWorld
 *  net.minecraft.client.gui.GuiYesNoCallback
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Session
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import com.thealtening.AltService;
import com.thealtening.api.TheAltening;
import com.thealtening.api.data.AccountData;
import java.net.Proxy;
import java.util.concurrent.CompletableFuture;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.misc.MiscUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.auth.GuiLoginSelection;
import net.aspw.client.visual.auth.LoginID;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class GuiMainMenu
extends GuiScreen
implements GuiYesNoCallback {
    private int alpha = 255;
    private long lastAnimTick;
    private boolean alrUpdate;
    private final ResourceLocation kawaiiLogo = new ResourceLocation("client/images/defoko.png");
    private final ResourceLocation goodLogo = new ResourceLocation("client/images/nightx-logo2.png");
    private final int buttonWidth;
    private final int buttonHeight;

    public GuiMainMenu() {
        this.buttonWidth = 112;
        this.buttonHeight = 20;
    }

    public final int getAlpha() {
        return this.alpha;
    }

    public final void setAlpha(int n) {
        this.alpha = n;
    }

    public void initGui() {
        if (!LoginID.INSTANCE.getLoggedIn()) {
            this.mc.displayGuiScreen((GuiScreen)new GuiLoginSelection(this));
        }
        this.buttonList.add(new GuiButton(0, this.width / 2 - 55, this.height / 2 - 80 + 80, this.buttonWidth, this.buttonHeight, "SINGLE PLAYER"));
        this.buttonList.add(new GuiButton(1, this.width / 2 - 55, this.height / 2 - 80 + 105 - 2, this.buttonWidth, this.buttonHeight, "MULTI PLAYER"));
        this.buttonList.add(new GuiButton(2, this.width / 2 - 55, this.height / 2 - 80 + 130 - 4, this.buttonWidth, this.buttonHeight, "ALT MANAGER"));
        this.buttonList.add(new GuiButton(3, this.width / 2 - 55, this.height / 2 - 80 + 155 - 6, this.buttonWidth, this.buttonHeight, "OPTIONS"));
        this.buttonList.add(new GuiButton(4, this.width / 2 - 55, this.height / 2 - 80 + 180 - 8, this.buttonWidth, this.buttonHeight, "EXIT"));
        this.buttonList.add(new GuiButton(5, 3, this.height - 36, this.buttonWidth - 60, this.buttonHeight, "ReLogin"));
        this.buttonList.add(new GuiButton(6, 58, this.height - 36, this.buttonWidth - 60, this.buttonHeight, "Discord"));
        this.buttonList.add(new GuiButton(7, 113, this.height - 36, this.buttonWidth + 30, this.buttonHeight, "Free Alt (Only Premium Users)"));
        super.initGui();
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!this.alrUpdate) {
            this.lastAnimTick = System.currentTimeMillis();
            this.alrUpdate = true;
        }
        GL11.glPushMatrix();
        this.drawBackground(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/mainmenu.png"), 0, 0, this.width, this.height);
        RenderUtils.drawImage2(this.goodLogo, (float)this.width / 2.0f - 50.0f, (float)this.height / 2.0f - 120.0f, 100, 100);
        RenderUtils.drawImage2(this.kawaiiLogo, (float)this.width - 86.0f, (float)this.height - 96.0f, 80, 80);
        GlStateManager.enableAlpha();
        Fonts.fontSFUI40.drawStringWithShadow(Intrinsics.stringPlus((String)"NightX Client \u00a7bRelease B57\u00a7r - \u00a76", (Object)this.mc.getSession().getUsername()), 4.0f, (float)this.height - 12.0f, -1);
        Fonts.fontSFUI40.drawStringWithShadow(Intrinsics.stringPlus((String)"Welcome, \u00a7a", (Object)LoginID.INSTANCE.getId()), (float)this.width - 4.0f - (float)Fonts.fontSFUI40.getStringWidth(Intrinsics.stringPlus((String)"Welcome, \u00a7a", (Object)LoginID.INSTANCE.getId())), (float)this.height - 12.0f, -1);
        GlStateManager.disableAlpha();
        GlStateManager.enableAlpha();
        GL11.glPopMatrix();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    protected void actionPerformed(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        switch (button.id) {
            case 0: {
                this.mc.displayGuiScreen((GuiScreen)new GuiSelectWorld((GuiScreen)this));
                break;
            }
            case 1: {
                this.mc.displayGuiScreen((GuiScreen)new GuiMultiplayer((GuiScreen)this));
                break;
            }
            case 2: {
                this.mc.displayGuiScreen((GuiScreen)new GuiAltManager(this));
                break;
            }
            case 3: {
                this.mc.displayGuiScreen((GuiScreen)new GuiOptions((GuiScreen)this, this.mc.gameSettings));
                break;
            }
            case 4: {
                this.mc.shutdown();
                break;
            }
            case 5: {
                this.mc.displayGuiScreen((GuiScreen)new GuiLoginSelection(this));
                break;
            }
            case 6: {
                MiscUtils.showURL("https://discord.gg/SGBccUXFK");
                break;
            }
            case 7: {
                if (LoginID.INSTANCE.isPremium()) {
                    TheAltening altening = new TheAltening("api-tlo0-67k3-mzst");
                    TheAltening.Asynchronous asynchronous = new TheAltening.Asynchronous(altening);
                    Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)boolValue);
                    if (((Boolean)boolValue.get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    ((CompletableFuture)asynchronous.getAccountData().thenAccept(arg_0 -> GuiMainMenu.actionPerformed$lambda-0(this, arg_0))).whenComplete(GuiMainMenu::actionPerformed$lambda-1);
                    break;
                }
                ClientUtils.getLogger().info("You are not using Premium Account!");
            }
        }
    }

    protected void keyTyped(char typedChar, int keyCode) {
    }

    private static final void actionPerformed$lambda-0(GuiMainMenu this$0, AccountData account) {
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
        Intrinsics.checkNotNull((Object)boolValue);
        if (((Boolean)boolValue.get()).booleanValue()) {
            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
        }
        try {
            GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.THEALTENING);
            Hud hud2 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue2 = hud2 == null ? null : hud2.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue2);
            if (((Boolean)boolValue2.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            YggdrasilUserAuthentication yggdrasilUserAuthentication = new YggdrasilUserAuthentication(new YggdrasilAuthenticationService(Proxy.NO_PROXY, ""), Agent.MINECRAFT);
            yggdrasilUserAuthentication.setUsername(account.getToken());
            yggdrasilUserAuthentication.setPassword("NightX");
            try {
                yggdrasilUserAuthentication.logIn();
                this$0.mc.session = new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
                Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
            }
            catch (AuthenticationException e) {
                GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                ClientUtils.getLogger().error("Failed to login.", (Throwable)e);
                Intrinsics.stringPlus((String)"\u00a7cFailed to login: ", (Object)e.getMessage());
            }
        }
        catch (Throwable throwable) {
            Hud hud3 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue3 = hud3 == null ? null : hud3.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue3);
            if (((Boolean)boolValue3.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            ClientUtils.getLogger().error("Failed to login.", throwable);
        }
    }

    private static final void actionPerformed$lambda-1(Void $noName_0, Throwable $noName_1) {
    }
}

