/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiTextField
 */
package net.aspw.client.visual.elements;

import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiTextField;

public final class GuiPasswordField
extends GuiTextField {
    public GuiPasswordField(int componentId, FontRenderer fontrendererObj, int x, int y, int par5Width, int par6Height) {
        Intrinsics.checkNotNullParameter((Object)fontrendererObj, (String)"fontrendererObj");
        super(componentId, fontrendererObj, x, y, par5Width, par6Height);
    }

    public void drawTextBox() {
        String realText = this.getText();
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        int n2 = this.getText().length();
        while (n < n2) {
            int i = n++;
            stringBuilder.append('*');
        }
        this.setText(stringBuilder.toString());
        super.drawTextBox();
        this.setText(realText);
    }
}

