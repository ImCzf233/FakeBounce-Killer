/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.value;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.value.Value;

public class BoolValue
extends Value<Boolean> {
    public BoolValue(String name, boolean value, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        super(name, value, displayable);
    }

    public BoolValue(String name, boolean value) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        this(name, value, (Function0<Boolean>)((Function0)1.INSTANCE));
    }

    public JsonPrimitive toJson() {
        return new JsonPrimitive((Boolean)this.getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        Intrinsics.checkNotNullParameter((Object)element, (String)"element");
        if (element.isJsonPrimitive()) {
            this.setValue(element.getAsBoolean() || StringsKt.equals((String)element.getAsString(), (String)"true", (boolean)true));
        }
    }
}

