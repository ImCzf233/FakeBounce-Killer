/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.value;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Arrays;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.value.Value;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public class ListValue
extends Value<String> {
    private final String[] values;
    @JvmField
    public boolean openList;

    public ListValue(String name, String[] values, String value, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)values, (String)"values");
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        super(name, value, displayable);
        this.values = values;
        this.setValue(value);
    }

    public final String[] getValues() {
        return this.values;
    }

    public ListValue(String name, String[] values, String value) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)values, (String)"values");
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        this(name, values, value, (Function0<Boolean>)((Function0)1.INSTANCE));
    }

    public final boolean contains(@Nullable String string) {
        return Arrays.stream(this.values).anyMatch(arg_0 -> ListValue.contains$lambda-0(string, arg_0));
    }

    @Override
    public void changeValue(String value) {
        Intrinsics.checkNotNullParameter((Object)value, (String)"value");
        for (String element : this.values) {
            if (!StringsKt.equals((String)element, (String)value, (boolean)true)) continue;
            this.setValue(element);
            break;
        }
    }

    public JsonPrimitive toJson() {
        return new JsonPrimitive((String)this.getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        Intrinsics.checkNotNullParameter((Object)element, (String)"element");
        if (element.isJsonPrimitive()) {
            String string = element.getAsString();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"element.asString");
            this.changeValue(string);
        }
    }

    private static final boolean contains$lambda-0(String $string, String s) {
        Intrinsics.checkNotNullParameter((Object)s, (String)"s");
        return StringsKt.equals((String)s, (String)$string, (boolean)true);
    }
}

