/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.value;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.value.Value;

public class IntegerValue
extends Value<Integer> {
    private final int minimum;
    private final int maximum;
    private final String suffix;

    public IntegerValue(String name, int value, int minimum, int maximum, String suffix, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)suffix, (String)"suffix");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        super(name, value, displayable);
        this.minimum = minimum;
        this.maximum = maximum;
        this.suffix = suffix;
    }

    public /* synthetic */ IntegerValue(String string, int n, int n2, int n3, String string2, Function0 function0, int n4, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n4 & 4) != 0) {
            n2 = 0;
        }
        if ((n4 & 8) != 0) {
            n3 = Integer.MAX_VALUE;
        }
        this(string, n, n2, n3, string2, (Function0<Boolean>)function0);
    }

    public final int getMinimum() {
        return this.minimum;
    }

    public final int getMaximum() {
        return this.maximum;
    }

    public final String getSuffix() {
        return this.suffix;
    }

    public IntegerValue(String name, int value, int minimum, int maximum, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        this(name, value, minimum, maximum, "", displayable);
    }

    public IntegerValue(String name, int value, int minimum, int maximum, String suffix) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)suffix, (String)"suffix");
        this(name, value, minimum, maximum, suffix, (Function0<Boolean>)((Function0)1.INSTANCE));
    }

    public IntegerValue(String name, int value, int minimum, int maximum) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        this(name, value, minimum, maximum, (Function0<Boolean>)((Function0)2.INSTANCE));
    }

    @Override
    public final void set(Number newValue) {
        Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
        this.set(newValue.intValue());
    }

    public JsonPrimitive toJson() {
        return new JsonPrimitive((Number)this.getValue());
    }

    @Override
    public void fromJson(JsonElement element) {
        Intrinsics.checkNotNullParameter((Object)element, (String)"element");
        if (element.isJsonPrimitive()) {
            this.setValue(element.getAsInt());
        }
    }
}

