/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.block.Block;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="BlockOverlay", spacedName="Block Overlay", description="", category=ModuleCategory.VISUAL)
public final class BlockOverlay
extends Module {
    private final IntegerValue colorRedValue = new IntegerValue("R", 154, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 115, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 175, 0, 255);
    private final BoolValue colorRainbow = new BoolValue("Rainbow", false);
    private final BoolValue infoValue = new BoolValue("Info", false);

    public final BoolValue getInfoValue() {
        return this.infoValue;
    }

    public final BlockPos getCurrentBlock() {
        MovingObjectPosition movingObjectPosition = MinecraftInstance.mc.objectMouseOver;
        Object object = movingObjectPosition == null ? null : movingObjectPosition.getBlockPos();
        if (object == null) {
            return null;
        }
        BlockPos blockPos = object;
        if (BlockUtils.canBeClicked(blockPos) && MinecraftInstance.mc.theWorld.getWorldBorder().contains(blockPos)) {
            return blockPos;
        }
        return null;
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        BlockPos blockPos = this.getCurrentBlock();
        if (blockPos == null) {
            return;
        }
        BlockPos blockPos2 = blockPos;
        Block block = MinecraftInstance.mc.theWorld.getBlockState(blockPos2).getBlock();
        if (block == null) {
            return;
        }
        Block block2 = block;
        float partialTicks = event.getPartialTicks();
        Color color = (Boolean)this.colorRainbow.get() != false ? ColorUtils.rainbow(0.4f) : new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue(), 102);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)1, (int)0);
        RenderUtils.glColor(color);
        GL11.glLineWidth((float)2.0f);
        GlStateManager.disableTexture2D();
        GlStateManager.depthMask((boolean)false);
        block2.setBlockBoundsBasedOnState((IBlockAccess)MinecraftInstance.mc.theWorld, blockPos2);
        double x = MinecraftInstance.mc.thePlayer.lastTickPosX + (MinecraftInstance.mc.thePlayer.posX - MinecraftInstance.mc.thePlayer.lastTickPosX) * (double)partialTicks;
        double y = MinecraftInstance.mc.thePlayer.lastTickPosY + (MinecraftInstance.mc.thePlayer.posY - MinecraftInstance.mc.thePlayer.lastTickPosY) * (double)partialTicks;
        double z = MinecraftInstance.mc.thePlayer.lastTickPosZ + (MinecraftInstance.mc.thePlayer.posZ - MinecraftInstance.mc.thePlayer.lastTickPosZ) * (double)partialTicks;
        AxisAlignedBB axisAlignedBB = block2.getSelectedBoundingBox((World)MinecraftInstance.mc.theWorld, blockPos2).expand((double)0.002f, (double)0.002f, (double)0.002f).offset(-x, -y, -z);
        RenderUtils.drawSelectionBoundingBox(axisAlignedBB);
        RenderUtils.drawFilledBox(axisAlignedBB);
        GlStateManager.depthMask((boolean)true);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.resetColor();
    }

    @EventTarget
    public final void onRender2D(Render2DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.infoValue.get()).booleanValue()) {
            BlockPos blockPos = this.getCurrentBlock();
            if (blockPos == null) {
                return;
            }
            BlockPos blockPos2 = blockPos;
            Block block = BlockUtils.getBlock(blockPos2);
            if (block == null) {
                return;
            }
            Block block2 = block;
            String info = block2.getLocalizedName() + " \u00a77ID: " + Block.getIdFromBlock((Block)block2);
            ScaledResolution scaledResolution = new ScaledResolution(MinecraftInstance.mc);
            GlStateManager.resetColor();
            Fonts.fontSFUI40.drawCenteredString(info, (float)scaledResolution.getScaledWidth() / 2.0f, (float)scaledResolution.getScaledHeight() / 2.0f + 6.0f, Color.WHITE.getRGB());
        }
    }
}

