/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class AAC4SlowHop
extends SpeedMode {
    public AAC4SlowHop() {
        super("AAC4SlowHop");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.timer.timerSpeed = 1.0f;
        Intrinsics.checkNotNull((Object)SpeedMode.mc.thePlayer);
        SpeedMode.mc.thePlayer.speedInAir = 0.02f;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.thePlayer;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            EntityPlayerSP entityPlayerSP2 = SpeedMode.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP2);
            if (entityPlayerSP2.onGround) {
                SpeedMode.mc.gameSettings.keyBindJump.pressed = false;
                EntityPlayerSP entityPlayerSP3 = SpeedMode.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP3);
                entityPlayerSP3.jump();
            }
            EntityPlayerSP entityPlayerSP4 = SpeedMode.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP4);
            if (!entityPlayerSP4.onGround) {
                EntityPlayerSP entityPlayerSP5 = SpeedMode.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP5);
                if ((double)entityPlayerSP5.fallDistance <= 0.1) {
                    Intrinsics.checkNotNull((Object)SpeedMode.mc.thePlayer);
                    SpeedMode.mc.thePlayer.speedInAir = 0.02f;
                    SpeedMode.mc.timer.timerSpeed = 1.4f;
                }
            }
            EntityPlayerSP entityPlayerSP6 = SpeedMode.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP6);
            if ((double)entityPlayerSP6.fallDistance > 0.1) {
                EntityPlayerSP entityPlayerSP7 = SpeedMode.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP7);
                if ((double)entityPlayerSP7.fallDistance < 1.3) {
                    Intrinsics.checkNotNull((Object)SpeedMode.mc.thePlayer);
                    SpeedMode.mc.thePlayer.speedInAir = 0.0205f;
                    SpeedMode.mc.timer.timerSpeed = 0.65f;
                }
            }
            EntityPlayerSP entityPlayerSP8 = SpeedMode.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP8);
            if ((double)entityPlayerSP8.fallDistance >= 1.3) {
                SpeedMode.mc.timer.timerSpeed = 1.0f;
                Intrinsics.checkNotNull((Object)SpeedMode.mc.thePlayer);
                SpeedMode.mc.thePlayer.speedInAir = 0.02f;
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
    }
}

