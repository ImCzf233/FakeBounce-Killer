/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.spectre;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class SpectreLowHop
extends SpeedMode {
    public SpectreLowHop() {
        super("SpectreLowHop");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving() || SpectreLowHop.mc.thePlayer.movementInput.jump) {
            return;
        }
        if (SpectreLowHop.mc.thePlayer.onGround) {
            MovementUtils.strafe(1.1f);
            SpectreLowHop.mc.thePlayer.motionY = 0.15;
            return;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!SpectreLowHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            SpectreLowHop.mc.thePlayer.motionX = 0.0;
            SpectreLowHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

