/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.CharsKt
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S0BPacketAnimation
 *  net.minecraft.network.play.server.S14PacketEntity
 *  net.minecraft.network.play.server.S18PacketEntityTeleport
 *  net.minecraft.network.play.server.S19PacketEntityHeadLook
 *  net.minecraft.network.play.server.S19PacketEntityStatus
 *  net.minecraft.network.play.server.S1DPacketEntityEffect
 *  net.minecraft.network.play.server.S20PacketEntityProperties
 *  net.minecraft.network.play.server.S49PacketUpdateEntityNBT
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.Unit;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.CharsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.network.play.server.S19PacketEntityHeadLook;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.network.play.server.S1DPacketEntityEffect;
import net.minecraft.network.play.server.S20PacketEntityProperties;
import net.minecraft.network.play.server.S49PacketUpdateEntityNBT;
import net.minecraft.world.World;

@ModuleInfo(name="AntiStaff", spacedName="Anti Staff", description="", category=ModuleCategory.COMBAT)
public final class AntiStaff
extends Module {
    private String obStaffs = "_";
    private boolean detected;
    private int totalCount;

    @Override
    public void onInitialize() {
        ThreadsKt.thread$default((boolean)false, (boolean)false, null, null, (int)0, (Function0)((Function0)new Function0<Unit>(this){
            final /* synthetic */ AntiStaff this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            /*
             * WARNING - void declaration
             */
            public final void invoke() {
                void $this$filterTo$iv$iv;
                void $this$filter$iv;
                String string = AntiStaff.access$getObStaffs$p(this.this$0);
                AntiStaff antiStaff = this.this$0;
                boolean $i$f$filter = false;
                CharSequence charSequence = (CharSequence)$this$filter$iv;
                Appendable destination$iv$iv = new StringBuilder();
                boolean $i$f$filterTo = false;
                int n = 0;
                int n2 = $this$filterTo$iv$iv.length();
                while (n < n2) {
                    char element$iv$iv;
                    int index$iv$iv = n++;
                    char it = element$iv$iv = $this$filterTo$iv$iv.charAt(index$iv$iv);
                    boolean bl = false;
                    if (!CharsKt.isWhitespace((char)it)) continue;
                    destination$iv$iv.append(element$iv$iv);
                }
                String string2 = ((StringBuilder)destination$iv$iv).toString();
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"filterTo(StringBuilder(), predicate).toString()");
                AntiStaff.access$setTotalCount$p(antiStaff, ((CharSequence)string2).length());
                System.out.println((Object)Intrinsics.stringPlus((String)"[Staff/fallback] ", (Object)AntiStaff.access$getObStaffs$p(this.this$0)));
            }
        }), (int)31, null);
    }

    @Override
    public void onEnable() {
        this.detected = false;
    }

    @EventTarget
    public final void onWorld(WorldEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        this.detected = false;
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        block47: {
            block48: {
                String string;
                Entity entity;
                Packet<?> packet;
                block45: {
                    block46: {
                        block43: {
                            block44: {
                                block41: {
                                    block42: {
                                        block39: {
                                            block40: {
                                                block37: {
                                                    block38: {
                                                        block35: {
                                                            block36: {
                                                                block33: {
                                                                    block34: {
                                                                        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                                                                        if (MinecraftInstance.mc.theWorld == null || MinecraftInstance.mc.thePlayer == null) {
                                                                            return;
                                                                        }
                                                                        packet = event.getPacket();
                                                                        if (!(packet instanceof S1DPacketEntityEffect) || (entity = MinecraftInstance.mc.theWorld.getEntityByID(((S1DPacketEntityEffect)packet).getEntityId())) == null) break block33;
                                                                        string = entity.getName();
                                                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                                                        if (this.obStaffs.equals(string)) break block34;
                                                                        string = entity.getDisplayName().getUnformattedText();
                                                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                                                        if (!this.obStaffs.equals(string)) break block33;
                                                                    }
                                                                    if (!this.detected) {
                                                                        Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                                                        MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                                                        this.detected = true;
                                                                    }
                                                                }
                                                                if (!(packet instanceof S18PacketEntityTeleport) || (entity = MinecraftInstance.mc.theWorld.getEntityByID(((S18PacketEntityTeleport)packet).getEntityId())) == null) break block35;
                                                                string = entity.getName();
                                                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                                                if (this.obStaffs.equals(string)) break block36;
                                                                string = entity.getDisplayName().getUnformattedText();
                                                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                                                if (!this.obStaffs.equals(string)) break block35;
                                                            }
                                                            if (!this.detected) {
                                                                Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                                                MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                                                this.detected = true;
                                                            }
                                                        }
                                                        if (!(packet instanceof S20PacketEntityProperties) || (entity = MinecraftInstance.mc.theWorld.getEntityByID(((S20PacketEntityProperties)packet).getEntityId())) == null) break block37;
                                                        string = entity.getName();
                                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                                        if (this.obStaffs.equals(string)) break block38;
                                                        string = entity.getDisplayName().getUnformattedText();
                                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                                        if (!this.obStaffs.equals(string)) break block37;
                                                    }
                                                    if (!this.detected) {
                                                        Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                                        MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                                        this.detected = true;
                                                    }
                                                }
                                                if (!(packet instanceof S0BPacketAnimation) || (entity = MinecraftInstance.mc.theWorld.getEntityByID(((S0BPacketAnimation)packet).getEntityID())) == null) break block39;
                                                string = entity.getName();
                                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                                if (this.obStaffs.equals(string)) break block40;
                                                string = entity.getDisplayName().getUnformattedText();
                                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                                if (!this.obStaffs.equals(string)) break block39;
                                            }
                                            if (!this.detected) {
                                                Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                                MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                                this.detected = true;
                                            }
                                        }
                                        if (!(packet instanceof S14PacketEntity) || (entity = ((S14PacketEntity)packet).getEntity((World)MinecraftInstance.mc.theWorld)) == null) break block41;
                                        string = entity.getName();
                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                        if (this.obStaffs.equals(string)) break block42;
                                        string = entity.getDisplayName().getUnformattedText();
                                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                        if (!this.obStaffs.equals(string)) break block41;
                                    }
                                    if (!this.detected) {
                                        Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                        MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                        this.detected = true;
                                    }
                                }
                                if (!(packet instanceof S19PacketEntityStatus) || (entity = ((S19PacketEntityStatus)packet).getEntity((World)MinecraftInstance.mc.theWorld)) == null) break block43;
                                string = entity.getName();
                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                                if (this.obStaffs.equals(string)) break block44;
                                string = entity.getDisplayName().getUnformattedText();
                                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                                if (!this.obStaffs.equals(string)) break block43;
                            }
                            if (!this.detected) {
                                Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                                MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                                this.detected = true;
                            }
                        }
                        if (!(packet instanceof S19PacketEntityHeadLook) || (entity = ((S19PacketEntityHeadLook)packet).getEntity((World)MinecraftInstance.mc.theWorld)) == null) break block45;
                        string = entity.getName();
                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                        if (this.obStaffs.equals(string)) break block46;
                        string = entity.getDisplayName().getUnformattedText();
                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                        if (!this.obStaffs.equals(string)) break block45;
                    }
                    if (!this.detected) {
                        Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                        MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                        this.detected = true;
                    }
                }
                if (!(packet instanceof S49PacketUpdateEntityNBT) || (entity = ((S49PacketUpdateEntityNBT)packet).getEntity((World)MinecraftInstance.mc.theWorld)) == null) break block47;
                string = entity.getName();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.name");
                if (this.obStaffs.equals(string)) break block48;
                string = entity.getDisplayName().getUnformattedText();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.displayName.unformattedText");
                if (!this.obStaffs.equals(string)) break block47;
            }
            if (!this.detected) {
                Client.INSTANCE.getHud().addNotification(new Notification("Staff Detected!", Notification.Type.ERROR));
                MinecraftInstance.mc.thePlayer.sendChatMessage("/leave");
                this.detected = true;
            }
        }
    }

    public static final /* synthetic */ void access$setTotalCount$p(AntiStaff $this, int n) {
        $this.totalCount = n;
    }

    public static final /* synthetic */ String access$getObStaffs$p(AntiStaff $this) {
        return $this.obStaffs;
    }
}

