/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C19PacketResourcePackStatus
 *  net.minecraft.network.play.client.C19PacketResourcePackStatus$Action
 *  net.minecraft.network.play.server.S48PacketResourcePackSend
 */
package net.aspw.client.features.module.impl.other;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C19PacketResourcePackStatus;
import net.minecraft.network.play.server.S48PacketResourcePackSend;

@ModuleInfo(name="PackSpoofer", spacedName="Pack Spoofer", description="", category=ModuleCategory.OTHER)
public final class PackSpoofer
extends Module {
    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S48PacketResourcePackSend) {
            String url = ((S48PacketResourcePackSend)packet).getURL();
            String hash = ((S48PacketResourcePackSend)packet).getHash();
            try {
                String scheme = new URI(url).getScheme();
                boolean isLevelProtocol = "level".equals(scheme);
                if (!("http".equals(scheme) || "https".equals(scheme) || isLevelProtocol)) {
                    throw new URISyntaxException(url, "Wrong protocol");
                }
                if (isLevelProtocol) {
                    Intrinsics.checkNotNullExpressionValue((Object)url, (String)"url");
                    if (url.equals("..") || !StringsKt.endsWith$default((String)url, (String)".zip", (boolean)false, (int)2, null)) {
                        String string = url.substring("level://".length());
                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).substring(startIndex)");
                        String s2 = string;
                        File file1 = new File(MinecraftInstance.mc.mcDataDir, "saves");
                        File file2 = new File(file1, s2);
                        if (!file2.isFile() || StringsKt.contains((CharSequence)url, (CharSequence)"liquidbounce", (boolean)true)) {
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C19PacketResourcePackStatus(hash, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
                            event.cancelEvent();
                            return;
                        }
                    }
                }
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C19PacketResourcePackStatus(((S48PacketResourcePackSend)packet).getHash(), C19PacketResourcePackStatus.Action.ACCEPTED));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C19PacketResourcePackStatus(((S48PacketResourcePackSend)packet).getHash(), C19PacketResourcePackStatus.Action.SUCCESSFULLY_LOADED));
            }
            catch (URISyntaxException e) {
                ClientUtils.getLogger().error("Failed to handle resource pack", (Throwable)e);
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C19PacketResourcePackStatus(hash, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
            }
            event.cancelEvent();
        }
    }
}

