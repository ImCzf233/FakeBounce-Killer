/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiScreen
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.Locale;
import kotlin.jvm.JvmField;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.ColorMixer;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.client.clickgui.dropdown.style.styles.DropDown;
import net.aspw.client.visual.client.clickgui.tab.NewUi;
import net.minecraft.client.gui.GuiScreen;

@ModuleInfo(name="Gui", description="", category=ModuleCategory.VISUAL, keyBind=54, onlyEnable=true, forceNoSound=true, array=false)
public final class Gui
extends Module {
    public static final Companion Companion = new Companion(null);
    private final ListValue styleValue;
    @JvmField
    public final ListValue animationValue;
    @JvmField
    public final FloatValue scaleValue;
    @JvmField
    public final ListValue imageModeValue;
    private static final ListValue colorModeValue;
    private static final IntegerValue colorRedValue;
    private static final IntegerValue colorGreenValue;
    private static final IntegerValue colorBlueValue;
    private static final FloatValue saturationValue;
    private static final FloatValue brightnessValue;
    private static final IntegerValue mixerSecondsValue;

    public Gui() {
        Object object = new String[]{"DropDown", "Tab"};
        String[] stringArray = object;
        this.styleValue = new ListValue(stringArray){};
        object = new String[]{"None", "Zoom"};
        stringArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Gui this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return ((String)Gui.access$getStyleValue$p(this.this$0).get()).equals("DropDown");
            }
        };
        this.animationValue = new ListValue(stringArray, (Object)object){};
        this.scaleValue = new FloatValue("Scale", 1.0f, 0.4f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Gui this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return ((String)Gui.access$getStyleValue$p(this.this$0).get()).equals("DropDown");
            }
        }));
        stringArray = new String[]{"none", "mahiro", "delta", "defoko", "astolfo", "nao", "miguel", "infinity"};
        this.imageModeValue = new ListValue("Image", stringArray, "mahiro", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Gui this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return ((String)Gui.access$getStyleValue$p(this.this$0).get()).equals("DropDown");
            }
        }));
    }

    @Override
    public void onEnable() {
        Client.INSTANCE.getClickGui().progress = 0.0;
        Client.INSTANCE.getClickGui().slide = 0.0;
        Client.INSTANCE.getClickGui().lastMS = System.currentTimeMillis();
        MinecraftInstance.mc.displayGuiScreen((GuiScreen)Client.INSTANCE.getClickGui());
        String string = (String)this.styleValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        String string3 = string2;
        if (string3.equals("dropdown")) {
            Client.INSTANCE.getClickGui().style = new DropDown();
        } else if (string3.equals("tab")) {
            MinecraftInstance.mc.displayGuiScreen((GuiScreen)NewUi.getInstance());
        }
    }

    @JvmStatic
    public static final Color generateColor() {
        return Companion.generateColor();
    }

    public static final /* synthetic */ ListValue access$getStyleValue$p(Gui $this) {
        return $this.styleValue;
    }

    static {
        String[] stringArray = new String[]{"Custom", "Sky", "Rainbow", "LiquidSlowly", "Fade", "Mixer"};
        colorModeValue = new ListValue("Color", stringArray, "Sky");
        colorRedValue = new IntegerValue("Red", 255, 0, 255);
        colorGreenValue = new IntegerValue("Green", 255, 0, 255);
        colorBlueValue = new IntegerValue("Blue", 255, 0, 255);
        saturationValue = new FloatValue("Saturation", 0.4f, 0.0f, 1.0f);
        brightnessValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
        mixerSecondsValue = new IntegerValue("Seconds", 6, 1, 10);
    }

    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final Color generateColor() {
            Color c = new Color(255, 255, 255, 255);
            String string = (String)colorModeValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string2) {
                case "custom": {
                    c = new Color(((Number)colorRedValue.get()).intValue(), ((Number)colorGreenValue.get()).intValue(), ((Number)colorBlueValue.get()).intValue());
                    break;
                }
                case "rainbow": {
                    c = new Color(RenderUtils.getRainbowOpaque(((Number)mixerSecondsValue.get()).intValue(), ((Number)saturationValue.get()).floatValue(), ((Number)brightnessValue.get()).floatValue(), 0));
                    break;
                }
                case "sky": {
                    Color color = RenderUtils.skyRainbow(0, ((Number)saturationValue.get()).floatValue(), ((Number)brightnessValue.get()).floatValue());
                    Intrinsics.checkNotNullExpressionValue((Object)color, (String)"skyRainbow(0, saturation\u2026), brightnessValue.get())");
                    c = color;
                    break;
                }
                case "liquidslowly": {
                    c = ColorUtils.LiquidSlowly(System.nanoTime(), 0, ((Number)saturationValue.get()).floatValue(), ((Number)brightnessValue.get()).floatValue());
                    break;
                }
                case "fade": {
                    c = ColorUtils.fade(new Color(((Number)colorRedValue.get()).intValue(), ((Number)colorGreenValue.get()).intValue(), ((Number)colorBlueValue.get()).intValue()), 0, 100);
                    break;
                }
                case "mixer": {
                    c = ColorMixer.Companion.getMixedColor(0, ((Number)mixerSecondsValue.get()).intValue());
                }
            }
            return c;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

