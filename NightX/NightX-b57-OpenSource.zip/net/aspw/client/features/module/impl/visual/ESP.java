/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="ESP", description="", category=ModuleCategory.VISUAL)
public final class ESP
extends Module {
    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        void $this$filterTo$iv$iv;
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP player = entityPlayerSP;
        List list = MinecraftInstance.mc.theWorld.loadedEntityList;
        Intrinsics.checkNotNullExpressionValue((Object)list, (String)"mc.theWorld.loadedEntityList");
        Iterable $this$filter$iv = list;
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Collection destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo = false;
        for (Object element$iv$iv : $this$filterTo$iv$iv) {
            Entity entity = (Entity)element$iv$iv;
            boolean bl = false;
            if (!(entity != null && entity != player && EntityUtils.isSelected(entity, false))) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        List selectedEntities = (List)destination$iv$iv;
        for (Entity entity : selectedEntities) {
            RenderUtils.drawEntityBox(entity, ColorUtils.rainbow(), true);
        }
    }
}

