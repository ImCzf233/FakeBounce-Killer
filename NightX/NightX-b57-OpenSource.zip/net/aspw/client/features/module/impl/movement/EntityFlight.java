/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtilsFix;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;

@ModuleInfo(name="EntityFlight", spacedName="Entity Flight", description="", category=ModuleCategory.MOVEMENT)
public final class EntityFlight
extends Module {
    private final ListValue modeValue;
    private final FloatValue speedValue;

    public EntityFlight() {
        String[] stringArray = new String[]{"Motion", "Clip", "Velocity"};
        this.modeValue = new ListValue("Mode", stringArray, "Motion");
        this.speedValue = new FloatValue("Speed", 0.3f, 0.0f, 1.0f);
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.thePlayer.isRiding()) {
            return;
        }
        Entity vehicle = MinecraftInstance.mc.thePlayer.ridingEntity;
        double x = -Math.sin(MovementUtilsFix.INSTANCE.getDirection()) * ((Number)this.speedValue.get()).doubleValue();
        double z = Math.cos(MovementUtilsFix.INSTANCE.getDirection()) * ((Number)this.speedValue.get()).doubleValue();
        String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
        switch (string) {
            case "motion": {
                vehicle.motionX = x;
                vehicle.motionY = ((Number)(MinecraftInstance.mc.gameSettings.keyBindJump.pressed ? this.speedValue.get() : Integer.valueOf(0))).doubleValue();
                vehicle.motionZ = z;
                break;
            }
            case "clip": {
                vehicle.setPosition(vehicle.posX + x, vehicle.posY + ((Number)(MinecraftInstance.mc.gameSettings.keyBindJump.pressed ? this.speedValue.get() : Integer.valueOf(0))).doubleValue(), vehicle.posZ + z);
                break;
            }
            case "velocity": {
                vehicle.addVelocity(x, MinecraftInstance.mc.gameSettings.keyBindJump.pressed ? (double)((Number)this.speedValue.get()).floatValue() : 0.0, z);
            }
        }
    }
}

