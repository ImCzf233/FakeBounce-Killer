/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds;

import net.aspw.client.Client;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.util.MinecraftInstance;

public abstract class SpeedMode
extends MinecraftInstance {
    public final String modeName;

    public SpeedMode(String modeName) {
        this.modeName = modeName;
    }

    public boolean isActive() {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        return speed2 != null && !SpeedMode.mc.thePlayer.isSneaking() && speed2.getState() && speed2.getModeName().equals(this.modeName);
    }

    public abstract void onMotion();

    public void onMotion(MotionEvent eventMotion) {
    }

    public abstract void onUpdate();

    public abstract void onMove(MoveEvent var1);

    public void onJump(JumpEvent event) {
    }

    public void onTick() {
    }

    public void onEnable() {
    }

    public void onDisable() {
    }
}

