/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.JvmField;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;

@ModuleInfo(name="SilentSneak", spacedName="Silent Sneak", description="", category=ModuleCategory.MOVEMENT)
public final class SilentSneak
extends Module {
    @JvmField
    public final ListValue modeValue;
    @JvmField
    public final BoolValue stopMoveValue;
    private boolean sneaked;

    public SilentSneak() {
        String[] stringArray = new String[]{"Normal", "Legit", "Vanilla", "Switch", "AAC3.6.4"};
        this.modeValue = new ListValue("Mode", stringArray, "Normal");
        this.stopMoveValue = new BoolValue("StopMove", false);
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        if (StringsKt.equals((String)"vanilla", (String)((String)this.modeValue.get()), (boolean)true)) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.stopMoveValue.get()).booleanValue() && MovementUtils.isMoving()) {
            if (this.sneaked) {
                this.onDisable();
                this.sneaked = false;
            }
            return;
        }
        this.sneaked = true;
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "legit": {
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = true;
                break;
            }
            case "switch": {
                switch (WhenMappings.$EnumSwitchMapping$0[event.getEventState().ordinal()]) {
                    case 1: {
                        if (!MovementUtils.isMoving()) {
                            return;
                        }
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
                        break;
                    }
                    case 2: {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
                    }
                }
                break;
            }
            case "normal": {
                if (event.getEventState() != EventState.PRE) break;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING));
                break;
            }
            case "aac3.6.4": {
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = true;
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.getSpeed() * 1.251f);
                    break;
                }
                MovementUtils.strafe(MovementUtils.getSpeed() * 1.03f);
            }
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "legit": 
            case "aac3.6.4": 
            case "vanilla": 
            case "switch": {
                if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) break;
                MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
                break;
            }
            case "normal": {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING));
            }
        }
        super.onDisable();
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[EventState.values().length];
            nArray[EventState.PRE.ordinal()] = 1;
            nArray[EventState.POST.ordinal()] = 2;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

