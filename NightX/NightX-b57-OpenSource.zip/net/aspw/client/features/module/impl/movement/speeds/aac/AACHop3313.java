/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockCarpet
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.minecraft.block.BlockCarpet;
import net.minecraft.util.MathHelper;

public class AACHop3313
extends SpeedMode {
    public AACHop3313() {
        super("AACHop3.3.13");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || AACHop3313.mc.thePlayer.isInWater() || AACHop3313.mc.thePlayer.isInLava() || AACHop3313.mc.thePlayer.isOnLadder() || AACHop3313.mc.thePlayer.isRiding() || AACHop3313.mc.thePlayer.hurtTime > 0) {
            return;
        }
        if (AACHop3313.mc.thePlayer.onGround && AACHop3313.mc.thePlayer.isCollidedVertically) {
            float yawRad = AACHop3313.mc.thePlayer.rotationYaw * ((float)Math.PI / 180);
            AACHop3313.mc.thePlayer.motionX -= (double)(MathHelper.sin((float)yawRad) * 0.202f);
            AACHop3313.mc.thePlayer.motionZ += (double)(MathHelper.cos((float)yawRad) * 0.202f);
            AACHop3313.mc.thePlayer.motionY = 0.405f;
            Client.eventManager.callEvent(new JumpEvent(0.405f));
            MovementUtils.strafe();
        } else if (AACHop3313.mc.thePlayer.fallDistance < 0.31f) {
            if (BlockUtils.getBlock(AACHop3313.mc.thePlayer.getPosition()) instanceof BlockCarpet) {
                return;
            }
            AACHop3313.mc.thePlayer.jumpMovementFactor = AACHop3313.mc.thePlayer.moveStrafing == 0.0f ? 0.027f : 0.021f;
            AACHop3313.mc.thePlayer.motionX *= 1.001;
            AACHop3313.mc.thePlayer.motionZ *= 1.001;
            if (!AACHop3313.mc.thePlayer.isCollidedHorizontally) {
                AACHop3313.mc.thePlayer.motionY -= 0.01499999314546585;
            }
        } else {
            AACHop3313.mc.thePlayer.jumpMovementFactor = 0.02f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        AACHop3313.mc.thePlayer.jumpMovementFactor = 0.02f;
    }
}

