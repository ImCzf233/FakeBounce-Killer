/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC2BHop
extends SpeedMode {
    public AAC2BHop() {
        super("AAC2BHop");
    }

    @Override
    public void onMotion() {
        if (AAC2BHop.mc.thePlayer.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (AAC2BHop.mc.thePlayer.onGround) {
                AAC2BHop.mc.thePlayer.jump();
                AAC2BHop.mc.thePlayer.motionX *= 1.02;
                AAC2BHop.mc.thePlayer.motionZ *= 1.02;
            } else if (AAC2BHop.mc.thePlayer.motionY > -0.2) {
                AAC2BHop.mc.thePlayer.jumpMovementFactor = 0.08f;
                AAC2BHop.mc.thePlayer.motionY += 0.01431;
                AAC2BHop.mc.thePlayer.jumpMovementFactor = 0.07f;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

