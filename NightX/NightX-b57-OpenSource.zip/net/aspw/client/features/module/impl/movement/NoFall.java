/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.network.play.server.S12PacketEntityVelocity
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.movement;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.movement.NoFall;
import net.aspw.client.features.module.impl.player.Freecam;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

@ModuleInfo(name="NoFall", spacedName="No Fall", description="", category=ModuleCategory.MOVEMENT)
public final class NoFall
extends Module {
    private final ListValue typeValue;
    private final ListValue editMode;
    private final ListValue packetMode;
    private final ListValue aacMode;
    private final ListValue hypixelMode;
    private final ListValue matrixMode;
    private final FloatValue flySpeedValue;
    private final BoolValue voidCheckValue;
    private final MSTimer aac4FlagCooldown;
    private final TickTimer spartanTimer;
    private int oldaacState;
    private boolean aac4Fakelag;
    private int aac4FlagCount;
    private boolean aac5doFlag;
    private boolean aac5Check;
    private int aac5Timer;
    private final List<C03PacketPlayer> aac4Packets;
    private boolean matrixFalling;
    private boolean matrixCanSpoof;
    private int matrixFallTicks;
    private double matrixLastMotionY;
    private int matrixFlagWait;
    private boolean matrixSend;
    private boolean isDmgFalling;
    private boolean jumped;
    private boolean modifiedTimer;
    private boolean packetModify;
    private boolean needSpoof;
    private boolean doSpoof;
    private boolean nextSpoof;
    private int lastFallDistRounded;

    public NoFall() {
        String[] stringArray = new String[]{"Edit", "Packet", "NoPacket", "AAC", "Spartan", "CubeCraft", "Hypixel", "Verus", "Medusa", "Motion", "Matrix"};
        this.typeValue = new ListValue("Type", stringArray, "Packet");
        stringArray = new String[]{"Always", "Default", "Smart", "NoGround", "Damage"};
        this.editMode = new ListValue("Edit-Mode", stringArray, "Default", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"edit", (boolean)true);
            }
        }));
        stringArray = new String[]{"Default", "Smart"};
        this.packetMode = new ListValue("Packet-Mode", stringArray, "Default", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"packet", (boolean)true);
            }
        }));
        stringArray = new String[]{"Default", "LAAC", "3.3.11", "3.3.15", "4.x", "4.4.x", "Loyisa4.4.2", "5.0.4", "5.0.14"};
        this.aacMode = new ListValue("AAC-Mode", stringArray, "Default", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"aac", (boolean)true);
            }
        }));
        stringArray = new String[]{"Default", "Packet", "New"};
        this.hypixelMode = new ListValue("Hypixel-Mode", stringArray, "Default", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"hypixel", (boolean)true);
            }
        }));
        stringArray = new String[]{"Old", "6.2.x", "6.6.3"};
        this.matrixMode = new ListValue("Matrix-Mode", stringArray, "6.6.3", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"matrix", (boolean)true);
            }
        }));
        this.flySpeedValue = new FloatValue("MotionSpeed", -0.01f, -5.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoFall this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"motion", (boolean)true);
            }
        }));
        this.voidCheckValue = new BoolValue("Void-Check", false);
        this.aac4FlagCooldown = new MSTimer();
        this.spartanTimer = new TickTimer();
        this.aac4Packets = new ArrayList();
    }

    public final ListValue getTypeValue() {
        return this.typeValue;
    }

    public final ListValue getEditMode() {
        return this.editMode;
    }

    @Override
    public void onEnable() {
        this.aac4FlagCount = 0;
        this.aac4Fakelag = false;
        this.aac5Check = false;
        this.packetModify = false;
        this.aac4Packets.clear();
        this.needSpoof = false;
        this.aac5doFlag = false;
        this.aac5Timer = 0;
        this.lastFallDistRounded = 0;
        this.oldaacState = 0;
        this.matrixFalling = false;
        this.matrixCanSpoof = false;
        this.matrixFallTicks = 0;
        this.matrixLastMotionY = 0.0;
        this.isDmgFalling = false;
        this.matrixFlagWait = 0;
        this.aac4FlagCooldown.reset();
        this.nextSpoof = false;
        this.doSpoof = false;
    }

    @Override
    public void onDisable() {
        this.matrixSend = false;
        this.aac4FlagCount = 0;
        this.aac4Fakelag = false;
        this.aac5Check = false;
        this.packetModify = false;
        this.aac4Packets.clear();
        this.needSpoof = false;
        this.aac5doFlag = false;
        this.aac5Timer = 0;
        this.lastFallDistRounded = 0;
        this.oldaacState = 0;
        this.matrixFalling = false;
        this.matrixCanSpoof = false;
        this.matrixFallTicks = 0;
        this.matrixLastMotionY = 0.0;
        this.isDmgFalling = false;
        this.matrixFlagWait = 0;
        this.aac4FlagCooldown.reset();
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
    }

    @EventTarget(ignoreCondition=true)
    public final void onUpdate(UpdateEvent event) {
        block100: {
            block99: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (this.modifiedTimer) {
                    MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                    this.modifiedTimer = false;
                }
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    this.jumped = false;
                }
                if (MinecraftInstance.mc.thePlayer.motionY > 0.0) {
                    this.jumped = true;
                }
                if (!this.getState()) break block99;
                Freecam freecam = Client.INSTANCE.getModuleManager().get(Freecam.class);
                Intrinsics.checkNotNull((Object)freecam);
                if (!freecam.getState() && !MinecraftInstance.mc.thePlayer.isSpectator() && !MinecraftInstance.mc.thePlayer.capabilities.allowFlying && !MinecraftInstance.mc.thePlayer.capabilities.disableDamage) break block100;
            }
            return;
        }
        Flight flight = Client.INSTANCE.getModuleManager().get(Flight.class);
        Intrinsics.checkNotNull((Object)flight);
        if (!flight.getState() && ((Boolean)this.voidCheckValue.get()).booleanValue() && !MovementUtils.isBlockUnder()) {
            return;
        }
        Object object = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"mc.thePlayer.entityBoundingBox");
        if (BlockUtils.collideBlock((AxisAlignedBB)object, (Function1<? super Block, Boolean>)((Function1)onUpdate.1.INSTANCE)) || BlockUtils.collideBlock(new AxisAlignedBB(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxY, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxZ, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY - 0.01, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minZ), (Function1<? super Block, Boolean>)((Function1)onUpdate.2.INSTANCE))) {
            return;
        }
        if (this.matrixFlagWait > 0) {
            int n = this.matrixFlagWait;
            this.matrixFlagWait = n + -1;
            if (n == 0) {
                MinecraftInstance.mc.timer.timerSpeed = 1.0f;
            }
        }
        String string = (String)this.typeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        Object object2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (object2) {
            case "packet": {
                String string2 = (String)this.packetMode.get();
                object2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"getDefault()");
                String string3 = string2.toLowerCase((Locale)object2);
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toLowerCase(locale)");
                String string4 = string3;
                if (string4.equals("default")) {
                    if (!(MinecraftInstance.mc.thePlayer.fallDistance > 2.0f)) break;
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                    break;
                }
                if (!string4.equals("smart") || !((double)MinecraftInstance.mc.thePlayer.fallDistance - MinecraftInstance.mc.thePlayer.motionY > 3.0)) break;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                break;
            }
            case "cubecraft": {
                if (!(MinecraftInstance.mc.thePlayer.fallDistance > 2.0f)) break;
                MinecraftInstance.mc.thePlayer.onGround = true;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                break;
            }
            case "spartan": {
                this.spartanTimer.update();
                if (!(MinecraftInstance.mc.thePlayer.fallDistance > 1.5f) || !this.spartanTimer.hasTimePassed(10)) break;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (double)10, MinecraftInstance.mc.thePlayer.posZ, true));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - (double)10, MinecraftInstance.mc.thePlayer.posZ, true));
                this.spartanTimer.reset();
                break;
            }
            case "verus": {
                if (!((double)MinecraftInstance.mc.thePlayer.fallDistance - MinecraftInstance.mc.thePlayer.motionY > 3.0)) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 0.5;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 0.5;
                MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                this.needSpoof = true;
                break;
            }
            case "matrix": {
                String string5 = (String)this.matrixMode.get();
                object2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"getDefault()");
                String string6 = string5.toLowerCase((Locale)object2);
                Intrinsics.checkNotNullExpressionValue((Object)string6, (String)"this as java.lang.String).toLowerCase(locale)");
                switch (string6) {
                    case "old": {
                        if (!(MinecraftInstance.mc.thePlayer.fallDistance > 3.0f)) break;
                        this.isDmgFalling = true;
                        break;
                    }
                    case "6.6.3": {
                        if (!((double)MinecraftInstance.mc.thePlayer.fallDistance - MinecraftInstance.mc.thePlayer.motionY > 3.0)) break;
                        MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                        this.matrixSend = true;
                        MinecraftInstance.mc.timer.timerSpeed = 0.5f;
                        this.modifiedTimer = true;
                        break;
                    }
                    case "6.2.x": {
                        if (this.matrixFalling) {
                            MinecraftInstance.mc.thePlayer.motionX = 0.0;
                            MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                            MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                            if (MinecraftInstance.mc.thePlayer.onGround) {
                                this.matrixFalling = false;
                            }
                        }
                        if ((double)MinecraftInstance.mc.thePlayer.fallDistance - MinecraftInstance.mc.thePlayer.motionY > 3.0) {
                            this.matrixFalling = true;
                            if (this.matrixFallTicks == 0) {
                                this.matrixLastMotionY = MinecraftInstance.mc.thePlayer.motionY;
                            }
                            MinecraftInstance.mc.thePlayer.motionY = 0.0;
                            MinecraftInstance.mc.thePlayer.motionX = 0.0;
                            MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                            MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                            MinecraftInstance.mc.thePlayer.fallDistance = 3.2f;
                            int n = this.matrixFallTicks;
                            boolean bl = 8 <= n ? n < 10 : false;
                            if (bl) {
                                this.matrixCanSpoof = true;
                            }
                            n = this.matrixFallTicks;
                            this.matrixFallTicks = n + 1;
                        }
                        if (this.matrixFallTicks <= 12 || MinecraftInstance.mc.thePlayer.onGround) break;
                        MinecraftInstance.mc.thePlayer.motionY = this.matrixLastMotionY;
                        MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                        this.matrixFallTicks = 0;
                        this.matrixCanSpoof = false;
                    }
                }
                break;
            }
            case "aac": {
                String string7 = (String)this.aacMode.get();
                object2 = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object2, (String)"getDefault()");
                String string8 = string7.toLowerCase((Locale)object2);
                Intrinsics.checkNotNullExpressionValue((Object)string8, (String)"this as java.lang.String).toLowerCase(locale)");
                switch (string8) {
                    case "default": {
                        if (MinecraftInstance.mc.thePlayer.fallDistance > 2.0f) {
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                            this.oldaacState = 2;
                        } else if (this.oldaacState == 2 && MinecraftInstance.mc.thePlayer.fallDistance < 2.0f) {
                            MinecraftInstance.mc.thePlayer.motionY = 0.1;
                            this.oldaacState = 3;
                            return;
                        }
                        int n = this.oldaacState;
                        boolean bl = 3 <= n ? n < 6 : false;
                        if (!bl) break;
                        MinecraftInstance.mc.thePlayer.motionY = 0.1;
                        if (this.oldaacState != 5) break;
                        this.oldaacState = 1;
                        break;
                    }
                    case "laac": {
                        if (this.jumped || !MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.thePlayer.isOnLadder() || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInWeb) break;
                        MinecraftInstance.mc.thePlayer.motionY = -6.0;
                        break;
                    }
                    case "3.3.11": {
                        if (!(MinecraftInstance.mc.thePlayer.fallDistance > 2.0f)) break;
                        MinecraftInstance.mc.thePlayer.motionX = 0.0;
                        MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - 0.001, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.onGround));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                        break;
                    }
                    case "3.3.15": {
                        if (!(MinecraftInstance.mc.thePlayer.fallDistance > 2.0f)) break;
                        if (!MinecraftInstance.mc.isIntegratedServerRunning()) {
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, Double.NaN, MinecraftInstance.mc.thePlayer.posZ, false));
                        }
                        MinecraftInstance.mc.thePlayer.fallDistance = -9999.0f;
                        break;
                    }
                    case "loyisa4.4.2": 
                    case "5.0.4": {
                        if (MinecraftInstance.mc.thePlayer.fallDistance > 3.0f) {
                            this.isDmgFalling = true;
                        }
                        if (!StringsKt.equals((String)((String)this.aacMode.get()), (String)"loyisa4.4.2", (boolean)true)) break;
                        if (this.aac4FlagCount >= 3 || this.aac4FlagCooldown.hasTimePassed(1500L)) {
                            return;
                        }
                        if (this.aac4FlagCooldown.hasTimePassed(1500L) || !MinecraftInstance.mc.thePlayer.onGround && !((double)MinecraftInstance.mc.thePlayer.fallDistance < 0.5)) break;
                        MinecraftInstance.mc.thePlayer.motionX = 0.0;
                        MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                        MinecraftInstance.mc.thePlayer.onGround = false;
                        MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                        break;
                    }
                    case "5.0.14": {
                        this.aac5Check = false;
                        for (double offsetYs = 0.0; MinecraftInstance.mc.thePlayer.motionY - 1.5 < offsetYs; offsetYs -= 0.5) {
                            Block block;
                            BlockPos blockPos = new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + offsetYs, MinecraftInstance.mc.thePlayer.posZ);
                            Block block2 = block = BlockUtils.getBlock(blockPos);
                            Intrinsics.checkNotNull((Object)block2);
                            AxisAlignedBB axisAlignedBB = block2.getCollisionBoundingBox((World)MinecraftInstance.mc.theWorld, blockPos, BlockUtils.getState(blockPos));
                            if (axisAlignedBB == null) continue;
                            offsetYs = -999.9;
                            this.aac5Check = true;
                        }
                        if (MinecraftInstance.mc.thePlayer.onGround) {
                            MinecraftInstance.mc.thePlayer.fallDistance = -2.0f;
                            this.aac5Check = false;
                        }
                        if (this.aac5Timer > 0) {
                            int n = this.aac5Timer;
                            this.aac5Timer = n + -1;
                        }
                        if (this.aac5Check && (double)MinecraftInstance.mc.thePlayer.fallDistance > 2.5 && !MinecraftInstance.mc.thePlayer.onGround) {
                            this.aac5doFlag = true;
                            this.aac5Timer = 18;
                        } else if (this.aac5Timer < 2) {
                            this.aac5doFlag = false;
                        }
                        if (!this.aac5doFlag) break;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + (MinecraftInstance.mc.thePlayer.onGround ? 0.5 : 0.41999998688698), MinecraftInstance.mc.thePlayer.posZ, true));
                    }
                }
                break;
            }
            case "motion": {
                if (!(MinecraftInstance.mc.thePlayer.fallDistance > 3.0f)) break;
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.flySpeedValue.get()).floatValue();
                break;
            }
            case "edit": {
                if (!StringsKt.equals((String)((String)this.editMode.get()), (String)"smart", (boolean)true)) break;
                if ((int)MinecraftInstance.mc.thePlayer.fallDistance / 3 > this.lastFallDistRounded) {
                    this.lastFallDistRounded = (int)MinecraftInstance.mc.thePlayer.fallDistance / 3;
                    this.packetModify = true;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) break;
                this.lastFallDistRounded = 0;
                break;
            }
            case "hypixel": {
                if (!StringsKt.equals((String)((String)this.hypixelMode.get()), (String)"packet", (boolean)true)) break;
                double offset = 2.5;
                if (!MinecraftInstance.mc.thePlayer.onGround && (double)MinecraftInstance.mc.thePlayer.fallDistance - (double)this.matrixFallTicks * offset >= 0.0) {
                    MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer(true));
                    int n = this.matrixFallTicks;
                    this.matrixFallTicks = n + 1;
                    break;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) break;
                this.matrixFallTicks = 1;
            }
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Flight flight = Client.INSTANCE.getModuleManager().get(Flight.class);
        Intrinsics.checkNotNull((Object)flight);
        if (!flight.getState() && ((Boolean)this.voidCheckValue.get()).booleanValue() && !MovementUtils.isBlockUnder()) {
            return;
        }
        if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true) && StringsKt.equals((String)((String)this.aacMode.get()), (String)"4.x", (boolean)true) && event.getEventState() == EventState.PRE) {
            if (!this.inVoid()) {
                if (this.aac4Fakelag) {
                    this.aac4Fakelag = false;
                    if (this.aac4Packets.size() > 0) {
                        for (C03PacketPlayer packet : this.aac4Packets) {
                            MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)packet);
                        }
                        this.aac4Packets.clear();
                    }
                }
                return;
            }
            if (MinecraftInstance.mc.thePlayer.onGround && this.aac4Fakelag) {
                this.aac4Fakelag = false;
                if (this.aac4Packets.size() > 0) {
                    for (C03PacketPlayer packet : this.aac4Packets) {
                        MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)packet);
                    }
                    this.aac4Packets.clear();
                }
                return;
            }
            if ((double)MinecraftInstance.mc.thePlayer.fallDistance > 2.5 && this.aac4Fakelag) {
                this.packetModify = true;
                MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
            }
            if (this.inAir(4.0, 1.0)) {
                return;
            }
            if (!this.aac4Fakelag) {
                this.aac4Fakelag = true;
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        block36: {
            Packet<?> packet;
            block37: {
                Object object;
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (MinecraftInstance.mc.thePlayer == null) {
                    return;
                }
                Flight flight = Client.INSTANCE.getModuleManager().get(Flight.class);
                Intrinsics.checkNotNull((Object)flight);
                if (!flight.getState() && ((Boolean)this.voidCheckValue.get()).booleanValue() && !MovementUtils.isBlockUnder()) {
                    return;
                }
                packet = event.getPacket();
                if (packet instanceof S12PacketEntityVelocity && StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true) && StringsKt.equals((String)((String)this.aacMode.get()), (String)"4.4.x", (boolean)true) && (double)MinecraftInstance.mc.thePlayer.fallDistance > 1.8) {
                    ((S12PacketEntityVelocity)packet).motionY = (int)((double)((S12PacketEntityVelocity)packet).motionY * -0.1);
                }
                if (packet instanceof S08PacketPlayerPosLook) {
                    if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true) && StringsKt.equals((String)((String)this.aacMode.get()), (String)"loyisa4.4.2", (boolean)true)) {
                        int n = this.aac4FlagCount;
                        this.aac4FlagCount = n + 1;
                        if (this.matrixFlagWait > 0) {
                            this.aac4FlagCooldown.reset();
                            this.aac4FlagCount = 1;
                            event.cancelEvent();
                        }
                    }
                    if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"matrix", (boolean)true) && StringsKt.equals((String)((String)this.matrixMode.get()), (String)"old", (boolean)true) && this.matrixFlagWait > 0) {
                        this.matrixFlagWait = 0;
                        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
                        event.cancelEvent();
                    }
                }
                if (!(packet instanceof C03PacketPlayer)) break block36;
                if (this.matrixSend) {
                    this.matrixSend = false;
                    event.cancelEvent();
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, ((C03PacketPlayer)packet).y, ((C03PacketPlayer)packet).z, true)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, ((C03PacketPlayer)packet).y, ((C03PacketPlayer)packet).z, false)));
                }
                if (this.doSpoof) {
                    ((C03PacketPlayer)packet).onGround = true;
                    this.doSpoof = false;
                    ((C03PacketPlayer)packet).y = (double)Math.round(MinecraftInstance.mc.thePlayer.posY * (double)2) / (double)2;
                    MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, ((C03PacketPlayer)packet).y, MinecraftInstance.mc.thePlayer.posZ);
                }
                if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"edit", (boolean)true)) {
                    String edits = (String)this.editMode.get();
                    if (StringsKt.equals((String)edits, (String)"always", (boolean)true) || StringsKt.equals((String)edits, (String)"default", (boolean)true) && MinecraftInstance.mc.thePlayer.fallDistance > 2.5f || StringsKt.equals((String)edits, (String)"damage", (boolean)true) && MinecraftInstance.mc.thePlayer.fallDistance > 3.5f || StringsKt.equals((String)edits, (String)"smart", (boolean)true) && this.packetModify) {
                        ((C03PacketPlayer)packet).onGround = true;
                        this.packetModify = false;
                    }
                    if (StringsKt.equals((String)edits, (String)"noground", (boolean)true)) {
                        ((C03PacketPlayer)packet).onGround = false;
                    }
                }
                if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"medusa", (boolean)true) && MinecraftInstance.mc.thePlayer.fallDistance > 2.3f) {
                    event.cancelEvent();
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer(true)));
                    MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
                }
                if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"hypixel", (boolean)true)) {
                    String string = (String)this.hypixelMode.get();
                    Locale locale = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                    object = string.toLowerCase(locale);
                    Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
                    String edits = object;
                    if (edits.equals("default")) {
                        if ((double)MinecraftInstance.mc.thePlayer.fallDistance > 1.5) {
                            ((C03PacketPlayer)packet).onGround = MinecraftInstance.mc.thePlayer.ticksExisted % 2 == 0;
                        }
                    } else if (edits.equals("new") && MinecraftInstance.mc.thePlayer.fallDistance > 2.5f && MinecraftInstance.mc.thePlayer.ticksExisted % 2 == 0) {
                        ((C03PacketPlayer)packet).onGround = true;
                        ((C03PacketPlayer)packet).setMoving(false);
                    }
                }
                if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"verus", (boolean)true) && this.needSpoof) {
                    ((C03PacketPlayer)packet).onGround = true;
                    this.needSpoof = false;
                }
                C03PacketPlayer playerPacket = (C03PacketPlayer)event.getPacket();
                if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"nopacket", (boolean)true) && MinecraftInstance.mc.thePlayer != null && MinecraftInstance.mc.thePlayer.fallDistance > 2.0f && MinecraftInstance.mc.thePlayer.ticksExisted % 2 == 0) {
                    playerPacket.onGround = true;
                    playerPacket.setMoving(false);
                }
                if (!StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true)) break block37;
                String string = (String)this.aacMode.get();
                object = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDefault()");
                String string2 = string.toLowerCase((Locale)object);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                switch (string2) {
                    case "4.x": {
                        if (!this.aac4Fakelag) break;
                        event.cancelEvent();
                        if (this.packetModify) {
                            ((C03PacketPlayer)packet).onGround = true;
                            this.packetModify = false;
                        }
                        this.aac4Packets.add((C03PacketPlayer)packet);
                        break;
                    }
                    case "4.4.x": {
                        if (!((double)MinecraftInstance.mc.thePlayer.fallDistance > 1.6)) break;
                        ((C03PacketPlayer)packet).onGround = true;
                        break;
                    }
                    case "5.0.4": {
                        if (!this.isDmgFalling || !((C03PacketPlayer)packet).onGround || !MinecraftInstance.mc.thePlayer.onGround) break;
                        this.isDmgFalling = false;
                        ((C03PacketPlayer)packet).onGround = true;
                        MinecraftInstance.mc.thePlayer.onGround = false;
                        ((C03PacketPlayer)packet).y += 1.0;
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, ((C03PacketPlayer)packet).y - 1.0784, ((C03PacketPlayer)packet).z, false));
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, ((C03PacketPlayer)packet).y - 0.5, ((C03PacketPlayer)packet).z, true));
                    }
                }
            }
            if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"matrix", (boolean)true) && StringsKt.equals((String)((String)this.matrixMode.get()), (String)"6.2.x", (boolean)true) && this.matrixCanSpoof) {
                ((C03PacketPlayer)packet).onGround = true;
                this.matrixCanSpoof = false;
            }
            if (this.isDmgFalling && (StringsKt.equals((String)((String)this.typeValue.get()), (String)"matrix", (boolean)true) && StringsKt.equals((String)((String)this.matrixMode.get()), (String)"old", (boolean)true) || StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true) && StringsKt.equals((String)((String)this.aacMode.get()), (String)"loyisa4.4.2", (boolean)true)) && ((C03PacketPlayer)packet).onGround && MinecraftInstance.mc.thePlayer.onGround) {
                this.matrixFlagWait = 2;
                this.isDmgFalling = false;
                event.cancelEvent();
                MinecraftInstance.mc.thePlayer.onGround = false;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, ((C03PacketPlayer)packet).y - (double)256, ((C03PacketPlayer)packet).z, false));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(((C03PacketPlayer)packet).x, -10.0, ((C03PacketPlayer)packet).z, true));
                MinecraftInstance.mc.timer.timerSpeed = 0.18f;
                this.modifiedTimer = true;
            }
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Flight flight = Client.INSTANCE.getModuleManager().get(Flight.class);
        Intrinsics.checkNotNull((Object)flight);
        if (!flight.getState() && ((Boolean)this.voidCheckValue.get()).booleanValue() && !MovementUtils.isBlockUnder()) {
            return;
        }
        AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
        Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBoundingBox");
        if (BlockUtils.collideBlock(axisAlignedBB, (Function1<? super Block, Boolean>)((Function1)onMove.1.INSTANCE)) || BlockUtils.collideBlock(new AxisAlignedBB(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxY, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxZ, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY - 0.01, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minZ), (Function1<? super Block, Boolean>)((Function1)onMove.2.INSTANCE))) {
            return;
        }
        if (StringsKt.equals((String)((String)this.typeValue.get()), (String)"aac", (boolean)true) && StringsKt.equals((String)((String)this.aacMode.get()), (String)"laac", (boolean)true) && !this.jumped && !MinecraftInstance.mc.thePlayer.onGround && !MinecraftInstance.mc.thePlayer.isOnLadder() && !MinecraftInstance.mc.thePlayer.isInWater() && !MinecraftInstance.mc.thePlayer.isInWeb && MinecraftInstance.mc.thePlayer.motionY < 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.jumped = true;
    }

    private final boolean inVoid() {
        if (MinecraftInstance.mc.thePlayer.posY < 0.0) {
            return false;
        }
        int off = 0;
        while ((double)off < MinecraftInstance.mc.thePlayer.posY + (double)2) {
            AxisAlignedBB bb = new AxisAlignedBB(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.posX, (double)off, MinecraftInstance.mc.thePlayer.posZ);
            if (!MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, bb).isEmpty()) {
                return true;
            }
            off += 2;
        }
        return false;
    }

    private final boolean inAir(double height, double plus) {
        if (MinecraftInstance.mc.thePlayer.posY < 0.0) {
            return false;
        }
        int off = 0;
        while ((double)off < height) {
            AxisAlignedBB bb = new AxisAlignedBB(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY - (double)off, MinecraftInstance.mc.thePlayer.posZ);
            if (!MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, bb).isEmpty()) {
                return true;
            }
            off += (int)plus;
        }
        return false;
    }

    @Override
    public String getTag() {
        return (String)this.typeValue.get();
    }
}

