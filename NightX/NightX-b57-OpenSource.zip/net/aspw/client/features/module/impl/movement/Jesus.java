/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Jesus;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Jesus", spacedName="Jesus", description="", category=ModuleCategory.MOVEMENT)
public final class Jesus
extends Module {
    @JvmField
    public final ListValue modeValue;
    private final FloatValue aacFlyValue;
    private boolean nextTick;

    public Jesus() {
        String[] stringArray = new String[]{"Vanilla", "NCP", "Bounce", "AAC", "AACFly", "AAC3.3.11", "AAC4.2.1", "Horizon1.4.6", "Twillight", "MatrixFast", "MatrixDolphin", "Dolphin", "Swim"};
        this.modeValue = new ListValue("Mode", stringArray, "NCP");
        this.aacFlyValue = new FloatValue("Motion", 0.5f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Jesus this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return ((String)this.this$0.modeValue.get()).equals("AACFly");
            }
        }));
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.thePlayer.isSneaking()) {
            return;
        }
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "ncp": 
            case "vanilla": {
                AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
                Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBoundingBox");
                if (!BlockUtils.collideBlock(axisAlignedBB, (Function1<? super Block, Boolean>)((Function1)onUpdate.1.INSTANCE)) || !MinecraftInstance.mc.thePlayer.isInsideOfMaterial(Material.air) || MinecraftInstance.mc.thePlayer.isSneaking()) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.08;
                break;
            }
            case "bounce": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.7;
                break;
            }
            case "aac": {
                BlockPos blockPos = MinecraftInstance.mc.thePlayer.getPosition().down();
                if (!MinecraftInstance.mc.thePlayer.onGround && BlockUtils.getBlock(blockPos) == Blocks.water || MinecraftInstance.mc.thePlayer.isInWater()) {
                    if (!MinecraftInstance.mc.thePlayer.isSprinting()) {
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionX *= 0.99999;
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionY *= 0.0;
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionZ *= 0.99999;
                        if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                            MinecraftInstance.mc.thePlayer.motionY = (float)((int)(MinecraftInstance.mc.thePlayer.posY - (double)((int)(MinecraftInstance.mc.thePlayer.posY - 1.0)))) / 8.0f;
                        }
                    } else {
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionX *= 0.99999;
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionY *= 0.0;
                        locale = MinecraftInstance.mc.thePlayer;
                        ((EntityPlayerSP)locale).motionZ *= 0.99999;
                        if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                            MinecraftInstance.mc.thePlayer.motionY = (float)((int)(MinecraftInstance.mc.thePlayer.posY - (double)((int)(MinecraftInstance.mc.thePlayer.posY - 1.0)))) / 8.0f;
                        }
                    }
                    if (MinecraftInstance.mc.thePlayer.fallDistance >= 4.0f) {
                        MinecraftInstance.mc.thePlayer.motionY = -0.004;
                    } else if (MinecraftInstance.mc.thePlayer.isInWater()) {
                        MinecraftInstance.mc.thePlayer.motionY = 0.09;
                    }
                }
                if (MinecraftInstance.mc.thePlayer.hurtTime == 0) break;
                MinecraftInstance.mc.thePlayer.onGround = false;
                break;
            }
            case "matrixfast": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.0;
                MovementUtils.strafe(0.6f);
                break;
            }
            case "matrixdolphin": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.6;
                break;
            }
            case "aac3.3.11": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 1.17;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ *= 1.17;
                if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.24;
                    break;
                }
                if (MinecraftInstance.mc.theWorld.getBlockState(new BlockPos(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 1.0, MinecraftInstance.mc.thePlayer.posZ)).getBlock() == Blocks.air) break;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.04;
                break;
            }
            case "dolphin": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += (double)0.04f;
                break;
            }
            case "aac4.2.1": {
                if ((MinecraftInstance.mc.thePlayer.onGround || BlockUtils.getBlock(MinecraftInstance.mc.thePlayer.getPosition().down()) != Blocks.water) && !MinecraftInstance.mc.thePlayer.isInWater()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY *= 0.0;
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.08f;
                if (MinecraftInstance.mc.thePlayer.fallDistance > 0.0f) {
                    return;
                }
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = true;
                break;
            }
            case "horizon1.4.6": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                MovementUtils.strafe();
                MinecraftInstance.mc.gameSettings.keyBindJump.pressed = true;
                if (!MovementUtils.isMoving() || MinecraftInstance.mc.thePlayer.onGround) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.13;
                break;
            }
            case "twillight": {
                if (!MinecraftInstance.mc.thePlayer.isInWater()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX *= 1.04;
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ *= 1.04;
                MovementUtils.strafe();
            }
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer.isInWater()) {
            MinecraftInstance.mc.thePlayer.motionX = 0.0;
            MinecraftInstance.mc.thePlayer.motionZ = 0.0;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        if ("aacfly".equals(string2) && MinecraftInstance.mc.thePlayer.isInWater()) {
            event.setY(((Number)this.aacFlyValue.get()).floatValue());
            MinecraftInstance.mc.thePlayer.motionY = ((Number)this.aacFlyValue.get()).floatValue();
        }
        if (StringsKt.equals((String)"twillight", (String)((String)this.modeValue.get()), (boolean)true) && MinecraftInstance.mc.thePlayer.isInWater()) {
            event.setY(0.01);
            MinecraftInstance.mc.thePlayer.motionY = 0.01;
        }
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.thePlayer.getEntityBoundingBox() == null) {
            return;
        }
        if (event.getBlock() instanceof BlockLiquid) {
            Object object = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"mc.thePlayer.entityBoundingBox");
            if (!BlockUtils.collideBlock((AxisAlignedBB)object, (Function1<? super Block, Boolean>)((Function1)onBlockBB.1.INSTANCE)) && !MinecraftInstance.mc.thePlayer.isSneaking()) {
                String string = (String)this.modeValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                object = string2;
                if (object.equals("ncp") ? true : object.equals("vanilla")) {
                    event.setBoundingBox(AxisAlignedBB.fromBounds((double)event.getX(), (double)event.getY(), (double)event.getZ(), (double)(event.getX() + 1), (double)(event.getY() + 1), (double)(event.getZ() + 1)));
                }
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null || !StringsKt.equals((String)((String)this.modeValue.get()), (String)"NCP", (boolean)true)) {
            return;
        }
        if (event.getPacket() instanceof C03PacketPlayer && BlockUtils.collideBlock(new AxisAlignedBB(MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxY, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().maxZ, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY - 0.01, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minZ), (Function1<? super Block, Boolean>)((Function1)onPacket.1.INSTANCE))) {
            boolean bl = this.nextTick = !this.nextTick;
            if (this.nextTick) {
                Packet<?> packet = event.getPacket();
                ((C03PacketPlayer)packet).y -= 0.001;
            }
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

