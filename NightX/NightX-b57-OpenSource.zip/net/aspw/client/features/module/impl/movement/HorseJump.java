/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;

@ModuleInfo(name="HorseJump", spacedName="Horse Jump", description="", category=ModuleCategory.MOVEMENT)
public final class HorseJump
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        MinecraftInstance.mc.thePlayer.horseJumpPowerCounter = 9;
        MinecraftInstance.mc.thePlayer.horseJumpPower = 1.0f;
    }
}

