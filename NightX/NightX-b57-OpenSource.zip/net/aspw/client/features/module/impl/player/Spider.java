/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.player;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.player.Spider;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;

@ModuleInfo(name="Spider", spacedName="Spider", description="", category=ModuleCategory.PLAYER)
public final class Spider
extends Module {
    private final ListValue modeValue;
    private final ListValue clipMode;
    private final FloatValue checkerClimbMotionValue;
    private final FloatValue verusClimbSpeed;
    private boolean glitch;
    private boolean canClimb;
    private int waited;
    private final TickTimer tickTimer;

    public Spider() {
        String[] stringArray = new String[]{"Simple", "Jump", "CheckerClimb", "Clip", "AAC3.3.12", "AACGlide", "Verus"};
        this.modeValue = new ListValue("Mode", stringArray, "Simple");
        stringArray = new String[]{"Jump", "Fast"};
        this.clipMode = new ListValue("ClipMode", stringArray, "Jump", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Spider this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)Spider.access$getModeValue$p(this.this$0).get()), (String)"clip", (boolean)true);
            }
        }));
        this.checkerClimbMotionValue = new FloatValue("CheckerClimbMotion", 0.0f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Spider this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)Spider.access$getModeValue$p(this.this$0).get()), (String)"checkerclimb", (boolean)true);
            }
        }));
        this.verusClimbSpeed = new FloatValue("VerusClimbSpeed", 0.2f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Spider this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)Spider.access$getModeValue$p(this.this$0).get()), (String)"verus", (boolean)true);
            }
        }));
        this.tickTimer = new TickTimer();
    }

    @Override
    public void onEnable() {
        this.glitch = false;
        this.canClimb = false;
        this.waited = 0;
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.thePlayer.isCollidedHorizontally || MinecraftInstance.mc.thePlayer.isOnLadder() || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInLava()) {
            return;
        }
        if (StringsKt.equals((String)"simple", (String)((String)this.modeValue.get()), (boolean)true)) {
            event.setY(0.2);
            MinecraftInstance.mc.thePlayer.motionY = 0.0;
        }
    }

    @EventTarget
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"verus", (boolean)true) && this.canClimb) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() != EventState.POST) {
            return;
        }
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        Object object = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (object) {
            case "jump": {
                this.tickTimer.update();
                if (!this.tickTimer.hasTimePassed(8) || !MinecraftInstance.mc.thePlayer.isCollidedHorizontally) break;
                MinecraftInstance.mc.thePlayer.motionY = 0.41999998688698;
                this.tickTimer.reset();
                break;
            }
            case "clip": {
                if (MinecraftInstance.mc.thePlayer.motionY < 0.0) {
                    this.glitch = true;
                }
                if (!MinecraftInstance.mc.thePlayer.isCollidedHorizontally) break;
                String string2 = (String)this.clipMode.get();
                object = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDefault()");
                String string3 = string2.toLowerCase((Locale)object);
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toLowerCase(locale)");
                String string4 = string3;
                if (string4.equals("jump")) {
                    if (!MinecraftInstance.mc.thePlayer.onGround) break;
                    MinecraftInstance.mc.thePlayer.jump();
                    break;
                }
                if (!string4.equals("fast")) break;
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.42;
                    break;
                }
                if (!(MinecraftInstance.mc.thePlayer.motionY < 0.0)) break;
                MinecraftInstance.mc.thePlayer.motionY = -0.3;
                break;
            }
            case "checkerclimb": {
                locale = MinecraftInstance.mc.thePlayer.getEntityBoundingBox();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"mc.thePlayer.entityBoundingBox");
                boolean isInsideBlock2 = BlockUtils.collideBlockIntersects((AxisAlignedBB)locale, (Function1<? super Block, Boolean>)((Function1)onUpdate.isInsideBlock.1.INSTANCE));
                float motion = ((Number)this.checkerClimbMotionValue.get()).floatValue();
                if (!isInsideBlock2 || motion == 0.0f) break;
                MinecraftInstance.mc.thePlayer.motionY = motion;
                break;
            }
            case "aac3.3.12": {
                if (MinecraftInstance.mc.thePlayer.isCollidedHorizontally && !MinecraftInstance.mc.thePlayer.isOnLadder()) {
                    int n = this.waited;
                    this.waited = n + 1;
                    if (this.waited == 1) {
                        MinecraftInstance.mc.thePlayer.motionY = 0.43;
                    }
                    if (this.waited == 12) {
                        MinecraftInstance.mc.thePlayer.motionY = 0.43;
                    }
                    if (this.waited == 23) {
                        MinecraftInstance.mc.thePlayer.motionY = 0.43;
                    }
                    if (this.waited == 29) {
                        MinecraftInstance.mc.thePlayer.setPosition(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY + 0.5, MinecraftInstance.mc.thePlayer.posZ);
                    }
                    if (this.waited < 30) break;
                    this.waited = 0;
                    break;
                }
                if (!MinecraftInstance.mc.thePlayer.onGround) break;
                this.waited = 0;
                break;
            }
            case "aacglide": {
                if (!MinecraftInstance.mc.thePlayer.isCollidedHorizontally || MinecraftInstance.mc.thePlayer.isOnLadder()) {
                    return;
                }
                MinecraftInstance.mc.thePlayer.motionY = -0.189;
                break;
            }
            case "verus": {
                if (!MinecraftInstance.mc.thePlayer.isCollidedHorizontally || MinecraftInstance.mc.thePlayer.isInWater() || MinecraftInstance.mc.thePlayer.isInLava() || MinecraftInstance.mc.thePlayer.isOnLadder() || MinecraftInstance.mc.thePlayer.isInWeb || MinecraftInstance.mc.thePlayer.isOnLadder()) {
                    this.canClimb = false;
                    break;
                }
                this.canClimb = true;
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.verusClimbSpeed.get()).floatValue();
                MinecraftInstance.mc.thePlayer.onGround = true;
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            Packet<?> packetPlayer = packet;
            if (this.glitch) {
                float yaw = (float)MovementUtils.getDirection();
                ((C03PacketPlayer)packetPlayer).x -= (double)MathHelper.sin((float)yaw) * 1.0E-8;
                ((C03PacketPlayer)packetPlayer).z += (double)MathHelper.cos((float)yaw) * 1.0E-8;
                this.glitch = false;
            }
            if (this.canClimb) {
                ((C03PacketPlayer)packetPlayer).onGround = true;
            }
        }
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        String mode = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = mode.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
        String string2 = string;
        if (string2.equals("checkerclimb")) {
            if ((double)event.getY() > MinecraftInstance.mc.thePlayer.posY) {
                event.setBoundingBox(null);
            }
        } else if (string2.equals("clip") && event.getBlock() != null && MinecraftInstance.mc.thePlayer != null && event.getBlock() instanceof BlockAir && (double)event.getY() < MinecraftInstance.mc.thePlayer.posY && MinecraftInstance.mc.thePlayer.isCollidedHorizontally && !MinecraftInstance.mc.thePlayer.isOnLadder() && !MinecraftInstance.mc.thePlayer.isInWater() && !MinecraftInstance.mc.thePlayer.isInLava()) {
            event.setBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0).offset(MinecraftInstance.mc.thePlayer.posX, (double)((int)MinecraftInstance.mc.thePlayer.posY - 1), MinecraftInstance.mc.thePlayer.posZ));
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(Spider $this) {
        return $this.modeValue;
    }
}

