/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Pair
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.IntIterator
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.IntRange
 *  net.minecraft.block.Block
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.ai.attributes.AttributeModifier
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.ClickBlockEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.item.ItemUtils;
import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;

@ModuleInfo(name="AutoTool", spacedName="Auto Tool", description="", category=ModuleCategory.PLAYER)
public final class AutoTool
extends Module {
    private boolean attackEnemy;
    private int spoofedSlot;

    @EventTarget
    public final void onClick(ClickBlockEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.thePlayer.isUsingItem()) {
            BlockPos blockPos = event.getClickedBlock();
            if (blockPos == null) {
                return;
            }
            this.switchSlot(blockPos);
        }
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.attackEnemy = true;
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof C02PacketUseEntity && ((C02PacketUseEntity)event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK && this.attackEnemy) {
            Object v0;
            void $this$filterTo$iv$iv;
            Iterable $this$mapTo$iv$iv;
            this.attackEnemy = false;
            Iterable $this$map$iv = (Iterable)new IntRange(0, 8);
            boolean $i$f$map = false;
            Iterable iterable = $this$map$iv;
            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv, (int)10));
            boolean $i$f$mapTo = false;
            Iterator iterator = $this$mapTo$iv$iv.iterator();
            while (iterator.hasNext()) {
                void it;
                int item$iv$iv;
                int n = item$iv$iv = ((IntIterator)iterator).nextInt();
                Collection collection = destination$iv$iv;
                boolean bl = false;
                collection.add(new Pair((Object)((int)it), (Object)MinecraftInstance.mc.thePlayer.inventory.getStackInSlot((int)it)));
            }
            Iterable $this$filter$iv = (List)destination$iv$iv;
            boolean $i$f$filter = false;
            $this$mapTo$iv$iv = $this$filter$iv;
            destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                Pair it2 = (Pair)element$iv$iv;
                boolean bl = false;
                if (!(it2.getSecond() != null && ((ItemStack)it2.getSecond()).getItem() instanceof ItemSword)) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            Iterable $this$maxByOrNull$iv = (List)destination$iv$iv;
            boolean $i$f$maxByOrNull = false;
            Iterator iterator$iv = $this$maxByOrNull$iv.iterator();
            if (!iterator$iv.hasNext()) {
                v0 = null;
            } else {
                Object maxElem$iv = iterator$iv.next();
                if (!iterator$iv.hasNext()) {
                    v0 = maxElem$iv;
                } else {
                    Pair it = (Pair)maxElem$iv;
                    boolean bl = false;
                    Collection element$iv$iv = ((ItemStack)it.getSecond()).getAttributeModifiers().get((Object)"generic.attackDamage");
                    Intrinsics.checkNotNullExpressionValue((Object)element$iv$iv, (String)"it.second.attributeModif\u2026s[\"generic.attackDamage\"]");
                    AttributeModifier it2 = (AttributeModifier)CollectionsKt.first((Iterable)element$iv$iv);
                    double maxValue$iv = (it2 == null ? 0.0 : (element$iv$iv = it2.getAmount())) + 1.25 * (double)ItemUtils.getEnchantment((ItemStack)it.getSecond(), Enchantment.sharpness);
                    do {
                        double d;
                        Object e$iv = iterator$iv.next();
                        Pair it3 = (Pair)e$iv;
                        $i$a$-maxByOrNull-AutoTool$onPacket$3 = false;
                        Collection collection = ((ItemStack)it3.getSecond()).getAttributeModifiers().get((Object)"generic.attackDamage");
                        Intrinsics.checkNotNullExpressionValue((Object)collection, (String)"it.second.attributeModif\u2026s[\"generic.attackDamage\"]");
                        AttributeModifier attributeModifier = (AttributeModifier)CollectionsKt.first((Iterable)collection);
                        double v$iv = (attributeModifier == null ? 0.0 : (d = attributeModifier.getAmount())) + 1.25 * (double)ItemUtils.getEnchantment((ItemStack)it3.getSecond(), Enchantment.sharpness);
                        if (Double.compare(maxValue$iv, v$iv) >= 0) continue;
                        maxElem$iv = e$iv;
                        maxValue$iv = v$iv;
                    } while (iterator$iv.hasNext());
                    v0 = maxElem$iv;
                }
            }
            Pair pair = v0;
            if (pair == null) {
                return;
            }
            int slot = ((Number)pair.component1()).intValue();
            if (slot == MinecraftInstance.mc.thePlayer.inventory.currentItem) {
                return;
            }
            MinecraftInstance.mc.thePlayer.inventory.currentItem = slot;
            MinecraftInstance.mc.playerController.updateController();
            MinecraftInstance.mc.getNetHandler().addToSendQueue(event.getPacket());
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent update) {
        Intrinsics.checkNotNullParameter((Object)update, (String)"update");
        if (this.spoofedSlot > 0) {
            if (this.spoofedSlot == 1) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.thePlayer.inventory.currentItem));
            }
            int n = this.spoofedSlot;
            this.spoofedSlot = n + -1;
        }
    }

    public final void switchSlot(BlockPos blockPos) {
        Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
        float bestSpeed = 1.0f;
        int bestSlot = -1;
        Block block = MinecraftInstance.mc.theWorld.getBlockState(blockPos).getBlock();
        int n = 0;
        while (n < 9) {
            ItemStack item;
            float speed2;
            int i;
            if (MinecraftInstance.mc.thePlayer.inventory.getStackInSlot(i = n++) == null || !((speed2 = item.getStrVsBlock(block)) > bestSpeed)) continue;
            bestSpeed = speed2;
            bestSlot = i;
        }
        if (bestSlot != -1) {
            MinecraftInstance.mc.thePlayer.inventory.currentItem = bestSlot;
        }
    }
}

