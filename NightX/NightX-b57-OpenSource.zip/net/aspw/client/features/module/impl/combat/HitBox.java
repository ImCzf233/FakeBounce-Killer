/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.combat;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.FloatValue;

@ModuleInfo(name="HitBox", spacedName="Hit Box", description="", category=ModuleCategory.COMBAT)
public final class HitBox
extends Module {
    private final FloatValue sizeValue = new FloatValue("Size", 1.0f, 0.0f, 1.0f);

    public final FloatValue getSizeValue() {
        return this.sizeValue;
    }

    @Override
    public String getTag() {
        return String.valueOf(((Number)this.sizeValue.get()).floatValue());
    }
}

