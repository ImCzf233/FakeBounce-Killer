/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class SlowHop
extends SpeedMode {
    public SlowHop() {
        super("SlowHop");
    }

    @Override
    public void onMotion() {
        if (SlowHop.mc.thePlayer.isInWater()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (SlowHop.mc.thePlayer.onGround && SlowHop.mc.thePlayer.jumpTicks == 0) {
                SlowHop.mc.thePlayer.jump();
                SlowHop.mc.thePlayer.jumpTicks = 10;
            } else {
                MovementUtils.strafe(MovementUtils.getSpeed() * 1.011f);
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

