/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C01PacketChatMessage
 *  net.minecraft.network.play.server.S02PacketChat
 *  net.minecraft.network.play.server.S45PacketTitle
 *  net.minecraft.util.IChatComponent
 */
package net.aspw.client.features.module.impl.other;

import java.util.ArrayList;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.TextValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S45PacketTitle;
import net.minecraft.util.IChatComponent;

@ModuleInfo(name="AutoAuth", spacedName="Auto Auth", description="", category=ModuleCategory.OTHER)
public final class AutoAuth
extends Module {
    private final TextValue password = new TextValue("Password", "Aspw95639535");
    private final TextValue regRegex = new TextValue("Register-Regex", "/register");
    private final TextValue loginRegex = new TextValue("Login-Regex", "/login");
    private final TextValue regCmd = new TextValue("Register-Cmd", "/register Aspw95639535 Aspw95639535");
    private final TextValue loginCmd = new TextValue("Login-Cmd", "/login Aspw95639535");
    private final IntegerValue delayValue = new IntegerValue("Delay", 5000, 0, 5000, "ms");
    private final ArrayList<C01PacketChatMessage> loginPackets = new ArrayList();
    private final ArrayList<C01PacketChatMessage> registerPackets = new ArrayList();
    private final MSTimer regTimer = new MSTimer();
    private final MSTimer logTimer = new MSTimer();

    @Override
    public void onEnable() {
        this.resetEverything();
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.resetEverything();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.registerPackets.isEmpty()) {
            this.regTimer.reset();
        } else if (this.regTimer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
            for (C01PacketChatMessage packet : this.registerPackets) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)packet));
            }
            Client.INSTANCE.getHud().addNotification(new Notification("Successfully registered.", Notification.Type.SUCCESS));
            this.registerPackets.clear();
            this.regTimer.reset();
        }
        if (this.loginPackets.isEmpty()) {
            this.logTimer.reset();
        } else if (this.logTimer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
            for (C01PacketChatMessage packet : this.loginPackets) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)packet));
            }
            Client.INSTANCE.getHud().addNotification(new Notification("Successfully logined.", Notification.Type.SUCCESS));
            this.loginPackets.clear();
            this.logTimer.reset();
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (packet instanceof S45PacketTitle) {
            IChatComponent iChatComponent = ((S45PacketTitle)packet).getMessage();
            if (iChatComponent == null) {
                return;
            }
            IChatComponent messageOrigin = iChatComponent;
            String string = messageOrigin.getUnformattedText();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"messageOrigin.unformattedText");
            String message = string;
            if (StringsKt.contains((CharSequence)message, (CharSequence)((CharSequence)this.loginRegex.get()), (boolean)true)) {
                this.sendLogin(StringsKt.replace((String)((String)this.loginCmd.get()), (String)"%p", (String)((String)this.password.get()), (boolean)true));
            }
            if (StringsKt.contains((CharSequence)message, (CharSequence)((CharSequence)this.regRegex.get()), (boolean)true)) {
                this.sendRegister(StringsKt.replace((String)((String)this.regCmd.get()), (String)"%p", (String)((String)this.password.get()), (boolean)true));
            }
        }
        if (packet instanceof S02PacketChat) {
            String string = ((S02PacketChat)packet).getChatComponent().getUnformattedText();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"packet.chatComponent.unformattedText");
            String message = string;
            if (StringsKt.contains((CharSequence)message, (CharSequence)((CharSequence)this.loginRegex.get()), (boolean)true)) {
                this.sendLogin(StringsKt.replace((String)((String)this.loginCmd.get()), (String)"%p", (String)((String)this.password.get()), (boolean)true));
            }
            if (StringsKt.contains((CharSequence)message, (CharSequence)((CharSequence)this.regRegex.get()), (boolean)true)) {
                this.sendRegister(StringsKt.replace((String)((String)this.regCmd.get()), (String)"%p", (String)((String)this.password.get()), (boolean)true));
            }
        }
    }

    private final boolean sendLogin(String str) {
        return this.loginPackets.add(new C01PacketChatMessage(str));
    }

    private final boolean sendRegister(String str) {
        return this.registerPackets.add(new C01PacketChatMessage(str));
    }

    private final void resetEverything() {
        this.registerPackets.clear();
        this.loginPackets.clear();
        this.regTimer.reset();
        this.logTimer.reset();
    }
}

