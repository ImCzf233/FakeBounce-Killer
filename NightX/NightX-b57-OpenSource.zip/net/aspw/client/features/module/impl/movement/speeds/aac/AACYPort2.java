/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACYPort2
extends SpeedMode {
    public AACYPort2() {
        super("AACYPort2");
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving() && AACYPort2.mc.thePlayer.onGround) {
            AACYPort2.mc.thePlayer.jump();
            AACYPort2.mc.thePlayer.motionY = 0.3851f;
            AACYPort2.mc.thePlayer.motionX *= 1.01;
            AACYPort2.mc.thePlayer.motionZ *= 1.01;
        } else {
            AACYPort2.mc.thePlayer.motionY = -0.21;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

