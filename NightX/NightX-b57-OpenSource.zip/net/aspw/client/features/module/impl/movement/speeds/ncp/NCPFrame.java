/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.timer.TickTimer;

public class NCPFrame
extends SpeedMode {
    private final TickTimer tickTimer = new TickTimer();
    private int motionTicks;
    private boolean move;

    public NCPFrame() {
        super("NCPFrame");
    }

    @Override
    public void onMotion() {
        if (NCPFrame.mc.thePlayer.movementInput.moveForward > 0.0f || NCPFrame.mc.thePlayer.movementInput.moveStrafe > 0.0f) {
            double speed2 = 4.25;
            if (NCPFrame.mc.thePlayer.onGround) {
                NCPFrame.mc.thePlayer.jump();
                if (this.motionTicks == 1) {
                    this.tickTimer.reset();
                    if (this.move) {
                        NCPFrame.mc.thePlayer.motionX = 0.0;
                        NCPFrame.mc.thePlayer.motionZ = 0.0;
                        this.move = false;
                    }
                    this.motionTicks = 0;
                } else {
                    this.motionTicks = 1;
                }
            } else if (!this.move && this.motionTicks == 1 && this.tickTimer.hasTimePassed(5)) {
                NCPFrame.mc.thePlayer.motionX *= 4.25;
                NCPFrame.mc.thePlayer.motionZ *= 4.25;
                this.move = true;
            }
            if (!NCPFrame.mc.thePlayer.onGround) {
                MovementUtils.strafe();
            }
            this.tickTimer.update();
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPFrame.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPFrame.mc.thePlayer.motionX = 0.0;
            NCPFrame.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

