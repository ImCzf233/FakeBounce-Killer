/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.item.ItemEnderPearl
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.PosLookInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="LongJump", spacedName="Long Jump", description="", category=ModuleCategory.MOVEMENT)
public final class LongJump
extends Module {
    private final ListValue modeValue;
    private final FloatValue ncpBoostValue;
    private final FloatValue matrixBoostValue;
    private final FloatValue matrixHeightValue;
    private final BoolValue matrixSilentValue;
    private final ListValue matrixBypassModeValue;
    private final BoolValue matrixDebugValue;
    private final BoolValue redeskyTimerBoostValue;
    private final FloatValue redeskyTimerBoostStartValue;
    private final FloatValue redeskyTimerBoostEndValue;
    private final IntegerValue redeskyTimerBoostSlowDownSpeedValue;
    private final BoolValue redeskyGlideAfterTicksValue;
    private final IntegerValue redeskyTickValue;
    private final FloatValue redeskyYMultiplier;
    private final FloatValue redeskyXZMultiplier;
    private final ListValue verusDmgModeValue;
    private final FloatValue verusBoostValue;
    private final FloatValue verusHeightValue;
    private final FloatValue verusTimerValue;
    private final FloatValue pearlBoostValue;
    private final FloatValue pearlHeightValue;
    private final FloatValue pearlTimerValue;
    private final BoolValue autoDisableValue;
    private final BoolValue fakeDmgValue;
    private final BoolValue fakeYValue;
    private final BoolValue viewBobbingValue;
    private final FloatValue bobbingAmountValue;
    private final MSTimer dmgTimer;
    private final PosLookInstance posLookInstance;
    private boolean hasJumped;
    private boolean no;
    private boolean jumped;
    private int jumpState;
    private boolean canBoost;
    private boolean teleported;
    private boolean canMineplexBoost;
    private int ticks;
    private float currentTimer;
    private boolean verusDmged;
    private boolean hpxDamage;
    private boolean damaged;
    private int verusJumpTimes;
    private int pearlState;
    private double lastMotX;
    private double lastMotY;
    private double lastMotZ;
    private double y;
    private boolean flagged;
    private boolean hasFell;

    public LongJump() {
        String[] stringArray = new String[]{"NCP", "AACv1", "AACv2", "AACv3", "AACv4", "Mineplex1", "Mineplex2", "Mineplex3", "RedeskyMaki", "Redesky", "InfiniteRedesky", "MatrixFlag", "VerusDmg", "Pearl"};
        this.modeValue = new ListValue("Mode", stringArray, "NCP");
        this.ncpBoostValue = new FloatValue("NCP-Boost", 20.0f, 10.0f, 40.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"ncp", (boolean)true);
            }
        }));
        this.matrixBoostValue = new FloatValue("MatrixFlag-Boost", 2.0f, 0.0f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"matrixflag", (boolean)true);
            }
        }));
        this.matrixHeightValue = new FloatValue("MatrixFlag-Height", 3.0f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"matrixflag", (boolean)true);
            }
        }));
        this.matrixSilentValue = new BoolValue("MatrixFlag-Silent", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"matrixflag", (boolean)true);
            }
        }));
        stringArray = new String[]{"Motion", "Clip", "None"};
        this.matrixBypassModeValue = new ListValue("MatrixFlag-BypassMode", stringArray, "Clip", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"matrixflag", (boolean)true);
            }
        }));
        this.matrixDebugValue = new BoolValue("MatrixFlag-Debug", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"matrixflag", (boolean)true);
            }
        }));
        this.redeskyTimerBoostValue = new BoolValue("Redesky-TimerBoost", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true);
            }
        }));
        this.redeskyTimerBoostStartValue = new FloatValue("Redesky-TimerBoostStart", 1.85f, 0.05f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true) && (Boolean)LongJump.access$getRedeskyTimerBoostValue$p(this.this$0).get() != false;
            }
        }));
        this.redeskyTimerBoostEndValue = new FloatValue("Redesky-TimerBoostEnd", 1.0f, 0.05f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true) && (Boolean)LongJump.access$getRedeskyTimerBoostValue$p(this.this$0).get() != false;
            }
        }));
        this.redeskyTimerBoostSlowDownSpeedValue = new IntegerValue("Redesky-TimerBoost-SlowDownSpeed", 2, 1, 10, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true) && (Boolean)LongJump.access$getRedeskyTimerBoostValue$p(this.this$0).get() != false;
            }
        }));
        this.redeskyGlideAfterTicksValue = new BoolValue("Redesky-GlideAfterTicks", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true);
            }
        }));
        this.redeskyTickValue = new IntegerValue("Redesky-Ticks", 21, 1, 25, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true);
            }
        }));
        this.redeskyYMultiplier = new FloatValue("Redesky-YMultiplier", 0.77f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true);
            }
        }));
        this.redeskyXZMultiplier = new FloatValue("Redesky-XZMultiplier", 0.9f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"redesky", (boolean)true);
            }
        }));
        stringArray = new String[]{"Instant", "InstantC06", "Jump"};
        this.verusDmgModeValue = new ListValue("VerusDmg-DamageMode", stringArray, "Instant", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"verusdmg", (boolean)true);
            }
        }));
        this.verusBoostValue = new FloatValue("VerusDmg-Boost", 1.5f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"verusdmg", (boolean)true);
            }
        }));
        this.verusHeightValue = new FloatValue("VerusDmg-Height", 0.42f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"verusdmg", (boolean)true);
            }
        }));
        this.verusTimerValue = new FloatValue("VerusDmg-Timer", 1.0f, 0.05f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"verusdmg", (boolean)true);
            }
        }));
        this.pearlBoostValue = new FloatValue("Pearl-Boost", 4.25f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"pearl", (boolean)true);
            }
        }));
        this.pearlHeightValue = new FloatValue("Pearl-Height", 0.42f, 0.0f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"pearl", (boolean)true);
            }
        }));
        this.pearlTimerValue = new FloatValue("Pearl-Timer", 1.0f, 0.05f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)LongJump.access$getModeValue$p(this.this$0).get()), (String)"pearl", (boolean)true);
            }
        }));
        this.autoDisableValue = new BoolValue("AutoDisable", true);
        this.fakeDmgValue = new BoolValue("FakeDamage", false);
        this.fakeYValue = new BoolValue("FakeY", false);
        this.viewBobbingValue = new BoolValue("ViewBobbing", false);
        this.bobbingAmountValue = new FloatValue("BobbingAmount", 0.1f, 0.0f, 0.1f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ LongJump this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)LongJump.access$getViewBobbingValue$p(this.this$0).get();
            }
        }));
        this.dmgTimer = new MSTimer();
        this.posLookInstance = new PosLookInstance();
        this.currentTimer = 1.0f;
    }

    public final BoolValue getFakeYValue() {
        return this.fakeYValue;
    }

    public final double getY() {
        return this.y;
    }

    public final void setY(double d) {
        this.y = d;
    }

    private final void debug(String message) {
        if (((Boolean)this.matrixDebugValue.get()).booleanValue()) {
            ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a7r", (Object)message));
        }
    }

    @EventTarget
    public final void onMotion(@Nullable MotionEvent event) {
        if (MovementUtils.isMoving() && ((Boolean)this.viewBobbingValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.cameraYaw = ((Number)this.bobbingAmountValue.get()).floatValue();
        }
        if (((Boolean)this.fakeYValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.cameraPitch = 0.0f;
        }
    }

    @Override
    public void onEnable() {
        if (((Boolean)this.fakeDmgValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.handleStatusUpdate((byte)2);
        }
        this.y = MinecraftInstance.mc.thePlayer.posY;
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"redesky", (boolean)true) && ((Boolean)this.redeskyTimerBoostValue.get()).booleanValue()) {
            this.currentTimer = ((Number)this.redeskyTimerBoostStartValue.get()).floatValue();
        }
        this.jumped = false;
        this.hasJumped = false;
        this.no = false;
        this.jumpState = 0;
        this.ticks = 0;
        this.verusDmged = false;
        this.hpxDamage = false;
        this.damaged = false;
        this.flagged = false;
        this.hasFell = false;
        this.pearlState = 0;
        this.verusJumpTimes = 0;
        this.dmgTimer.reset();
        this.posLookInstance.reset();
        double x = MinecraftInstance.mc.thePlayer.posX;
        double y = MinecraftInstance.mc.thePlayer.posY;
        double z = MinecraftInstance.mc.thePlayer.posZ;
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"verusdmg", (boolean)true)) {
            if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Instant", (boolean)true)) {
                if (MinecraftInstance.mc.thePlayer.onGround && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y + (double)4, MinecraftInstance.mc.thePlayer.posZ, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, true)));
                    MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                }
            } else if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"InstantC06", (boolean)true)) {
                if (MinecraftInstance.mc.thePlayer.onGround && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, 4.0, 0.0).expand(0.0, 0.0, 0.0)).isEmpty()) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y + (double)4, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, false)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.thePlayer.posX, y, MinecraftInstance.mc.thePlayer.posZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch, true)));
                    MinecraftInstance.mc.thePlayer.motionX = MinecraftInstance.mc.thePlayer.motionZ = 0.0;
                }
            } else if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) && MinecraftInstance.mc.thePlayer.onGround) {
                MinecraftInstance.mc.thePlayer.jump();
                this.verusJumpTimes = 1;
            }
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"matrixflag", (boolean)true)) {
            if (StringsKt.equals((String)((String)this.matrixBypassModeValue.get()), (String)"none", (boolean)true)) {
                this.debug("no less flag enabled.");
                this.hasFell = true;
                return;
            }
            if (MinecraftInstance.mc.thePlayer.onGround) {
                if (StringsKt.equals((String)((String)this.matrixBypassModeValue.get()), (String)"clip", (boolean)true)) {
                    MinecraftInstance.mc.thePlayer.setPosition(x, y + 0.01, z);
                    this.debug("clipped");
                }
                if (StringsKt.equals((String)((String)this.matrixBypassModeValue.get()), (String)"motion", (boolean)true)) {
                    MinecraftInstance.mc.thePlayer.jump();
                }
            } else if (MinecraftInstance.mc.thePlayer.fallDistance > 0.0f) {
                this.hasFell = true;
                this.debug("falling detected");
            }
        }
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ncp", (boolean)true)) {
            MinecraftInstance.mc.gameSettings.keyBindJump.pressed = false;
        }
        if (!this.no && MinecraftInstance.mc.thePlayer.onGround) {
            this.jumped = true;
            if (this.hasJumped && ((Boolean)this.autoDisableValue.get()).booleanValue()) {
                this.jumpState = 0;
                this.setState(false);
                return;
            }
            MinecraftInstance.mc.thePlayer.jump();
            this.hasJumped = true;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"matrixflag", (boolean)true)) {
            if (this.hasFell) {
                if (!this.flagged && !((Boolean)this.matrixSilentValue.get()).booleanValue()) {
                    MovementUtils.strafe(((Number)this.matrixBoostValue.get()).floatValue());
                    MinecraftInstance.mc.thePlayer.motionY = ((Number)this.matrixHeightValue.get()).floatValue();
                    this.debug("triggering");
                }
            } else {
                if (StringsKt.equals((String)((String)this.matrixBypassModeValue.get()), (String)"motion", (boolean)true)) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX *= 0.2;
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ *= 0.2;
                    if (MinecraftInstance.mc.thePlayer.fallDistance > 0.0f) {
                        this.hasFell = true;
                        this.debug("activated");
                    }
                }
                if (StringsKt.equals((String)((String)this.matrixBypassModeValue.get()), (String)"clip", (boolean)true) && MinecraftInstance.mc.thePlayer.motionY < 0.0) {
                    this.hasFell = true;
                    this.debug("activated");
                }
            }
            return;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"verusdmg", (boolean)true)) {
            if (MinecraftInstance.mc.thePlayer.hurtTime > 0 && !this.verusDmged) {
                this.verusDmged = true;
                MovementUtils.strafe(((Number)this.verusBoostValue.get()).floatValue());
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.verusHeightValue.get()).floatValue();
            }
            if (StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) && this.verusJumpTimes < 5) {
                if (MinecraftInstance.mc.thePlayer.onGround) {
                    MinecraftInstance.mc.thePlayer.jump();
                    ++this.verusJumpTimes;
                }
                return;
            }
            if (this.verusDmged) {
                MinecraftInstance.mc.timer.timerSpeed = ((Number)this.verusTimerValue.get()).floatValue();
            } else {
                MinecraftInstance.mc.thePlayer.movementInput.moveForward = 0.0f;
                MinecraftInstance.mc.thePlayer.movementInput.moveStrafe = 0.0f;
                if (!StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true)) {
                    MinecraftInstance.mc.thePlayer.motionY = 0.0;
                }
            }
            return;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ncp", (boolean)true) && MinecraftInstance.mc.thePlayer.onGround) {
            this.canBoost = true;
        }
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"pearl", (boolean)true)) {
            int enderPearlSlot = this.getPearlSlot();
            if (this.pearlState == 0) {
                if (enderPearlSlot == -1) {
                    Client.INSTANCE.getHud().addNotification(new Notification("You don't have any ender pearl!", Notification.Type.ERROR));
                    this.pearlState = -1;
                    this.setState(false);
                    return;
                }
                if (MinecraftInstance.mc.thePlayer.inventory.currentItem != enderPearlSlot) {
                    MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C09PacketHeldItemChange(enderPearlSlot));
                }
                MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C05PacketPlayerLook(MinecraftInstance.mc.thePlayer.rotationYaw, 90.0f, MinecraftInstance.mc.thePlayer.onGround));
                MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(enderPearlSlot + 36).getStack(), 0.0f, 0.0f, 0.0f));
                if (enderPearlSlot != MinecraftInstance.mc.thePlayer.inventory.currentItem) {
                    MinecraftInstance.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.thePlayer.inventory.currentItem));
                }
                this.pearlState = 1;
            }
            if (this.pearlState == 1 && MinecraftInstance.mc.thePlayer.hurtTime > 0) {
                this.pearlState = 2;
                MovementUtils.strafe(((Number)this.pearlBoostValue.get()).floatValue());
                MinecraftInstance.mc.thePlayer.motionY = ((Number)this.pearlHeightValue.get()).floatValue();
            }
            if (this.pearlState == 2) {
                MinecraftInstance.mc.timer.timerSpeed = ((Number)this.pearlTimerValue.get()).floatValue();
            }
            return;
        }
        String mode = (String)this.modeValue.get();
        if (MinecraftInstance.mc.thePlayer.onGround || MinecraftInstance.mc.thePlayer.capabilities.isFlying) {
            this.jumped = false;
            this.canMineplexBoost = false;
            if (StringsKt.equals((String)mode, (String)"NCP", (boolean)true)) {
                MinecraftInstance.mc.thePlayer.motionX = 0.0;
                MinecraftInstance.mc.thePlayer.motionZ = 0.0;
            }
            return;
        }
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = mode.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string) {
            case "ncp": {
                MovementUtils.strafe(MovementUtils.getSpeed() * (this.canBoost ? ((Number)this.ncpBoostValue.get()).floatValue() : 1.0f));
                this.canBoost = false;
                break;
            }
            case "aacv1": {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.05999;
                MovementUtils.strafe(MovementUtils.getSpeed() * 1.08f);
                break;
            }
            case "mineplex3": 
            case "aacv2": {
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.09f;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.01321;
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.08f;
                MovementUtils.strafe();
                break;
            }
            case "aacv3": {
                EntityPlayerSP player = MinecraftInstance.mc.thePlayer;
                if (!(player.fallDistance > 0.5f) || this.teleported) break;
                double value = 3.0;
                EnumFacing horizontalFacing = player.getHorizontalFacing();
                double x = 0.0;
                double z = 0.0;
                EnumFacing enumFacing = horizontalFacing;
                switch (enumFacing == null ? -1 : WhenMappings.$EnumSwitchMapping$0[enumFacing.ordinal()]) {
                    case 1: {
                        z = -value;
                        break;
                    }
                    case 2: {
                        x = value;
                        break;
                    }
                    case 3: {
                        z = value;
                        break;
                    }
                    case 4: {
                        x = -value;
                    }
                }
                player.setPosition(player.posX + x, player.posY, player.posZ + z);
                this.teleported = true;
                break;
            }
            case "mineplex1": {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.01321;
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.08f;
                MovementUtils.strafe();
                break;
            }
            case "mineplex2": {
                if (this.canMineplexBoost) break;
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.1f;
                if (MinecraftInstance.mc.thePlayer.fallDistance > 1.5f) {
                    MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.0f;
                    MinecraftInstance.mc.thePlayer.motionY = -10.0;
                }
                MovementUtils.strafe();
                break;
            }
            case "aacv4": {
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.05837456f;
                MinecraftInstance.mc.timer.timerSpeed = 0.5f;
                break;
            }
            case "redeskymaki": {
                MinecraftInstance.mc.thePlayer.jumpMovementFactor = 0.15f;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.05;
                break;
            }
            case "redesky": {
                EntityPlayerSP entityPlayerSP;
                if (((Boolean)this.redeskyTimerBoostValue.get()).booleanValue()) {
                    MinecraftInstance.mc.timer.timerSpeed = this.currentTimer;
                }
                if (this.ticks < ((Number)this.redeskyTickValue.get()).intValue()) {
                    MinecraftInstance.mc.thePlayer.jump();
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY *= (double)((Number)this.redeskyYMultiplier.get()).floatValue();
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionX *= (double)((Number)this.redeskyXZMultiplier.get()).floatValue();
                    entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionZ *= (double)((Number)this.redeskyXZMultiplier.get()).floatValue();
                } else {
                    if (((Boolean)this.redeskyGlideAfterTicksValue.get()).booleanValue()) {
                        entityPlayerSP = MinecraftInstance.mc.thePlayer;
                        entityPlayerSP.motionY += 0.03;
                    }
                    if (((Boolean)this.redeskyTimerBoostValue.get()).booleanValue() && this.currentTimer > ((Number)this.redeskyTimerBoostEndValue.get()).floatValue()) {
                        this.currentTimer = Math.max(0.08f, this.currentTimer - 0.05f * ((Number)this.redeskyTimerBoostSlowDownSpeedValue.get()).floatValue());
                    }
                }
                int n = this.ticks;
                this.ticks = n + 1;
                break;
            }
            case "infiniteredesky": {
                if (MinecraftInstance.mc.thePlayer.fallDistance > 0.6f) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                    entityPlayerSP.motionY += 0.02;
                }
                MovementUtils.strafe((float)Math.min(0.85, Math.max(0.25, (double)MovementUtils.getSpeed() * 1.05878)));
            }
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"mineplex3", (boolean)true)) {
            if (!(MinecraftInstance.mc.thePlayer.fallDistance == 0.0f)) {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionY += 0.037;
            }
        } else if (StringsKt.equals((String)mode, (String)"ncp", (boolean)true) && !MovementUtils.isMoving() && this.jumped) {
            MinecraftInstance.mc.thePlayer.motionX = 0.0;
            MinecraftInstance.mc.thePlayer.motionZ = 0.0;
            event.zeroXZ();
        }
        if (StringsKt.equals((String)mode, (String)"verusdmg", (boolean)true) && !this.verusDmged) {
            event.zeroXZ();
        }
        if (StringsKt.equals((String)mode, (String)"pearl", (boolean)true) && this.pearlState != 2) {
            event.cancelEvent();
        }
        if (((Boolean)this.matrixSilentValue.get()).booleanValue() && this.hasFell && !this.flagged) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String mode = (String)this.modeValue.get();
        if (event.getPacket() instanceof C03PacketPlayer) {
            Packet<?> packetPlayer = event.getPacket();
            if (StringsKt.equals((String)mode, (String)"verusdmg", (boolean)true) && StringsKt.equals((String)((String)this.verusDmgModeValue.get()), (String)"Jump", (boolean)true) && this.verusJumpTimes < 5) {
                ((C03PacketPlayer)packetPlayer).onGround = false;
            }
            if (StringsKt.equals((String)mode, (String)"matrixflag", (boolean)true)) {
                if (event.getPacket() instanceof C03PacketPlayer.C06PacketPlayerPosLook && this.posLookInstance.equalFlag((C03PacketPlayer.C06PacketPlayerPosLook)event.getPacket())) {
                    this.posLookInstance.reset();
                    MinecraftInstance.mc.thePlayer.motionX = this.lastMotX;
                    MinecraftInstance.mc.thePlayer.motionY = this.lastMotY;
                    MinecraftInstance.mc.thePlayer.motionZ = this.lastMotZ;
                    this.debug("should be launched by now");
                } else if (((Boolean)this.matrixSilentValue.get()).booleanValue() && this.hasFell && !this.flagged && ((C03PacketPlayer)packetPlayer).isMoving()) {
                    this.debug("modifying packet: rotate false, onGround false, moving enabled, x, y, z set to expected speed");
                    ((C03PacketPlayer)packetPlayer).onGround = false;
                    double[] data = MovementUtils.getXZDist(((Number)this.matrixBoostValue.get()).floatValue(), ((C03PacketPlayer)packetPlayer).rotating ? ((C03PacketPlayer)packetPlayer).yaw : MinecraftInstance.mc.thePlayer.rotationYaw);
                    this.lastMotX = data[0];
                    this.lastMotZ = data[1];
                    this.lastMotY = ((Number)this.matrixHeightValue.get()).floatValue();
                    ((C03PacketPlayer)packetPlayer).x += this.lastMotX;
                    ((C03PacketPlayer)packetPlayer).y += this.lastMotY;
                    ((C03PacketPlayer)packetPlayer).z += this.lastMotZ;
                }
            }
        }
        if (event.getPacket() instanceof S08PacketPlayerPosLook && StringsKt.equals((String)mode, (String)"matrixflag", (boolean)true) && this.hasFell) {
            this.debug("flag check started");
            this.flagged = true;
            this.posLookInstance.set((S08PacketPlayerPosLook)event.getPacket());
            if (!((Boolean)this.matrixSilentValue.get()).booleanValue()) {
                this.debug("data saved");
                this.lastMotX = MinecraftInstance.mc.thePlayer.motionX;
                this.lastMotY = MinecraftInstance.mc.thePlayer.motionY;
                this.lastMotZ = MinecraftInstance.mc.thePlayer.motionZ;
            }
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onJump(JumpEvent event) {
        block13: {
            Intrinsics.checkNotNullParameter((Object)event, (String)"event");
            this.jumped = true;
            this.teleported = false;
            if (!this.getState()) break block13;
            String string = (String)this.modeValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string2) {
                case "mineplex1": {
                    event.setMotion(event.getMotion() * 4.08f);
                    break;
                }
                case "mineplex2": {
                    if (!MinecraftInstance.mc.thePlayer.isCollidedHorizontally) break;
                    event.setMotion(2.31f);
                    this.canMineplexBoost = true;
                    MinecraftInstance.mc.thePlayer.onGround = false;
                    break;
                }
                case "aacv4": {
                    event.setMotion(event.getMotion() * 1.0799f);
                }
            }
        }
    }

    private final int getPearlSlot() {
        int n = 36;
        while (n < 45) {
            int i;
            ItemStack stack;
            if ((stack = MinecraftInstance.mc.thePlayer.inventoryContainer.getSlot(i = n++).getStack()) == null || !(stack.getItem() instanceof ItemEnderPearl)) continue;
            return i - 36;
        }
        return -1;
    }

    @Override
    public void onDisable() {
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ncp", (boolean)true) && GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindJump)) {
            MinecraftInstance.mc.gameSettings.keyBindJump.pressed = true;
        }
        MinecraftInstance.mc.thePlayer.eyeHeight = MinecraftInstance.mc.thePlayer.getDefaultEyeHeight();
        MinecraftInstance.mc.timer.timerSpeed = 1.0f;
        if (!MinecraftInstance.mc.thePlayer.isSneaking()) {
            MinecraftInstance.mc.thePlayer.motionX = 0.0;
            MinecraftInstance.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(LongJump $this) {
        return $this.modeValue;
    }

    public static final /* synthetic */ BoolValue access$getRedeskyTimerBoostValue$p(LongJump $this) {
        return $this.redeskyTimerBoostValue;
    }

    public static final /* synthetic */ BoolValue access$getViewBobbingValue$p(LongJump $this) {
        return $this.viewBobbingValue;
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[EnumFacing.values().length];
            nArray[EnumFacing.NORTH.ordinal()] = 1;
            nArray[EnumFacing.EAST.ordinal()] = 2;
            nArray[EnumFacing.SOUTH.ordinal()] = 3;
            nArray[EnumFacing.WEST.ordinal()] = 4;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

