/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.spectre;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.util.MathHelper;

public class SpectreOnGround
extends SpeedMode {
    private int speedUp;

    public SpectreOnGround() {
        super("SpectreOnGround");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!SpectreOnGround.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            SpectreOnGround.mc.thePlayer.motionX = 0.0;
            SpectreOnGround.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        if (!MovementUtils.isMoving() || SpectreOnGround.mc.thePlayer.movementInput.jump) {
            return;
        }
        if (this.speedUp >= 10) {
            if (SpectreOnGround.mc.thePlayer.onGround) {
                SpectreOnGround.mc.thePlayer.motionX = 0.0;
                SpectreOnGround.mc.thePlayer.motionZ = 0.0;
                this.speedUp = 0;
            }
            return;
        }
        if (SpectreOnGround.mc.thePlayer.onGround && SpectreOnGround.mc.gameSettings.keyBindForward.isKeyDown()) {
            float f = SpectreOnGround.mc.thePlayer.rotationYaw * ((float)Math.PI / 180);
            SpectreOnGround.mc.thePlayer.motionX -= (double)(MathHelper.sin((float)f) * 0.145f);
            SpectreOnGround.mc.thePlayer.motionZ += (double)(MathHelper.cos((float)f) * 0.145f);
            event.setX(SpectreOnGround.mc.thePlayer.motionX);
            event.setY(0.005);
            event.setZ(SpectreOnGround.mc.thePlayer.motionZ);
            ++this.speedUp;
        }
    }
}

