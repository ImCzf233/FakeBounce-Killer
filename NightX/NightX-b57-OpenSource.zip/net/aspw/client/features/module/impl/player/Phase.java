/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.client.network.NetHandlerPlayClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.functions.Function1;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.PushOutEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

@ModuleInfo(name="Phase", description="", category=ModuleCategory.PLAYER)
public class Phase
extends Module {
    public final ListValue modeValue = new ListValue("Mode", new String[]{"Vanilla", "Skip", "Spartan", "Clip", "AAC3.5.0", "AACv4", "Vulcan", "Packetless", "Redesky", "SmartVClip"}, "Packetless");
    private final TickTimer tickTimer = new TickTimer();
    private final TickTimer mineplexTickTimer = new TickTimer();
    private boolean mineplexClip;
    private boolean noRot;
    private int stage;

    @Override
    public void onEnable() {
        this.stage = 0;
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            Phase.mc.timer.timerSpeed = 0.1f;
        }
    }

    @Override
    public void onDisable() {
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            Phase.mc.timer.timerSpeed = 1.0f;
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            switch (this.stage) {
                case 1: {
                    Phase.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY + -1.0E-8, Phase.mc.thePlayer.posZ, Phase.mc.thePlayer.rotationYaw, Phase.mc.thePlayer.rotationPitch, false));
                    Phase.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 1.0, Phase.mc.thePlayer.posZ, Phase.mc.thePlayer.rotationYaw, Phase.mc.thePlayer.rotationPitch, false));
                    break;
                }
                case 3: {
                    this.setState(false);
                }
            }
            ++this.stage;
            return;
        }
        if (((String)this.modeValue.get()).equalsIgnoreCase("redesky")) {
            switch (this.stage) {
                case 0: {
                    Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 1.0E-8, Phase.mc.thePlayer.posZ);
                    Phase.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 1.0E-8, Phase.mc.thePlayer.posZ, Phase.mc.thePlayer.rotationYaw, Phase.mc.thePlayer.rotationPitch, false));
                    break;
                }
                case 1: {
                    Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 1.0, Phase.mc.thePlayer.posZ);
                    Phase.mc.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 1.0, Phase.mc.thePlayer.posZ, Phase.mc.thePlayer.rotationYaw, Phase.mc.thePlayer.rotationPitch, false));
                    break;
                }
                case 3: {
                    this.setState(false);
                }
            }
            ++this.stage;
            return;
        }
        boolean isInsideBlock2 = BlockUtils.collideBlockIntersects(Phase.mc.thePlayer.getEntityBoundingBox(), (Function1<? super Block, Boolean>)((Function1)block -> !(block instanceof BlockAir)));
        if (isInsideBlock2 && !((String)this.modeValue.get()).equalsIgnoreCase("Packetless") && !((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip")) {
            Phase.mc.thePlayer.noClip = true;
            Phase.mc.thePlayer.motionY = 0.0;
            Phase.mc.thePlayer.onGround = true;
        }
        NetHandlerPlayClient netHandlerPlayClient = mc.getNetHandler();
        switch (((String)this.modeValue.get()).toLowerCase()) {
            case "vanilla": {
                if (!Phase.mc.thePlayer.onGround || !this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2 && !Phase.mc.thePlayer.isSneaking()) break;
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY + 0.2, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX + 0.5, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + 0.5, true));
                double yaw = Math.toRadians(Phase.mc.thePlayer.rotationYaw);
                double x = -Math.sin(yaw) * 0.04;
                double z = Math.cos(yaw) * 0.04;
                Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX + x, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + z);
                this.tickTimer.reset();
                break;
            }
            case "skip": {
                if (!Phase.mc.thePlayer.onGround || !this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2 && !Phase.mc.thePlayer.isSneaking()) break;
                double direction = MovementUtils.getDirection();
                double posX = -Math.sin(direction) * 0.3;
                double posZ = Math.cos(direction) * 0.3;
                for (int i = 0; i < 3; ++i) {
                    mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY + 0.06, Phase.mc.thePlayer.posZ, true));
                    mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX + posX * (double)i, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + posZ * (double)i, true));
                }
                Phase.mc.thePlayer.setEntityBoundingBox(Phase.mc.thePlayer.getEntityBoundingBox().offset(posX, 0.0, posZ));
                Phase.mc.thePlayer.setPositionAndUpdate(Phase.mc.thePlayer.posX + posX, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + posZ);
                this.tickTimer.reset();
                break;
            }
            case "spartan": {
                if (!Phase.mc.thePlayer.onGround || !this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2 && !Phase.mc.thePlayer.isSneaking()) break;
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 0.2, Phase.mc.thePlayer.posZ, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX + 0.5, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + 0.5, true));
                double yaw = Math.toRadians(Phase.mc.thePlayer.rotationYaw);
                double x = -Math.sin(yaw) * 0.04;
                double z = Math.cos(yaw) * 0.04;
                Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX + x, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + z);
                this.tickTimer.reset();
                break;
            }
            case "clip": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2 && !Phase.mc.thePlayer.isSneaking()) break;
                double yaw = Math.toRadians(Phase.mc.thePlayer.rotationYaw);
                double oldX = Phase.mc.thePlayer.posX;
                double oldZ = Phase.mc.thePlayer.posZ;
                for (int i = 1; i <= 10; ++i) {
                    double z;
                    double x = -Math.sin(yaw) * (double)i;
                    if (!(BlockUtils.getBlock(new BlockPos(oldX + x, Phase.mc.thePlayer.posY, oldZ + (z = Math.cos(yaw) * (double)i))) instanceof BlockAir) || !(BlockUtils.getBlock(new BlockPos(oldX + x, Phase.mc.thePlayer.posY + 1.0, oldZ + z)) instanceof BlockAir)) continue;
                    Phase.mc.thePlayer.setPosition(oldX + x, Phase.mc.thePlayer.posY, oldZ + z);
                    break;
                }
                this.tickTimer.reset();
                break;
            }
            case "aac3.5.0": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2 && !Phase.mc.thePlayer.isSneaking()) break;
                double yaw = Math.toRadians(Phase.mc.thePlayer.rotationYaw);
                double oldX = Phase.mc.thePlayer.posX;
                double oldZ = Phase.mc.thePlayer.posZ;
                double x = -Math.sin(yaw);
                double z = Math.cos(yaw);
                Phase.mc.thePlayer.setPosition(oldX + x, Phase.mc.thePlayer.posY, oldZ + z);
                this.tickTimer.reset();
                break;
            }
            case "vulcan": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.thePlayer.isCollidedHorizontally || isInsideBlock2) break;
                double yaw = Math.toRadians(Phase.mc.thePlayer.rotationYaw);
                double oldX = Phase.mc.thePlayer.posX;
                double oldZ = Phase.mc.thePlayer.posZ;
                double x = -Math.sin(yaw);
                double z = Math.cos(yaw);
                Phase.mc.thePlayer.setPosition(oldX + x, Phase.mc.thePlayer.posY, oldZ + z);
                Phase.mc.thePlayer.noClip = true;
                this.tickTimer.reset();
                break;
            }
            case "smartvclip": {
                boolean cageCollision = Phase.mc.theWorld.getBlockState(new BlockPos((Entity)Phase.mc.thePlayer).up(3)).getBlock() != Blocks.air && Phase.mc.theWorld.getBlockState(new BlockPos((Entity)Phase.mc.thePlayer).down()).getBlock() != Blocks.air;
                boolean bl = this.noRot = Phase.mc.thePlayer.ticksExisted >= 0 && Phase.mc.thePlayer.ticksExisted <= 40 && cageCollision;
                if (Phase.mc.thePlayer.ticksExisted < 20 || Phase.mc.thePlayer.ticksExisted >= 40 || !cageCollision) break;
                mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 4.0, Phase.mc.thePlayer.posZ, false));
                Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX, Phase.mc.thePlayer.posY - 4.0, Phase.mc.thePlayer.posZ);
                break;
            }
            case "redesky": {
                this.setState(false);
                break;
            }
            case "redesky2": {
                this.setState(false);
            }
        }
        this.tickTimer.update();
    }

    @EventTarget
    public void onBlockBB(BlockBBEvent event) {
        if (Phase.mc.thePlayer != null && BlockUtils.collideBlockIntersects(Phase.mc.thePlayer.getEntityBoundingBox(), (Function1<? super Block, Boolean>)((Function1)block -> !(block instanceof BlockAir))) && event.getBoundingBox() != null && event.getBoundingBox().maxY > Phase.mc.thePlayer.getEntityBoundingBox().minY && !((String)this.modeValue.get()).equalsIgnoreCase("Packetless") && !((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip")) {
            AxisAlignedBB axisAlignedBB = event.getBoundingBox();
            event.setBoundingBox(new AxisAlignedBB(axisAlignedBB.maxX, Phase.mc.thePlayer.getEntityBoundingBox().minY, axisAlignedBB.maxZ, axisAlignedBB.minX, axisAlignedBB.minY, axisAlignedBB.minZ));
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            float yaw;
            C03PacketPlayer packetPlayer = (C03PacketPlayer)packet;
            if (((String)this.modeValue.get()).equalsIgnoreCase("AAC3.5.0")) {
                yaw = (float)MovementUtils.getDirection();
                packetPlayer.x -= (double)MathHelper.sin((float)yaw) * 1.0E-8;
                packetPlayer.z += (double)MathHelper.cos((float)yaw) * 1.0E-8;
            }
            if (((String)this.modeValue.get()).equalsIgnoreCase("Vulcan")) {
                yaw = (float)MovementUtils.getDirection();
                packetPlayer.x -= (double)MathHelper.sin((float)yaw) * 8.0E-8;
                packetPlayer.z += (double)MathHelper.cos((float)yaw) * 8.0E-8;
            }
            if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot && packetPlayer.rotating) {
                event.cancelEvent();
            }
        }
        if (packet instanceof C0BPacketEntityAction && ((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.cancelEvent();
        }
    }

    @EventTarget
    private void onMove(MoveEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("packetless")) {
            if (Phase.mc.thePlayer.isCollidedHorizontally) {
                this.mineplexClip = true;
            }
            if (!this.mineplexClip) {
                return;
            }
            this.mineplexTickTimer.update();
            event.setX(0.0);
            event.setZ(0.0);
            if (this.mineplexTickTimer.hasTimePassed(3)) {
                this.mineplexTickTimer.reset();
                this.mineplexClip = false;
            } else if (this.mineplexTickTimer.hasTimePassed(1)) {
                double offset = this.mineplexTickTimer.hasTimePassed(2) ? 1.6 : 0.06;
                double direction = MovementUtils.getDirection();
                Phase.mc.thePlayer.setPosition(Phase.mc.thePlayer.posX + -Math.sin(direction) * offset, Phase.mc.thePlayer.posY, Phase.mc.thePlayer.posZ + Math.cos(direction) * offset);
            }
        }
        if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.zeroXZ();
        }
    }

    @EventTarget
    public void onPushOut(PushOutEvent event) {
        event.cancelEvent();
    }

    @EventTarget
    public void onJump(JumpEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.cancelEvent();
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

