/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.other;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.IntegerValue;

@ModuleInfo(name="FastPlace", spacedName="Fast Place", description="", category=ModuleCategory.OTHER)
public final class FastPlace
extends Module {
    private final IntegerValue speedValue = new IntegerValue("Speed", 0, 0, 4);

    public final IntegerValue getSpeedValue() {
        return this.speedValue;
    }
}

