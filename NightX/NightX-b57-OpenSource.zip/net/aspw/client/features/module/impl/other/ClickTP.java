/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MovingObjectPosition
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.features.module.impl.other;

import java.util.ArrayList;
import java.util.Arrays;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.pathfinder.Vec3;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Mouse;

@ModuleInfo(name="ClickTP", spacedName="Click TP", description="", category=ModuleCategory.OTHER)
public class ClickTP
extends Module {
    private final ListValue buttonValue = new ListValue("Button", new String[]{"Left", "Right", "Middle"}, "Middle");
    private int delay;
    private BlockPos endPos;
    private MovingObjectPosition objectPosition;

    @Override
    public void onDisable() {
        this.delay = 0;
        this.endPos = null;
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (ClickTP.mc.currentScreen == null && Mouse.isButtonDown((int)Arrays.asList(this.buttonValue.getValues()).indexOf(this.buttonValue.get())) && this.delay <= 0) {
            this.endPos = this.objectPosition.getBlockPos();
            if (BlockUtils.getBlock(this.endPos).getMaterial() == Material.air) {
                this.endPos = null;
                return;
            }
            Client.hud.addNotification(new Notification("Successfully Teleported to X: " + this.endPos.getX() + ", Y: " + this.endPos.getY() + ", Z: " + this.endPos.getZ(), Notification.Type.SUCCESS));
            this.delay = 6;
        }
        if (this.delay > 0) {
            --this.delay;
        }
        if (this.endPos != null) {
            double endX = (double)this.endPos.getX() + 0.5;
            double endY = (double)this.endPos.getY() + 1.0;
            double endZ = (double)this.endPos.getZ() + 0.5;
            new Thread(() -> {
                ArrayList<Vec3> path = MainPathFinder.computePath(new Vec3(ClickTP.mc.thePlayer.posX, ClickTP.mc.thePlayer.posY, ClickTP.mc.thePlayer.posZ), new Vec3(endX, endY, endZ));
                for (Vec3 point : path) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true));
                }
                ClickTP.mc.thePlayer.setPosition(endX, endY, endZ);
            }).start();
            if (((Boolean)Client.moduleManager.getModule(Hud.class).getFlagSoundValue().get()).booleanValue()) {
                Client.tipSoundManager.getPopSound().asyncPlay(Client.moduleManager.getPopSoundPower());
            }
            this.endPos = null;
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        this.objectPosition = ClickTP.mc.thePlayer.rayTrace(1000.0, event.getPartialTicks());
        if (this.objectPosition.getBlockPos() == null) {
            return;
        }
        int x = this.objectPosition.getBlockPos().getX();
        int y = this.objectPosition.getBlockPos().getY();
        int z = this.objectPosition.getBlockPos().getZ();
        if (BlockUtils.getBlock(this.objectPosition.getBlockPos()).getMaterial() != Material.air) {
            RenderManager renderManager = mc.getRenderManager();
        }
    }
}

