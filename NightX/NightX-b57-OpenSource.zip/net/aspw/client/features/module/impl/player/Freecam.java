/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Freecam", description="", category=ModuleCategory.PLAYER, keyBind=66)
public final class Freecam
extends Module {
    private final FloatValue speedValue = new FloatValue("Speed", 1.0f, 0.1f, 2.0f, "m");
    private final BoolValue noClipValue = new BoolValue("NoClip", true);
    private EntityOtherPlayerMP fakePlayer;
    private double oldX;
    private double oldY;
    private double oldZ;

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        this.oldX = MinecraftInstance.mc.thePlayer.posX;
        this.oldY = MinecraftInstance.mc.thePlayer.posY;
        this.oldZ = MinecraftInstance.mc.thePlayer.posZ;
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer = new EntityOtherPlayerMP((World)MinecraftInstance.mc.theWorld, MinecraftInstance.mc.thePlayer.getGameProfile());
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        entityOtherPlayerMP.func_71049_a((EntityPlayer)MinecraftInstance.mc.thePlayer, true);
        Intrinsics.checkNotNull((Object)this.fakePlayer);
        this.fakePlayer.field_70759_as = MinecraftInstance.mc.thePlayer.rotationYawHead;
        EntityOtherPlayerMP entityOtherPlayerMP2 = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP2);
        entityOtherPlayerMP2.copyLocationAndAnglesFrom((Entity)MinecraftInstance.mc.thePlayer);
        MinecraftInstance.mc.theWorld.addEntityToWorld(-1000, (Entity)this.fakePlayer);
        if (((Boolean)this.noClipValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.noClip = true;
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.thePlayer == null || this.fakePlayer == null) {
            return;
        }
        MinecraftInstance.mc.thePlayer.setPositionAndRotation(this.oldX, this.oldY, this.oldZ, MinecraftInstance.mc.thePlayer.rotationYaw, MinecraftInstance.mc.thePlayer.rotationPitch);
        WorldClient worldClient = MinecraftInstance.mc.theWorld;
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        worldClient.removeEntityFromWorld(entityOtherPlayerMP.getEntityId());
        this.fakePlayer = null;
        MinecraftInstance.mc.thePlayer.motionX = 0.0;
        MinecraftInstance.mc.thePlayer.motionY = 0.0;
        MinecraftInstance.mc.thePlayer.motionZ = 0.0;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        EntityPlayerSP entityPlayerSP;
        if (((Boolean)this.noClipValue.get()).booleanValue()) {
            MinecraftInstance.mc.thePlayer.noClip = true;
        }
        MinecraftInstance.mc.thePlayer.fallDistance = 0.0f;
        float value = ((Number)this.speedValue.get()).floatValue();
        MinecraftInstance.mc.thePlayer.motionY = 0.0;
        MinecraftInstance.mc.thePlayer.motionX = 0.0;
        MinecraftInstance.mc.thePlayer.motionZ = 0.0;
        if (MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown()) {
            entityPlayerSP = MinecraftInstance.mc.thePlayer;
            entityPlayerSP.motionY += (double)value;
        }
        if (GameSettings.isKeyDown((KeyBinding)MinecraftInstance.mc.gameSettings.keyBindSneak)) {
            entityPlayerSP = MinecraftInstance.mc.thePlayer;
            entityPlayerSP.motionY -= (double)value;
            MinecraftInstance.mc.gameSettings.keyBindSneak.pressed = false;
        }
        MovementUtils.strafe(value);
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        MinecraftInstance.mc.thePlayer.cameraPitch = 0.0f;
        MinecraftInstance.mc.thePlayer.cameraYaw = 0.0f;
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer || packet instanceof C0BPacketEntityAction) {
            event.cancelEvent();
        }
    }
}

