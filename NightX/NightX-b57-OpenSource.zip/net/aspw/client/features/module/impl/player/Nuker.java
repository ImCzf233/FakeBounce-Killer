/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.MapsKt
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.math.MathKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.player.AutoTool;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.VecRotation;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

@ModuleInfo(name="Nuker", description="", category=ModuleCategory.PLAYER)
public final class Nuker
extends Module {
    public static final Companion Companion = new Companion(null);
    private final FloatValue radiusValue = new FloatValue("Radius", 4.2f, 1.0f, 6.0f);
    private final BoolValue throughWallsValue = new BoolValue("ThroughWalls", true);
    private final ListValue priorityValue;
    private final BoolValue rotationsValue;
    private final BoolValue layerValue;
    private final IntegerValue hitDelayValue;
    private final IntegerValue nukeValue;
    private final IntegerValue nukeDelay;
    private final ArrayList<BlockPos> attackedBlocks;
    private BlockPos currentBlock;
    private int blockHitDelay;
    private boolean isBreaking;
    private TickTimer nukeTimer;
    private int nuke;
    private static float currentDamage;

    public Nuker() {
        String[] stringArray = new String[]{"Distance", "Hardness"};
        this.priorityValue = new ListValue("Priority", stringArray, "Distance");
        this.rotationsValue = new BoolValue("Rotations", true);
        this.layerValue = new BoolValue("Layer", false);
        this.hitDelayValue = new IntegerValue("HitDelay", 0, 0, 20);
        this.nukeValue = new IntegerValue("Nuke", 1, 1, 20);
        this.nukeDelay = new IntegerValue("NukeDelay", 1, 1, 20);
        this.attackedBlocks = new ArrayList();
        this.nukeTimer = new TickTimer();
    }

    public final BoolValue getRotationsValue() {
        return this.rotationsValue;
    }

    public final boolean isBreaking() {
        return this.isBreaking;
    }

    public final void setBreaking(boolean bl) {
        this.isBreaking = bl;
    }

    @Override
    public void onDisable() {
        this.isBreaking = false;
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        block47: {
            void $this$filterTo$iv$iv;
            EntityPlayerSP thePlayer;
            block44: {
                Map.Entry element$iv$iv;
                String $this$filterTo$iv$iv2;
                Map.Entry $this$filter$iv;
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (this.blockHitDelay <= 0) {
                    this.isBreaking = false;
                }
                if (this.blockHitDelay > 0) {
                    int n = this.blockHitDelay;
                    this.blockHitDelay = n + -1;
                    return;
                }
                this.nukeTimer.update();
                if (this.nukeTimer.hasTimePassed(((Number)this.nukeDelay.get()).intValue())) {
                    this.nuke = 0;
                    this.nukeTimer.reset();
                }
                this.attackedBlocks.clear();
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP);
                thePlayer = entityPlayerSP;
                if (MinecraftInstance.mc.playerController.isInCreativeMode()) break block44;
                Map<BlockPos, Block> map = BlockUtils.searchBlocks(MathKt.roundToInt((float)((Number)this.radiusValue.get()).floatValue()) + 1);
                boolean $i$f$filter2 = false;
                void var6_9 = $this$filter$iv;
                Map destination$iv$iv = new LinkedHashMap();
                int $i$f$filterTo2 = 0;
                Iterator iterator = $this$filterTo$iv$iv2.entrySet().iterator();
                while (iterator.hasNext()) {
                    boolean bl;
                    Map.Entry $dstr$pos$block = element$iv$iv = iterator.next();
                    boolean bl2 = false;
                    BlockPos pos = (BlockPos)$dstr$pos$block.getKey();
                    Block block = (Block)$dstr$pos$block.getValue();
                    if (BlockUtils.getCenterDistance(pos) <= (double)((Number)this.radiusValue.get()).floatValue() && this.validBlock(block)) {
                        if (((Boolean)this.layerValue.get()).booleanValue() && (double)pos.getY() < thePlayer.posY) {
                            bl = false;
                        } else if (!((Boolean)this.throughWallsValue.get()).booleanValue()) {
                            Vec3 eyesPos = new Vec3(thePlayer.posX, thePlayer.getEntityBoundingBox().minY + (double)thePlayer.eyeHeight, thePlayer.posZ);
                            Vec3 blockVec = new Vec3((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5);
                            WorldClient worldClient = MinecraftInstance.mc.theWorld;
                            Intrinsics.checkNotNull((Object)worldClient);
                            MovingObjectPosition rayTrace = worldClient.rayTraceBlocks(eyesPos, blockVec, false, true, false);
                            bl = rayTrace != null && rayTrace.getBlockPos().equals(pos);
                        } else {
                            bl = true;
                        }
                    } else {
                        bl = false;
                    }
                    if (!bl) continue;
                    destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
                }
                Map validBlocks = MapsKt.toMutableMap((Map)destination$iv$iv);
                do {
                    BlockPos blockPos;
                    block46: {
                        Block block;
                        block45: {
                            AutoTool autoTool;
                            Map.Entry entry;
                            BlockPos safePos;
                            Block block2;
                            BlockPos pos;
                            BlockPos safePos2;
                            if (($this$filterTo$iv$iv2 = (String)this.priorityValue.get()).equals("Distance")) {
                                Map.Entry entry2;
                                iterator = ((Iterable)validBlocks.entrySet()).iterator();
                                if (!iterator.hasNext()) {
                                    entry2 = null;
                                } else {
                                    element$iv$iv = iterator.next();
                                    if (!iterator.hasNext()) {
                                        entry2 = element$iv$iv;
                                    } else {
                                        Map.Entry $dstr$pos$block22 = element$iv$iv;
                                        boolean bl = false;
                                        BlockPos pos2 = (BlockPos)$dstr$pos$block22.getKey();
                                        Block block3 = (Block)$dstr$pos$block22.getValue();
                                        double distance = BlockUtils.getCenterDistance(pos2);
                                        safePos2 = new BlockPos(thePlayer.posX, thePlayer.posY - 1.0, thePlayer.posZ);
                                        double $dstr$pos$block22 = pos2.getX() == safePos2.getX() && safePos2.getY() <= pos2.getY() && pos2.getZ() == safePos2.getZ() ? Double.MAX_VALUE - distance : distance;
                                        do {
                                            Map.Entry $dstr$pos$block32 = bl = iterator.next();
                                            $i$a$-minByOrNull-Nuker$onUpdate$1 = false;
                                            pos = (BlockPos)$dstr$pos$block32.getKey();
                                            block2 = (Block)$dstr$pos$block32.getValue();
                                            double distance2 = BlockUtils.getCenterDistance(pos);
                                            safePos = new BlockPos(thePlayer.posX, thePlayer.posY - 1.0, thePlayer.posZ);
                                            double $dstr$pos$block32 = pos.getX() == safePos.getX() && safePos.getY() <= pos.getY() && pos.getZ() == safePos.getZ() ? Double.MAX_VALUE - distance2 : distance2;
                                            if (Double.compare($dstr$pos$block22, $dstr$pos$block32) <= 0) continue;
                                            element$iv$iv = bl;
                                            $dstr$pos$block22 = $dstr$pos$block32;
                                        } while (iterator.hasNext());
                                        entry2 = element$iv$iv;
                                    }
                                }
                                entry = entry2;
                            } else if ($this$filterTo$iv$iv2.equals("Hardness")) {
                                Map.Entry entry3;
                                iterator = ((Iterable)validBlocks.entrySet()).iterator();
                                if (!iterator.hasNext()) {
                                    entry3 = null;
                                } else {
                                    element$iv$iv = iterator.next();
                                    if (!iterator.hasNext()) {
                                        entry3 = element$iv$iv;
                                    } else {
                                        Map.Entry $dstr$pos$block42 = element$iv$iv;
                                        boolean bl = false;
                                        BlockPos pos3 = (BlockPos)$dstr$pos$block42.getKey();
                                        Block block4 = (Block)$dstr$pos$block42.getValue();
                                        EntityPlayer entityPlayer = (EntityPlayer)thePlayer;
                                        WorldClient worldClient = MinecraftInstance.mc.theWorld;
                                        Intrinsics.checkNotNull((Object)worldClient);
                                        double hardness = block4.getPlayerRelativeBlockHardness(entityPlayer, (World)worldClient, pos3);
                                        safePos2 = new BlockPos(thePlayer.posX, thePlayer.posY - 1.0, thePlayer.posZ);
                                        double $dstr$pos$block42 = pos3.getX() == safePos2.getX() && safePos2.getY() <= pos3.getY() && pos3.getZ() == safePos2.getZ() ? Double.MIN_VALUE + hardness : hardness;
                                        do {
                                            Map.Entry $dstr$pos$block52 = bl = iterator.next();
                                            $i$a$-maxByOrNull-Nuker$onUpdate$2 = false;
                                            pos = (BlockPos)$dstr$pos$block52.getKey();
                                            block2 = (Block)$dstr$pos$block52.getValue();
                                            EntityPlayer entityPlayer2 = (EntityPlayer)thePlayer;
                                            WorldClient worldClient2 = MinecraftInstance.mc.theWorld;
                                            Intrinsics.checkNotNull((Object)worldClient2);
                                            double hardness2 = block2.getPlayerRelativeBlockHardness(entityPlayer2, (World)worldClient2, pos);
                                            safePos = new BlockPos(thePlayer.posX, thePlayer.posY - 1.0, thePlayer.posZ);
                                            double $dstr$pos$block52 = pos.getX() == safePos.getX() && safePos.getY() <= pos.getY() && pos.getZ() == safePos.getZ() ? Double.MIN_VALUE + hardness2 : hardness2;
                                            if (Double.compare($dstr$pos$block42, $dstr$pos$block52) >= 0) continue;
                                            element$iv$iv = bl;
                                            $dstr$pos$block42 = $dstr$pos$block52;
                                        } while (iterator.hasNext());
                                        entry3 = element$iv$iv;
                                    }
                                }
                                entry = entry3;
                            } else {
                                return;
                            }
                            Map.Entry $i$f$filter2 = entry;
                            if ($i$f$filter2 == null) {
                                return;
                            }
                            $this$filter$iv = $i$f$filter2;
                            blockPos = (BlockPos)$this$filter$iv.getKey();
                            block = (Block)$this$filter$iv.getValue();
                            if (!blockPos.equals(this.currentBlock)) {
                                currentDamage = 0.0f;
                            }
                            if (((Boolean)this.rotationsValue.get()).booleanValue()) {
                                VecRotation rotation;
                                if (RotationUtils.faceBlock(blockPos) == null) {
                                    return;
                                }
                                RotationUtils.setTargetRotation(rotation.getRotation());
                                this.isBreaking = true;
                            }
                            this.currentBlock = blockPos;
                            this.attackedBlocks.add(blockPos);
                            if (Client.INSTANCE.getModuleManager().getModule(AutoTool.class) == null) {
                                throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.AutoTool");
                            }
                            if (autoTool.getState()) {
                                autoTool.switchSlot(blockPos);
                            }
                            if (!(currentDamage == 0.0f)) break block45;
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, blockPos, EnumFacing.DOWN));
                            EntityPlayer entityPlayer = (EntityPlayer)thePlayer;
                            WorldClient worldClient = MinecraftInstance.mc.theWorld;
                            Intrinsics.checkNotNull((Object)worldClient);
                            if (block.getPlayerRelativeBlockHardness(entityPlayer, (World)worldClient, blockPos) >= 1.0f) break block46;
                        }
                        EntityPlayer entityPlayer = (EntityPlayer)thePlayer;
                        WorldClient worldClient = MinecraftInstance.mc.theWorld;
                        Intrinsics.checkNotNull((Object)worldClient);
                        WorldClient worldClient3 = MinecraftInstance.mc.theWorld;
                        Intrinsics.checkNotNull((Object)worldClient3);
                        worldClient3.sendBlockBreakProgress(thePlayer.getEntityId(), blockPos, (int)((currentDamage += block.getPlayerRelativeBlockHardness(entityPlayer, (World)worldClient, blockPos)) * 10.0f) - 1);
                        if (currentDamage >= 1.0f) {
                            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockPos, EnumFacing.DOWN));
                            MinecraftInstance.mc.playerController.onPlayerDestroyBlock(blockPos, EnumFacing.DOWN);
                            this.blockHitDelay = ((Number)this.hitDelayValue.get()).intValue();
                            currentDamage = 0.0f;
                        }
                        return;
                    }
                    currentDamage = 0.0f;
                    MinecraftInstance.mc.playerController.onPlayerDestroyBlock(blockPos, EnumFacing.DOWN);
                    this.blockHitDelay = ((Number)this.hitDelayValue.get()).intValue();
                    validBlocks.remove(blockPos);
                    $i$f$filterTo2 = this.nuke;
                    this.nuke = $i$f$filterTo2 + 1;
                } while (this.nuke < ((Number)this.nukeValue.get()).intValue());
                break block47;
            }
            ItemStack itemStack = thePlayer.getHeldItem();
            if ((itemStack == null ? null : itemStack.getItem()) instanceof ItemSword) {
                return;
            }
            Map<BlockPos, Block> $this$filter$iv = BlockUtils.searchBlocks(MathKt.roundToInt((float)((Number)this.radiusValue.get()).floatValue()) + 1);
            boolean $i$f$filter = false;
            Map<BlockPos, Block> blockPos = $this$filter$iv;
            Map destination$iv$iv = new LinkedHashMap();
            boolean $i$f$filterTo = false;
            Iterator $i$f$filterTo2 = $this$filterTo$iv$iv.entrySet().iterator();
            while ($i$f$filterTo2.hasNext()) {
                boolean bl;
                Map.Entry element$iv$iv;
                Map.Entry $dstr$pos$block = element$iv$iv = $i$f$filterTo2.next();
                boolean bl3 = false;
                BlockPos pos = (BlockPos)$dstr$pos$block.getKey();
                Block block = (Block)$dstr$pos$block.getValue();
                if (BlockUtils.getCenterDistance(pos) <= (double)((Number)this.radiusValue.get()).floatValue() && this.validBlock(block)) {
                    if (((Boolean)this.layerValue.get()).booleanValue() && (double)pos.getY() < thePlayer.posY) {
                        bl = false;
                    } else if (!((Boolean)this.throughWallsValue.get()).booleanValue()) {
                        Vec3 eyesPos = new Vec3(thePlayer.posX, thePlayer.getEntityBoundingBox().minY + (double)thePlayer.eyeHeight, thePlayer.posZ);
                        Vec3 blockVec = new Vec3((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5);
                        WorldClient worldClient = MinecraftInstance.mc.theWorld;
                        Intrinsics.checkNotNull((Object)worldClient);
                        MovingObjectPosition rayTrace = worldClient.rayTraceBlocks(eyesPos, blockVec, false, true, false);
                        bl = rayTrace != null && rayTrace.getBlockPos().equals(pos);
                    } else {
                        bl = true;
                    }
                } else {
                    bl = false;
                }
                if (!bl) continue;
                destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
            }
            Map $this$forEach$iv = destination$iv$iv;
            boolean $i$f$forEach = false;
            Iterator iterator = $this$forEach$iv.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry element$iv;
                Map.Entry $dstr$pos$_u24__u24 = element$iv = iterator.next();
                boolean bl = false;
                BlockPos pos = (BlockPos)$dstr$pos$_u24__u24.getKey();
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.DOWN));
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, EnumFacing.DOWN));
                this.attackedBlocks.add(pos);
            }
        }
    }

    private final boolean validBlock(Block block) {
        return !block.equals(Blocks.air) && !(block instanceof BlockLiquid);
    }

    public static final class Companion {
        private Companion() {
        }

        public final float getCurrentDamage() {
            return currentDamage;
        }

        public final void setCurrentDamage(float f) {
            currentDamage = f;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

