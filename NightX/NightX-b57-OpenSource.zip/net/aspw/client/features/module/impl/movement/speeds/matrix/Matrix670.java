/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S12PacketEntityVelocity
 */
package net.aspw.client.features.module.impl.movement.speeds.matrix;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;

public final class Matrix670
extends SpeedMode {
    private int noVelocityY;

    public Matrix670() {
        super("Matrix6.7.0");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.timer.timerSpeed = 1.0f;
        this.noVelocityY = 0;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.thePlayer;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.isInWater()) {
            return;
        }
        if (this.noVelocityY >= 0) {
            --this.noVelocityY;
        }
        if (!SpeedMode.mc.thePlayer.onGround && this.noVelocityY <= 0) {
            EntityPlayerSP entityPlayerSP2;
            if (SpeedMode.mc.thePlayer.motionY > 0.0) {
                entityPlayerSP2 = SpeedMode.mc.thePlayer;
                entityPlayerSP2.motionY -= 5.0E-4;
            }
            entityPlayerSP2 = SpeedMode.mc.thePlayer;
            entityPlayerSP2.motionY -= 0.009400114514191982;
        }
        if (!SpeedMode.mc.thePlayer.onGround) {
            SpeedMode.mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown((KeyBinding)SpeedMode.mc.gameSettings.keyBindJump);
            if ((double)MovementUtils.getSpeed() < 0.2177 && this.noVelocityY < 8) {
                MovementUtils.strafe(0.2177f);
            }
        }
        SpeedMode.mc.thePlayer.jumpMovementFactor = (double)Math.abs(SpeedMode.mc.thePlayer.movementInput.moveStrafe) < 0.1 ? 0.026f : 0.0247f;
        if (SpeedMode.mc.thePlayer.onGround && MovementUtils.isMoving()) {
            SpeedMode.mc.gameSettings.keyBindJump.pressed = false;
            SpeedMode.mc.thePlayer.jump();
            SpeedMode.mc.thePlayer.motionY = 0.4105000114514192;
            if ((double)Math.abs(SpeedMode.mc.thePlayer.movementInput.moveStrafe) < 0.1) {
                MovementUtils.strafe();
            }
        }
        if (!MovementUtils.isMoving()) {
            SpeedMode.mc.thePlayer.motionX = 0.0;
            SpeedMode.mc.thePlayer.motionZ = 0.0;
        }
    }

    public final void onPacket(PacketEvent event) {
        block4: {
            block6: {
                block5: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    Packet<?> packet = event.getPacket();
                    if (!(packet instanceof S12PacketEntityVelocity)) break block4;
                    if (SpeedMode.mc.thePlayer == null) break block5;
                    WorldClient worldClient = SpeedMode.mc.theWorld;
                    Entity entity = worldClient == null ? null : worldClient.getEntityByID(((S12PacketEntityVelocity)packet).getEntityID());
                    if (entity == null) {
                        return;
                    }
                    if (entity.equals(SpeedMode.mc.thePlayer)) break block6;
                }
                return;
            }
            this.noVelocityY = 10;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
    }
}

