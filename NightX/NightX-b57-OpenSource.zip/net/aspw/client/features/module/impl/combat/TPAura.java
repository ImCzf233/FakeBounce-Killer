/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PathUtils;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="TPAura", spacedName="TP Aura", description="", category=ModuleCategory.COMBAT)
public final class TPAura
extends Module {
    private final IntegerValue apsValue = new IntegerValue("APS", 2, 1, 10);
    private final IntegerValue maxTargetsValue = new IntegerValue("MaxTargets", 3, 1, 8);
    private final IntegerValue rangeValue = new IntegerValue("Range", 50, 10, 200, "m");
    private final FloatValue fovValue = new FloatValue("FOV", 180.0f, 0.0f, 180.0f, "\u00b0");
    private final ListValue swingValue;
    private final BoolValue autoBlock;
    private final ListValue renderValue;
    private final ListValue priorityValue;
    private final MSTimer clickTimer;
    private ArrayList<Vec3> tpVectors;
    private Thread thread;
    private boolean isBlocking;
    private EntityLivingBase lastTarget;

    public TPAura() {
        String[] stringArray = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Normal");
        this.autoBlock = new BoolValue("AutoBlock", true);
        stringArray = new String[]{"Box", "Lines", "None"};
        this.renderValue = new ListValue("Render", stringArray, "Box");
        stringArray = new String[]{"Health", "Distance", "LivingTime"};
        this.priorityValue = new ListValue("Priority", stringArray, "Distance");
        this.clickTimer = new MSTimer();
        this.tpVectors = new ArrayList();
    }

    public final boolean isBlocking() {
        return this.isBlocking;
    }

    public final void setBlocking(boolean bl) {
        this.isBlocking = bl;
    }

    public final EntityLivingBase getLastTarget() {
        return this.lastTarget;
    }

    public final void setLastTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.lastTarget = entityLivingBase;
    }

    private final long getAttackDelay() {
        return 1000L / (long)((Number)this.apsValue.get()).intValue();
    }

    @Override
    public void onEnable() {
        this.clickTimer.reset();
        this.tpVectors.clear();
        this.lastTarget = null;
    }

    @Override
    public void onDisable() {
        this.isBlocking = false;
        this.clickTimer.reset();
        this.tpVectors.clear();
        this.lastTarget = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!this.clickTimer.hasTimePassed(this.getAttackDelay())) {
            return;
        }
        if (this.thread != null) {
            Thread thread = this.thread;
            Intrinsics.checkNotNull((Object)thread);
            if (thread.isAlive()) {
                this.clickTimer.reset();
                return;
            }
        }
        this.tpVectors.clear();
        this.clickTimer.reset();
        Thread thread = this.thread = new Thread(() -> TPAura.onUpdate$lambda-0(this));
        Intrinsics.checkNotNull((Object)thread);
        thread.start();
    }

    private final void runAttack() {
        if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.theWorld == null) {
            return;
        }
        ArrayList<Entity> targets = new ArrayList<Entity>();
        int entityCount = 0;
        for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase) || !EntityUtils.isSelected(entity, true) || !(MinecraftInstance.mc.thePlayer.getDistanceToEntity(entity) <= (float)((Number)this.rangeValue.get()).intValue()) || ((Number)this.fovValue.get()).floatValue() < 180.0f && RotationUtils.getRotationDifference(entity) > (double)((Number)this.fovValue.get()).floatValue()) continue;
            if (entityCount >= ((Number)this.maxTargetsValue.get()).intValue()) break;
            if (((Boolean)this.autoBlock.get()).booleanValue()) {
                this.isBlocking = true;
            }
            targets.add(entity);
            int n = entityCount;
            entityCount = n + 1;
        }
        if (targets.isEmpty()) {
            this.lastTarget = null;
            this.isBlocking = false;
            return;
        }
        String string = (String)this.priorityValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "distance": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(TPAura.access$getMc$p$s1046033730().thePlayer.getDistanceToEntity((Entity)it));
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(TPAura.access$getMc$p$s1046033730().thePlayer.getDistanceToEntity((Entity)it)));
                    }
                });
                break;
            }
            case "health": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(it.getHealth());
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.getHealth()));
                    }
                });
                break;
            }
            case "livingtime": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(-it.ticksExisted);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(-it.ticksExisted));
                    }
                });
            }
        }
        Iterable $this$forEach$iv = targets;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Vec3 point;
            Object element$iv2;
            EntityLivingBase it = (EntityLivingBase)element$iv;
            boolean bl = false;
            if (MinecraftInstance.mc.thePlayer == null || MinecraftInstance.mc.theWorld == null) {
                return;
            }
            ArrayList<Vec3> path = PathUtils.findTeleportPath((EntityLivingBase)MinecraftInstance.mc.thePlayer, it, 3.0);
            Intrinsics.checkNotNullExpressionValue(path, (String)"path");
            Object $this$forEach$iv2 = path;
            boolean $i$f$forEach2 = false;
            Iterator iterator = $this$forEach$iv2.iterator();
            while (iterator.hasNext()) {
                element$iv2 = iterator.next();
                point = (Vec3)element$iv2;
                boolean bl2 = false;
                this.tpVectors.add(point);
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.xCoord, point.yCoord, point.zCoord, true));
            }
            this.setLastTarget(it);
            String string3 = (String)this.swingValue.get();
            iterator = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"getDefault()");
            element$iv2 = string3.toLowerCase((Locale)((Object)iterator));
            Intrinsics.checkNotNullExpressionValue(element$iv2, (String)"this as java.lang.String).toLowerCase(locale)");
            $this$forEach$iv2 = element$iv2;
            if ($this$forEach$iv2.equals("normal")) {
                MinecraftInstance.mc.thePlayer.swingItem();
            } else if ($this$forEach$iv2.equals("packet")) {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
            }
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity((Entity)it, C02PacketUseEntity.Action.ATTACK));
            $this$forEach$iv2 = CollectionsKt.reversed((Iterable)path);
            $i$f$forEach2 = false;
            iterator = $this$forEach$iv2.iterator();
            while (iterator.hasNext()) {
                element$iv2 = iterator.next();
                point = (Vec3)element$iv2;
                boolean bl3 = false;
                if (StringsKt.equals((String)((String)this.renderValue.get()), (String)"lines", (boolean)true)) {
                    this.tpVectors.add(point);
                }
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.xCoord, point.yCoord, point.zCoord, true));
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S08PacketPlayerPosLook) {
            this.clickTimer.reset();
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        ArrayList<Vec3> arrayList = this.tpVectors;
        synchronized (arrayList) {
            boolean bl = false;
            if (StringsKt.equals((String)((String)this.renderValue.get()), (String)"none", (boolean)true) || this.tpVectors.isEmpty()) {
                return;
            }
            double renderPosX = MinecraftInstance.mc.getRenderManager().viewerPosX;
            double renderPosY = MinecraftInstance.mc.getRenderManager().viewerPosY;
            double renderPosZ = MinecraftInstance.mc.getRenderManager().viewerPosZ;
            GL11.glPushMatrix();
            GL11.glEnable((int)3042);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glShadeModel((int)7425);
            GL11.glDisable((int)3553);
            GL11.glEnable((int)2848);
            GL11.glDisable((int)2929);
            GL11.glDisable((int)2896);
            GL11.glDepthMask((boolean)false);
            GL11.glHint((int)3154, (int)4354);
            GL11.glLoadIdentity();
            MinecraftInstance.mc.entityRenderer.setupCameraTransform(MinecraftInstance.mc.timer.renderPartialTicks, 2);
            RenderUtils.glColor(Color.WHITE);
            GL11.glLineWidth((float)1.0f);
            if (StringsKt.equals((String)((String)this.renderValue.get()), (String)"lines", (boolean)true)) {
                GL11.glBegin((int)3);
            }
            try {
                for (Vec3 vec : this.tpVectors) {
                    double x = vec.xCoord - renderPosX;
                    double y = vec.yCoord - renderPosY;
                    double z = vec.zCoord - renderPosZ;
                    double width = 0.3;
                    double height = MinecraftInstance.mc.thePlayer.getEyeHeight();
                    String string = (String)this.renderValue.get();
                    Locale locale = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                    String string2 = string.toLowerCase(locale);
                    Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                    String string3 = string2;
                    if (string3.equals("box")) {
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(x - width), (double)y, (double)(z - width));
                        GL11.glVertex3d((double)(x - width), (double)y, (double)(z - width));
                        GL11.glVertex3d((double)(x - width), (double)(y + height), (double)(z - width));
                        GL11.glVertex3d((double)(x + width), (double)(y + height), (double)(z - width));
                        GL11.glVertex3d((double)(x + width), (double)y, (double)(z - width));
                        GL11.glVertex3d((double)(x - width), (double)y, (double)(z - width));
                        GL11.glVertex3d((double)(x - width), (double)y, (double)(z + width));
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(x + width), (double)y, (double)(z + width));
                        GL11.glVertex3d((double)(x + width), (double)(y + height), (double)(z + width));
                        GL11.glVertex3d((double)(x - width), (double)(y + height), (double)(z + width));
                        GL11.glVertex3d((double)(x - width), (double)y, (double)(z + width));
                        GL11.glVertex3d((double)(x + width), (double)y, (double)(z + width));
                        GL11.glVertex3d((double)(x + width), (double)y, (double)(z - width));
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(x + width), (double)(y + height), (double)(z + width));
                        GL11.glVertex3d((double)(x + width), (double)(y + height), (double)(z - width));
                        GL11.glEnd();
                        GL11.glBegin((int)3);
                        GL11.glVertex3d((double)(x - width), (double)(y + height), (double)(z + width));
                        GL11.glVertex3d((double)(x - width), (double)(y + height), (double)(z - width));
                        GL11.glEnd();
                        continue;
                    }
                    if (!string3.equals("lines")) continue;
                    GL11.glVertex3d((double)x, (double)y, (double)z);
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (StringsKt.equals((String)((String)this.renderValue.get()), (String)"lines", (boolean)true)) {
                GL11.glEnd();
            }
            GL11.glDepthMask((boolean)true);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glEnable((int)3553);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            Unit unit = Unit.INSTANCE;
        }
    }

    private static final void onUpdate$lambda-0(TPAura this$0) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        this$0.runAttack();
    }

    public static final /* synthetic */ Minecraft access$getMc$p$s1046033730() {
        return MinecraftInstance.mc;
    }
}

