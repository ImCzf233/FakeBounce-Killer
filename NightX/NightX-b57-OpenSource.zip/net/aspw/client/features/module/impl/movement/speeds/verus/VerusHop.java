/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.verus;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class VerusHop
extends SpeedMode {
    public VerusHop() {
        super("VerusHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!(VerusHop.mc.thePlayer.isInWeb || VerusHop.mc.thePlayer.isInLava() || VerusHop.mc.thePlayer.isInWater() || VerusHop.mc.thePlayer.isOnLadder() || VerusHop.mc.thePlayer.ridingEntity != null || !MovementUtils.isMoving())) {
            VerusHop.mc.gameSettings.keyBindJump.pressed = false;
            if (VerusHop.mc.thePlayer.onGround) {
                VerusHop.mc.thePlayer.jump();
                MovementUtils.strafe(0.48f);
            }
            MovementUtils.strafe();
        }
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!VerusHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            VerusHop.mc.thePlayer.motionX = 0.0;
            VerusHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

