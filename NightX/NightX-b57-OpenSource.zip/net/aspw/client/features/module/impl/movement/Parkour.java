/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.minecraft.entity.Entity;

@ModuleInfo(name="Parkour", description="", category=ModuleCategory.MOVEMENT)
public final class Parkour
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MovementUtils.isMoving() && MinecraftInstance.mc.thePlayer.onGround && !MinecraftInstance.mc.thePlayer.isSneaking() && !MinecraftInstance.mc.gameSettings.keyBindSneak.isKeyDown() && !MinecraftInstance.mc.gameSettings.keyBindJump.isKeyDown() && MinecraftInstance.mc.theWorld.getCollidingBoundingBoxes((Entity)MinecraftInstance.mc.thePlayer, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().offset(0.0, -0.5, 0.0).expand(-0.001, 0.0, -0.001)).isEmpty()) {
            MinecraftInstance.mc.thePlayer.jump();
        }
    }
}

