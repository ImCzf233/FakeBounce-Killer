/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.internal.ProgressionUtilKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.item.EntityArmorStand
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.internal.ProgressionUtilKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EntityMovementEvent;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.BackTrack;
import net.aspw.client.features.module.impl.exploit.Disabler;
import net.aspw.client.features.module.impl.other.FreeLook;
import net.aspw.client.features.module.impl.player.Freecam;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.targets.AntiTeams;
import net.aspw.client.util.CooldownHelper;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.RaycastUtils;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.VecRotation;
import net.aspw.client.util.extensions.PlayerExtensionKt;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="KillAura", spacedName="Kill Aura", description="", category=ModuleCategory.COMBAT)
public final class KillAura
extends Module {
    private final BoolValue coolDownCheck = new BoolValue("Cooldown-Check", false);
    private final BoolValue clickOnly = new BoolValue("Click-Only", false);
    private final IntegerValue maxCPS;
    private final IntegerValue minCPS;
    private final IntegerValue hurtTimeValue;
    private final FloatValue rangeValue;
    private final ListValue rotations;
    private final FloatValue maxTurnSpeed;
    private final FloatValue minTurnSpeed;
    private final IntegerValue angleTick;
    private final BoolValue animationValue;
    private final BoolValue cancelSprintValue;
    private final BoolValue noInventoryAttackValue;
    private final BoolValue movementFix;
    private final BoolValue multiCombo;
    private final IntegerValue amountValue;
    private final BoolValue noHitCheck;
    private final ListValue priorityValue;
    private final ListValue targetModeValue;
    private final ListValue swingValue;
    private final ListValue autoBlockModeValue;
    private final BoolValue interactAutoBlockValue;
    private final BoolValue verusAutoBlockValue;
    private final BoolValue silentRotationValue;
    private final BoolValue toggleFreeLook;
    private final FloatValue fovValue;
    private final FloatValue failRateValue;
    private final IntegerValue limitedMultiTargetsValue;
    private final BoolValue simpleESPValue;
    private final BoolValue espValue;
    private final BoolValue circleValue;
    private EntityLivingBase target;
    private EntityLivingBase currentTarget;
    private boolean hitable;
    private final List<Integer> prevTargetEntities;
    private EntityLivingBase markEntity;
    private final MSTimer attackTimer;
    private final TickTimer endTimer;
    private final TickTimer endingTimer;
    private boolean failedHit;
    private long attackDelay;
    private int clicks;
    private long containerOpen;
    private boolean blockingStatus;
    private boolean verusBlocking;
    private boolean fakeBlock;
    private float spinYaw;

    public KillAura() {
        String[] stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.maxCPS = new IntegerValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MaxCPS", 12, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)KillAura.access$getMinCPS$p(this.this$0).get()).intValue();
                if (i > newValue) {
                    this.set(i);
                }
                KillAura.access$setAttackDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)KillAura.access$getMinCPS$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.minCPS = new IntegerValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MinCPS", 10, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)KillAura.access$getMaxCPS$p(this.this$0).get()).intValue();
                if (i < newValue) {
                    this.set(i);
                }
                KillAura.access$setAttackDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)this.get()).intValue(), ((Number)KillAura.access$getMaxCPS$p(this.this$0).get()).intValue()));
            }
        };
        this.hurtTimeValue = new IntegerValue("HurtTime", 10, 0, 10);
        this.rangeValue = new FloatValue(){};
        stringArray = new String[]{"Undetectable", "HvH", "Zero", "None"};
        this.rotations = new ListValue("RotationMode", stringArray, "Undetectable");
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"zero", (boolean)true);
            }
        };
        this.maxTurnSpeed = new FloatValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MaxTurnSpeed", 120.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)KillAura.access$getMinTurnSpeed$p(this.this$0).get()).floatValue();
                if (v > newValue) {
                    this.set(Float.valueOf(v));
                }
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"zero", (boolean)true);
            }
        };
        this.minTurnSpeed = new FloatValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MinTurnSpeed", 100.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)KillAura.access$getMaxTurnSpeed$p(this.this$0).get()).floatValue();
                if (v < newValue) {
                    this.set(Float.valueOf(v));
                }
            }
        };
        this.angleTick = new IntegerValue("Angle-Tick", 1, 1, 100, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.animationValue = new BoolValue("Animation", true);
        this.cancelSprintValue = new BoolValue("Cancel-Sprinting", false);
        this.noInventoryAttackValue = new BoolValue("NoInvAttack", false);
        this.movementFix = new BoolValue("MovementFix", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.multiCombo = new BoolValue("MultiCombo", false);
        this.amountValue = new IntegerValue("Multi-Packet", 5, 0, 20, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getMultiCombo$p(this.this$0).get();
            }
        }));
        this.noHitCheck = new BoolValue("NoHitCheck", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        stringArray = new String[]{"Health", "Distance", "Direction", "LivingTime", "Armor", "HurtResistance", "HurtTime", "HealthAbsorption", "RegenAmplifier"};
        this.priorityValue = new ListValue("Priority", stringArray, "Distance");
        stringArray = new String[]{"Single", "Switch", "Multi"};
        this.targetModeValue = new ListValue("TargetMode", stringArray, "Single");
        stringArray = new String[]{"Full", "Smart", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Full");
        stringArray = new String[]{"Packet", "AfterTick", "NCP", "HurtTime", "Click", "OldHypixel", "OldIntave", "Fake", "None"};
        this.autoBlockModeValue = new ListValue("AutoBlock", stringArray, "Fake");
        this.interactAutoBlockValue = new BoolValue("InteractAutoBlock", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"Fake", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"None", (boolean)true);
            }
        }));
        this.verusAutoBlockValue = new BoolValue("UnBlock-Exploit", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"Fake", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"None", (boolean)true);
            }
        }));
        this.silentRotationValue = new BoolValue("SilentRotation", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.toggleFreeLook = new BoolValue("ToggleFreeLook", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && (Boolean)this.this$0.getSilentRotationValue().get() == false;
            }
        }));
        this.fovValue = new FloatValue("FOV", 180.0f, 0.0f, 180.0f);
        this.failRateValue = new FloatValue("FailRate", 0.0f, 0.0f, 100.0f);
        this.limitedMultiTargetsValue = new IntegerValue("LimitedMultiTargets", 6, 1, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)KillAura.access$getTargetModeValue$p(this.this$0).get()), (String)"multi", (boolean)true);
            }
        }));
        this.simpleESPValue = new BoolValue("Simple-ESP", true);
        this.espValue = new BoolValue("CSGO-ESP", false);
        this.circleValue = new BoolValue("Circle", false);
        this.prevTargetEntities = new ArrayList();
        this.attackTimer = new MSTimer();
        this.endTimer = new TickTimer();
        this.endingTimer = new TickTimer();
        this.containerOpen = -1L;
    }

    public final ListValue getRotations() {
        return this.rotations;
    }

    public final BoolValue getMovementFix() {
        return this.movementFix;
    }

    public final ListValue getAutoBlockModeValue() {
        return this.autoBlockModeValue;
    }

    public final BoolValue getSilentRotationValue() {
        return this.silentRotationValue;
    }

    public final EntityLivingBase getTarget() {
        return this.target;
    }

    public final void setTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.target = entityLivingBase;
    }

    public final EntityLivingBase getCurrentTarget() {
        return this.currentTarget;
    }

    public final void setCurrentTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.currentTarget = entityLivingBase;
    }

    public final boolean getHitable() {
        return this.hitable;
    }

    public final void setHitable(boolean bl) {
        this.hitable = bl;
    }

    public final boolean getBlockingStatus() {
        return this.blockingStatus;
    }

    public final void setBlockingStatus(boolean bl) {
        this.blockingStatus = bl;
    }

    public final boolean getVerusBlocking() {
        return this.verusBlocking;
    }

    public final void setVerusBlocking(boolean bl) {
        this.verusBlocking = bl;
    }

    public final boolean getFakeBlock() {
        return this.fakeBlock;
    }

    public final void setFakeBlock(boolean bl) {
        this.fakeBlock = bl;
    }

    public final float getSpinYaw() {
        return this.spinYaw;
    }

    public final void setSpinYaw(float f) {
        this.spinYaw = f;
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        if (MinecraftInstance.mc.theWorld == null) {
            return;
        }
        this.updateTarget();
        this.verusBlocking = false;
    }

    @Override
    public void onDisable() {
        this.target = null;
        this.currentTarget = null;
        this.hitable = false;
        this.prevTargetEntities.clear();
        this.attackTimer.reset();
        this.clicks = 0;
        if (((Boolean)this.toggleFreeLook.get()).booleanValue() && this.target != null) {
            FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
            Intrinsics.checkNotNull((Object)freeLook);
            freeLook.setState(false);
        }
        this.stopBlocking();
        if (this.verusBlocking && !this.blockingStatus && !MinecraftInstance.mc.thePlayer.isBlocking()) {
            this.verusBlocking = false;
            if (((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN)));
            }
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() == EventState.POST) {
            if (this.target == null) {
                return;
            }
            if (this.currentTarget == null) {
                return;
            }
            this.updateHitable();
            if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"AfterTick", (boolean)true) && this.getCanBlock()) {
                EntityLivingBase entityLivingBase = this.currentTarget;
                Intrinsics.checkNotNull((Object)entityLivingBase);
                this.startBlocking((Entity)entityLivingBase, this.hitable);
            }
        }
        if (((Boolean)this.toggleFreeLook.get()).booleanValue() && !((Boolean)this.silentRotationValue.get()).booleanValue() && this.target != null && !StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
            Intrinsics.checkNotNull((Object)freeLook);
            freeLook.setState(true);
        }
    }

    public final void update() {
        if (this.getCancelRun() || ((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.currentScreen instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            return;
        }
        this.updateTarget();
        if (this.target == null) {
            this.stopBlocking();
            return;
        }
        this.currentTarget = this.target;
        if (!StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Switch", (boolean)true) && this.isEnemy((Entity)this.currentTarget)) {
            this.target = this.currentTarget;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (this.verusBlocking && (packet instanceof C07PacketPlayerDigging && ((C07PacketPlayerDigging)packet).getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM || packet instanceof C08PacketPlayerBlockPlacement) && ((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
            event.cancelEvent();
        }
        if (packet instanceof C09PacketHeldItemChange) {
            this.verusBlocking = false;
        }
    }

    @EventTarget
    public final void onStrafe(StrafeEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.update();
        if (this.target != null) {
            EntityLivingBase entityLivingBase = this.target;
            Integer n = entityLivingBase == null ? null : Integer.valueOf(entityLivingBase.hurtTime);
            Intrinsics.checkNotNull((Object)n);
            if (n > 8) {
                if (((Boolean)this.cancelSprintValue.get()).booleanValue()) {
                    MinecraftInstance.mc.thePlayer.setSprinting(false);
                }
                if (((Boolean)this.animationValue.get()).booleanValue()) {
                    MinecraftInstance.mc.getItemRenderer().resetEquippedProgress2();
                }
            }
            EntityLivingBase entityLivingBase2 = this.target;
            Integer n2 = entityLivingBase2 == null ? null : Integer.valueOf(entityLivingBase2.hurtTime);
            Intrinsics.checkNotNull((Object)n2);
            if (n2 > 9) {
                MinecraftInstance.mc.effectRenderer.emitParticleAtEntity((Entity)this.target, EnumParticleTypes.CRIT_MAGIC);
                MinecraftInstance.mc.effectRenderer.emitParticleAtEntity((Entity)this.target, EnumParticleTypes.CRIT);
            }
        }
        if (((Boolean)this.movementFix.get()).booleanValue() && this.currentTarget != null && RotationUtils.targetRotation != null) {
            Rotation rotation = RotationUtils.targetRotation;
            if (rotation == null) {
                return;
            }
            float yaw = rotation.component1();
            float strafe = event.getStrafe();
            float forward = event.getForward();
            float friction = event.getFriction();
            float f = strafe * strafe + forward * forward;
            if (f >= 1.0E-4f) {
                if ((f = MathHelper.sqrt_float((float)f)) < 1.0f) {
                    f = 1.0f;
                }
                f = friction / f;
                float yawSin = MathHelper.sin((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                float yawCos = MathHelper.cos((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionX += (double)((strafe *= f) * yawCos - (forward *= f) * yawSin);
                entityPlayerSP = MinecraftInstance.mc.thePlayer;
                entityPlayerSP.motionZ += (double)(forward * yawCos + strafe * yawSin);
            }
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.updateKA();
        if (MinecraftInstance.mc.thePlayer.isBlocking() || this.blockingStatus || this.target != null) {
            this.verusBlocking = true;
        } else if (this.verusBlocking) {
            this.verusBlocking = false;
            if (((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN)));
            }
        }
    }

    private final void updateKA() {
        if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.gameSettings.keyBindAttack.isKeyDown() || MinecraftInstance.mc.thePlayer.isRiding()) {
            return;
        }
        if (this.getCancelRun()) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            this.stopBlocking();
            return;
        }
        if (((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.currentScreen instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            if (MinecraftInstance.mc.currentScreen instanceof GuiContainer) {
                this.containerOpen = System.currentTimeMillis();
            }
            return;
        }
        if (((Boolean)this.coolDownCheck.get()).booleanValue() && CooldownHelper.INSTANCE.getAttackCooldownProgress() < 1.0) {
            return;
        }
        if (this.target != null && this.currentTarget != null) {
            this.endingTimer.update();
            this.endTimer.update();
            while (this.clicks > 0) {
                this.runAttack();
                int n = this.clicks;
                this.clicks = n + -1;
            }
        }
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        int i;
        int n;
        int n2;
        int n3;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.circleValue.get()).booleanValue()) {
            GL11.glPushMatrix();
            GL11.glTranslated((double)(MinecraftInstance.mc.thePlayer.lastTickPosX + (MinecraftInstance.mc.thePlayer.posX - MinecraftInstance.mc.thePlayer.lastTickPosX) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosX), (double)(MinecraftInstance.mc.thePlayer.lastTickPosY + (MinecraftInstance.mc.thePlayer.posY - MinecraftInstance.mc.thePlayer.lastTickPosY) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosY), (double)(MinecraftInstance.mc.thePlayer.lastTickPosZ + (MinecraftInstance.mc.thePlayer.posZ - MinecraftInstance.mc.thePlayer.lastTickPosZ) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosZ));
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glLineWidth((float)1.0f);
            GL11.glColor4f((float)0.0f, (float)1.0f, (float)1.0f, (float)0.78431374f);
            GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glBegin((int)3);
            n3 = 20;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * ((Number)this.rangeValue.get()).floatValue() - 0.3f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * ((Number)this.rangeValue.get()).floatValue() - 0.3f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glPopMatrix();
        }
        if (this.getCancelRun()) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            this.stopBlocking();
            return;
        }
        if (((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.currentScreen instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            if (MinecraftInstance.mc.currentScreen instanceof GuiContainer) {
                this.containerOpen = System.currentTimeMillis();
            }
            return;
        }
        if (this.target == null) {
            return;
        }
        if (((Boolean)this.simpleESPValue.get()).booleanValue()) {
            EntityLivingBase entityLivingBase = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            int n4 = (int)entityLivingBase.posX;
            EntityLivingBase entityLivingBase2 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase2);
            int n5 = (int)entityLivingBase2.posY + 1;
            EntityLivingBase entityLivingBase3 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase3);
            RenderUtils.drawBlockBox(new BlockPos(n4, n5, (int)entityLivingBase3.posZ), Color.WHITE, false);
        }
        if (((Boolean)this.espValue.get()).booleanValue()) {
            if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.gameSettings.keyBindAttack.isKeyDown() || MinecraftInstance.mc.thePlayer.isRiding()) {
                return;
            }
            GL11.glPushMatrix();
            EntityLivingBase entityLivingBase = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            double d = entityLivingBase.lastTickPosX;
            EntityLivingBase entityLivingBase4 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase4);
            double d2 = entityLivingBase4.posX;
            EntityLivingBase entityLivingBase5 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase5);
            double d3 = d + (d2 - entityLivingBase5.lastTickPosX) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosX;
            EntityLivingBase entityLivingBase6 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase6);
            double d4 = entityLivingBase6.lastTickPosY;
            EntityLivingBase entityLivingBase7 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase7);
            double d5 = entityLivingBase7.posY;
            EntityLivingBase entityLivingBase8 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase8);
            double d6 = d4 + (d5 - entityLivingBase8.lastTickPosY) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosY;
            EntityLivingBase entityLivingBase9 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase9);
            double d7 = entityLivingBase9.lastTickPosZ;
            EntityLivingBase entityLivingBase10 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase10);
            double d8 = entityLivingBase10.posZ;
            EntityLivingBase entityLivingBase11 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase11);
            GL11.glTranslated((double)d3, (double)d6, (double)(d7 + (d8 - entityLivingBase11.lastTickPosZ) * (double)MinecraftInstance.mc.timer.renderPartialTicks - MinecraftInstance.mc.getRenderManager().renderPosZ));
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glLineWidth((float)4.25f);
            GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
            GL11.glBegin((int)2);
            n3 = 40;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * 0.8f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * 0.8f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glLineWidth((float)3.0f);
            GL11.glBegin((int)2);
            n3 = 40;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glColor3f((float)1.0f, (float)1.0f, (float)0.0f);
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * 0.8f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * 0.8f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glPopMatrix();
            GlStateManager.resetColor();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        if (this.currentTarget != null && this.attackTimer.hasTimePassed(this.attackDelay)) {
            EntityLivingBase entityLivingBase = this.currentTarget;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            if (entityLivingBase.hurtTime <= ((Number)this.hurtTimeValue.get()).intValue()) {
                n3 = this.clicks;
                this.clicks = n3 + 1;
                this.attackTimer.reset();
                this.attackDelay = (Boolean)this.coolDownCheck.get() != false ? TimeUtils.randomClickDelay(20, 20) : TimeUtils.randomClickDelay(((Number)this.minCPS.get()).intValue(), ((Number)this.maxCPS.get()).intValue());
            }
        }
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.multiCombo.get()).booleanValue()) {
            if (event.getTargetEntity() == null) {
                return;
            }
            int n = ((Number)this.amountValue.get()).intValue();
            int n2 = 0;
            while (n2 < n) {
                int n3;
                int it = n3 = n2++;
                boolean bl = false;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0APacketAnimation()));
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C02PacketUseEntity(event.getTargetEntity(), C02PacketUseEntity.Action.ATTACK)));
            }
        }
    }

    @EventTarget
    public final void onEntityMove(EntityMovementEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Entity movedEntity = event.getMovedEntity();
        if (this.target == null || !movedEntity.equals(this.currentTarget)) {
            return;
        }
        this.updateHitable();
    }

    /*
     * Unable to fully structure code
     */
    private final void runAttack() {
        if (this.target == null) {
            return;
        }
        if (this.currentTarget == null) {
            return;
        }
        failRate = ((Number)this.failRateValue.get()).floatValue();
        multi = StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Multi", (boolean)true);
        if (!(failRate > 0.0f)) ** GOTO lbl-1000
        v0 = new Random();
        if ((float)v0.nextInt(100) <= failRate) {
            v1 = true;
        } else lbl-1000:
        // 2 sources

        {
            v1 = failHit = false;
        }
        if (!this.hitable || failHit) {
            if (failHit) {
                this.failedHit = true;
            }
        } else {
            if (!multi) {
                v2 = this.currentTarget;
                Intrinsics.checkNotNull((Object)v2);
                this.attackEntity(v2);
            } else {
                targets = 0;
                for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
                    var9_8 = MinecraftInstance.mc.thePlayer;
                    Intrinsics.checkNotNullExpressionValue((Object)var9_8, (String)"mc.thePlayer");
                    v3 = (Entity)var9_8;
                    Intrinsics.checkNotNullExpressionValue((Object)entity, (String)"entity");
                    distance = PlayerExtensionKt.getDistanceToEntityBox(v3, entity);
                    if (!(entity instanceof EntityLivingBase) || !this.isEnemy(entity) || !(distance <= (double)this.getRange(entity))) continue;
                    this.attackEntity((EntityLivingBase)entity);
                    if (((Number)this.limitedMultiTargetsValue.get()).intValue() == 0 || ((Number)this.limitedMultiTargetsValue.get()).intValue() > ++targets) continue;
                }
            }
            v4 = this.currentTarget;
            Intrinsics.checkNotNull((Object)v4);
            this.prevTargetEntities.add(v4.getEntityId());
            if (this.target.equals(this.currentTarget)) {
                this.target = null;
            }
        }
    }

    private final void updateTarget() {
        Object searchTarget = null;
        int hurtTime = ((Number)this.hurtTimeValue.get()).intValue();
        float fov = ((Number)this.fovValue.get()).floatValue();
        boolean switchMode = StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Switch", (boolean)true);
        List targets = new ArrayList();
        for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
            if (!(entity instanceof EntityLivingBase) || !this.isEnemy(entity) || switchMode && this.prevTargetEntities.contains(((EntityLivingBase)entity).getEntityId())) continue;
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
            double distance = PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity);
            double entityFov = RotationUtils.getRotationDifference(entity);
            if (!(distance <= (double)this.getMaxRange()) || !(fov == 180.0f) && !(entityFov <= (double)fov) || ((EntityLivingBase)entity).hurtTime > hurtTime) continue;
            targets.add(entity);
        }
        String string = (String)this.priorityValue.get();
        Locale distance = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)distance, (String)"getDefault()");
        String string2 = string.toLowerCase(distance);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "distance": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        EntityPlayerSP entityPlayerSP = KillAura.access$getMc$p$s1046033730().thePlayer;
                        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
                        Comparable comparable = Double.valueOf(PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, (Entity)it));
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        entityPlayerSP = KillAura.access$getMc$p$s1046033730().thePlayer;
                        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Double.valueOf(PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, (Entity)it)));
                    }
                });
                break;
            }
            case "health": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(it.getHealth());
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.getHealth()));
                    }
                });
                break;
            }
            case "direction": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Double.valueOf(RotationUtils.getRotationDifference((Entity)it));
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Double.valueOf(RotationUtils.getRotationDifference((Entity)it)));
                    }
                });
                break;
            }
            case "livingtime": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(-it.ticksExisted);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(-it.ticksExisted));
                    }
                });
                break;
            }
            case "hurtresistance": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(it.hurtResistantTime);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.hurtResistantTime));
                    }
                });
                break;
            }
            case "hurttime": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(it.hurtTime);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.hurtTime));
                    }
                });
                break;
            }
            case "healthabsorption": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(it.getHealth() + it.getAbsorptionAmount());
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.getHealth() + it.getAbsorptionAmount()));
                    }
                });
                break;
            }
            case "regenamplifier": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        int n = it.isPotionActive(Potion.regeneration) ? it.getActivePotionEffect(Potion.regeneration).getAmplifier() : -1;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(n);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.isPotionActive(Potion.regeneration) ? it.getActivePotionEffect(Potion.regeneration).getAmplifier() : -1));
                    }
                });
            }
        }
        boolean found = false;
        for (EntityLivingBase entity : targets) {
            if (!this.updateRotations((Entity)entity)) continue;
            BackTrack backTrack = Client.INSTANCE.getModuleManager().getModule(BackTrack.class);
            if (backTrack != null) {
                backTrack.loopThroughBacktrackData((Entity)entity, (Function0<Boolean>)((Function0)new Function0<Boolean>(this, entity){
                    final /* synthetic */ KillAura this$0;
                    final /* synthetic */ EntityLivingBase $entity;
                    {
                        this.this$0 = $receiver;
                        this.$entity = $entity;
                        super(0);
                    }

                    public final Boolean invoke() {
                        if (KillAura.access$updateRotations(this.this$0, (Entity)this.$entity)) {
                            return true;
                        }
                        return false;
                    }
                }));
            }
            this.target = entity;
            found = true;
            break;
        }
        if (found) {
            return;
        }
        this.target = null;
        if (!((Collection)this.prevTargetEntities).isEmpty()) {
            this.prevTargetEntities.clear();
            this.updateTarget();
        }
    }

    public final boolean isEnemy(@Nullable Entity entity) {
        if (entity instanceof EntityLivingBase && (EntityUtils.targetDead || this.isAlive((EntityLivingBase)entity)) && !entity.equals(MinecraftInstance.mc.thePlayer)) {
            if (!EntityUtils.targetInvisible && ((EntityLivingBase)entity).isInvisible()) {
                return false;
            }
            if (EntityUtils.targetPlayer && entity instanceof EntityPlayer) {
                if (((EntityPlayer)entity).isSpectator() || AntiBots.Companion.isBot((EntityLivingBase)entity)) {
                    return false;
                }
                if (EntityUtils.isFriend(entity)) {
                    return false;
                }
                AntiTeams antiTeams = Client.INSTANCE.getModuleManager().get(AntiTeams.class);
                if (antiTeams == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.targets.AntiTeams");
                }
                AntiTeams antiTeams2 = antiTeams;
                return !antiTeams2.getState() || !antiTeams2.isInYourTeam((EntityLivingBase)entity);
            }
            return EntityUtils.targetMobs && EntityUtils.isMob(entity) || EntityUtils.targetAnimals && EntityUtils.isAnimal(entity);
        }
        return false;
    }

    private final void attackEntity(EntityLivingBase entity) {
        Client.INSTANCE.getEventManager().callEvent(new AttackEvent((Entity)entity));
        this.markEntity = entity;
        String string = (String)this.swingValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "full": {
                MinecraftInstance.mc.thePlayer.swingItem();
                break;
            }
            case "smart": {
                MinecraftInstance.mc.thePlayer.isSwingInProgress = true;
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                break;
            }
            case "packet": {
                MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
            }
        }
        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity((Entity)entity, C02PacketUseEntity.Action.ATTACK));
        if (!StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"AfterTick", (boolean)true) && (MinecraftInstance.mc.thePlayer.isBlocking() || this.getCanBlock())) {
            this.startBlocking((Entity)entity, (Boolean)this.interactAutoBlockValue.get());
        }
    }

    private final boolean updateRotations(Entity entity) {
        if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.gameSettings.keyBindAttack.isKeyDown() || MinecraftInstance.mc.thePlayer.isRiding()) {
            return false;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            return true;
        }
        Disabler disabler = Client.INSTANCE.getModuleManager().getModule(Disabler.class);
        Intrinsics.checkNotNull((Object)disabler);
        Disabler disabler2 = disabler;
        boolean modify = disabler2.getCanModifyRotation();
        if (modify) {
            return true;
        }
        Rotation rotation = this.getTargetRotation(entity);
        if (rotation == null) {
            return false;
        }
        Rotation defRotation = rotation;
        if (!((Object)defRotation).equals(RotationUtils.serverRotation)) {
            defRotation.setYaw(RotationUtils.roundRotation(defRotation.getYaw(), ((Number)this.angleTick.get()).intValue()));
        }
        if (((Boolean)this.silentRotationValue.get()).booleanValue()) {
            RotationUtils.setTargetRotation(defRotation, 0);
        } else {
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            defRotation.toPlayer((EntityPlayer)entityPlayerSP);
        }
        return true;
    }

    private final Rotation getTargetRotation(Entity entity) {
        AxisAlignedBB boundingBox = null;
        boundingBox = entity.getEntityBoundingBox();
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"HvH", (boolean)true)) {
            Rotation rotation;
            Rotation rotation2 = RotationUtils.serverRotation;
            if (rotation2 == null) {
                rotation = null;
            } else {
                Rotation it = rotation2;
                boolean bl = false;
                Vec3 vec3 = RotationUtils.getCenter(entity.getEntityBoundingBox());
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP);
                rotation = RotationUtils.limitAngleChange(it, RotationUtils.OtherRotation(boundingBox, vec3, false, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity) < (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f), this.getMaxRange()), (float)(Math.random() * (double)(((Number)this.maxTurnSpeed.get()).floatValue() - ((Number)this.minTurnSpeed.get()).floatValue()) + ((Number)this.minTurnSpeed.get()).doubleValue()));
            }
            Rotation limitedRotation = rotation;
            return limitedRotation;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"Undetectable", (boolean)true)) {
            if (((Number)this.maxTurnSpeed.get()).floatValue() <= 0.0f) {
                return RotationUtils.serverRotation;
            }
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            VecRotation vecRotation = RotationUtils.searchCenter(boundingBox, false, true, false, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity) < (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f), this.getMaxRange(), RandomUtils.nextFloat(10.0f, 15.0f), false);
            if (vecRotation == null) {
                return null;
            }
            Rotation rotation = vecRotation.component2();
            Rotation rotation3 = RotationUtils.limitAngleChange(RotationUtils.serverRotation, rotation, (float)(Math.random() * (double)(((Number)this.maxTurnSpeed.get()).floatValue() - ((Number)this.minTurnSpeed.get()).floatValue()) + ((Number)this.minTurnSpeed.get()).doubleValue()));
            Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026).toFloat()\n            )");
            Rotation limitedRotation = rotation3;
            return limitedRotation;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"Zero", (boolean)true)) {
            Vec3 vec3 = MinecraftInstance.mc.thePlayer.getPositionEyes(1.0f);
            Intrinsics.checkNotNullExpressionValue((Object)vec3, (String)"mc.thePlayer.getPositionEyes(1F)");
            Vec3 vec32 = vec3;
            vec3 = boundingBox;
            Intrinsics.checkNotNullExpressionValue((Object)vec3, (String)"boundingBox");
            return RotationUtils.calculate(PlayerExtensionKt.getNearestPointBB(vec32, (AxisAlignedBB)vec3));
        }
        return RotationUtils.serverRotation;
    }

    private final void updateHitable() {
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            this.hitable = true;
            return;
        }
        Disabler disabler = Client.INSTANCE.getModuleManager().getModule(Disabler.class);
        Intrinsics.checkNotNull((Object)disabler);
        Disabler disabler2 = disabler;
        if (((Number)this.maxTurnSpeed.get()).floatValue() <= 0.0f || ((Boolean)this.noHitCheck.get()).booleanValue() || disabler2.getCanModifyRotation()) {
            this.hitable = true;
            return;
        }
        double d = this.getAttackRange();
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
        Entity entity = (Entity)entityPlayerSP;
        EntityLivingBase entityLivingBase = this.target;
        Intrinsics.checkNotNull((Object)entityLivingBase);
        Entity raycastedEntity = RaycastUtils.raycastEntity(Math.min(d, PlayerExtensionKt.getDistanceToEntityBox(entity, (Entity)entityLivingBase)) + 1.0, arg_0 -> KillAura.updateHitable$lambda-10(this, arg_0));
        if (raycastedEntity instanceof EntityLivingBase && !EntityUtils.isFriend(raycastedEntity)) {
            this.currentTarget = (EntityLivingBase)raycastedEntity;
        }
        this.hitable = ((Number)this.maxTurnSpeed.get()).floatValue() > 0.0f ? this.currentTarget.equals(raycastedEntity) : true;
    }

    private final void startBlocking(Entity interactEntity, boolean interact) {
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"none", (boolean)true)) {
            this.fakeBlock = false;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"fake", (boolean)true)) {
            this.fakeBlock = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"ncp", (boolean)true)) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, null, 0.0f, 0.0f, 0.0f)));
            this.blockingStatus = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"click", (boolean)true)) {
            KeyBinding.setKeyBindState((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode(), (boolean)true);
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldintave", (boolean)true)) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange((MinecraftInstance.mc.thePlayer.inventory.currentItem + 1) % 9));
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.thePlayer.inventory.currentItem));
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"hurttime", (boolean)true)) {
            if (MinecraftInstance.mc.thePlayer.hurtTime > 1) {
                if (!MinecraftInstance.mc.thePlayer.onGround) {
                    KeyBinding.setKeyBindState((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode(), (boolean)true);
                }
            } else {
                KeyBinding.setKeyBindState((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode(), (boolean)false);
            }
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"packet", (boolean)true)) {
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.thePlayer.inventory.getCurrentItem()));
            this.blockingStatus = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldhypixel", (boolean)true)) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.thePlayer.inventory.getCurrentItem(), 0.0f, 0.0f, 0.0f)));
            this.blockingStatus = true;
        }
        if (interact) {
            Entity entity = MinecraftInstance.mc.getRenderViewEntity();
            Vec3 positionEye = entity == null ? null : entity.getPositionEyes(1.0f);
            double expandSize = interactEntity.getCollisionBorderSize();
            AxisAlignedBB boundingBox = interactEntity.getEntityBoundingBox().expand(expandSize, expandSize, expandSize);
            Rotation rotation = RotationUtils.targetRotation;
            if (rotation == null) {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP);
                float f = entityPlayerSP.rotationYaw;
                EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.thePlayer;
                Intrinsics.checkNotNull((Object)entityPlayerSP2);
                rotation = new Rotation(f, entityPlayerSP2.rotationPitch);
            }
            Rotation rotation2 = rotation;
            float yaw = rotation2.component1();
            float pitch = rotation2.component2();
            float yawCos = (float)Math.cos(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
            float yawSin = (float)Math.sin(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
            float pitchCos = -((float)Math.cos(-pitch * ((float)Math.PI / 180)));
            float pitchSin = (float)Math.sin(-pitch * ((float)Math.PI / 180));
            double d = this.getMaxRange();
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            double range2 = Math.min(d, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, interactEntity)) + 1.0;
            Vec3 vec3 = positionEye;
            Intrinsics.checkNotNull((Object)vec3);
            Vec3 lookAt = vec3.addVector((double)(yawSin * pitchCos) * range2, (double)pitchSin * range2, (double)(yawCos * pitchCos) * range2);
            MovingObjectPosition movingObjectPosition = boundingBox.calculateIntercept(positionEye, lookAt);
            if (movingObjectPosition == null) {
                return;
            }
            MovingObjectPosition movingObject = movingObjectPosition;
            Vec3 hitVec = movingObject.hitVec;
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity(interactEntity, new Vec3(hitVec.xCoord - interactEntity.posX, hitVec.yCoord - interactEntity.posY, hitVec.zCoord - interactEntity.posZ)));
            MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C02PacketUseEntity(interactEntity, C02PacketUseEntity.Action.INTERACT));
        }
    }

    private final void stopBlocking() {
        block18: {
            block19: {
                this.fakeBlock = false;
                this.blockingStatus = false;
                if (this.endTimer.hasTimePassed(2)) {
                    if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"click", (boolean)true) || StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"hurttime", (boolean)true)) {
                        KeyBinding.setKeyBindState((int)MinecraftInstance.mc.gameSettings.keyBindUseItem.getKeyCode(), (boolean)false);
                    }
                    if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldhypixel", (boolean)true)) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(1.0, 1.0, 1.0), EnumFacing.DOWN)));
                    }
                    if (!StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"fake", (boolean)true) && !StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"none", (boolean)true)) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN)));
                    }
                    if (((Boolean)this.toggleFreeLook.get()).booleanValue()) {
                        FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
                        Boolean bl = freeLook == null ? null : Boolean.valueOf(freeLook.getState());
                        Intrinsics.checkNotNull((Object)bl);
                        if (bl.booleanValue()) {
                            FreeLook freeLook2 = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
                            Intrinsics.checkNotNull((Object)freeLook2);
                            freeLook2.setState(false);
                        }
                    }
                    this.endTimer.reset();
                }
                if (!this.endingTimer.hasTimePassed(3)) break block18;
                if (((Boolean)this.coolDownCheck.get()).booleanValue()) break block19;
                String string = (String)this.swingValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                switch (string2) {
                    case "smart": 
                    case "full": {
                        MinecraftInstance.mc.thePlayer.swingItem();
                        break;
                    }
                    case "packet": {
                        MinecraftInstance.mc.getNetHandler().addToSendQueue((Packet)new C0APacketAnimation());
                    }
                }
            }
            this.endingTimer.reset();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean getCancelRun() {
        if (MinecraftInstance.mc.thePlayer.isSpectator()) return true;
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
        if (!this.isAlive((EntityLivingBase)entityPlayerSP)) return true;
        Freecam freecam = Client.INSTANCE.getModuleManager().get(Freecam.class);
        Intrinsics.checkNotNull((Object)freecam);
        if (freecam.getState()) return true;
        Scaffold scaffold = Client.INSTANCE.getModuleManager().get(Scaffold.class);
        Intrinsics.checkNotNull((Object)scaffold);
        if (!scaffold.getState()) return false;
        return true;
    }

    private final boolean isAlive(EntityLivingBase entity) {
        return entity.isEntityAlive() && entity.getHealth() > 0.0f;
    }

    private final boolean getCanBlock() {
        return MinecraftInstance.mc.thePlayer.getHeldItem() != null && MinecraftInstance.mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }

    private final float getMaxRange() {
        return Math.max(((Number)this.rangeValue.get()).floatValue() - 0.3f, ((Number)this.rangeValue.get()).floatValue() - 0.3f);
    }

    private final float getAttackRange() {
        return Math.max(((Number)this.rangeValue.get()).floatValue() - 0.3f, ((Number)this.rangeValue.get()).floatValue() - 0.3f);
    }

    private final float getRange(Entity entity) {
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
        return (PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity) >= (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f) ? ((Number)this.rangeValue.get()).floatValue() - 0.3f : ((Number)this.rangeValue.get()).floatValue() - 0.3f) - (MinecraftInstance.mc.thePlayer.isSprinting() ? 0.02f : 0.0f);
    }

    @Override
    public String getTag() {
        return (String)this.targetModeValue.get();
    }

    private static final boolean updateHitable$lambda-10(KillAura this$0, Entity it) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        return it instanceof EntityLivingBase && !(it instanceof EntityArmorStand) && this$0.isEnemy(it);
    }

    public static final /* synthetic */ boolean access$updateRotations(KillAura $this, Entity entity) {
        return $this.updateRotations(entity);
    }

    public static final /* synthetic */ Minecraft access$getMc$p$s1046033730() {
        return MinecraftInstance.mc;
    }

    public static final /* synthetic */ IntegerValue access$getMinCPS$p(KillAura $this) {
        return $this.minCPS;
    }

    public static final /* synthetic */ void access$setAttackDelay$p(KillAura $this, long l) {
        $this.attackDelay = l;
    }

    public static final /* synthetic */ BoolValue access$getCoolDownCheck$p(KillAura $this) {
        return $this.coolDownCheck;
    }

    public static final /* synthetic */ IntegerValue access$getMaxCPS$p(KillAura $this) {
        return $this.maxCPS;
    }

    public static final /* synthetic */ FloatValue access$getMinTurnSpeed$p(KillAura $this) {
        return $this.minTurnSpeed;
    }

    public static final /* synthetic */ FloatValue access$getMaxTurnSpeed$p(KillAura $this) {
        return $this.maxTurnSpeed;
    }

    public static final /* synthetic */ BoolValue access$getMultiCombo$p(KillAura $this) {
        return $this.multiCombo;
    }

    public static final /* synthetic */ ListValue access$getTargetModeValue$p(KillAura $this) {
        return $this.targetModeValue;
    }
}

