/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="Trails", description="", category=ModuleCategory.VISUAL)
public final class Trails
extends Module {
    private final BoolValue unlimitedValue = new BoolValue("Unlimited", false);
    private final FloatValue lineWidth = new FloatValue("LineWidth", 4.0f, 1.0f, 10.0f);
    private final IntegerValue colorRedValue = new IntegerValue("R", 255, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 255, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 255, 0, 255);
    private final IntegerValue alphaValue = new IntegerValue("Alpha", 150, 0, 255);
    private final IntegerValue fadeSpeedValue = new IntegerValue("Fade-Speed", 1, 0, 255);
    private final BoolValue colorRainbow = new BoolValue("Rainbow", true);
    private final LinkedList<Dot> positions = new LinkedList();
    private double lastX;
    private double lastY;
    private double lastZ;

    public final BoolValue getUnlimitedValue() {
        return this.unlimitedValue;
    }

    public final FloatValue getLineWidth() {
        return this.lineWidth;
    }

    public final IntegerValue getColorRedValue() {
        return this.colorRedValue;
    }

    public final IntegerValue getColorGreenValue() {
        return this.colorGreenValue;
    }

    public final IntegerValue getColorBlueValue() {
        return this.colorBlueValue;
    }

    public final IntegerValue getAlphaValue() {
        return this.alphaValue;
    }

    public final IntegerValue getFadeSpeedValue() {
        return this.fadeSpeedValue;
    }

    public final BoolValue getColorRainbow() {
        return this.colorRainbow;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        Color color = (Boolean)this.colorRainbow.get() != false ? ColorUtils.rainbow() : new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue());
        LinkedList<Dot> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            GL11.glPushMatrix();
            GL11.glDisable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)2848);
            GL11.glEnable((int)3042);
            GL11.glDisable((int)2929);
            MinecraftInstance.mc.entityRenderer.disableLightmap();
            GL11.glLineWidth((float)((Number)this.getLineWidth().get()).floatValue());
            GL11.glBegin((int)3);
            double renderPosX = MinecraftInstance.mc.getRenderManager().viewerPosX;
            double renderPosY = MinecraftInstance.mc.getRenderManager().viewerPosY - 0.5;
            double renderPosZ = MinecraftInstance.mc.getRenderManager().viewerPosZ;
            List removeQueue = new ArrayList();
            for (Dot dot : this.positions) {
                if (dot.getAlpha() > 0) {
                    dot.render(color, renderPosX, renderPosY, renderPosZ, (Boolean)this.getUnlimitedValue().get() != false ? 0 : ((Number)this.getFadeSpeedValue().get()).intValue());
                    continue;
                }
                Intrinsics.checkNotNullExpressionValue((Object)dot, (String)"dot");
                removeQueue.add(dot);
            }
            for (Dot removeDot : removeQueue) {
                this.positions.remove(removeDot);
            }
            GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
            GL11.glEnd();
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
            Unit unit = Unit.INSTANCE;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        LinkedList<Dot> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            if (!(MinecraftInstance.mc.thePlayer.posX == this.lastX && MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY == this.lastY && MinecraftInstance.mc.thePlayer.posZ == this.lastZ)) {
                double[] dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY, MinecraftInstance.mc.thePlayer.posZ};
                this.positions.add(new Dot(dArray));
                this.lastX = MinecraftInstance.mc.thePlayer.posX;
                this.lastY = MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY;
                this.lastZ = MinecraftInstance.mc.thePlayer.posZ;
            }
            Unit unit = Unit.INSTANCE;
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.thePlayer == null) {
            return;
        }
        LinkedList<Dot> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            double[] dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY + (double)(MinecraftInstance.mc.thePlayer.getEyeHeight() * 0.5f), MinecraftInstance.mc.thePlayer.posZ};
            this.positions.add(new Dot(dArray));
            dArray = new double[]{MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.getEntityBoundingBox().minY, MinecraftInstance.mc.thePlayer.posZ};
            boolean bl2 = this.positions.add(new Dot(dArray));
        }
        super.onEnable();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Override
    public void onDisable() {
        LinkedList<Dot> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            this.positions.clear();
            Unit unit = Unit.INSTANCE;
        }
        super.onDisable();
    }

    public final class Dot {
        private final double[] pos;
        private int alpha;

        public Dot(double[] pos) {
            Intrinsics.checkNotNullParameter((Object)Trails.this, (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)pos, (String)"pos");
            this.pos = pos;
            this.alpha = ((Number)Trails.this.getAlphaValue().get()).intValue();
        }

        public final int getAlpha() {
            return this.alpha;
        }

        public final void setAlpha(int n) {
            this.alpha = n;
        }

        public final void render(@Nullable Color color, double renderPosX, double renderPosY, double renderPosZ, int decreaseBy) {
            Color color2 = color;
            Intrinsics.checkNotNull((Object)color2);
            Color reColor = ColorUtils.reAlpha(color2, this.alpha);
            RenderUtils.glColor(reColor);
            GL11.glVertex3d((double)(this.pos[0] - renderPosX), (double)(this.pos[1] - renderPosY), (double)(this.pos[2] - renderPosZ));
            this.alpha -= decreaseBy;
            if (this.alpha < 0) {
                this.alpha = 0;
            }
        }
    }
}

