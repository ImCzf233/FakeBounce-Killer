/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACYPort
extends SpeedMode {
    public AACYPort() {
        super("AACYPort");
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving() && !AACYPort.mc.thePlayer.isSneaking() && AACYPort.mc.thePlayer.onGround) {
            AACYPort.mc.thePlayer.motionY = 0.3425f;
            AACYPort.mc.thePlayer.motionX *= (double)1.5893f;
            AACYPort.mc.thePlayer.motionZ *= (double)1.5893f;
        } else {
            AACYPort.mc.thePlayer.motionY = -0.19;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

