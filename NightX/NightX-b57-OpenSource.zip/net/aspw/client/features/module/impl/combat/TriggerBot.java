/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.util.MovingObjectPosition
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.CooldownHelper;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.MovingObjectPosition;

@ModuleInfo(name="TriggerBot", spacedName="Trigger Bot", description="", category=ModuleCategory.COMBAT)
public final class TriggerBot
extends Module {
    private final BoolValue coolDownCheck = new BoolValue("Cooldown-Check", false);
    private final IntegerValue maxCPS;
    private final IntegerValue minCPS;
    private long delay;
    private long lastSwing;

    public TriggerBot() {
        Object object = new Function0<Boolean>(this){
            final /* synthetic */ TriggerBot this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)TriggerBot.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.maxCPS = new IntegerValue(this, (Object)object){
            final /* synthetic */ TriggerBot this$0;
            {
                this.this$0 = $receiver;
                super("MaxCPS", 12, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)TriggerBot.access$getMinCPS$p(this.this$0).get()).intValue();
                if (i > newValue) {
                    this.set(i);
                }
                TriggerBot.access$setDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)TriggerBot.access$getMinCPS$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
            }
        };
        object = new Function0<Boolean>(this){
            final /* synthetic */ TriggerBot this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)TriggerBot.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.minCPS = new IntegerValue(this, (Object)object){
            final /* synthetic */ TriggerBot this$0;
            {
                this.this$0 = $receiver;
                super("MinCPS", 10, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)TriggerBot.access$getMaxCPS$p(this.this$0).get()).intValue();
                if (i < newValue) {
                    this.set(i);
                }
                TriggerBot.access$setDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)this.get()).intValue(), ((Number)TriggerBot.access$getMaxCPS$p(this.this$0).get()).intValue()));
            }
        };
        this.delay = (Boolean)this.coolDownCheck.get() != false ? TimeUtils.randomClickDelay(20, 20) : TimeUtils.randomClickDelay(((Number)this.minCPS.get()).intValue(), ((Number)this.maxCPS.get()).intValue());
    }

    @EventTarget
    public final void onRender(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.coolDownCheck.get()).booleanValue() && CooldownHelper.INSTANCE.getAttackCooldownProgress() < 1.0) {
            return;
        }
        MovingObjectPosition objectMouseOver = MinecraftInstance.mc.objectMouseOver;
        if (objectMouseOver != null && System.currentTimeMillis() - this.lastSwing >= this.delay && EntityUtils.isSelected(objectMouseOver.entityHit, true)) {
            KeyBinding.onTick((int)MinecraftInstance.mc.gameSettings.keyBindAttack.getKeyCode());
            this.lastSwing = System.currentTimeMillis();
            this.delay = (Boolean)this.coolDownCheck.get() != false ? TimeUtils.randomClickDelay(20, 20) : TimeUtils.randomClickDelay(((Number)this.minCPS.get()).intValue(), ((Number)this.maxCPS.get()).intValue());
        }
    }

    public static final /* synthetic */ IntegerValue access$getMinCPS$p(TriggerBot $this) {
        return $this.minCPS;
    }

    public static final /* synthetic */ void access$setDelay$p(TriggerBot $this, long l) {
        $this.delay = l;
    }

    public static final /* synthetic */ BoolValue access$getCoolDownCheck$p(TriggerBot $this) {
        return $this.coolDownCheck;
    }

    public static final /* synthetic */ IntegerValue access$getMaxCPS$p(TriggerBot $this) {
        return $this.maxCPS;
    }
}

