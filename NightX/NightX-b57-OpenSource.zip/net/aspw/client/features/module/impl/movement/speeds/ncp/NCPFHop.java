/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPFHop
extends SpeedMode {
    public NCPFHop() {
        super("NCPFHop");
    }

    @Override
    public void onEnable() {
        NCPFHop.mc.timer.timerSpeed = 1.0866f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        NCPFHop.mc.timer.timerSpeed = 1.0f;
        super.onDisable();
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPFHop.mc.thePlayer.isSneaking() && !scaffold.getState()) {
            NCPFHop.mc.thePlayer.motionX = 0.0;
            NCPFHop.mc.thePlayer.motionZ = 0.0;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (NCPFHop.mc.thePlayer.onGround) {
                NCPFHop.mc.thePlayer.jump();
                NCPFHop.mc.thePlayer.motionX *= 1.01;
                NCPFHop.mc.thePlayer.motionZ *= 1.01;
                NCPFHop.mc.thePlayer.speedInAir = 0.0223f;
            }
            NCPFHop.mc.thePlayer.motionY -= 9.9999E-4;
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

