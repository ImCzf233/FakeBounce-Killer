/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.visual;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;

@ModuleInfo(name="CameraNoClip", spacedName="Camera No Clip", description="", category=ModuleCategory.VISUAL)
public final class CameraNoClip
extends Module {
}

