/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.network.play.server.S03PacketTimeUpdate
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.network.play.server.S03PacketTimeUpdate;

@ModuleInfo(name="WorldTime", spacedName="World Time", description="", category=ModuleCategory.OTHER)
public final class WorldTime
extends Module {
    private final ListValue timeModeValue;
    private final IntegerValue cycleSpeedValue;
    private final IntegerValue staticTimeValue;
    private final ListValue weatherModeValue;
    private final FloatValue rainStrengthValue;
    private long timeCycle;

    public WorldTime() {
        String[] stringArray = new String[]{"Static", "Cycle"};
        this.timeModeValue = new ListValue("Time", stringArray, "Static");
        this.cycleSpeedValue = new IntegerValue("CycleSpeed", 30, -30, 100, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ WorldTime this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTimeModeValue().get()), (String)"cycle", (boolean)true);
            }
        }));
        this.staticTimeValue = new IntegerValue("StaticTime", 18000, 0, 24000, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ WorldTime this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTimeModeValue().get()), (String)"static", (boolean)true);
            }
        }));
        stringArray = new String[]{"Clear", "Rain", "NoModification"};
        this.weatherModeValue = new ListValue("Weather", stringArray, "Clear");
        this.rainStrengthValue = new FloatValue("RainStrength", 1.0f, 0.01f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ WorldTime this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getWeatherModeValue().get()), (String)"rain", (boolean)true);
            }
        }));
    }

    public final ListValue getTimeModeValue() {
        return this.timeModeValue;
    }

    public final IntegerValue getCycleSpeedValue() {
        return this.cycleSpeedValue;
    }

    public final IntegerValue getStaticTimeValue() {
        return this.staticTimeValue;
    }

    public final ListValue getWeatherModeValue() {
        return this.weatherModeValue;
    }

    public final FloatValue getRainStrengthValue() {
        return this.rainStrengthValue;
    }

    @Override
    public void onEnable() {
        this.timeCycle = 0L;
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof S03PacketTimeUpdate) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (StringsKt.equals((String)((String)this.timeModeValue.get()), (String)"static", (boolean)true)) {
            MinecraftInstance.mc.theWorld.setWorldTime((long)((Number)this.staticTimeValue.get()).intValue());
        } else {
            MinecraftInstance.mc.theWorld.setWorldTime(this.timeCycle);
            this.timeCycle += (long)(((Number)this.cycleSpeedValue.get()).intValue() * 10);
            if (this.timeCycle > 24000L) {
                this.timeCycle = 0L;
            }
            if (this.timeCycle < 0L) {
                this.timeCycle = 24000L;
            }
        }
        if (!StringsKt.equals((String)((String)this.weatherModeValue.get()), (String)"nomodification", (boolean)true)) {
            MinecraftInstance.mc.theWorld.setRainStrength(StringsKt.equals((String)((String)this.weatherModeValue.get()), (String)"clear", (boolean)true) ? 0.0f : ((Number)this.rainStrengthValue.get()).floatValue());
        }
    }
}

