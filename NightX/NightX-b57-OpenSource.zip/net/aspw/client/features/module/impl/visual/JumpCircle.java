/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.ColorMixer;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.Render;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="JumpCircle", spacedName="Jump Circle", description="", category=ModuleCategory.VISUAL)
public final class JumpCircle
extends Module {
    private final FloatValue radius = new FloatValue("Radius", 1.0f, 1.0f, 5.0f, "m");
    private final ListValue colorModeValue;
    private final IntegerValue colorRedValue;
    private final IntegerValue colorGreenValue;
    private final IntegerValue colorBlueValue;
    private final FloatValue saturationValue;
    private final FloatValue brightnessValue;
    private final IntegerValue mixerSecondsValue;
    private final Map<Integer, List<Render>> points;
    private boolean jump;
    private final List<Circle> circles;
    private int red;
    private int green;
    private int blue;

    public JumpCircle() {
        String[] stringArray = new String[]{"Custom", "Rainbow", "Sky", "LiquidSlowly", "Fade", "Mixer"};
        this.colorModeValue = new ListValue("Color", stringArray, "LiquidSlowly");
        this.colorRedValue = new IntegerValue("Red", 200, 0, 255);
        this.colorGreenValue = new IntegerValue("Green", 150, 0, 255);
        this.colorBlueValue = new IntegerValue("Blue", 200, 0, 255);
        this.saturationValue = new FloatValue("Saturation", 1.0f, 0.0f, 1.0f);
        this.brightnessValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
        this.mixerSecondsValue = new IntegerValue("Seconds", 2, 1, 10);
        this.points = new LinkedHashMap();
        this.circles = new ArrayList();
        this.red = ((Number)this.colorRedValue.get()).intValue();
        this.green = ((Number)this.colorGreenValue.get()).intValue();
        this.blue = ((Number)this.colorBlueValue.get()).intValue();
    }

    public final FloatValue getRadius() {
        return this.radius;
    }

    public final boolean getJump() {
        return this.jump;
    }

    public final void setJump(boolean bl) {
        this.jump = bl;
    }

    public final List<Circle> getCircles() {
        return this.circles;
    }

    public final int getRed() {
        return this.red;
    }

    public final void setRed(int n) {
        this.red = n;
    }

    public final int getGreen() {
        return this.green;
    }

    public final void setGreen(int n) {
        this.green = n;
    }

    public final int getBlue() {
        return this.blue;
    }

    public final void setBlue(int n) {
        this.blue = n;
    }

    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        this.circles.removeIf(JumpCircle::onRender3D$lambda-0);
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2884);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glDisable((int)3008);
        GL11.glShadeModel((int)7425);
        Iterable $this$forEach$iv = this.circles;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Circle it = (Circle)element$iv;
            boolean bl = false;
            it.draw();
        }
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)3008);
        GL11.glShadeModel((int)7424);
        GL11.glPopMatrix();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.thePlayer.onGround && !this.jump) {
            this.jump = true;
        }
        if (MinecraftInstance.mc.thePlayer.onGround && this.jump) {
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.thePlayer;
            Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
            this.updatePoints((EntityLivingBase)entityPlayerSP);
            this.jump = false;
        }
    }

    public final void updatePoints(EntityLivingBase entity) {
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        this.circles.add(new Circle(System.currentTimeMillis(), MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ));
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.points.clear();
    }

    @Override
    public void onDisable() {
        this.points.clear();
    }

    private static final boolean onRender3D$lambda-0(Circle it) {
        Intrinsics.checkNotNullParameter((Object)it, (String)"it");
        return System.currentTimeMillis() > it.getTime() + (long)1000;
    }

    public static final /* synthetic */ Minecraft access$getMc$p$s1046033730() {
        return MinecraftInstance.mc;
    }

    public static final class Circle {
        private final long time;
        private final double x;
        private final double y;
        private final double z;
        private EntityLivingBase entity;
        private final JumpCircle jumpModule;
        private String colorModeValue;
        private int colorRedValue;
        private int colorGreenValue;
        private int colorBlueValue;
        private int mixerSecondsValue;
        private float saturationValue;
        private float brightnessValue;

        public Circle(long time, double x, double y, double z) {
            this.time = time;
            this.x = x;
            this.y = y;
            this.z = z;
            EntityPlayerSP entityPlayerSP = JumpCircle.access$getMc$p$s1046033730().thePlayer;
            Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
            this.entity = (EntityLivingBase)entityPlayerSP;
            JumpCircle jumpCircle = Client.INSTANCE.getModuleManager().getModule(JumpCircle.class);
            if (jumpCircle == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.visual.JumpCircle");
            }
            this.jumpModule = jumpCircle;
            this.colorModeValue = (String)this.jumpModule.colorModeValue.get();
            this.colorRedValue = ((Number)this.jumpModule.colorRedValue.get()).intValue();
            this.colorGreenValue = ((Number)this.jumpModule.colorGreenValue.get()).intValue();
            this.colorBlueValue = ((Number)this.jumpModule.colorBlueValue.get()).intValue();
            this.mixerSecondsValue = ((Number)this.jumpModule.mixerSecondsValue.get()).intValue();
            this.saturationValue = ((Number)this.jumpModule.saturationValue.get()).floatValue();
            this.brightnessValue = ((Number)this.jumpModule.brightnessValue.get()).floatValue();
        }

        public final long getTime() {
            return this.time;
        }

        public final double getX() {
            return this.x;
        }

        public final double getY() {
            return this.y;
        }

        public final double getZ() {
            return this.z;
        }

        public final EntityLivingBase getEntity() {
            return this.entity;
        }

        public final void setEntity(EntityLivingBase entityLivingBase) {
            Intrinsics.checkNotNullParameter((Object)entityLivingBase, (String)"<set-?>");
            this.entity = entityLivingBase;
        }

        public final JumpCircle getJumpModule() {
            return this.jumpModule;
        }

        public final String getColorModeValue() {
            return this.colorModeValue;
        }

        public final void setColorModeValue(String string) {
            Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
            this.colorModeValue = string;
        }

        public final int getColorRedValue() {
            return this.colorRedValue;
        }

        public final void setColorRedValue(int n) {
            this.colorRedValue = n;
        }

        public final int getColorGreenValue() {
            return this.colorGreenValue;
        }

        public final void setColorGreenValue(int n) {
            this.colorGreenValue = n;
        }

        public final int getColorBlueValue() {
            return this.colorBlueValue;
        }

        public final void setColorBlueValue(int n) {
            this.colorBlueValue = n;
        }

        public final int getMixerSecondsValue() {
            return this.mixerSecondsValue;
        }

        public final void setMixerSecondsValue(int n) {
            this.mixerSecondsValue = n;
        }

        public final float getSaturationValue() {
            return this.saturationValue;
        }

        public final void setSaturationValue(float f) {
            this.saturationValue = f;
        }

        public final float getBrightnessValue() {
            return this.brightnessValue;
        }

        public final void setBrightnessValue(float f) {
            this.brightnessValue = f;
        }

        public final void draw() {
            if (this.jumpModule == null) {
                return;
            }
            long dif = System.currentTimeMillis() - this.time;
            float c = (float)125 - (float)dif / 1000.0f * (float)125;
            GL11.glPushMatrix();
            GL11.glTranslated((double)(this.x - JumpCircle.access$getMc$p$s1046033730().getRenderManager().viewerPosX), (double)(this.y - JumpCircle.access$getMc$p$s1046033730().getRenderManager().viewerPosY), (double)(this.z - JumpCircle.access$getMc$p$s1046033730().getRenderManager().viewerPosZ));
            GL11.glBegin((int)5);
            int n = 0;
            while (n < 361) {
                int i = n++;
                Color color = this.getColor((Entity)this.entity, 0);
                double x = (double)((float)dif * ((Number)this.jumpModule.getRadius().get()).floatValue()) * 0.001 * Math.sin(i);
                double z = (double)((float)dif * ((Number)this.jumpModule.getRadius().get()).floatValue()) * 0.001 * Math.cos(i);
                RenderUtils.glColor(color.getRed(), color.getGreen(), color.getBlue(), 0);
                GL11.glVertex3d((double)(x / (double)2), (double)0.0, (double)(z / (double)2));
                RenderUtils.glColor(color.getRed(), color.getGreen(), color.getBlue(), (int)c);
                GL11.glVertex3d((double)x, (double)0.0, (double)z);
            }
            GL11.glEnd();
            GL11.glPopMatrix();
        }

        public final Color getColor(@Nullable Entity ent, int index) {
            Color color;
            switch (this.colorModeValue) {
                case "Custom": {
                    color = new Color(this.colorRedValue, this.colorGreenValue, this.colorBlueValue);
                    break;
                }
                case "Rainbow": {
                    color = new Color(RenderUtils.getRainbowOpaque(this.mixerSecondsValue, this.saturationValue, this.brightnessValue, index));
                    break;
                }
                case "Sky": {
                    Color color2 = RenderUtils.skyRainbow(index, this.saturationValue, this.brightnessValue);
                    Intrinsics.checkNotNullExpressionValue((Object)color2, (String)"skyRainbow(index, satura\u2026onValue, brightnessValue)");
                    color = color2;
                    break;
                }
                case "LiquidSlowly": {
                    color = ColorUtils.LiquidSlowly(System.nanoTime(), index, this.saturationValue, this.brightnessValue);
                    break;
                }
                case "Mixer": {
                    color = ColorMixer.Companion.getMixedColor(index, this.mixerSecondsValue);
                    break;
                }
                default: {
                    color = ColorUtils.fade(new Color(this.colorRedValue, this.colorGreenValue, this.colorBlueValue), index, 100);
                }
            }
            return color;
        }
    }
}

