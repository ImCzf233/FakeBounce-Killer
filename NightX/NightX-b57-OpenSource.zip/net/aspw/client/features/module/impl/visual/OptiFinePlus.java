/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 */
package net.aspw.client.features.module.impl.visual;

import kotlin.jvm.JvmField;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.BoolValue;

@ModuleInfo(name="OptiFine+", description="", category=ModuleCategory.VISUAL, onlyEnable=true, forceNoSound=true, array=false)
public final class OptiFinePlus
extends Module {
    @JvmField
    public BoolValue fastGuiLoadingValue = new BoolValue("FastGui-Loading", true);
    @JvmField
    public BoolValue noHitDelay = new BoolValue("NoHitDelay", true);
    @JvmField
    public BoolValue mouseDelayFix = new BoolValue("MouseDelayFix", true);
}

