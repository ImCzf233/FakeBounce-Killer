/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACHop350
extends SpeedMode
implements Listenable {
    public AACHop350() {
        super("AACHop3.5.0");
        Client.eventManager.registerListener(this);
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    @EventTarget
    public void onMotion(MotionEvent event) {
        if (event.getEventState() == EventState.POST && MovementUtils.isMoving() && !AACHop350.mc.thePlayer.isInWater() && !AACHop350.mc.thePlayer.isInLava()) {
            AACHop350.mc.thePlayer.jumpMovementFactor += 0.00208f;
            if (AACHop350.mc.thePlayer.fallDistance <= 1.0f) {
                if (AACHop350.mc.thePlayer.onGround) {
                    AACHop350.mc.thePlayer.jump();
                    AACHop350.mc.thePlayer.motionX *= (double)1.0118f;
                    AACHop350.mc.thePlayer.motionZ *= (double)1.0118f;
                } else {
                    AACHop350.mc.thePlayer.motionY -= (double)0.0147f;
                    AACHop350.mc.thePlayer.motionX *= (double)1.00138f;
                    AACHop350.mc.thePlayer.motionZ *= (double)1.00138f;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        if (AACHop350.mc.thePlayer.onGround) {
            AACHop350.mc.thePlayer.motionZ = 0.0;
            AACHop350.mc.thePlayer.motionX = 0.0;
        }
    }

    @Override
    public void onDisable() {
        AACHop350.mc.thePlayer.jumpMovementFactor = 0.02f;
    }

    @Override
    public boolean handleEvents() {
        return this.isActive();
    }
}

