/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module;

public final class ModuleCategory
extends Enum<ModuleCategory> {
    private final String displayName;
    public static final /* enum */ ModuleCategory COMBAT = new ModuleCategory("Combat");
    public static final /* enum */ ModuleCategory MOVEMENT = new ModuleCategory("Movement");
    public static final /* enum */ ModuleCategory PLAYER = new ModuleCategory("Player");
    public static final /* enum */ ModuleCategory EXPLOIT = new ModuleCategory("Exploit");
    public static final /* enum */ ModuleCategory OTHER = new ModuleCategory("Other");
    public static final /* enum */ ModuleCategory VISUAL = new ModuleCategory("Visual");
    public static final /* enum */ ModuleCategory TARGETS = new ModuleCategory("Targets");
    private static final /* synthetic */ ModuleCategory[] $VALUES;

    private ModuleCategory(String displayName) {
        this.displayName = displayName;
    }

    public final String getDisplayName() {
        return this.displayName;
    }

    public static ModuleCategory[] values() {
        return (ModuleCategory[])$VALUES.clone();
    }

    public static ModuleCategory valueOf(String value) {
        return Enum.valueOf(ModuleCategory.class, value);
    }

    static {
        $VALUES = moduleCategoryArray = new ModuleCategory[]{ModuleCategory.COMBAT, ModuleCategory.MOVEMENT, ModuleCategory.PLAYER, ModuleCategory.EXPLOIT, ModuleCategory.OTHER, ModuleCategory.VISUAL, ModuleCategory.TARGETS};
    }
}

