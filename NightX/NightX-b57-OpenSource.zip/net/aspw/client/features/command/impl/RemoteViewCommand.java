/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public final class RemoteViewCommand
extends Command {
    public RemoteViewCommand() {
        String[] stringArray = new String[]{"rv"};
        super("remoteview", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length < 2) {
            if (!MinecraftInstance.mc.getRenderViewEntity().equals(MinecraftInstance.mc.thePlayer)) {
                MinecraftInstance.mc.setRenderViewEntity((Entity)MinecraftInstance.mc.thePlayer);
                return;
            }
            this.chatSyntax("remoteview <username>");
            return;
        }
        String targetName = args[1];
        for (Entity entity : MinecraftInstance.mc.theWorld.loadedEntityList) {
            if (!targetName.equals(entity.getName())) continue;
            MinecraftInstance.mc.setRenderViewEntity(entity);
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            this.chat("Now viewing perspective of \u00a78" + entity.getName() + "\u00a73.");
            this.chat("Execute \u00a78.remoteview \u00a73again to go back to yours.");
            break;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C0BPacketEntityAction && (((C0BPacketEntityAction)packet).getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING || ((C0BPacketEntityAction)packet).getAction() == C0BPacketEntityAction.Action.START_SPRINTING)) {
            event.cancelEvent();
        }
    }
}

