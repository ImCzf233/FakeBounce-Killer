/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.Module;

public final class ToggleCommand
extends Command {
    public ToggleCommand() {
        String[] stringArray = new String[]{"t"};
        super("toggle", stringArray);
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length <= 1) {
            this.chatSyntax("toggle <module> [on/off]");
            return;
        }
        Module module = Client.INSTANCE.getModuleManager().getModule(args[1]);
        if (module == null) {
            this.chat("Module '" + args[1] + "' not found.");
            return;
        }
        if (args.length > 2) {
            String string = args[2];
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            String newState = string2;
            if (!newState.equals("on") && !newState.equals("off")) {
                this.chatSyntax("toggle <module> [on/off]");
                return;
            }
            module.setState(newState.equals("on"));
        } else {
            module.toggle();
        }
        this.chat((module.getState() ? "Enabled" : "Disabled") + " module \u00a78" + module.getName() + "\u00a73.");
    }
}

