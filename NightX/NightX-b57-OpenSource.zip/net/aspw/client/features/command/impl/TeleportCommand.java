/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 */
package net.aspw.client.features.command.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.pathfinder.Vec3;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class TeleportCommand
extends Command {
    public TeleportCommand() {
        String[] stringArray = new String[]{"teleport"};
        super("tp", stringArray);
    }

    /*
     * WARNING - void declaration
     */
    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length == 2) {
            void $this$filterTo$iv$iv;
            void $this$filter$iv;
            String theName = args[1];
            Iterable iterable = MinecraftInstance.mc.theWorld.playerEntities;
            Intrinsics.checkNotNullExpressionValue((Object)iterable, (String)"mc.theWorld.playerEntities");
            iterable = iterable;
            boolean $i$f$filter = false;
            void var6_8 = $this$filter$iv;
            Collection destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                EntityPlayer it = (EntityPlayer)element$iv$iv;
                boolean bl = false;
                Intrinsics.checkNotNullExpressionValue((Object)it, (String)"it");
                if (!(!AntiBots.Companion.isBot((EntityLivingBase)it) && StringsKt.equals((String)it.getName(), (String)theName, (boolean)true))) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            EntityPlayer targetPlayer = (EntityPlayer)CollectionsKt.firstOrNull((List)((List)destination$iv$iv));
            if (targetPlayer != null) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                new Thread(() -> TeleportCommand.execute$lambda-1(targetPlayer)).start();
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)"Successfully teleported to \u00a7a", (Object)targetPlayer.getName()), Notification.Type.SUCCESS));
                return;
            }
            Client.INSTANCE.getHud().addNotification(new Notification("No players found!", Notification.Type.ERROR));
            return;
        }
        if (args.length == 4) {
            try {
                double posX = StringsKt.equals((String)args[1], (String)"~", (boolean)true) ? MinecraftInstance.mc.thePlayer.posX : Double.parseDouble(args[1]);
                double posY = StringsKt.equals((String)args[2], (String)"~", (boolean)true) ? MinecraftInstance.mc.thePlayer.posY : Double.parseDouble(args[2]);
                double posZ = StringsKt.equals((String)args[3], (String)"~", (boolean)true) ? MinecraftInstance.mc.thePlayer.posZ : Double.parseDouble(args[3]);
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                new Thread(() -> TeleportCommand.execute$lambda-2(posX, posY, posZ)).start();
                Client.INSTANCE.getHud().addNotification(new Notification("Successfully teleported to \u00a7a" + posX + ", " + posY + ", " + posZ, Notification.Type.SUCCESS));
                return;
            }
            catch (NumberFormatException e) {
                Client.INSTANCE.getHud().addNotification(new Notification("Failed to teleport", Notification.Type.ERROR));
                return;
            }
        }
        this.chatSyntax("tp <player name/x y z>");
    }

    private static final void execute$lambda-1(EntityPlayer $targetPlayer) {
        ArrayList<Vec3> arrayList = MainPathFinder.computePath(new Vec3(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ), new Vec3($targetPlayer.posX, $targetPlayer.posY, $targetPlayer.posZ));
        Intrinsics.checkNotNullExpressionValue(arrayList, (String)"computePath(\n           \u2026sZ)\n                    )");
        ArrayList<Vec3> path = arrayList;
        for (Vec3 point : path) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true)));
        }
        MinecraftInstance.mc.thePlayer.setPosition($targetPlayer.posX, $targetPlayer.posY, $targetPlayer.posZ);
    }

    private static final void execute$lambda-2(double $posX, double $posY, double $posZ) {
        ArrayList<Vec3> arrayList = MainPathFinder.computePath(new Vec3(MinecraftInstance.mc.thePlayer.posX, MinecraftInstance.mc.thePlayer.posY, MinecraftInstance.mc.thePlayer.posZ), new Vec3($posX, $posY, $posZ));
        Intrinsics.checkNotNullExpressionValue(arrayList, (String)"computePath(\n           \u2026sZ)\n                    )");
        ArrayList<Vec3> path = arrayList;
        for (Vec3 point : path) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true)));
        }
        MinecraftInstance.mc.thePlayer.setPosition($posX, $posY, $posZ);
    }
}

