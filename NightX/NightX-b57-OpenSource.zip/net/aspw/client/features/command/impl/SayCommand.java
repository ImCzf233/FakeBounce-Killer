/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.StringUtils;

public final class SayCommand
extends Command {
    public SayCommand() {
        boolean $i$f$emptyArray = false;
        super("say", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            MinecraftInstance.mc.thePlayer.sendChatMessage(StringUtils.toCompleteString(args, 1));
            return;
        }
        this.chatSyntax("say <message>");
    }
}

