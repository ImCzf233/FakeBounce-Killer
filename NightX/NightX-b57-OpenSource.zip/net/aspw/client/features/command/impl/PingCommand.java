/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;

public final class PingCommand
extends Command {
    public PingCommand() {
        boolean $i$f$emptyArray = false;
        super("ping", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        this.chat("\u00a73Your ping is \u00a7a" + MinecraftInstance.mc.getNetHandler().getPlayerInfo(MinecraftInstance.mc.thePlayer.getUniqueID()).getResponseTime() + "ms\u00a73.");
    }
}

