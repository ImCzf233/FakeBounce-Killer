/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.command.CommandManager;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleManager;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.misc.sound.TipSoundManager;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.clickgui.tab.NewUi;
import net.aspw.client.visual.font.Fonts;

public final class ReloadCommand
extends Command {
    public ReloadCommand() {
        boolean $i$f$emptyArray = false;
        super("reload", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        Client.INSTANCE.setCommandManager(new CommandManager());
        Client.INSTANCE.getCommandManager().registerCommands();
        for (Module module : Client.INSTANCE.getModuleManager().getModules()) {
            ModuleManager moduleManager = Client.INSTANCE.getModuleManager();
            Intrinsics.checkNotNullExpressionValue((Object)module, (String)"module");
            moduleManager.generateCommand$nightx(module);
        }
        Fonts.loadFonts();
        Client.INSTANCE.setTipSoundManager(new TipSoundManager());
        Client.INSTANCE.getFileManager().loadConfig(Client.INSTANCE.getFileManager().modulesConfig);
        Client.INSTANCE.getFileManager().loadConfig(Client.INSTANCE.getFileManager().valuesConfig);
        Client.INSTANCE.getFileManager().loadConfig(Client.INSTANCE.getFileManager().accountsConfig);
        Client.INSTANCE.getFileManager().loadConfig(Client.INSTANCE.getFileManager().friendsConfig);
        NewUi.resetInstance();
        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
        Intrinsics.checkNotNull((Object)boolValue);
        if (((Boolean)boolValue.get()).booleanValue()) {
            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
        }
        this.chat("Reloaded!");
    }
}

