/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.Unpooled
 *  net.minecraft.client.Minecraft
 *  net.minecraft.network.Packet
 *  net.minecraft.network.PacketBuffer
 *  net.minecraft.network.play.client.C17PacketCustomPayload
 *  net.minecraftforge.fml.common.network.internal.FMLProxyPacket
 */
package net.aspw.client.features.api;

import io.netty.buffer.Unpooled;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;

public class ClientSpoof
extends MinecraftInstance
implements Listenable {
    @EventTarget
    public void onPacket(PacketEvent event) {
        Packet<?> packet = event.getPacket();
        net.aspw.client.features.module.impl.other.ClientSpoof clientSpoof = Client.moduleManager.getModule(net.aspw.client.features.module.impl.other.ClientSpoof.class);
        if (!Minecraft.getMinecraft().isIntegratedServerRunning()) {
            if (((Boolean)Objects.requireNonNull(clientSpoof).blockModsCheck.get()).booleanValue() && packet instanceof FMLProxyPacket) {
                event.cancelEvent();
            }
            if (packet instanceof C17PacketCustomPayload) {
                try {
                    C17PacketCustomPayload customPayload = (C17PacketCustomPayload)packet;
                    if (!customPayload.getChannelName().startsWith("MC|")) {
                        event.cancelEvent();
                    } else if (customPayload.getChannelName().equalsIgnoreCase("MC|Brand")) {
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Vanilla")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("vanilla");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Forge")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("FML");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("LabyMod")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("LMC");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("CheatBreaker")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("CB");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("PvPLounge")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("PLC18");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Geyser")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("eyser");
                        }
                        if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Lunar")) {
                            customPayload.data = new PacketBuffer(Unpooled.buffer()).writeString("lunarclient:" + RandomUtils.randomString(7));
                        }
                    }
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public boolean handleEvents() {
        return true;
    }
}

