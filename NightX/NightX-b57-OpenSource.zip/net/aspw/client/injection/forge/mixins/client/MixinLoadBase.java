/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.LazyLoadBase
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 */
package net.aspw.client.injection.forge.mixins.client;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.OptiFinePlus;
import net.minecraft.util.LazyLoadBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(value={LazyLoadBase.class})
public abstract class MixinLoadBase<T> {
    @Shadow
    private boolean field_179282_b;
    @Shadow
    private T field_179283_a;

    @Shadow
    protected abstract T func_179280_b();

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @Overwrite
    public T func_179281_c() {
        if (((Boolean)Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class)).fastGuiLoadingValue.get()).booleanValue() && !this.field_179282_b) {
            MixinLoadBase mixinLoadBase = this;
            synchronized (mixinLoadBase) {
                if (!this.field_179282_b) {
                    this.field_179283_a = this.func_179280_b();
                    this.field_179282_b = true;
                }
            }
        }
        return this.field_179283_a;
    }
}

