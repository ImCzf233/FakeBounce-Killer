/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.inventory.GuiChest
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.player.ChestStealer;
import net.aspw.client.features.module.impl.player.InvManager;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.injection.forge.mixins.gui.MixinGuiScreen;
import net.aspw.client.util.render.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiContainer;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiContainer.class})
public abstract class MixinGuiContainer
extends MixinGuiScreen {
    @Shadow
    protected int field_146999_f;
    @Shadow
    protected int field_147000_g;
    @Shadow
    protected int field_147003_i;
    @Shadow
    protected int field_147009_r;
    @Shadow
    private int field_146988_G;
    @Shadow
    private int field_146996_I;
    private GuiButton stealButton;
    private GuiButton chestStealerButton;
    private GuiButton invManagerButton;
    private GuiButton killAuraButton;
    private float progress = 0.0f;
    private long lastMS = 0L;

    @Shadow
    protected abstract boolean func_146983_a(int var1);

    @Inject(method={"initGui"}, at={@At(value="HEAD")})
    public void injectInitGui(CallbackInfo callbackInfo) {
        GuiScreen guiScreen = Minecraft.getMinecraft().currentScreen;
        if (guiScreen instanceof GuiChest) {
            this.killAuraButton = new GuiButton(1024576, 5, 5, 150, 20, "Disable KillAura");
            this.field_146292_n.add(this.killAuraButton);
            this.invManagerButton = new GuiButton(321123, 5, 27, 150, 20, "Disable InvManager");
            this.field_146292_n.add(this.invManagerButton);
            this.chestStealerButton = new GuiButton(727, 5, 49, 150, 20, "Disable ChestStealer");
            this.field_146292_n.add(this.chestStealerButton);
        }
        this.lastMS = System.currentTimeMillis();
        this.progress = 0.0f;
    }

    @Override
    protected void injectedActionPerformed(GuiButton button) {
        KillAura killAura = Objects.requireNonNull(Client.moduleManager.getModule(KillAura.class));
        InvManager invManager = Objects.requireNonNull(Client.moduleManager.getModule(InvManager.class));
        ChestStealer chestStealer = Objects.requireNonNull(Client.moduleManager.getModule(ChestStealer.class));
        if (button.id == 1024576) {
            killAura.setState(false);
        }
        if (button.id == 321123) {
            invManager.setState(false);
        }
        if (button.id == 727) {
            chestStealer.setState(false);
        }
    }

    @Inject(method={"drawScreen"}, at={@At(value="HEAD")}, cancellable=true)
    private void drawScreenHead(CallbackInfo callbackInfo) {
        ChestStealer chestStealer = Objects.requireNonNull(Client.moduleManager.getModule(ChestStealer.class));
        KillAura killAura = Objects.requireNonNull(Client.moduleManager.getModule(KillAura.class));
        InvManager invManager = Objects.requireNonNull(Client.moduleManager.getModule(InvManager.class));
        Hud hud = Objects.requireNonNull(Client.moduleManager.getModule(Hud.class));
        Minecraft mc = Minecraft.getMinecraft();
        this.progress = this.progress >= 1.0f ? 1.0f : (float)(System.currentTimeMillis() - this.lastMS) / 200.0f;
        if (!(!((Boolean)hud.getContainerBackground().get()).booleanValue() || mc.currentScreen instanceof GuiChest && chestStealer.getState() && ((Boolean)chestStealer.getSilenceValue().get()).booleanValue() && !((Boolean)chestStealer.getStillDisplayValue().get()).booleanValue())) {
            RenderUtils.drawGradientRect(0, 0, this.field_146294_l, this.field_146295_m, -1072689136, -804253680);
        }
        try {
            GuiScreen guiScreen = mc.currentScreen;
            if (this.stealButton != null) {
                boolean bl = this.stealButton.enabled = !chestStealer.getState();
            }
            if (this.killAuraButton != null) {
                this.killAuraButton.enabled = killAura.getState();
            }
            if (this.chestStealerButton != null) {
                this.chestStealerButton.enabled = chestStealer.getState();
            }
            if (this.invManagerButton != null) {
                this.invManagerButton.enabled = invManager.getState();
            }
            if (chestStealer.getState() && ((Boolean)chestStealer.getSilenceValue().get()).booleanValue() && guiScreen instanceof GuiChest) {
                mc.setIngameFocus();
                mc.currentScreen = guiScreen;
                if (((Boolean)chestStealer.getShowStringValue().get()).booleanValue() && !((Boolean)chestStealer.getStillDisplayValue().get()).booleanValue()) {
                    String tipString = "Stealing... Press Esc to stop.";
                    mc.fontRendererObj.drawString(tipString, (float)this.field_146294_l / 2.0f - (float)mc.fontRendererObj.getStringWidth(tipString) / 2.0f - 0.5f, (float)this.field_146295_m / 2.0f + 30.0f, 0, false);
                    mc.fontRendererObj.drawString(tipString, (float)this.field_146294_l / 2.0f - (float)mc.fontRendererObj.getStringWidth(tipString) / 2.0f + 0.5f, (float)this.field_146295_m / 2.0f + 30.0f, 0, false);
                    mc.fontRendererObj.drawString(tipString, (float)this.field_146294_l / 2.0f - (float)mc.fontRendererObj.getStringWidth(tipString) / 2.0f, (float)this.field_146295_m / 2.0f + 29.5f, 0, false);
                    mc.fontRendererObj.drawString(tipString, (float)this.field_146294_l / 2.0f - (float)mc.fontRendererObj.getStringWidth(tipString) / 2.0f, (float)this.field_146295_m / 2.0f + 30.5f, 0, false);
                    mc.fontRendererObj.drawString(tipString, (float)this.field_146294_l / 2.0f - (float)mc.fontRendererObj.getStringWidth(tipString) / 2.0f, (float)this.field_146295_m / 2.0f + 30.0f, -1, false);
                }
                if (!chestStealer.getOnce() && !((Boolean)chestStealer.getStillDisplayValue().get()).booleanValue()) {
                    callbackInfo.cancel();
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    protected boolean shouldRenderBackground() {
        return false;
    }

    @Inject(method={"drawScreen"}, at={@At(value="RETURN")})
    public void drawScreenReturn(CallbackInfo callbackInfo) {
        boolean checkFullSilence;
        Animations animMod = Objects.requireNonNull(Client.moduleManager.getModule(Animations.class));
        ChestStealer chestStealer = Objects.requireNonNull(Client.moduleManager.getModule(ChestStealer.class));
        Minecraft mc = Minecraft.getMinecraft();
        boolean bl = checkFullSilence = chestStealer.getState() && (Boolean)chestStealer.getSilenceValue().get() != false && (Boolean)chestStealer.getStillDisplayValue().get() == false;
        if (!(animMod == null || !animMod.getState() || mc.currentScreen instanceof GuiChest && checkFullSilence)) {
            GL11.glPopMatrix();
        }
    }

    @Inject(method={"mouseClicked"}, at={@At(value="HEAD")}, cancellable=true)
    private void checkCloseClick(int mouseX, int mouseY, int mouseButton, CallbackInfo ci) {
        if (mouseButton - 100 == this.field_146297_k.gameSettings.keyBindInventory.getKeyCode()) {
            this.field_146297_k.thePlayer.closeScreen();
            ci.cancel();
        }
    }

    @Inject(method={"mouseClicked"}, at={@At(value="TAIL")})
    private void checkHotbarClicks(int mouseX, int mouseY, int mouseButton, CallbackInfo ci) {
        this.func_146983_a(mouseButton - 100);
    }

    @Inject(method={"updateDragSplitting"}, at={@At(value="INVOKE", target="Lnet/minecraft/item/ItemStack;copy()Lnet/minecraft/item/ItemStack;")}, cancellable=true)
    private void fixRemnants(CallbackInfo ci) {
        if (this.field_146988_G == 2) {
            this.field_146996_I = this.field_146297_k.thePlayer.inventory.getItemStack().getMaxStackSize();
            ci.cancel();
        }
    }
}

