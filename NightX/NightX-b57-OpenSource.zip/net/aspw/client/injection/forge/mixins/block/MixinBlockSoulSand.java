/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockSoulSand
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.block;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.movement.NoSlow;
import net.minecraft.block.BlockSoulSand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={BlockSoulSand.class})
public class MixinBlockSoulSand {
    @Inject(method={"onEntityCollidedWithBlock"}, at={@At(value="HEAD")}, cancellable=true)
    private void onEntityCollidedWithBlock(CallbackInfo callbackInfo) {
        NoSlow noSlow = Objects.requireNonNull(Client.moduleManager.getModule(NoSlow.class));
        if (noSlow.getState() && ((Boolean)noSlow.getSoulsandValue().get()).booleanValue()) {
            callbackInfo.cancel();
        }
    }
}

