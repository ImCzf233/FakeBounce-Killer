/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.entity.RendererLivingEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EnumPlayerModelParts
 *  net.minecraft.util.EnumChatFormatting
 *  net.minecraft.util.MathHelper
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.other.PlayerEdit;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.injection.forge.mixins.render.MixinRender;
import net.aspw.client.util.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={RendererLivingEntity.class})
public abstract class MixinRendererLivingEntity
extends MixinRender {
    @Final
    @Shadow
    private static final Logger field_147923_a = LogManager.getLogger();
    @Shadow
    protected ModelBase field_77045_g;
    @Shadow
    protected boolean field_177098_i = false;

    @Shadow
    protected <T extends EntityLivingBase> float func_77037_a(T p_getDeathMaxRotation_1_) {
        return 90.0f;
    }

    @Shadow
    protected abstract float func_77034_a(float var1, float var2, float var3);

    @Shadow
    protected abstract <T extends EntityLivingBase> boolean func_177090_c(T var1, float var2);

    @Shadow
    protected abstract <T extends EntityLivingBase> boolean func_177088_c(T var1);

    @Shadow
    protected abstract <T extends EntityLivingBase> float func_77040_d(T var1, float var2);

    @Shadow
    protected abstract void func_180565_e();

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_77041_b(T var1, float var2);

    @Shadow
    protected abstract void func_177091_f();

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_77039_a(T var1, double var2, double var4, double var6);

    @Shadow
    protected abstract <T extends EntityLivingBase> float func_77044_a(T var1, float var2);

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_177093_a(T var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8);

    @Overwrite
    protected <T extends EntityLivingBase> void func_77043_a(T p_rotateCorpse_1_, float p_rotateCorpse_2_, float p_rotateCorpse_3_, float p_rotateCorpse_4_) {
        PlayerEdit playerEdit = Objects.requireNonNull(Client.moduleManager.getModule(PlayerEdit.class));
        GlStateManager.rotate((float)(180.0f - p_rotateCorpse_3_), (float)0.0f, (float)1.0f, (float)0.0f);
        if (p_rotateCorpse_1_.deathTime > 0) {
            float f = ((float)p_rotateCorpse_1_.deathTime + p_rotateCorpse_4_ - 1.0f) / 20.0f * 1.6f;
            if ((f = MathHelper.sqrt_float((float)f)) > 1.0f) {
                f = 1.0f;
            }
            GlStateManager.rotate((float)(f * this.func_77037_a(p_rotateCorpse_1_)), (float)0.0f, (float)0.0f, (float)1.0f);
        } else {
            String s = EnumChatFormatting.getTextWithoutFormattingCodes((String)p_rotateCorpse_1_.getName());
            if (s != null && ((Boolean)PlayerEdit.rotatePlayer.get()).booleanValue() && p_rotateCorpse_1_.equals((Object)Minecraft.getMinecraft().thePlayer) && playerEdit.getState() && (!(p_rotateCorpse_1_ instanceof EntityPlayer) || ((EntityPlayer)p_rotateCorpse_1_).isWearing(EnumPlayerModelParts.CAPE))) {
                GlStateManager.translate((float)0.0f, (float)(p_rotateCorpse_1_.height + ((Float)PlayerEdit.yPos.get()).floatValue() - 1.8f), (float)0.0f);
                GlStateManager.rotate((float)((Float)PlayerEdit.xRot.get()).floatValue(), (float)0.0f, (float)0.0f, (float)1.0f);
            }
        }
    }

    @Inject(method={"canRenderName(Lnet/minecraft/entity/EntityLivingBase;)Z"}, at={@At(value="HEAD")}, cancellable=true)
    private <T extends EntityLivingBase> void canRenderName(T entity, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(Hud.class)).getState() && ((Boolean)Objects.requireNonNull(Client.moduleManager.getModule(Hud.class)).getF5nameTag().get()).booleanValue()) {
            callbackInfoReturnable.setReturnValue((Object)true);
        }
    }

    @Inject(method={"doRender(Lnet/minecraft/entity/EntityLivingBase;DDDFF)V"}, at={@At(value="HEAD")})
    private <T extends EntityLivingBase> void injectFakeBody(T entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo ci) {
        GlStateManager.pushMatrix();
        GlStateManager.disableCull();
        this.field_77045_g.swingProgress = this.func_77040_d(entity, partialTicks);
        this.field_77045_g.isRiding = entity.isRiding();
        this.field_77045_g.isChild = entity.isChild();
        try {
            float renderyaw;
            float renderpitch;
            float f = this.func_77034_a(entity.prevRenderYawOffset, entity.renderYawOffset, partialTicks);
            float f1 = this.func_77034_a(entity.prevRotationYawHead, entity.rotationYawHead, partialTicks);
            float f2 = f1 - f;
            if (entity.isRiding() && entity.ridingEntity instanceof EntityLivingBase) {
                EntityLivingBase entitylivingbase = (EntityLivingBase)entity.ridingEntity;
                f = this.func_77034_a(entitylivingbase.prevRenderYawOffset, entitylivingbase.renderYawOffset, partialTicks);
                f2 = f1 - f;
                float f3 = MathHelper.wrapAngleTo180_float((float)f2);
                if (f3 < -85.0f) {
                    f3 = -85.0f;
                }
                if (f3 >= 85.0f) {
                    f3 = 85.0f;
                }
                f = f1 - f3;
                if (f3 * f3 > 2500.0f) {
                    f += f3 * 0.2f;
                }
            }
            float f7 = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks;
            this.func_77039_a(entity, x, y, z);
            float f8 = this.func_77044_a(entity, partialTicks);
            this.func_77043_a(entity, f8, f, partialTicks);
            GlStateManager.enableRescaleNormal();
            GlStateManager.scale((float)-1.0f, (float)-1.0f, (float)1.0f);
            this.func_77041_b(entity, partialTicks);
            GlStateManager.translate((float)0.0f, (float)-1.5078125f, (float)0.0f);
            float f5 = entity.prevLimbSwingAmount + (entity.limbSwingAmount - entity.prevLimbSwingAmount) * partialTicks;
            float f6 = entity.limbSwing - entity.limbSwingAmount * (1.0f - partialTicks);
            if (entity.isChild()) {
                f6 *= 3.0f;
            }
            if (f5 > 1.0f) {
                f5 = 1.0f;
            }
            GlStateManager.enableAlpha();
            this.field_77045_g.setLivingAnimations(entity, f6, f5, partialTicks);
            this.field_77045_g.setRotationAngles(f6, f5, f8, f2, f7, 0.0625f, entity);
            if (this.field_177098_i) {
                boolean flag1 = this.func_177088_c(entity);
                this.func_77036_a(entity, f6, f5, f8, f2, f7, 0.0625f);
                if (flag1) {
                    this.func_180565_e();
                }
            } else {
                boolean flag = this.func_177090_c(entity, partialTicks);
                this.func_77036_a(entity, f6, f5, f8, f2, f7, 0.0625f);
                if (flag) {
                    this.func_177091_f();
                }
                GlStateManager.depthMask((boolean)true);
                if (!(entity instanceof EntityPlayer) || !((EntityPlayer)entity).isSpectator()) {
                    this.func_177093_a(entity, f6, f5, partialTicks, f8, f2, f7, 0.0625f);
                }
            }
            SilentView rotations = Client.moduleManager.getModule(SilentView.class);
            float f3 = Minecraft.getMinecraft().gameSettings.thirdPersonView != 0 && rotations.getState() && (Boolean)rotations.getSilentValue().get() != false && entity == Minecraft.getMinecraft().thePlayer ? entity.prevRotationPitch + ((RotationUtils.serverRotation.getPitch() != 0.0f ? RotationUtils.serverRotation.getPitch() : entity.rotationPitch) - entity.prevRotationPitch) : (renderpitch = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks);
            float f4 = Minecraft.getMinecraft().gameSettings.thirdPersonView != 0 && rotations.getState() && (Boolean)rotations.getSilentValue().get() != false && entity == Minecraft.getMinecraft().thePlayer ? entity.prevRotationYaw + ((RotationUtils.serverRotation.getYaw() != 0.0f ? RotationUtils.serverRotation.getYaw() : entity.rotationYaw) - entity.prevRotationYaw) : (renderyaw = entity.prevRotationYaw + (entity.rotationYaw - entity.prevRotationYaw) * partialTicks);
            if (rotations.getState() && ((Boolean)rotations.getSilentValue().get()).booleanValue() && entity.equals((Object)Minecraft.getMinecraft().thePlayer) && rotations.shouldRotate()) {
                GL11.glPushMatrix();
                GL11.glPushAttrib((int)1048575);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)2896);
                GL11.glPolygonMode((int)1032, (int)6914);
                if (Minecraft.getMinecraft().thePlayer.hurtTime > 0) {
                    GL11.glColor4f((float)255.0f, (float)0.0f, (float)0.0f, (float)8.0f);
                } else {
                    GL11.glColor4f((float)255.0f, (float)200.0f, (float)0.0f, (float)8.0f);
                }
                GL11.glRotatef((float)(renderyaw - f), (float)0.0f, (float)0.001f, (float)0.0f);
                this.field_77045_g.render((Entity)Minecraft.getMinecraft().thePlayer, f6, f5, renderpitch, f2, renderpitch, 0.0625f);
                GL11.glEnable((int)2896);
                GL11.glDisable((int)3042);
                GL11.glEnable((int)3553);
                GL11.glEnable((int)2929);
                GL11.glColor3d((double)1.0, (double)1.0, (double)1.0);
                GL11.glPopAttrib();
                GL11.glPopMatrix();
            }
            GlStateManager.disableRescaleNormal();
        }
        catch (Exception exception) {
            field_147923_a.error("Couldn't render entity", (Throwable)exception);
        }
        GlStateManager.setActiveTexture((int)OpenGlHelper.lightmapTexUnit);
        GlStateManager.enableTexture2D();
        GlStateManager.setActiveTexture((int)OpenGlHelper.defaultTexUnit);
        GlStateManager.enableCull();
        GlStateManager.popMatrix();
        if (!this.field_177098_i) {
            super.doRenders((Entity)entity, x, y, z, entityYaw, partialTicks);
        }
    }

    @Overwrite
    protected <T extends EntityLivingBase> void func_77036_a(T entitylivingbaseIn, float p_77036_2_, float p_77036_3_, float p_77036_4_, float p_77036_5_, float p_77036_6_, float scaleFactor) {
        boolean silent;
        boolean visible = !entitylivingbaseIn.isInvisible();
        boolean semiVisible = !visible && !entitylivingbaseIn.isInvisibleToPlayer((EntityPlayer)Minecraft.getMinecraft().thePlayer);
        boolean bl = silent = entitylivingbaseIn == Minecraft.getMinecraft().thePlayer && Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).getState() && (Boolean)Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).getSilentValue().get() != false && Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).shouldRotate();
        if (visible || semiVisible || silent) {
            if (!this.func_180548_c(entitylivingbaseIn)) {
                return;
            }
            if (semiVisible) {
                GlStateManager.pushMatrix();
                GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)0.15f);
                GlStateManager.depthMask((boolean)false);
                GlStateManager.enableBlend();
                GlStateManager.blendFunc((int)770, (int)771);
                GlStateManager.alphaFunc((int)516, (float)0.003921569f);
            }
            if (silent) {
                GlStateManager.pushMatrix();
                GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)0.1f);
                GlStateManager.depthMask((boolean)false);
                GlStateManager.enableBlend();
                GlStateManager.blendFunc((int)770, (int)771);
                GlStateManager.alphaFunc((int)516, (float)0.003921569f);
            }
            this.field_77045_g.render(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
            if (semiVisible) {
                GlStateManager.disableBlend();
                GlStateManager.alphaFunc((int)516, (float)0.1f);
                GlStateManager.popMatrix();
                GlStateManager.depthMask((boolean)true);
            }
            if (silent) {
                GlStateManager.disableBlend();
                GlStateManager.alphaFunc((int)516, (float)0.05f);
                GlStateManager.popMatrix();
                GlStateManager.depthMask((boolean)true);
            }
        }
    }
}

