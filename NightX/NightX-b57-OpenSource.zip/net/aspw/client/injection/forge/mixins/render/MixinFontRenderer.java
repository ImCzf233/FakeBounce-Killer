/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.FontRenderer
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.render;

import net.aspw.client.Client;
import net.aspw.client.event.TextEvent;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={FontRenderer.class})
public abstract class MixinFontRenderer {
    @Shadow
    protected abstract void func_78265_b();

    @Inject(method={"drawString(Ljava/lang/String;FFIZ)I"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/gui/FontRenderer;renderString(Ljava/lang/String;FFIZ)I", ordinal=0, shift=At.Shift.AFTER)})
    private void resetStyle(CallbackInfoReturnable<Integer> ci) {
        this.func_78265_b();
    }

    @ModifyVariable(method={"renderString"}, at=@At(value="HEAD"), require=1, ordinal=0, argsOnly=true)
    private String renderString(String string) {
        if (string == null) {
            return null;
        }
        if (Client.eventManager == null) {
            return string;
        }
        TextEvent textEvent = new TextEvent(string);
        Client.eventManager.callEvent(textEvent);
        return textEvent.getText();
    }

    @ModifyVariable(method={"getStringWidth"}, at=@At(value="HEAD"), require=1, ordinal=0, argsOnly=true)
    private String getStringWidth(String string) {
        if (string == null) {
            return null;
        }
        if (Client.eventManager == null) {
            return string;
        }
        TextEvent textEvent = new TextEvent(string);
        Client.eventManager.callEvent(textEvent);
        return textEvent.getText();
    }
}

