/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiLanguage
 *  net.minecraft.client.gui.GuiScreen
 *  org.spongepowered.asm.mixin.Mixin
 */
package net.aspw.client.injection.forge.mixins.gui;

import net.minecraft.client.gui.GuiLanguage;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={GuiLanguage.class})
public class MixinGuiLanguage
extends GuiScreen {
    public void onGuiClosed() {
        this.mc.ingameGUI.getChatGUI().refreshChat();
    }
}

