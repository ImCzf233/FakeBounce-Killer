/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.ItemRenderer
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.block.model.ItemCameraTransforms$TransformType
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.item.EnumAction
 *  net.minecraft.item.ItemCarrotOnAStick
 *  net.minecraft.item.ItemFishingRod
 *  net.minecraft.item.ItemMap
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.util.MathHelper
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.item;

import net.aspw.client.Client;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.combat.TPAura;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.features.module.impl.visual.AntiBlind;
import net.aspw.client.util.timer.MSTimer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.EnumAction;
import net.minecraft.item.ItemCarrotOnAStick;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ItemRenderer.class})
public abstract class MixinItemRenderer {
    float delay = 0.0f;
    MSTimer rotateTimer = new MSTimer();
    @Shadow
    private float field_78451_d;
    @Shadow
    private float field_78454_c;
    @Shadow
    @Final
    private Minecraft field_78455_a;
    @Shadow
    private ItemStack field_78453_b;

    @Shadow
    protected abstract void func_178101_a(float var1, float var2);

    @Shadow
    protected abstract void func_178109_a(AbstractClientPlayer var1);

    @Shadow
    protected abstract void func_178110_a(EntityPlayerSP var1, float var2);

    @Shadow
    protected abstract void func_178097_a(AbstractClientPlayer var1, float var2, float var3, float var4);

    @Shadow
    protected abstract void func_178096_b(float var1, float var2);

    @Shadow
    protected abstract void func_178104_a(AbstractClientPlayer var1, float var2);

    @Shadow
    protected abstract void func_178103_d();

    @Shadow
    protected abstract void func_178098_a(float var1, AbstractClientPlayer var2);

    @Shadow
    protected abstract void func_178105_d(float var1);

    @Shadow
    public abstract void func_178099_a(EntityLivingBase var1, ItemStack var2, ItemCameraTransforms.TransformType var3);

    @Shadow
    protected abstract void func_178095_a(AbstractClientPlayer var1, float var2, float var3);

    private void func_178103_d(float qq) {
        GlStateManager.translate((float)-0.5f, (float)qq, (float)0.0f);
        GlStateManager.rotate((float)30.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.rotate((float)-80.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.rotate((float)60.0f, (float)0.0f, (float)1.0f, (float)0.0f);
    }

    private void func_178103_d() {
        GlStateManager.translate((float)-0.5f, (float)0.2f, (float)0.0f);
        GlStateManager.rotate((float)30.0f, (float)0.0f, (float)1.0f, (float)0.0f);
        GlStateManager.rotate((float)-80.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        GlStateManager.rotate((float)60.0f, (float)0.0f, (float)1.0f, (float)0.0f);
    }

    @Overwrite
    public void func_78440_a(float partialTicks) {
        float f = 1.0f - (this.field_78451_d + (this.field_78454_c - this.field_78451_d) * partialTicks);
        EntityPlayerSP abstractclientplayer = this.field_78455_a.thePlayer;
        float f1 = abstractclientplayer.getSwingProgress(partialTicks);
        float f2 = abstractclientplayer.prevRotationPitch + (abstractclientplayer.rotationPitch - abstractclientplayer.prevRotationPitch) * partialTicks;
        float f3 = abstractclientplayer.prevRotationYaw + (abstractclientplayer.rotationYaw - abstractclientplayer.prevRotationYaw) * partialTicks;
        GL11.glTranslated((double)((Float)Animations.itemPosX.get()).doubleValue(), (double)((Float)Animations.itemPosY.get()).doubleValue(), (double)((Float)Animations.itemPosZ.get()).doubleValue());
        this.func_178101_a(f2, f3);
        this.func_178109_a((AbstractClientPlayer)abstractclientplayer);
        this.func_178110_a(abstractclientplayer, partialTicks);
        GlStateManager.scale((float)1.0f, (float)1.0f, (float)(-((Float)Animations.itemFov.getValue()).floatValue() + 1.0f));
        GlStateManager.enableRescaleNormal();
        GlStateManager.pushMatrix();
        GL11.glTranslated((double)((Float)Animations.itemPosX.get()).doubleValue(), (double)((Float)Animations.itemPosY.get()).doubleValue(), (double)((Float)Animations.itemPosZ.get()).doubleValue());
        if (this.field_78453_b != null) {
            if (((Boolean)Animations.oldAnimations.getValue()).booleanValue() && (this.field_78453_b.getItem() instanceof ItemCarrotOnAStick || this.field_78453_b.getItem() instanceof ItemFishingRod)) {
                GlStateManager.translate((float)0.08f, (float)-0.027f, (float)-0.33f);
                GlStateManager.scale((float)0.93f, (float)1.0f, (float)1.0f);
            }
            KillAura killAura = Client.moduleManager.getModule(KillAura.class);
            TPAura tpAura = Client.moduleManager.getModule(TPAura.class);
            if (this.field_78453_b.getItem() instanceof ItemMap) {
                this.func_178097_a((AbstractClientPlayer)abstractclientplayer, f2, f, f1);
            } else if (abstractclientplayer.func_71052_bv() > 0 || this.field_78453_b.getItem() instanceof ItemSword && (killAura.getBlockingStatus() || killAura.getFakeBlock()) && !((String)killAura.getAutoBlockModeValue().get()).equals("None") || this.field_78453_b.getItem() instanceof ItemSword && tpAura.getState() && tpAura.isBlocking() || this.field_78453_b.getItem() instanceof ItemSword && killAura.getTarget() != null && !((String)killAura.getAutoBlockModeValue().get()).equals("None")) {
                EnumAction enumaction = killAura.getBlockingStatus() ? EnumAction.BLOCK : this.field_78453_b.getItemUseAction();
                block0 : switch (enumaction) {
                    case NONE: {
                        if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                            this.func_178096_b(0.0f, 0.0f);
                        } else {
                            this.func_178096_b(f, 0.0f);
                        }
                        GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                        break;
                    }
                    case EAT: 
                    case DRINK: {
                        this.func_178104_a((AbstractClientPlayer)abstractclientplayer, partialTicks);
                        if (((Boolean)Animations.oldAnimations.getValue()).booleanValue()) {
                            if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                                this.func_178096_b(0.0f, f1);
                            } else {
                                this.func_178096_b(f, f1);
                            }
                        } else if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                            this.func_178096_b(0.0f, 0.0f);
                        } else {
                            this.func_178096_b(f, 0.0f);
                        }
                        GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                        break;
                    }
                    case BLOCK: {
                        String z;
                        switch (z = (String)Animations.Sword.get()) {
                            case "Astolfo": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var9 * 58.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)0.5f);
                                GlStateManager.rotate((float)(-var9 * 43.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Leaked": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.11), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var = MathHelper.sin((float)((float)((double)MathHelper.sqrt_float((float)f1) * Math.PI)));
                                this.func_178096_b(0.0f, 0.0f);
                                this.func_178103_d();
                                float var16 = MathHelper.sin((float)((float)((double)(f1 * f1) * Math.PI)));
                                GlStateManager.rotate((float)(-var16 * 16.0f), (float)0.0f, (float)1.0f, (float)0.0f);
                                GlStateManager.rotate((float)(-var * 0.0f), (float)0.0f, (float)0.0f, (float)1.0f);
                                GlStateManager.rotate((float)(-var * 28.0f), (float)1.5f, (float)0.0f, (float)0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Reverse": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.24), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.12));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 1.4f, f1);
                                }
                                this.func_178103_d();
                                GL11.glTranslated((double)0.08, (double)-0.1, (double)-0.3);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Smooth": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.14), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.02), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.24));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.0f, 0.0f);
                                }
                                float var91 = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                this.func_178103_d(0.2f);
                                GlStateManager.translate((float)-0.36f, (float)0.25f, (float)-0.06f);
                                GlStateManager.rotate((float)(-var91 * 35.0f), (float)-8.0f, (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(-var91 * 70.0f), (float)1.0f, (float)0.4f, (float)-0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Hide": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)((Float)Animations.blockPosY.get()).doubleValue(), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((String)Animations.swingAnimValue.get()).equals("Vanilla")) {
                                    this.func_178105_d(f1);
                                    if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                        this.func_178096_b(0.0f, f1);
                                    } else {
                                        this.func_178096_b(f, f1);
                                    }
                                }
                                if (((String)Animations.swingAnimValue.get()).equals("Flux")) {
                                    if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                        this.func_178096_b(0.0f, f1);
                                    } else {
                                        this.func_178096_b(f, f1);
                                    }
                                }
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Winter": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() - 0.02), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 1.5f, f1);
                                }
                                this.func_178103_d();
                                GL11.glTranslatef((float)-0.35f, (float)0.1f, (float)0.0f);
                                GL11.glTranslatef((float)-0.05f, (float)-0.1f, (float)0.1f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Slide": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.1), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.01), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.07));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 1.5f, 0.0f);
                                }
                                float var91 = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                this.func_178103_d(0.2f);
                                GlStateManager.translate((float)-0.4f, (float)0.28f, (float)0.0f);
                                GlStateManager.rotate((float)(-var91 * 35.0f), (float)-8.0f, (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(-var91 * 70.0f), (float)1.0f, (float)-0.4f, (float)-0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Sigma4": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.01), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.46), (double)(((Float)Animations.blockPosZ.get()).doubleValue() + 0.2));
                                float var = MathHelper.sin((float)((float)((double)MathHelper.sqrt_float((float)f1) * Math.PI)));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.0f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var * 55.0f / 2.0f), (float)-8.0f, (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(-var * 45.0f), (float)1.0f, (float)(var / 2.0f), (float)0.0f);
                                this.func_178103_d();
                                GL11.glTranslated((double)1.2, (double)0.3, (double)0.5);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Old": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.08), (double)((Float)Animations.blockPosY.get()).doubleValue(), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.05));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f, f1);
                                }
                                this.func_178103_d();
                                GlStateManager.translate((float)-0.35f, (float)0.2f, (float)0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Jigsaw": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() - 0.04), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.1));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f, f1);
                                }
                                this.func_178103_d();
                                GlStateManager.translate((double)-0.5, (double)0.0, (double)0.0);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Small": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.18), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.07), (double)(((Float)Animations.blockPosZ.get()).doubleValue() - 0.24));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 1.4f, f1);
                                }
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Dash": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 0.0f);
                                }
                                GL11.glRotated((double)(-var9 * 20.0f), (double)(var9 / 2.0f), (double)0.0, (double)9.0);
                                GL11.glRotated((double)(-var9 * 50.0f), (double)0.8f, (double)(var9 / 2.0f), (double)0.0);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Remix": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var = MathHelper.sin((float)((float)((double)MathHelper.sqrt_float((float)f1) * Math.PI)));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 1.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 1.0f);
                                }
                                this.func_178103_d();
                                GlStateManager.rotate((float)0.0f, (float)-2.0f, (float)0.0f, (float)10.0f);
                                GlStateManager.rotate((float)(-var * 25.0f), (float)0.5f, (float)0.0f, (float)1.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Xiv": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var = MathHelper.sin((float)((float)((double)MathHelper.sqrt_float((float)f1) * Math.PI)));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 1.5f, 0.0f);
                                }
                                this.func_178103_d();
                                float var16 = MathHelper.sin((float)((float)((double)(f1 * f1) * Math.PI)));
                                GlStateManager.rotate((float)(-var16 * 20.0f), (float)0.0f, (float)1.0f, (float)0.0f);
                                GlStateManager.rotate((float)(-var * 20.0f), (float)0.0f, (float)0.0f, (float)1.0f);
                                GlStateManager.rotate((float)(-var * 80.0f), (float)1.0f, (float)0.0f, (float)0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Swank": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 2.0f, f1);
                                }
                                GL11.glRotatef((float)(var9 * 30.0f / 2.0f), (float)(-var9), (float)-0.0f, (float)9.0f);
                                GL11.glRotatef((float)(var9 * 40.0f), (float)1.0f, (float)(-var9 / 2.0f), (float)-0.0f);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Swonk": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 3.0f, 0.0f);
                                }
                                GL11.glRotated((double)(-var9 * -30.0f / 2.0f), (double)(var9 / 2.0f), (double)1.0, (double)4.0);
                                GL11.glRotated((double)(-var9 * 7.5f), (double)1.0, (double)(var9 / 3.0f), (double)-0.0);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "MoonPush": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 0.0f);
                                }
                                this.func_178103_d();
                                float sin = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                GlStateManager.scale((float)1.0f, (float)1.0f, (float)1.0f);
                                GlStateManager.translate((float)-0.2f, (float)0.45f, (float)0.25f);
                                GlStateManager.rotate((float)(-sin * 20.0f), (float)-5.0f, (float)-5.0f, (float)9.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Stella": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                this.func_178096_b(-0.1f, f1);
                                GlStateManager.translate((float)-0.5f, (float)0.3f, (float)-0.2f);
                                GlStateManager.rotate((float)32.0f, (float)0.0f, (float)1.0f, (float)0.0f);
                                GlStateManager.rotate((float)-70.0f, (float)1.0f, (float)0.0f, (float)0.0f);
                                GlStateManager.rotate((float)40.0f, (float)0.0f, (float)1.0f, (float)0.0f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Sigma3": {
                                GL11.glTranslated((double)(((Float)Animations.blockPosX.get()).doubleValue() + 0.02), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.16), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 2.0f, f1);
                                }
                                GL11.glTranslated((double)0.4, (double)-0.06, (double)-0.46);
                                float Swang = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                GlStateManager.rotate((float)(Swang * 25.0f / 2.0f), (float)(-Swang), (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(Swang * 15.0f), (float)1.0f, (float)(-Swang / 2.0f), (float)-0.0f);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Push": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var9 * 40.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)4.0f);
                                GlStateManager.rotate((float)(-var9 * 30.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Aqua": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 6.0f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var9 * 17.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)4.0f);
                                GlStateManager.rotate((float)(-var9 * 6.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Swang": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.5f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var9 * 65.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)4.0f);
                                GlStateManager.rotate((float)(-var9 * 47.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Moon": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.0f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-var9 * 65.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)4.0f);
                                GlStateManager.rotate((float)(-var9 * 60.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "1.8": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f, 0.0f);
                                }
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Swing": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 1.4f, f1);
                                }
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Float": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, 0.0f);
                                } else {
                                    this.func_178096_b(f / 2.0f, 0.0f);
                                }
                                GlStateManager.rotate((float)(-MathHelper.sin((float)(f1 * f1 * (float)Math.PI)) * 40.0f / 2.0f), (float)(MathHelper.sin((float)(f1 * f1 * (float)Math.PI)) / 2.0f), (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(-MathHelper.sin((float)(f1 * f1 * (float)Math.PI)) * 30.0f), (float)1.0f, (float)(MathHelper.sin((float)(f1 * f1 * (float)Math.PI)) / 2.0f), (float)-0.0f);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Ninja": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                float var9 = MathHelper.sin((float)(MathHelper.sqrt_float((float)this.field_78455_a.thePlayer.getSwingProgress(partialTicks)) * (float)Math.PI));
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                this.func_178096_b(-0.1f, 0.0f);
                                GlStateManager.rotate((float)(-var9 * 70.0f / 2.0f), (float)(var9 / 2.0f), (float)1.0f, (float)4.0f);
                                GlStateManager.rotate((float)(-var9 * 0.0f), (float)1.0f, (float)(var9 / 3.0f), (float)-0.0f);
                                this.func_178103_d(0.2f);
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                            case "Edit": {
                                GL11.glTranslated((double)((Float)Animations.blockPosX.get()).doubleValue(), (double)(((Float)Animations.blockPosY.get()).doubleValue() + 0.14), (double)((Float)Animations.blockPosZ.get()).doubleValue());
                                if (((Boolean)Animations.cancelEquip.get()).booleanValue()) {
                                    this.func_178096_b(0.0f, f1);
                                } else {
                                    this.func_178096_b(f / 2.0f, f1);
                                }
                                GL11.glTranslated((double)0.0, (double)0.0, (double)0.0);
                                float Swang = MathHelper.sin((float)(MathHelper.sqrt_float((float)f1) * (float)Math.PI));
                                GlStateManager.rotate((float)(Swang * 16.0f / 2.0f), (float)(-Swang), (float)-0.0f, (float)9.0f);
                                GlStateManager.rotate((float)(Swang * 28.0f), (float)1.0f, (float)(-Swang / 3.0f), (float)-0.0f);
                                this.func_178103_d();
                                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                                break block0;
                            }
                        }
                        break;
                    }
                    case BOW: {
                        if (((Boolean)Animations.oldAnimations.getValue()).booleanValue()) {
                            if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                                this.func_178096_b(0.0f, f1);
                            } else {
                                this.func_178096_b(f, f1);
                            }
                        } else if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                            this.func_178096_b(0.0f, 0.0f);
                        } else {
                            this.func_178096_b(f, 0.0f);
                        }
                        this.func_178098_a(partialTicks, (AbstractClientPlayer)abstractclientplayer);
                        GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
                    }
                }
            } else {
                if (((String)Animations.swingAnimValue.get()).equals("Vanilla")) {
                    this.func_178105_d(f1);
                    if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                        this.func_178096_b(0.0f, f1);
                    } else {
                        this.func_178096_b(f, f1);
                    }
                }
                if (((String)Animations.swingAnimValue.get()).equals("Flux")) {
                    if (((Boolean)Animations.cancelEquip.get()).booleanValue() && !((Boolean)Animations.blockingOnly.get()).booleanValue()) {
                        this.func_178096_b(0.0f, f1);
                    } else {
                        this.func_178096_b(f, f1);
                    }
                }
                GlStateManager.scale((float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f), (float)(((Float)Animations.scale.get()).floatValue() + 1.0f));
            }
            this.func_178099_a((EntityLivingBase)abstractclientplayer, this.field_78453_b, ItemCameraTransforms.TransformType.FIRST_PERSON);
        } else if (!abstractclientplayer.isInvisible()) {
            this.func_178095_a((AbstractClientPlayer)abstractclientplayer, f, f1);
        }
        GlStateManager.popMatrix();
        GlStateManager.disableRescaleNormal();
        RenderHelper.disableStandardItemLighting();
        GL11.glTranslated((double)(-((Float)Animations.itemPosX.get()).doubleValue()), (double)(-((Float)Animations.itemPosY.get()).doubleValue()), (double)(-((Float)Animations.itemPosZ.get()).doubleValue()));
    }

    @Inject(method={"renderFireInFirstPerson"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderFireInFirstPerson(CallbackInfo callbackInfo) {
        AntiBlind antiBlind = Client.moduleManager.getModule(AntiBlind.class);
        if (antiBlind.getState() && ((Boolean)antiBlind.getFireEffect().get()).booleanValue()) {
            GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)0.9f);
            GlStateManager.depthFunc((int)519);
            GlStateManager.depthMask((boolean)false);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)1, (int)0);
            GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GlStateManager.disableBlend();
            GlStateManager.depthMask((boolean)true);
            GlStateManager.depthFunc((int)515);
            callbackInfo.cancel();
        }
    }
}

