/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.IChatComponent
 *  org.lwjgl.input.Mouse
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  scala.Int
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.other.InfiniteChat;
import net.aspw.client.injection.forge.mixins.gui.MixinGuiScreen;
import net.aspw.client.util.AnimationUtils;
import net.aspw.client.util.render.RenderUtils;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import scala.Int;

@Mixin(value={GuiChat.class})
public abstract class MixinGuiChat
extends MixinGuiScreen {
    @Shadow
    protected GuiTextField field_146415_a;
    @Shadow
    private List<String> field_146412_t;
    @Shadow
    private boolean field_146414_r;
    private float yPosOfInputField;
    private float fade = 0.0f;

    @Shadow
    public abstract void func_146406_a(String[] var1);

    @Inject(method={"initGui"}, at={@At(value="RETURN")})
    private void init(CallbackInfo callbackInfo) {
        this.field_146415_a.yPosition = this.field_146295_m + 1;
        this.yPosOfInputField = this.field_146415_a.yPosition;
    }

    @Inject(method={"keyTyped"}, at={@At(value="RETURN")})
    private void updateLength(CallbackInfo callbackInfo) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(InfiniteChat.class)).getState()) {
            this.field_146415_a.setMaxStringLength(Int.MaxValue());
        }
        if (!this.field_146415_a.getText().startsWith(".") || Objects.requireNonNull(Client.moduleManager.getModule(InfiniteChat.class)).getState()) {
            return;
        }
        this.field_146415_a.setMaxStringLength(100);
    }

    @Inject(method={"updateScreen"}, at={@At(value="HEAD")})
    private void updateScreen(CallbackInfo callbackInfo) {
        int delta = RenderUtils.deltaTime;
        if (this.fade < 14.0f) {
            this.fade = AnimationUtils.animate(14.0f, this.fade, 10.0f * (float)delta);
        }
        if (this.fade > 14.0f) {
            this.fade = 14.0f;
        }
        if (this.yPosOfInputField > (float)(this.field_146295_m - 12)) {
            this.yPosOfInputField = AnimationUtils.animate(this.field_146295_m - 12, this.yPosOfInputField, 8.571428f * (float)delta);
        }
        if (this.yPosOfInputField < (float)(this.field_146295_m - 12)) {
            this.yPosOfInputField = this.field_146295_m - 12;
        }
        this.field_146415_a.yPosition = (int)this.yPosOfInputField;
    }

    @Inject(method={"autocompletePlayerNames"}, at={@At(value="HEAD")})
    private void prioritizeClientFriends(CallbackInfo callbackInfo) {
        this.field_146412_t.sort(Comparator.comparing(s -> !Client.fileManager.friendsConfig.isFriend((String)s)));
    }

    @Overwrite
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        IChatComponent ichatcomponent;
        RenderUtils.drawRect(2.0f, (float)this.field_146295_m - this.fade, (float)(this.field_146294_l - 2), (float)this.field_146295_m - this.fade + 12.0f, Integer.MIN_VALUE);
        this.field_146415_a.drawTextBox();
        if (!this.field_146415_a.getText().isEmpty() && this.field_146415_a.getText().startsWith(".")) {
            this.field_146297_k.fontRendererObj.drawStringWithShadow("", (float)(this.field_146415_a.xPosition + this.field_146297_k.fontRendererObj.getStringWidth(this.field_146415_a.getText())), (float)this.field_146415_a.yPosition, new Color(165, 165, 165).getRGB());
        }
        if ((ichatcomponent = this.field_146297_k.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY())) != null) {
            this.func_175272_a(ichatcomponent, mouseX, mouseY);
        }
    }
}

