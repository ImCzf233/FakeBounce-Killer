/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiIngameMenu
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.injection.forge.mixins.gui.MixinGuiScreen;
import net.aspw.client.util.ServerUtils;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiIngameMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiIngameMenu.class})
public abstract class MixinGuiIngameMenu
extends MixinGuiScreen {
    @Inject(method={"initGui"}, at={@At(value="RETURN")})
    private void initGui(CallbackInfo callbackInfo) {
        this.field_146292_n.add(new GuiButton(1337, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 128, "Reconnect"));
        this.field_146292_n.add(new GuiButton(727, this.field_146294_l / 2 - 100, this.field_146295_m - 30, "Open Click Gui"));
    }

    @Inject(method={"actionPerformed"}, at={@At(value="HEAD")})
    private void actionPerformed(GuiButton button, CallbackInfo callbackInfo) {
        if (button.id == 1337 && !this.field_146297_k.isIntegratedServerRunning()) {
            this.field_146297_k.theWorld.sendQuittingDisconnectingPacket();
            ServerUtils.connectToLastServer();
        }
        if (button.id == 727) {
            Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).setState(true);
        }
    }

    @Inject(method={"drawScreen"}, at={@At(value="RETURN")})
    private void drawScreen(CallbackInfo callbackInfo) {
        Fonts.minecraftFont.drawStringWithShadow("\u00a77Username: \u00a7d" + this.field_146297_k.getSession().getUsername(), 6.0f, 6.0f, 0xFFFFFF);
    }
}

