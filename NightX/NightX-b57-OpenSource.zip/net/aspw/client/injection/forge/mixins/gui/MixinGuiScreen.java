/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.event.ClickEvent
 *  net.minecraft.event.HoverEvent
 *  net.minecraft.util.ChatStyle
 *  net.minecraft.util.IChatComponent
 *  org.lwjgl.input.Keyboard
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.util.Collections;
import java.util.List;
import net.aspw.client.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiScreen.class})
public abstract class MixinGuiScreen {
    @Shadow
    public Minecraft field_146297_k;
    @Shadow
    public int field_146294_l;
    @Shadow
    public int field_146295_m;
    @Shadow
    protected List<GuiButton> field_146292_n;
    @Shadow
    protected FontRenderer field_146289_q;

    @Shadow
    public void func_73876_c() {
    }

    @Shadow
    public abstract void func_175272_a(IChatComponent var1, int var2, int var3);

    @Shadow
    protected abstract void func_146283_a(List<String> var1, int var2, int var3);

    @Shadow
    public abstract void func_146276_q_();

    @Redirect(method={"handleKeyboardInput"}, at=@At(value="INVOKE", target="Lorg/lwjgl/input/Keyboard;getEventKeyState()Z", remap=false))
    private boolean checkCharacter() {
        return Keyboard.getEventKey() == 0 && Keyboard.getEventCharacter() >= ' ' || Keyboard.getEventKeyState();
    }

    @Inject(method={"drawWorldBackground"}, at={@At(value="HEAD")}, cancellable=true)
    private void drawWorldBackground(CallbackInfo callbackInfo) {
        if (!this.shouldRenderBackground()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"drawBackground"}, at={@At(value="HEAD")})
    private void drawClientBackground(CallbackInfo callbackInfo) {
        GlStateManager.disableLighting();
        GlStateManager.disableFog();
    }

    @Inject(method={"sendChatMessage(Ljava/lang/String;Z)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void messageSend(String msg, boolean addToChat, CallbackInfo callbackInfo) {
        if (msg.startsWith(".") && addToChat) {
            this.field_146297_k.ingameGUI.getChatGUI().addToSentMessages(msg);
            Client.commandManager.executeCommands(msg);
            callbackInfo.cancel();
        }
    }

    @Inject(method={"handleComponentHover"}, at={@At(value="HEAD")})
    private void handleHoverOverComponent(IChatComponent component, int x, int y, CallbackInfo callbackInfo) {
        if (component == null || component.getChatStyle().getChatClickEvent() == null) {
            return;
        }
        ChatStyle chatStyle = component.getChatStyle();
        ClickEvent clickEvent = chatStyle.getChatClickEvent();
        HoverEvent hoverEvent = chatStyle.getChatHoverEvent();
        this.func_146283_a(Collections.singletonList("\u00a7c\u00a7l" + clickEvent.getAction().getCanonicalName().toUpperCase() + ": \u00a7a" + clickEvent.getValue()), x, y - (hoverEvent != null ? 17 : 0));
    }

    @Inject(method={"actionPerformed"}, at={@At(value="RETURN")})
    protected void injectActionPerformed(GuiButton button, CallbackInfo callbackInfo) {
        this.injectedActionPerformed(button);
    }

    protected boolean shouldRenderBackground() {
        return true;
    }

    protected void injectedActionPerformed(GuiButton button) {
    }
}

