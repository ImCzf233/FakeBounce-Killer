/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockBush
 *  net.minecraft.block.BlockLilyPad
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.world.World
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 */
package net.aspw.client.injection.forge.mixins.block;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.exploit.ViaVersionFix;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockLilyPad;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(value={BlockLilyPad.class})
public abstract class MixinBlockLilyPad
extends BlockBush {
    @Overwrite
    public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos, IBlockState state) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(ViaVersionFix.class)).getState()) {
            return new AxisAlignedBB((double)pos.getX() + 0.0625, (double)pos.getY() + 0.0, (double)pos.getZ() + 0.0625, (double)pos.getX() + 0.9375, (double)pos.getY() + 0.09375, (double)pos.getZ() + 0.9375);
        }
        return new AxisAlignedBB((double)pos.getX() + 0.0, (double)pos.getY() + 0.0, (double)pos.getZ() + 0.0, (double)pos.getX() + 1.0, (double)pos.getY() + 0.015625, (double)pos.getZ() + 1.0);
    }
}

