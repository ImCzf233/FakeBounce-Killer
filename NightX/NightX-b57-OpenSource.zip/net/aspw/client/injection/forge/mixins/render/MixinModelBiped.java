/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelRenderer
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemSword
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.combat.TPAura;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={ModelBiped.class})
public abstract class MixinModelBiped {
    @Shadow
    public ModelRenderer field_178723_h;
    @Shadow
    public int field_78120_m;
    @Shadow
    public ModelRenderer field_78116_c;
    @Shadow
    public ModelRenderer field_78115_e;
    @Shadow
    public ModelRenderer field_178720_f;
    @Shadow
    public ModelRenderer field_178724_i;
    @Shadow
    public ModelRenderer field_178721_j;
    @Shadow
    public ModelRenderer field_178722_k;
    @Shadow
    public int field_78119_l;

    @Shadow
    public abstract void func_78087_a(float var1, float var2, float var3, float var4, float var5, float var6, Entity var7);

    @Inject(method={"setRotationAngles"}, at={@At(value="FIELD", target="Lnet/minecraft/client/model/ModelBiped;swingProgress:F")})
    private void revertSwordAnimation(float p_setRotationAngles1, float p_setRotationAngles2, float p_setRotationAngles3, float p_setRotationAngles4, float p_setRotationAngles5, float p_setRotationAngles6, Entity p_setRotationAngles7, CallbackInfo callbackInfo) {
        SilentView silentView = Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class));
        KillAura killAura = Objects.requireNonNull(Client.moduleManager.getModule(KillAura.class));
        TPAura tpAura = Objects.requireNonNull(Client.moduleManager.getModule(TPAura.class));
        if (p_setRotationAngles7 instanceof EntityPlayer && p_setRotationAngles7.equals((Object)Minecraft.getMinecraft().thePlayer) && ((Boolean)silentView.getNormalRotationsValue().get()).booleanValue() && !((Boolean)silentView.getSilentValue().get()).booleanValue() && silentView.getState() && (((Boolean)silentView.getModuleCheckValue().get()).booleanValue() && silentView.shouldRotate() || !((Boolean)silentView.getModuleCheckValue().get()).booleanValue())) {
            this.field_78116_c.rotateAngleX = (float)Math.toRadians(SilentView.lerp(Minecraft.getMinecraft().timer.renderPartialTicks, SilentView.getPrevHeadPitch(), SilentView.getHeadPitch()));
        }
        if (this.field_78120_m == 3) {
            this.field_178723_h.rotateAngleZ = 0.0f;
            this.field_178723_h.rotateAngleY = -0.5235988f;
            return;
        }
        if (this.field_78120_m == 0 || this.field_78120_m == 2) {
            return;
        }
        if ((killAura.getState() && killAura.getTarget() != null && !((String)killAura.getAutoBlockModeValue().get()).equals("None") || tpAura.getState() && tpAura.isBlocking()) && Minecraft.getMinecraft().gameSettings.thirdPersonView != 0 && p_setRotationAngles7 instanceof EntityPlayer && p_setRotationAngles7.equals((Object)Minecraft.getMinecraft().thePlayer) && Minecraft.getMinecraft().thePlayer.getHeldItem().getItem() instanceof ItemSword) {
            this.field_178723_h.rotateAngleZ = 0.0f;
            this.field_178723_h.rotateAngleX = this.field_178723_h.rotateAngleX * 0.4f - 0.7853982f;
            this.field_178723_h.rotateAngleY = -0.5235988f;
        }
    }
}

