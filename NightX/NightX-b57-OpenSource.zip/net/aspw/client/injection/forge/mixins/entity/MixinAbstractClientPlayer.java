/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraft.util.ResourceLocation
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.entity;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Cape;
import net.aspw.client.features.module.impl.visual.CustomModel;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.injection.forge.mixins.entity.MixinEntityPlayer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={AbstractClientPlayer.class})
public abstract class MixinAbstractClientPlayer
extends MixinEntityPlayer {
    @Inject(method={"getLocationCape"}, at={@At(value="HEAD")}, cancellable=true)
    private void getCape(CallbackInfoReturnable<ResourceLocation> callbackInfoReturnable) {
        Cape cape = Objects.requireNonNull(Client.moduleManager.getModule(Cape.class));
        SilentView silentView = Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class));
        CustomModel customModel = Objects.requireNonNull(Client.moduleManager.getModule(CustomModel.class));
        if ((silentView.getState() && ((Boolean)silentView.getSilentValue().get()).booleanValue() && silentView.shouldRotate() || customModel.getState() && ((Boolean)customModel.getHideCape().get()).booleanValue()) && Objects.equals(this.func_146103_bH().getName(), Minecraft.getMinecraft().thePlayer.getGameProfile().getName())) {
            callbackInfoReturnable.cancel();
            return;
        }
        if (cape.getState() && Objects.equals(this.func_146103_bH().getName(), Minecraft.getMinecraft().thePlayer.getGameProfile().getName())) {
            callbackInfoReturnable.setReturnValue((Object)cape.getCapeLocation((String)cape.getStyleValue().get()));
        }
    }

    @Inject(method={"getFovModifier"}, at={@At(value="HEAD")}, cancellable=true)
    private void getFovModifier(CallbackInfoReturnable<Float> callbackInfoReturnable) {
        Hud hud = Objects.requireNonNull(Client.moduleManager.getModule(Hud.class));
        float newFov = ((Float)hud.getCustomFovModifier().getValue()).floatValue();
        newFov *= 1.0f;
        if (((Boolean)hud.getCustomFov().get()).booleanValue() && hud.getState()) {
            callbackInfoReturnable.setReturnValue((Object)Float.valueOf(newFov));
        }
    }
}

