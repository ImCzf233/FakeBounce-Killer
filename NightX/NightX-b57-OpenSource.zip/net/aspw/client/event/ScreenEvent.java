/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;
import net.minecraft.client.gui.GuiScreen;
import org.jetbrains.annotations.Nullable;

public final class ScreenEvent
extends Event {
    private final GuiScreen guiScreen;

    public ScreenEvent(@Nullable GuiScreen guiScreen) {
        this.guiScreen = guiScreen;
    }

    public final GuiScreen getGuiScreen() {
        return this.guiScreen;
    }
}

