/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.event;

import java.lang.reflect.Method;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;

public final class EventHook {
    private final Listenable eventClass;
    private final Method method;
    private final int priority;
    private final boolean isIgnoreCondition;

    public EventHook(Listenable eventClass, Method method, int priority, EventTarget eventTarget) {
        Intrinsics.checkNotNullParameter((Object)eventClass, (String)"eventClass");
        Intrinsics.checkNotNullParameter((Object)method, (String)"method");
        Intrinsics.checkNotNullParameter((Object)eventTarget, (String)"eventTarget");
        this.eventClass = eventClass;
        this.method = method;
        this.priority = priority;
        this.isIgnoreCondition = eventTarget.ignoreCondition();
    }

    public final Listenable getEventClass() {
        return this.eventClass;
    }

    public final Method getMethod() {
        return this.method;
    }

    public final int getPriority() {
        return this.priority;
    }

    public final boolean isIgnoreCondition() {
        return this.isIgnoreCondition;
    }

    public EventHook(Listenable eventClass, Method method, EventTarget eventTarget) {
        Intrinsics.checkNotNullParameter((Object)eventClass, (String)"eventClass");
        Intrinsics.checkNotNullParameter((Object)method, (String)"method");
        Intrinsics.checkNotNullParameter((Object)eventTarget, (String)"eventTarget");
        this(eventClass, method, 0, eventTarget);
    }
}

