/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;
import org.jetbrains.annotations.Nullable;

public final class TextEvent
extends Event {
    private String text;

    public TextEvent(@Nullable String text) {
        this.text = text;
    }

    public final String getText() {
        return this.text;
    }

    public final void setText(@Nullable String string) {
        this.text = string;
    }
}

