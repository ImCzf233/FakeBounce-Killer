/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.model.ModelPlayer
 *  net.minecraft.entity.player.EntityPlayer
 */
package net.aspw.client.event;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.entity.player.EntityPlayer;

public final class UpdateModelEvent
extends Event {
    private final EntityPlayer player;
    private final ModelPlayer model;

    public UpdateModelEvent(EntityPlayer player, ModelPlayer model) {
        Intrinsics.checkNotNullParameter((Object)player, (String)"player");
        Intrinsics.checkNotNullParameter((Object)model, (String)"model");
        this.player = player;
        this.model = model;
    }

    public final EntityPlayer getPlayer() {
        return this.player;
    }

    public final ModelPlayer getModel() {
        return this.model;
    }
}

