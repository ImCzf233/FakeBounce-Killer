/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public final class Render2DEvent
extends Event {
    private final float partialTicks;

    public Render2DEvent(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public final float getPartialTicks() {
        return this.partialTicks;
    }
}

