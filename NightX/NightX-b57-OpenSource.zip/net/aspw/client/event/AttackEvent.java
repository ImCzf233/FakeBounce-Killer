/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;
import net.minecraft.entity.Entity;
import org.jetbrains.annotations.Nullable;

public final class AttackEvent
extends Event {
    private final Entity targetEntity;

    public AttackEvent(@Nullable Entity targetEntity) {
        this.targetEntity = targetEntity;
    }

    public final Entity getTargetEntity() {
        return this.targetEntity;
    }
}

