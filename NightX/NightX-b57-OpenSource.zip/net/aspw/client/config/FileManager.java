/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 */
package net.aspw.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.lang.reflect.Field;
import net.aspw.client.Client;
import net.aspw.client.config.FileConfig;
import net.aspw.client.config.configs.AccountsConfig;
import net.aspw.client.config.configs.FriendsConfig;
import net.aspw.client.config.configs.HudConfig;
import net.aspw.client.config.configs.ModulesConfig;
import net.aspw.client.config.configs.ValuesConfig;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;

public class FileManager
extends MinecraftInstance {
    public static final Gson PRETTY_GSON = new GsonBuilder().setPrettyPrinting().create();
    public File dir;
    public final File fontsDir;
    public final File settingsDir;
    public final File soundsDir;
    public final File themesDir;
    public final FileConfig modulesConfig;
    public final FileConfig valuesConfig;
    public final AccountsConfig accountsConfig;
    public final FriendsConfig friendsConfig;
    public final FileConfig hudConfig;

    public FileManager() {
        this.dir = new File(FileManager.mc.mcDataDir, "NightX-Adjust");
        this.fontsDir = new File(this.dir, "fonts");
        this.settingsDir = new File(this.dir, "configs");
        this.soundsDir = new File(this.dir, "sounds");
        this.themesDir = new File(this.dir, "themes");
        this.modulesConfig = new ModulesConfig(new File(this.dir, "toggled.json"));
        this.valuesConfig = new ValuesConfig(new File(this.dir, "value.json"));
        this.accountsConfig = new AccountsConfig(new File(this.dir, "alts.json"));
        this.friendsConfig = new FriendsConfig(new File(this.dir, "friends.json"));
        this.hudConfig = new HudConfig(new File(this.dir, "hud.json"));
        this.setupFolder();
    }

    public void setupFolder() {
        if (!this.dir.exists()) {
            this.dir.mkdir();
        }
        if (!this.fontsDir.exists()) {
            this.fontsDir.mkdir();
        }
        if (!this.settingsDir.exists()) {
            this.settingsDir.mkdir();
        }
        if (!this.soundsDir.exists()) {
            this.soundsDir.mkdir();
        }
        if (!this.themesDir.exists()) {
            this.themesDir.mkdir();
        }
    }

    public void loadConfigs(FileConfig ... configs) {
        for (FileConfig fileConfig : configs) {
            this.loadConfig(fileConfig);
        }
    }

    public void loadConfig(FileConfig config) {
        if (!config.hasConfig()) {
            ClientUtils.getLogger().info("[FileManager] Skipped loading config: " + config.getFile().getName() + ".");
            this.saveConfig(config, true);
            return;
        }
        try {
            config.loadConfig();
            ClientUtils.getLogger().info("[FileManager] Loaded config: " + config.getFile().getName() + ".");
        }
        catch (Throwable t) {
            ClientUtils.getLogger().error("[FileManager] Failed to load config file: " + config.getFile().getName() + ".", t);
        }
    }

    public void saveAllConfigs() {
        for (Field field : this.getClass().getDeclaredFields()) {
            if (field.getType() != FileConfig.class) continue;
            try {
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                FileConfig fileConfig = (FileConfig)field.get(this);
                this.saveConfig(fileConfig);
            }
            catch (IllegalAccessException e) {
                ClientUtils.getLogger().error("[FileManager] Failed to save config file of field " + field.getName() + ".", (Throwable)e);
            }
        }
    }

    public void saveConfig(FileConfig config) {
        this.saveConfig(config, false);
    }

    private void saveConfig(FileConfig config, boolean ignoreStarting) {
        if (!ignoreStarting && Client.INSTANCE.isStarting()) {
            return;
        }
        try {
            if (!config.hasConfig()) {
                config.createConfig();
            }
            config.saveConfig();
            ClientUtils.getLogger().info("[FileManager] Saved config: " + config.getFile().getName() + ".");
        }
        catch (Throwable t) {
            ClientUtils.getLogger().error("[FileManager] Failed to save config file: " + config.getFile().getName() + ".", t);
        }
    }
}

