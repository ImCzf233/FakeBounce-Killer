/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.CancellableEvent;

public final class JumpEvent
extends CancellableEvent {
    private float motion;

    public JumpEvent(float motion) {
        this.motion = motion;
    }

    public final float getMotion() {
        return this.motion;
    }

    public final void setMotion(float f) {
        this.motion = f;
    }
}

