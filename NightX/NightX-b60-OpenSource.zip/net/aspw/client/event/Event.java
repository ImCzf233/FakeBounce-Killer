/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

public class Event {
}

