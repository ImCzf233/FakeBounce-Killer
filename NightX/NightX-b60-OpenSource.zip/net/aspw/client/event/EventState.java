/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

public final class EventState
extends Enum<EventState> {
    private final String stateName;
    public static final /* enum */ EventState PRE = new EventState("PRE");
    public static final /* enum */ EventState POST = new EventState("POST");
    private static final /* synthetic */ EventState[] $VALUES;

    private EventState(String stateName) {
        this.stateName = stateName;
    }

    public final String getStateName() {
        return this.stateName;
    }

    public static EventState[] values() {
        return (EventState[])$VALUES.clone();
    }

    public static EventState valueOf(String value) {
        return Enum.valueOf(EventState.class, value);
    }

    static {
        $VALUES = eventStateArray = new EventState[]{EventState.PRE, EventState.POST};
    }
}

