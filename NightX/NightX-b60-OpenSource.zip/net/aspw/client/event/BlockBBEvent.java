/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.event;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.minecraft.block.Block;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import org.jetbrains.annotations.Nullable;

public final class BlockBBEvent
extends Event {
    private final Block block;
    private AxisAlignedBB boundingBox;
    private final int x;
    private final int y;
    private final int z;

    public BlockBBEvent(BlockPos blockPos, Block block, @Nullable AxisAlignedBB boundingBox) {
        Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
        Intrinsics.checkNotNullParameter((Object)block, (String)"block");
        this.block = block;
        this.boundingBox = boundingBox;
        this.x = blockPos.func_177958_n();
        this.y = blockPos.func_177956_o();
        this.z = blockPos.func_177952_p();
    }

    public final Block getBlock() {
        return this.block;
    }

    public final AxisAlignedBB getBoundingBox() {
        return this.boundingBox;
    }

    public final void setBoundingBox(@Nullable AxisAlignedBB axisAlignedBB) {
        this.boundingBox = axisAlignedBB;
    }

    public final int getX() {
        return this.x;
    }

    public final int getY() {
        return this.y;
    }

    public final int getZ() {
        return this.z;
    }
}

