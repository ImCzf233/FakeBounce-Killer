/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.event;

import net.aspw.client.event.Event;

public class CancellableEvent
extends Event {
    private boolean isCancelled;

    public final boolean isCancelled() {
        return this.isCancelled;
    }

    public final void cancelEvent() {
        this.isCancelled = true;
    }
}

