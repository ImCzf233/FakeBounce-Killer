/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.event;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.Event;
import net.aspw.client.event.EventState;

public final class MotionEvent
extends Event {
    private double x;
    private double y;
    private double z;
    private float yaw;
    private float pitch;
    private boolean onGround;
    private EventState eventState;

    public MotionEvent(double x, double y, double z, float yaw, float pitch, boolean onGround) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.onGround = onGround;
        this.eventState = EventState.PRE;
    }

    public final double getX() {
        return this.x;
    }

    public final void setX(double d) {
        this.x = d;
    }

    public final double getY() {
        return this.y;
    }

    public final void setY(double d) {
        this.y = d;
    }

    public final double getZ() {
        return this.z;
    }

    public final void setZ(double d) {
        this.z = d;
    }

    public final float getYaw() {
        return this.yaw;
    }

    public final void setYaw(float f) {
        this.yaw = f;
    }

    public final float getPitch() {
        return this.pitch;
    }

    public final void setPitch(float f) {
        this.pitch = f;
    }

    public final boolean getOnGround() {
        return this.onGround;
    }

    public final void setOnGround(boolean bl) {
        this.onGround = bl;
    }

    public final EventState getEventState() {
        return this.eventState;
    }

    public final void setEventState(EventState eventState) {
        Intrinsics.checkNotNullParameter((Object)((Object)eventState), (String)"<set-?>");
        this.eventState = eventState;
    }
}

