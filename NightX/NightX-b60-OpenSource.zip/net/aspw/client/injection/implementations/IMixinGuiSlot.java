/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.injection.implementations;

public interface IMixinGuiSlot {
    public void setListWidth(int var1);

    public void setEnableScissor(boolean var1);
}

