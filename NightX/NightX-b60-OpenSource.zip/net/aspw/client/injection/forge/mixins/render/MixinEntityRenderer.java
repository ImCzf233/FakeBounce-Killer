/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.renderer.ActiveRenderInfo
 *  net.minecraft.client.renderer.EntityRenderer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.texture.DynamicTexture
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.item.EntityItemFrame
 *  net.minecraft.entity.passive.EntityAnimal
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EntitySelectors
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  net.minecraftforge.client.ForgeHooksClient
 *  net.minecraftforge.client.event.EntityViewRenderEvent$CameraSetup
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.Event
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Mutable
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.Slice
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.render;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.awt.Color;
import java.util.List;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.impl.combat.Reach;
import net.aspw.client.features.module.impl.other.FreeLook;
import net.aspw.client.features.module.impl.visual.CameraNoClip;
import net.aspw.client.features.module.impl.visual.FullBright;
import net.aspw.client.features.module.impl.visual.XRay;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={EntityRenderer.class})
public abstract class MixinEntityRenderer {
    @Mutable
    @Final
    @Shadow
    private final int[] field_78504_Q;
    @Mutable
    @Final
    @Shadow
    private final DynamicTexture field_78513_d;
    @Shadow
    private final float field_78514_e;
    @Shadow
    private final float field_82831_U;
    @Shadow
    private final float field_82832_V;
    @Shadow
    private Entity field_78528_u;
    @Shadow
    private Minecraft field_78531_r;
    @Shadow
    public float field_78491_C;
    @Shadow
    public float field_78490_B;
    @Shadow
    private boolean field_78500_U;
    @Shadow
    private boolean field_78536_aa;
    @Shadow
    private float field_78507_R;

    protected MixinEntityRenderer(int[] lightmapColors, DynamicTexture lightmapTexture, float torchFlickerX, float bossColorModifier, float bossColorModifierPrev, Minecraft mc, float thirdPersonDistanceTemp, float thirdPersonDistance) {
        this.field_78504_Q = lightmapColors;
        this.field_78513_d = lightmapTexture;
        this.field_78514_e = torchFlickerX;
        this.field_82831_U = bossColorModifier;
        this.field_82832_V = bossColorModifierPrev;
        this.field_78531_r = mc;
        this.field_78491_C = thirdPersonDistanceTemp;
        this.field_78490_B = thirdPersonDistance;
    }

    @Shadow
    public abstract void func_175069_a(ResourceLocation var1);

    @Shadow
    public abstract void func_78479_a(float var1, int var2);

    @Inject(method={"renderStreamIndicator"}, at={@At(value="HEAD")}, cancellable=true)
    private void cancelStreamIndicator(CallbackInfo ci) {
        ci.cancel();
    }

    @Inject(method={"renderWorldPass"}, slice={@Slice(from=@At(value="FIELD", target="Lnet/minecraft/util/EnumWorldBlockLayer;TRANSLUCENT:Lnet/minecraft/util/EnumWorldBlockLayer;"))}, at={@At(value="INVOKE", target="Lnet/minecraft/client/renderer/RenderGlobal;renderBlockLayer(Lnet/minecraft/util/EnumWorldBlockLayer;DILnet/minecraft/entity/Entity;)I", ordinal=0)})
    private void enablePolygonOffset(CallbackInfo ci) {
        GlStateManager.func_179088_q();
        GlStateManager.func_179136_a((float)-0.325f, (float)-0.325f);
    }

    @Inject(method={"renderWorldPass"}, slice={@Slice(from=@At(value="FIELD", target="Lnet/minecraft/util/EnumWorldBlockLayer;TRANSLUCENT:Lnet/minecraft/util/EnumWorldBlockLayer;"))}, at={@At(value="INVOKE", target="Lnet/minecraft/client/renderer/RenderGlobal;renderBlockLayer(Lnet/minecraft/util/EnumWorldBlockLayer;DILnet/minecraft/entity/Entity;)I", ordinal=0, shift=At.Shift.AFTER)})
    private void disablePolygonOffset(CallbackInfo ci) {
        GlStateManager.func_179113_r();
    }

    @Inject(method={"renderWorldPass"}, at={@At(value="FIELD", target="Lnet/minecraft/client/renderer/EntityRenderer;renderHand:Z", shift=At.Shift.BEFORE)})
    private void renderWorldPass(int pass, float partialTicks, long finishTimeNano, CallbackInfo callbackInfo) {
        Client.eventManager.callEvent(new Render3DEvent(partialTicks));
    }

    @Inject(method={"orientCamera"}, at={@At(value="INVOKE", target="Lnet/minecraft/util/Vec3;distanceTo(Lnet/minecraft/util/Vec3;)D")}, cancellable=true)
    private void cameraClip(float partialTicks, CallbackInfo callbackInfo) {
        CameraNoClip cameraNoClip = Objects.requireNonNull(Client.moduleManager.getModule(CameraNoClip.class));
        FreeLook freeLook = Objects.requireNonNull(Client.moduleManager.getModule(FreeLook.class));
        if (cameraNoClip.getState() && !freeLook.getState()) {
            callbackInfo.cancel();
            Entity entity = this.field_78531_r.func_175606_aa();
            float f = entity.func_70047_e();
            if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).func_70608_bn()) {
                f = (float)((double)f + 1.0);
                GlStateManager.func_179109_b((float)0.0f, (float)0.3f, (float)0.0f);
                if (!this.field_78531_r.field_71474_y.field_74325_U) {
                    BlockPos blockpos = new BlockPos(entity);
                    IBlockState iblockstate = this.field_78531_r.field_71441_e.func_180495_p(blockpos);
                    ForgeHooksClient.orientBedCamera((IBlockAccess)this.field_78531_r.field_71441_e, (BlockPos)blockpos, (IBlockState)iblockstate, (Entity)entity);
                    GlStateManager.func_179114_b((float)(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks + 180.0f), (float)0.0f, (float)-1.0f, (float)0.0f);
                    GlStateManager.func_179114_b((float)(entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks), (float)-1.0f, (float)0.0f, (float)0.0f);
                }
            } else if (this.field_78531_r.field_71474_y.field_74320_O > 0) {
                double d3 = this.field_78491_C + (this.field_78490_B - this.field_78491_C) * partialTicks;
                if (this.field_78531_r.field_71474_y.field_74325_U) {
                    GlStateManager.func_179109_b((float)0.0f, (float)0.0f, (float)((float)(-d3)));
                } else {
                    float f1 = entity.field_70177_z;
                    float f2 = entity.field_70125_A;
                    if (this.field_78531_r.field_71474_y.field_74320_O == 2) {
                        f2 += 180.0f;
                    }
                    if (this.field_78531_r.field_71474_y.field_74320_O == 2) {
                        GlStateManager.func_179114_b((float)180.0f, (float)0.0f, (float)1.0f, (float)0.0f);
                    }
                    GlStateManager.func_179114_b((float)(entity.field_70125_A - f2), (float)1.0f, (float)0.0f, (float)0.0f);
                    GlStateManager.func_179114_b((float)(entity.field_70177_z - f1), (float)0.0f, (float)1.0f, (float)0.0f);
                    GlStateManager.func_179109_b((float)0.0f, (float)0.0f, (float)((float)(-d3)));
                    GlStateManager.func_179114_b((float)(f1 - entity.field_70177_z), (float)0.0f, (float)1.0f, (float)0.0f);
                    GlStateManager.func_179114_b((float)(f2 - entity.field_70125_A), (float)1.0f, (float)0.0f, (float)0.0f);
                }
            } else {
                GlStateManager.func_179109_b((float)0.0f, (float)0.0f, (float)-0.1f);
            }
            if (!this.field_78531_r.field_71474_y.field_74325_U) {
                float yaw = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks + 180.0f;
                float pitch = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks;
                float roll = 0.0f;
                if (entity instanceof EntityAnimal) {
                    EntityAnimal entityanimal = (EntityAnimal)entity;
                    yaw = entityanimal.field_70758_at + (entityanimal.field_70759_as - entityanimal.field_70758_at) * partialTicks + 180.0f;
                }
                Block block = ActiveRenderInfo.func_180786_a((World)this.field_78531_r.field_71441_e, (Entity)entity, (float)partialTicks);
                EntityViewRenderEvent.CameraSetup event = new EntityViewRenderEvent.CameraSetup((EntityRenderer)this, entity, block, (double)partialTicks, yaw, pitch, roll);
                MinecraftForge.EVENT_BUS.post((Event)event);
                GlStateManager.func_179114_b((float)event.roll, (float)0.0f, (float)0.0f, (float)1.0f);
                GlStateManager.func_179114_b((float)event.pitch, (float)1.0f, (float)0.0f, (float)0.0f);
                GlStateManager.func_179114_b((float)event.yaw, (float)0.0f, (float)1.0f, (float)0.0f);
            }
            GlStateManager.func_179109_b((float)0.0f, (float)(-f), (float)0.0f);
            double d0 = entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * (double)partialTicks;
            double d1 = entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * (double)partialTicks + (double)f;
            double d2 = entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * (double)partialTicks;
            this.field_78500_U = this.field_78531_r.field_71438_f.func_72721_a(d0, d1, d2, partialTicks);
        }
    }

    @Inject(method={"getMouseOver"}, at={@At(value="HEAD")}, cancellable=true)
    private void getMouseOver(float p_getMouseOver_1_, CallbackInfo ci) {
        Entity entity = this.field_78531_r.func_175606_aa();
        if (entity != null && this.field_78531_r.field_71441_e != null) {
            MovingObjectPosition movingObjectPosition;
            this.field_78531_r.field_71424_I.func_76320_a("pick");
            this.field_78531_r.field_147125_j = null;
            Reach reach = Objects.requireNonNull(Client.moduleManager.getModule(Reach.class));
            double d0 = reach.getState() ? (double)reach.getMaxRange() : (double)this.field_78531_r.field_71442_b.func_78757_d();
            this.field_78531_r.field_71476_x = entity.func_174822_a(reach.getState() ? (double)((Float)reach.getBuildReachValue().get()).floatValue() : d0, p_getMouseOver_1_);
            double d1 = d0;
            Vec3 vec3 = entity.func_174824_e(p_getMouseOver_1_);
            boolean flag = false;
            if (this.field_78531_r.field_71442_b.func_78749_i()) {
                d0 = 6.0;
                d1 = 6.0;
            } else if (d0 > 3.0) {
                flag = true;
            }
            if (this.field_78531_r.field_71476_x != null) {
                d1 = this.field_78531_r.field_71476_x.field_72307_f.func_72438_d(vec3);
            }
            if (reach.getState() && (movingObjectPosition = entity.func_174822_a((double)((Float)reach.getBuildReachValue().get()).floatValue(), p_getMouseOver_1_)) != null) {
                d1 = movingObjectPosition.field_72307_f.func_72438_d(vec3);
            }
            Vec3 vec31 = entity.func_70676_i(p_getMouseOver_1_);
            Vec3 vec32 = vec3.func_72441_c(vec31.field_72450_a * d0, vec31.field_72448_b * d0, vec31.field_72449_c * d0);
            this.field_78528_u = null;
            Vec3 vec33 = null;
            float f = 1.0f;
            List list = this.field_78531_r.field_71441_e.func_175674_a(entity, entity.func_174813_aQ().func_72321_a(vec31.field_72450_a * d0, vec31.field_72448_b * d0, vec31.field_72449_c * d0).func_72314_b((double)f, (double)f, (double)f), Predicates.and((Predicate)EntitySelectors.field_180132_d, Entity::func_70067_L));
            double d2 = d1;
            for (Entity entity1 : list) {
                double d3;
                float f1 = entity1.func_70111_Y();
                AxisAlignedBB axisalignedbb = entity1.func_174813_aQ().func_72314_b((double)f1, (double)f1, (double)f1);
                MovingObjectPosition movingobjectposition = axisalignedbb.func_72327_a(vec3, vec32);
                if (axisalignedbb.func_72318_a(vec3)) {
                    if (!(d2 >= 0.0)) continue;
                    this.field_78528_u = entity1;
                    vec33 = movingobjectposition == null ? vec3 : movingobjectposition.field_72307_f;
                    d2 = 0.0;
                    continue;
                }
                if (movingobjectposition == null || !((d3 = vec3.func_72438_d(movingobjectposition.field_72307_f)) < d2) && d2 != 0.0) continue;
                if (entity1 == entity.field_70154_o && !entity.canRiderInteract()) {
                    if (d2 != 0.0) continue;
                    this.field_78528_u = entity1;
                    vec33 = movingobjectposition.field_72307_f;
                    continue;
                }
                this.field_78528_u = entity1;
                vec33 = movingobjectposition.field_72307_f;
                d2 = d3;
            }
            if (this.field_78528_u != null && flag) {
                double d = vec3.func_72438_d(vec33);
                double d3 = reach.getState() ? (double)((Float)reach.getCombatReachValue().get()).floatValue() : 3.0;
                if (d > d3) {
                    this.field_78528_u = null;
                    this.field_78531_r.field_71476_x = new MovingObjectPosition(MovingObjectPosition.MovingObjectType.MISS, (Vec3)Objects.requireNonNull(vec33), null, new BlockPos(vec33));
                }
            }
            if (this.field_78528_u != null && (d2 < d1 || this.field_78531_r.field_71476_x == null)) {
                this.field_78531_r.field_71476_x = new MovingObjectPosition(this.field_78528_u, vec33);
                if (this.field_78528_u instanceof EntityLivingBase || this.field_78528_u instanceof EntityItemFrame) {
                    this.field_78531_r.field_147125_j = this.field_78528_u;
                }
            }
            this.field_78531_r.field_71424_I.func_76319_b();
        }
        ci.cancel();
    }

    @Redirect(method={"updateCameraAndRender"}, at=@At(value="FIELD", target="Lnet/minecraft/client/Minecraft;inGameHasFocus:Z", opcode=180))
    public boolean updateCameraAndRender(Minecraft minecraft) {
        return FreeLook.overrideMouse();
    }

    @Redirect(method={"orientCamera"}, at=@At(value="FIELD", target="Lnet/minecraft/entity/Entity;rotationYaw:F", opcode=180))
    public float getRotationYaw(Entity entity) {
        return FreeLook.perspectiveToggled ? FreeLook.cameraYaw : entity.field_70177_z;
    }

    @Redirect(method={"orientCamera"}, at=@At(value="FIELD", target="Lnet/minecraft/entity/Entity;prevRotationYaw:F", opcode=180))
    public float getPrevRotationYaw(Entity entity) {
        return FreeLook.perspectiveToggled ? FreeLook.cameraYaw : entity.field_70126_B;
    }

    @Redirect(method={"orientCamera"}, at=@At(value="FIELD", target="Lnet/minecraft/entity/Entity;rotationPitch:F", opcode=180))
    public float getRotationPitch(Entity entity) {
        return FreeLook.perspectiveToggled ? FreeLook.cameraPitch : entity.field_70125_A;
    }

    @Redirect(method={"orientCamera"}, at=@At(value="FIELD", target="Lnet/minecraft/entity/Entity;prevRotationPitch:F"))
    public float getPrevRotationPitch(Entity entity) {
        return FreeLook.perspectiveToggled ? FreeLook.cameraPitch : entity.field_70127_C;
    }

    @Overwrite
    private void func_78472_g(float f2) {
        FullBright brightness = Objects.requireNonNull(Client.moduleManager.getModule(FullBright.class));
        XRay xray = Objects.requireNonNull(Client.moduleManager.getModule(XRay.class));
        if (this.field_78536_aa) {
            this.field_78531_r.field_71424_I.func_76320_a("lightTex");
            WorldClient world = this.field_78531_r.field_71441_e;
            if (world != null) {
                float f3 = world.func_72971_b(1.0f);
                float f4 = f3 * 0.95f + 0.05f;
                for (int i2 = 0; i2 < 256; ++i2) {
                    float f5;
                    float f6;
                    float f7 = world.field_73011_w.func_177497_p()[i2 / 16] * f4;
                    float f8 = world.field_73011_w.func_177497_p()[i2 % 16] * (this.field_78514_e * 0.1f + 1.5f);
                    if (world.func_175658_ac() > 0) {
                        f7 = world.field_73011_w.func_177497_p()[i2 / 16];
                    }
                    float f9 = f7 * (f3 * 0.65f + 0.35f);
                    float f10 = f7 * (f3 * 0.65f + 0.35f);
                    float f11 = f8 * ((f8 * 0.6f + 0.4f) * 0.6f + 0.4f);
                    float f12 = f8 * (f8 * f8 * 0.6f + 0.4f);
                    float f13 = f9 + f8;
                    float f14 = f10 + f11;
                    float f15 = f7 + f12;
                    f13 = f13 * 0.96f + 0.03f;
                    f14 = f14 * 0.96f + 0.03f;
                    f15 = f15 * 0.96f + 0.03f;
                    if (this.field_82831_U > 0.0f) {
                        float f16 = this.field_82832_V + (this.field_82831_U - this.field_82832_V) * f2;
                        f13 = f13 * (1.0f - f16) + f13 * 0.7f * f16;
                        f14 = f14 * (1.0f - f16) + f14 * 0.6f * f16;
                        f15 = f15 * (1.0f - f16) + f15 * 0.6f * f16;
                    }
                    if (world.field_73011_w.func_177502_q() == 1) {
                        f13 = 0.22f + f8 * 0.75f;
                        f14 = 0.28f + f11 * 0.75f;
                        f15 = 0.25f + f12 * 0.75f;
                    }
                    if (this.field_78531_r.field_71439_g.func_70644_a(Potion.field_76439_r)) {
                        f6 = this.getNightVisionBrightness((EntityLivingBase)this.field_78531_r.field_71439_g, f2);
                        f5 = 1.0f / f13;
                        if (f5 > 1.0f / f14) {
                            f5 = 1.0f / f14;
                        }
                        if (f5 > 1.0f / f15) {
                            f5 = 1.0f / f15;
                        }
                        f13 = f13 * (1.0f - f6) + f13 * f5 * f6;
                        f14 = f14 * (1.0f - f6) + f14 * f5 * f6;
                        f15 = f15 * (1.0f - f6) + f15 * f5 * f6;
                    }
                    if (f13 > 1.0f) {
                        f13 = 1.0f;
                    }
                    if (f14 > 1.0f) {
                        f14 = 1.0f;
                    }
                    if (f15 > 1.0f) {
                        f15 = 1.0f;
                    }
                    f6 = this.field_78531_r.field_71474_y.field_74333_Y;
                    f5 = 1.0f - f13;
                    float f17 = 1.0f - f14;
                    float f18 = 1.0f - f15;
                    f5 = 1.0f - f5 * f5 * f5 * f5;
                    f17 = 1.0f - f17 * f17 * f17 * f17;
                    f18 = 1.0f - f18 * f18 * f18 * f18;
                    f13 = f13 * (1.0f - f6) + f5 * f6;
                    f14 = f14 * (1.0f - f6) + f17 * f6;
                    f15 = f15 * (1.0f - f6) + f18 * f6;
                    f13 = f13 * 0.96f + 0.03f;
                    f14 = f14 * 0.96f + 0.03f;
                    f15 = f15 * 0.96f + 0.03f;
                    if (f13 > 1.0f) {
                        f13 = 1.0f;
                    }
                    if (f14 > 1.0f) {
                        f14 = 1.0f;
                    }
                    if (f15 > 1.0f) {
                        f15 = 1.0f;
                    }
                    if (f13 < 0.0f) {
                        f13 = 0.0f;
                    }
                    if (f14 < 0.0f) {
                        f14 = 0.0f;
                    }
                    if (f15 < 0.0f) {
                        f15 = 0.0f;
                    }
                    int n2 = (int)(f13 * 255.0f);
                    int n3 = (int)(f14 * 255.0f);
                    int n4 = (int)(f15 * 255.0f);
                    this.field_78504_Q[i2] = xray.getState() || brightness.getState() ? new Color(220, 220, 220).getRGB() : 0xFF000000 | n2 << 16 | n3 << 8 | n4;
                }
                this.field_78513_d.func_110564_a();
                this.field_78536_aa = false;
                this.field_78531_r.field_71424_I.func_76319_b();
            }
        }
    }

    private float getNightVisionBrightness(EntityLivingBase p_getNightVisionBrightness_1_, float p_getNightVisionBrightness_2_) {
        int i = p_getNightVisionBrightness_1_.func_70660_b(Potion.field_76439_r).func_76459_b();
        return i > 200 ? 1.0f : 0.7f + MathHelper.func_76126_a((float)(((float)i - p_getNightVisionBrightness_2_) * (float)Math.PI * 0.2f)) * 0.3f;
    }
}

