/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.renderer.entity.layers.LayerArmorBase
 *  net.minecraft.entity.EntityLivingBase
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.CustomModel;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={LayerArmorBase.class})
public class MixinLayerArmorBase {
    @Inject(method={"doRenderLayer"}, at={@At(value="HEAD")}, cancellable=true)
    public void doRenderLayer(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale, CallbackInfo ci) {
        CustomModel customModel = Objects.requireNonNull(Client.moduleManager.getModule(CustomModel.class));
        SilentView silentView = Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class));
        if (customModel.getState() && ((Boolean)customModel.getOnlySelf().get()).booleanValue() && entitylivingbaseIn == Minecraft.func_71410_x().field_71439_g) {
            ci.cancel();
        } else if (customModel.getState() && !((Boolean)customModel.getOnlySelf().get()).booleanValue()) {
            ci.cancel();
        }
        if (silentView.getState() && ((Boolean)silentView.getSilentValue().get()).booleanValue() && silentView.shouldRotate() && entitylivingbaseIn == Minecraft.func_71410_x().field_71439_g) {
            ci.cancel();
        }
    }
}

