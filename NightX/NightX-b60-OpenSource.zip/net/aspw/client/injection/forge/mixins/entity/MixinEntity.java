/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.Minecraft
 *  net.minecraft.crash.CrashReportCategory
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 *  net.minecraftforge.common.capabilities.Capability
 *  net.minecraftforge.common.capabilities.CapabilityDispatcher
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.entity;

import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import net.aspw.client.Client;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.features.module.impl.combat.HitBox;
import net.aspw.client.features.module.impl.movement.AntiWaterPush;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.other.InfinitePitch;
import net.aspw.client.protocol.Protocol;
import net.aspw.client.protocol.ViaPatcher;
import net.aspw.client.util.EntityUtils;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityDispatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={Entity.class})
public abstract class MixinEntity {
    @Shadow
    public double field_70165_t;
    @Shadow
    public double field_70163_u;
    @Shadow
    public double field_70161_v;
    @Shadow
    public float field_70125_A;
    @Shadow
    public float field_70177_z;
    @Shadow
    public Entity field_70154_o;
    @Shadow
    public double field_70159_w;
    @Shadow
    public double field_70181_x;
    @Shadow
    public double field_70179_y;
    @Shadow
    public boolean field_70122_E;
    @Shadow
    public boolean field_70160_al;
    @Shadow
    public boolean field_70145_X;
    @Shadow
    public World field_70170_p;
    @Shadow
    public boolean field_70134_J;
    @Shadow
    public float field_70138_W;
    @Shadow
    public boolean field_70123_F;
    @Shadow
    public boolean field_70124_G;
    @Shadow
    public boolean field_70132_H;
    @Shadow
    public float field_70140_Q;
    @Shadow
    public float field_82151_R;
    @Shadow
    public int field_70174_ab;
    @Shadow
    public int field_71088_bW;
    @Shadow
    public float field_70130_N;
    @Shadow
    public float field_70127_C;
    @Shadow
    public float field_70126_B;
    @Shadow
    protected Random field_70146_Z;
    @Shadow
    protected boolean field_71087_bX;
    @Shadow
    private int field_70150_b;
    @Shadow
    private int field_70151_c;
    @Shadow(remap=false)
    private CapabilityDispatcher capabilities;

    @Shadow
    public abstract boolean func_70051_ag();

    @Shadow
    public abstract AxisAlignedBB func_174813_aQ();

    @Shadow
    public abstract void func_174826_a(AxisAlignedBB var1);

    @Shadow
    public abstract float func_70032_d(Entity var1);

    @Shadow
    public void func_70091_d(double x, double y, double z) {
    }

    @Shadow
    public abstract boolean func_70090_H();

    @Shadow
    public abstract boolean func_70115_ae();

    @Shadow
    protected abstract void func_70081_e(int var1);

    @Shadow
    public abstract boolean func_70026_G();

    @Shadow
    public abstract void func_85029_a(CrashReportCategory var1);

    @Shadow
    protected abstract void func_145775_I();

    @Shadow
    protected abstract void func_180429_a(BlockPos var1, Block var2);

    @Shadow
    protected abstract Vec3 func_174806_f(float var1, float var2);

    @Shadow
    public abstract UUID func_110124_au();

    @Shadow
    public abstract boolean func_70093_af();

    @Shadow
    public abstract boolean func_70055_a(Material var1);

    public int getNextStepDistance() {
        return this.field_70150_b;
    }

    public void setNextStepDistance(int nextStepDistance) {
        this.field_70150_b = nextStepDistance;
    }

    public int getFire() {
        return this.field_70151_c;
    }

    @Shadow
    public abstract void func_70015_d(int var1);

    @Shadow
    public abstract float func_70047_e();

    @Shadow
    public abstract Vec3 func_70676_i(float var1);

    @Inject(method={"getCollisionBorderSize"}, at={@At(value="HEAD")}, cancellable=true)
    private void getCollisionBorderSize(CallbackInfoReturnable<Float> callbackInfoReturnable) {
        HitBox hitBoxes = Objects.requireNonNull(Client.moduleManager.getModule(HitBox.class));
        if (hitBoxes.getState() && EntityUtils.isSelected((Entity)this, true)) {
            if (ViaPatcher.INSTANCE.getEntityFix() & !Protocol.versionSlider.getSliderVersion().getName().equals("1.8.x")) {
                callbackInfoReturnable.setReturnValue(hitBoxes.getSizeValue().get());
            } else {
                callbackInfoReturnable.setReturnValue((Object)Float.valueOf(0.1f + ((Float)hitBoxes.getSizeValue().get()).floatValue()));
            }
        } else if (ViaPatcher.INSTANCE.getEntityFix() & !Protocol.versionSlider.getSliderVersion().getName().equals("1.8.x")) {
            callbackInfoReturnable.setReturnValue((Object)Float.valueOf(0.0f));
        }
    }

    @Inject(method={"setAngles"}, at={@At(value="HEAD")}, cancellable=true)
    private void setAngles(float yaw, float pitch, CallbackInfo callbackInfo) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(InfinitePitch.class)).getState()) {
            callbackInfo.cancel();
            float f = this.field_70125_A;
            float f1 = this.field_70177_z;
            this.field_70177_z = (float)((double)this.field_70177_z + (double)yaw * 0.15);
            this.field_70125_A = (float)((double)this.field_70125_A - (double)pitch * 0.15);
            this.field_70127_C += this.field_70125_A - f;
            this.field_70126_B += this.field_70177_z - f1;
        }
    }

    @Inject(method={"moveFlying"}, at={@At(value="HEAD")}, cancellable=true)
    private void handleRotations(float strafe, float forward, float friction, CallbackInfo callbackInfo) {
        if (this != Minecraft.func_71410_x().field_71439_g) {
            return;
        }
        StrafeEvent strafeEvent = new StrafeEvent(strafe, forward, friction);
        Client.eventManager.callEvent(strafeEvent);
        if (strafeEvent.isCancelled()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"isInWater"}, at={@At(value="HEAD")}, cancellable=true)
    private void isInWater(CallbackInfoReturnable<Boolean> cir) {
        AntiWaterPush antiWaterPush = Objects.requireNonNull(Client.moduleManager.getModule(AntiWaterPush.class));
        Flight flight = Objects.requireNonNull(Client.moduleManager.getModule(Flight.class));
        if (antiWaterPush.getState() && ((Boolean)antiWaterPush.getWaterValue().get()).booleanValue()) {
            cir.setReturnValue((Object)false);
            return;
        }
        if (flight.getState() && ((String)flight.modeValue.get()).contains("Water")) {
            cir.setReturnValue((Object)true);
        }
    }

    @Inject(method={"isInLava"}, at={@At(value="HEAD")}, cancellable=true)
    private void isInLava(CallbackInfoReturnable<Boolean> cir) {
        AntiWaterPush antiWaterPush = Objects.requireNonNull(Client.moduleManager.getModule(AntiWaterPush.class));
        if (antiWaterPush.getState() && ((Boolean)antiWaterPush.getLavaValue().get()).booleanValue()) {
            cir.setReturnValue((Object)false);
        }
    }

    @Redirect(method={"getBrightnessForRender"}, at=@At(value="INVOKE", target="Lnet/minecraft/world/World;isBlockLoaded(Lnet/minecraft/util/BlockPos;)Z"))
    public boolean alwaysReturnTrue(World world, BlockPos pos) {
        return true;
    }

    @Inject(method={"spawnRunningParticles"}, at={@At(value="HEAD")}, cancellable=true)
    private void checkGroundState(CallbackInfo ci) {
        if (!this.field_70122_E) {
            ci.cancel();
        }
    }

    @Overwrite(remap=false)
    public boolean hasCapability(Capability<?> capability, EnumFacing direction) {
        return this.capabilities != null && this.capabilities.hasCapability(capability, direction);
    }
}

