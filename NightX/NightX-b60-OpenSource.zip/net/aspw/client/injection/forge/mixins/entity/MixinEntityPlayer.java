/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.InventoryPlayer
 *  net.minecraft.entity.player.PlayerCapabilities
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.FoodStats
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.entity;

import com.mojang.authlib.GameProfile;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.movement.LongJump;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.player.BowLongJump;
import net.aspw.client.injection.forge.mixins.entity.MixinEntityLivingBase;
import net.aspw.client.util.CooldownHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.ItemStack;
import net.minecraft.util.FoodStats;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={EntityPlayer.class})
public abstract class MixinEntityPlayer
extends MixinEntityLivingBase {
    @Shadow
    public PlayerCapabilities field_71075_bZ;
    @Shadow
    protected int field_71101_bC;
    @Shadow
    public float eyeHeight = this.getDefaultEyeHeight();
    @Shadow
    public InventoryPlayer field_71071_by;
    private ItemStack cooldownStack;
    private int cooldownStackSlot;

    @Override
    @Shadow
    public abstract ItemStack func_70694_bm();

    @Shadow
    public abstract GameProfile func_146103_bH();

    @Shadow
    protected abstract boolean func_70041_e_();

    @Shadow
    protected abstract String func_145776_H();

    @Shadow
    public abstract FoodStats func_71024_bL();

    @Shadow
    public abstract int func_71057_bx();

    @Shadow
    public abstract ItemStack func_71011_bu();

    @Shadow
    public abstract boolean func_71039_bw();

    @Shadow
    public abstract boolean func_70608_bn();

    @Shadow
    public abstract float getDefaultEyeHeight();

    @Override
    @Overwrite
    public float func_70047_e() {
        Minecraft mc = Minecraft.func_71410_x();
        LongJump longJump = Objects.requireNonNull(Client.moduleManager.getModule(LongJump.class));
        Flight flight = Objects.requireNonNull(Client.moduleManager.getModule(Flight.class));
        Speed speed2 = Objects.requireNonNull(Client.moduleManager.getModule(Speed.class));
        BowLongJump bowLongJump = Objects.requireNonNull(Client.moduleManager.getModule(BowLongJump.class));
        if (longJump.getState() && ((Boolean)longJump.getFakeYValue().get()).booleanValue()) {
            float f2 = 1.62f;
            double y = longJump.getY();
            f2 = (float)((double)1.62f - (mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * (double)mc.field_71428_T.field_74281_c - y));
            return f2;
        }
        if (flight.getState() && ((Boolean)flight.getFakeYValue().get()).booleanValue()) {
            float f2 = 1.62f;
            double y = flight.getY();
            f2 = (float)((double)1.62f - (mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * (double)mc.field_71428_T.field_74281_c - y));
            return f2;
        }
        if (speed2.getState() && ((Boolean)speed2.getFakeYValue().get()).booleanValue()) {
            float f2 = 1.62f;
            double y = speed2.getY();
            f2 = (float)((double)1.62f - (mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * (double)mc.field_71428_T.field_74281_c - y));
            return f2;
        }
        if (bowLongJump.getState() && ((Boolean)bowLongJump.getFakeYValue().get()).booleanValue()) {
            float f2 = 1.62f;
            double y = bowLongJump.getY();
            f2 = (float)((double)1.62f - (mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * (double)mc.field_71428_T.field_74281_c - y));
            return f2;
        }
        float f = this.eyeHeight;
        if (this.func_70608_bn()) {
            f = 0.2f;
        }
        if (this.func_70093_af()) {
            f -= 0.08f;
        }
        return f;
    }

    @Inject(method={"onUpdate"}, at={@At(value="RETURN")})
    private void injectCooldown(CallbackInfo callbackInfo) {
        if (this.func_146103_bH() == Minecraft.func_71410_x().field_71439_g.func_146103_bH()) {
            CooldownHelper.INSTANCE.incrementLastAttackedTicks();
            CooldownHelper.INSTANCE.updateGenericAttackSpeed(this.func_70694_bm());
            if (this.cooldownStackSlot != this.field_71071_by.field_70461_c || !ItemStack.func_77989_b((ItemStack)this.cooldownStack, (ItemStack)this.func_70694_bm())) {
                CooldownHelper.INSTANCE.resetLastAttackedTicks();
            }
            this.cooldownStack = this.func_70694_bm();
            this.cooldownStackSlot = this.field_71071_by.field_70461_c;
        }
    }
}

