/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.util.Vec3
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.block;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.exploit.LiquidInteract;
import net.aspw.client.features.module.impl.movement.NoSlow;
import net.minecraft.block.BlockLiquid;
import net.minecraft.util.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={BlockLiquid.class})
public class MixinBlockLiquid {
    @Inject(method={"canCollideCheck"}, at={@At(value="HEAD")}, cancellable=true)
    private void onCollideCheck(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        LiquidInteract liquidInteract = Objects.requireNonNull(Client.moduleManager.getModule(LiquidInteract.class));
        if (liquidInteract.getState()) {
            callbackInfoReturnable.setReturnValue((Object)true);
        }
    }

    @Inject(method={"modifyAcceleration"}, at={@At(value="HEAD")}, cancellable=true)
    private void onModifyAcceleration(CallbackInfoReturnable<Vec3> callbackInfoReturnable) {
        NoSlow noSlow = Objects.requireNonNull(Client.moduleManager.getModule(NoSlow.class));
        if (noSlow.getState() && ((Boolean)noSlow.getLiquidPushValue().get()).booleanValue()) {
            callbackInfoReturnable.setReturnValue((Object)new Vec3(0.0, 0.0, 0.0));
        }
    }
}

