/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher
 *  net.minecraft.tileentity.TileEntity
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.XRay;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.tileentity.TileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={TileEntityRendererDispatcher.class})
public class MixinTileEntityRendererDispatcher {
    @Inject(method={"renderTileEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderTileEntity(TileEntity tileentityIn, float partialTicks, int destroyStage, CallbackInfo callbackInfo) {
        XRay xray = Objects.requireNonNull(Client.moduleManager.getModule(XRay.class));
        if (xray.getState() && !xray.getXrayBlocks().contains(tileentityIn.func_145838_q())) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"renderTileEntity"}, at={@At(value="INVOKE", target="Lnet/minecraft/world/World;getCombinedLight(Lnet/minecraft/util/BlockPos;I)I")})
    private void enableLighting(CallbackInfo ci) {
        RenderHelper.func_74519_b();
    }
}

