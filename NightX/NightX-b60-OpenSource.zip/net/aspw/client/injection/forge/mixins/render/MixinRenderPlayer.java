/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.entity.AbstractClientPlayer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.entity.RenderPlayer
 *  net.minecraft.util.ResourceLocation
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.other.PlayerEdit;
import net.aspw.client.features.module.impl.visual.CustomModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={RenderPlayer.class})
public class MixinRenderPlayer {
    private final ResourceLocation rabbit = new ResourceLocation("client/models/rabbit.png");
    private final ResourceLocation fred = new ResourceLocation("client/models/freddy.png");
    private final ResourceLocation amongus = new ResourceLocation("client/models/amongus.png");

    @Inject(method={"renderLivingAt"}, at={@At(value="HEAD")})
    protected void renderLivingAt(AbstractClientPlayer entityLivingBaseIn, double x, double y, double z, CallbackInfo callbackInfo) {
        PlayerEdit playerEdit = Objects.requireNonNull(Client.moduleManager.getModule(PlayerEdit.class));
        if (playerEdit.getState() & entityLivingBaseIn.equals((Object)Minecraft.func_71410_x().field_71439_g) && ((Boolean)PlayerEdit.editPlayerSizeValue.get()).booleanValue()) {
            GlStateManager.func_179152_a((float)((Float)PlayerEdit.playerSizeValue.get()).floatValue(), (float)((Float)PlayerEdit.playerSizeValue.get()).floatValue(), (float)((Float)PlayerEdit.playerSizeValue.get()).floatValue());
        }
    }

    @Inject(method={"getEntityTexture"}, at={@At(value="HEAD")}, cancellable=true)
    public void getEntityTexture(AbstractClientPlayer entity, CallbackInfoReturnable<ResourceLocation> ci) {
        CustomModel customModel = Objects.requireNonNull(Client.moduleManager.getModule(CustomModel.class));
        if (customModel.getState() && (!((Boolean)customModel.getOnlySelf().get()).booleanValue() || entity == Minecraft.func_71410_x().field_71439_g)) {
            if (((String)customModel.getMode().get()).contains("Rabbit")) {
                ci.setReturnValue((Object)this.rabbit);
            }
            if (((String)customModel.getMode().get()).contains("Freddy")) {
                ci.setReturnValue((Object)this.fred);
            }
            if (((String)customModel.getMode().get()).contains("Amongus")) {
                ci.setReturnValue((Object)this.amongus);
            }
        }
    }
}

