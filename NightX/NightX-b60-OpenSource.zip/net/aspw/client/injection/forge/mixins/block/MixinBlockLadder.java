/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockLadder
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 */
package net.aspw.client.injection.forge.mixins.block;

import net.aspw.client.injection.forge.mixins.block.MixinBlock;
import net.aspw.client.protocol.Protocol;
import net.aspw.client.protocol.ViaPatcher;
import net.minecraft.block.BlockLadder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(value={BlockLadder.class})
public abstract class MixinBlockLadder
extends MixinBlock {
    @ModifyConstant(method={"setBlockBoundsBasedOnState"}, constant={@Constant(floatValue=0.125f)})
    private float ViaVersion_LadderBB(float constant) {
        if (ViaPatcher.INSTANCE.getLadderFix() & !Protocol.versionSlider.getSliderVersion().getName().equals("1.8.x")) {
            return 0.1875f;
        }
        return 0.125f;
    }
}

