/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiOptions
 *  net.minecraft.client.gui.GuiScreen
 *  org.spongepowered.asm.mixin.Mixin
 */
package net.aspw.client.injection.forge.mixins.gui;

import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={GuiOptions.class})
public class MixinGuiOptions
extends GuiScreen {
    public void func_146281_b() {
        this.field_146297_k.field_71474_y.func_74303_b();
    }
}

