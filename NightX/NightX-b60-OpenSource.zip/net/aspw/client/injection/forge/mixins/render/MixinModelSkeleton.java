/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.model.ModelBiped
 *  net.minecraft.client.model.ModelSkeleton
 *  org.spongepowered.asm.mixin.Mixin
 */
package net.aspw.client.injection.forge.mixins.render;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelSkeleton;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={ModelSkeleton.class})
public class MixinModelSkeleton
extends ModelBiped {
    public void func_178718_a(float scale) {
        this.field_178723_h.field_78800_c += 1.0f;
        this.field_178723_h.func_78794_c(scale);
        this.field_178723_h.field_78800_c -= 1.0f;
    }
}

