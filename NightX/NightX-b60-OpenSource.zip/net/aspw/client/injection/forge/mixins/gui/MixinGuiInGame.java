/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiIngame
 *  net.minecraft.client.gui.GuiPlayerTabOverlay
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.scoreboard.ScoreObjective
 *  net.minecraft.util.ResourceLocation
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.gui;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.features.module.impl.visual.AntiBlind;
import net.aspw.client.features.module.impl.visual.Crosshair;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.injection.forge.mixins.gui.MixinGui;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.font.AWTFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={GuiIngame.class})
public abstract class MixinGuiInGame
extends MixinGui {
    @Shadow
    @Final
    protected static ResourceLocation field_110330_c;
    @Final
    @Shadow
    public GuiPlayerTabOverlay field_175196_v;

    @Shadow
    protected abstract void func_175184_a(int var1, int var2, int var3, float var4, EntityPlayer var5);

    @Inject(method={"showCrosshair"}, at={@At(value="HEAD")}, cancellable=true)
    private void injectCrosshair(CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        Crosshair crosshair = Objects.requireNonNull(Client.moduleManager.getModule(Crosshair.class));
        Hud hud = Objects.requireNonNull(Client.moduleManager.getModule(Hud.class));
        if (crosshair.getState() || Minecraft.func_71410_x().field_71474_y.field_74320_O != 0 && ((Boolean)hud.getNof5crossHair().get()).booleanValue()) {
            callbackInfoReturnable.setReturnValue((Object)false);
        }
    }

    @Inject(method={"renderScoreboard"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderScoreboard(ScoreObjective scoreObjective, ScaledResolution scaledResolution, CallbackInfo callbackInfo) {
        AntiBlind antiBlind = Objects.requireNonNull(Client.moduleManager.getModule(AntiBlind.class));
        if (antiBlind.getState() && ((Boolean)antiBlind.getScoreBoard().get()).booleanValue()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"renderBossHealth"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderBossHealth(CallbackInfo callbackInfo) {
        AntiBlind antiBlind = Objects.requireNonNull(Client.moduleManager.getModule(AntiBlind.class));
        if (antiBlind.getState() && ((Boolean)antiBlind.getBossHealth().get()).booleanValue()) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"renderTooltip"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderTooltip(ScaledResolution sr, float partialTicks, CallbackInfo callbackInfo) {
        Hud hud = Objects.requireNonNull(Client.moduleManager.getModule(Hud.class));
        if (Minecraft.func_71410_x().func_175606_aa() instanceof EntityPlayer && hud.getState() && (((Boolean)hud.getBlackHotbarValue().get()).booleanValue() || ((Boolean)hud.getAnimHotbarValue().get()).booleanValue())) {
            Minecraft mc = Minecraft.func_71410_x();
            EntityPlayer entityPlayer = (EntityPlayer)mc.func_175606_aa();
            boolean blackHB = (Boolean)hud.getBlackHotbarValue().get();
            int middleScreen = sr.func_78326_a() / 2;
            float posInv = hud.getAnimPos((float)entityPlayer.field_71071_by.field_70461_c * 20.0f);
            GlStateManager.func_179117_G();
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            mc.func_110434_K().func_110577_a(field_110330_c);
            float f = this.field_73735_i;
            this.field_73735_i = -90.0f;
            GlStateManager.func_179117_G();
            if (blackHB) {
                RenderUtils.originalRoundedRect(middleScreen - 91, sr.func_78328_b() - 2, middleScreen + 91, sr.func_78328_b() - 22, 3.0f, Integer.MIN_VALUE);
                RenderUtils.originalRoundedRect((float)(middleScreen - 91) + posInv, sr.func_78328_b() - 2, (float)(middleScreen - 91) + posInv + 22.0f, sr.func_78328_b() - 22, 3.0f, Integer.MAX_VALUE);
            } else {
                this.func_175174_a((float)middleScreen - 91.0f, sr.func_78328_b() - 22, 0, 0, 182, 22);
                this.func_175174_a((float)middleScreen - 91.0f + posInv - 1.0f, sr.func_78328_b() - 22 - 1, 0, 22, 24, 22);
            }
            this.field_73735_i = f;
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            GlStateManager.func_179091_B();
            GlStateManager.func_179147_l();
            GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
            RenderHelper.func_74520_c();
            for (int j = 0; j < 9; ++j) {
                int k = sr.func_78326_a() / 2 - 90 + j * 20 + 2;
                int l = sr.func_78328_b() - 19 - (blackHB ? 1 : 0);
                this.func_175184_a(j, k, l, partialTicks, entityPlayer);
            }
            RenderHelper.func_74518_a();
            GlStateManager.func_179101_C();
            GlStateManager.func_179084_k();
            GlStateManager.func_179117_G();
            Client.eventManager.callEvent(new Render2DEvent(partialTicks));
            AWTFontRenderer.Companion.garbageCollectionTick();
            callbackInfo.cancel();
        }
    }

    @Inject(method={"renderTooltip"}, at={@At(value="TAIL")})
    private void renderTooltipPost(ScaledResolution sr, float partialTicks, CallbackInfo callbackInfo) {
        Client.eventManager.callEvent(new Render2DEvent(partialTicks));
        AWTFontRenderer.Companion.garbageCollectionTick();
    }

    @Inject(method={"renderPumpkinOverlay"}, at={@At(value="HEAD")}, cancellable=true)
    private void renderPumpkinOverlay(CallbackInfo callbackInfo) {
        AntiBlind antiBlind = Objects.requireNonNull(Client.moduleManager.getModule(AntiBlind.class));
        if (antiBlind.getState() && ((Boolean)antiBlind.getPumpkinEffect().get()).booleanValue()) {
            callbackInfo.cancel();
        }
    }
}

