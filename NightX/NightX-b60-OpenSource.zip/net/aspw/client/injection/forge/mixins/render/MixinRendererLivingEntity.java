/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.model.ModelBase
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  net.minecraft.client.renderer.entity.RendererLivingEntity
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.entity.player.EnumPlayerModelParts
 *  net.minecraft.util.EnumChatFormatting
 *  net.minecraft.util.MathHelper
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 *  org.lwjgl.opengl.GL11
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Overwrite
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package net.aspw.client.injection.forge.mixins.render;

import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.other.PlayerEdit;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.features.module.impl.visual.OptiFinePlus;
import net.aspw.client.features.module.impl.visual.SilentView;
import net.aspw.client.injection.forge.mixins.render.MixinRender;
import net.aspw.client.util.RotationUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={RendererLivingEntity.class})
public abstract class MixinRendererLivingEntity
extends MixinRender {
    @Final
    @Shadow
    private static final Logger field_147923_a = LogManager.getLogger();
    @Shadow
    protected ModelBase field_77045_g;
    @Shadow
    protected boolean field_177098_i = false;

    @Shadow
    protected <T extends EntityLivingBase> float func_77037_a(T p_getDeathMaxRotation_1_) {
        return 90.0f;
    }

    @Shadow
    protected abstract float func_77034_a(float var1, float var2, float var3);

    @Shadow
    protected abstract <T extends EntityLivingBase> boolean func_177090_c(T var1, float var2);

    @Shadow
    protected abstract <T extends EntityLivingBase> boolean func_177088_c(T var1);

    @Shadow
    protected abstract <T extends EntityLivingBase> float func_77040_d(T var1, float var2);

    @Shadow
    protected abstract void func_180565_e();

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_77041_b(T var1, float var2);

    @Shadow
    protected abstract void func_177091_f();

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_77039_a(T var1, double var2, double var4, double var6);

    @Shadow
    protected abstract <T extends EntityLivingBase> float func_77044_a(T var1, float var2);

    @Shadow
    protected abstract <T extends EntityLivingBase> void func_177093_a(T var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8);

    @Overwrite
    protected <T extends EntityLivingBase> void func_77043_a(T p_rotateCorpse_1_, float p_rotateCorpse_2_, float p_rotateCorpse_3_, float p_rotateCorpse_4_) {
        PlayerEdit playerEdit = Objects.requireNonNull(Client.moduleManager.getModule(PlayerEdit.class));
        GlStateManager.func_179114_b((float)(180.0f - p_rotateCorpse_3_), (float)0.0f, (float)1.0f, (float)0.0f);
        if (p_rotateCorpse_1_.field_70725_aQ > 0) {
            float f = ((float)p_rotateCorpse_1_.field_70725_aQ + p_rotateCorpse_4_ - 1.0f) / 20.0f * 1.6f;
            if ((f = MathHelper.func_76129_c((float)f)) > 1.0f) {
                f = 1.0f;
            }
            GlStateManager.func_179114_b((float)(f * this.func_77037_a(p_rotateCorpse_1_)), (float)0.0f, (float)0.0f, (float)1.0f);
        } else {
            String s = EnumChatFormatting.func_110646_a((String)p_rotateCorpse_1_.func_70005_c_());
            if (s != null && ((Boolean)PlayerEdit.rotatePlayer.get()).booleanValue() && p_rotateCorpse_1_.equals((Object)Minecraft.func_71410_x().field_71439_g) && playerEdit.getState() && (!(p_rotateCorpse_1_ instanceof EntityPlayer) || ((EntityPlayer)p_rotateCorpse_1_).func_175148_a(EnumPlayerModelParts.CAPE))) {
                GlStateManager.func_179109_b((float)0.0f, (float)(p_rotateCorpse_1_.field_70131_O + ((Float)PlayerEdit.yPos.get()).floatValue() - 1.8f), (float)0.0f);
                GlStateManager.func_179114_b((float)((Float)PlayerEdit.xRot.get()).floatValue(), (float)0.0f, (float)0.0f, (float)1.0f);
            }
        }
    }

    @Inject(method={"doRender(Lnet/minecraft/entity/EntityLivingBase;DDDFF)V"}, at={@At(value="HEAD")}, cancellable=true)
    private <T extends EntityLivingBase> void injectChamsPre(T entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo callbackInfo) {
        OptiFinePlus optiFinePlus = Objects.requireNonNull(Client.moduleManager.getModule(OptiFinePlus.class));
        if (optiFinePlus.getState() && optiFinePlus.shouldStopRender((Entity)entity)) {
            callbackInfo.cancel();
        }
    }

    @Inject(method={"canRenderName(Lnet/minecraft/entity/EntityLivingBase;)Z"}, at={@At(value="HEAD")}, cancellable=true)
    private <T extends EntityLivingBase> void canRenderName(T entity, CallbackInfoReturnable<Boolean> callbackInfoReturnable) {
        if (Objects.requireNonNull(Client.moduleManager.getModule(Hud.class)).getState() && ((Boolean)Objects.requireNonNull(Client.moduleManager.getModule(Hud.class)).getF5nameTag().get()).booleanValue()) {
            callbackInfoReturnable.setReturnValue((Object)true);
        }
    }

    @Inject(method={"doRender(Lnet/minecraft/entity/EntityLivingBase;DDDFF)V"}, at={@At(value="HEAD")})
    private <T extends EntityLivingBase> void injectFakeBody(T entity, double x, double y, double z, float entityYaw, float partialTicks, CallbackInfo ci) {
        GlStateManager.func_179094_E();
        GlStateManager.func_179129_p();
        this.field_77045_g.field_78095_p = this.func_77040_d(entity, partialTicks);
        this.field_77045_g.field_78093_q = entity.func_70115_ae();
        this.field_77045_g.field_78091_s = entity.func_70631_g_();
        try {
            float renderyaw;
            float renderpitch;
            float f = this.func_77034_a(entity.field_70760_ar, entity.field_70761_aq, partialTicks);
            float f1 = this.func_77034_a(entity.field_70758_at, entity.field_70759_as, partialTicks);
            float f2 = f1 - f;
            if (entity.func_70115_ae() && entity.field_70154_o instanceof EntityLivingBase) {
                EntityLivingBase entitylivingbase = (EntityLivingBase)entity.field_70154_o;
                f = this.func_77034_a(entitylivingbase.field_70760_ar, entitylivingbase.field_70761_aq, partialTicks);
                f2 = f1 - f;
                float f3 = MathHelper.func_76142_g((float)f2);
                if (f3 < -85.0f) {
                    f3 = -85.0f;
                }
                if (f3 >= 85.0f) {
                    f3 = 85.0f;
                }
                f = f1 - f3;
                if (f3 * f3 > 2500.0f) {
                    f += f3 * 0.2f;
                }
            }
            float f7 = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks;
            this.func_77039_a(entity, x, y, z);
            float f8 = this.func_77044_a(entity, partialTicks);
            this.func_77043_a(entity, f8, f, partialTicks);
            GlStateManager.func_179091_B();
            GlStateManager.func_179152_a((float)-1.0f, (float)-1.0f, (float)1.0f);
            this.func_77041_b(entity, partialTicks);
            GlStateManager.func_179109_b((float)0.0f, (float)-1.5078125f, (float)0.0f);
            float f5 = entity.field_70722_aY + (entity.field_70721_aZ - entity.field_70722_aY) * partialTicks;
            float f6 = entity.field_70754_ba - entity.field_70721_aZ * (1.0f - partialTicks);
            if (entity.func_70631_g_()) {
                f6 *= 3.0f;
            }
            if (f5 > 1.0f) {
                f5 = 1.0f;
            }
            GlStateManager.func_179141_d();
            this.field_77045_g.func_78086_a(entity, f6, f5, partialTicks);
            this.field_77045_g.func_78087_a(f6, f5, f8, f2, f7, 0.0625f, entity);
            if (this.field_177098_i) {
                boolean flag1 = this.func_177088_c(entity);
                this.func_77036_a(entity, f6, f5, f8, f2, f7, 0.0625f);
                if (flag1) {
                    this.func_180565_e();
                }
            } else {
                boolean flag = this.func_177090_c(entity, partialTicks);
                this.func_77036_a(entity, f6, f5, f8, f2, f7, 0.0625f);
                if (flag) {
                    this.func_177091_f();
                }
                GlStateManager.func_179132_a((boolean)true);
                if (!(entity instanceof EntityPlayer) || !((EntityPlayer)entity).func_175149_v()) {
                    this.func_177093_a(entity, f6, f5, partialTicks, f8, f2, f7, 0.0625f);
                }
            }
            SilentView rotations = Client.moduleManager.getModule(SilentView.class);
            float f3 = Minecraft.func_71410_x().field_71474_y.field_74320_O != 0 && rotations.getState() && (Boolean)rotations.getSilentValue().get() != false && entity == Minecraft.func_71410_x().field_71439_g ? entity.field_70127_C + ((RotationUtils.serverRotation.getPitch() != 0.0f ? RotationUtils.serverRotation.getPitch() : entity.field_70125_A) - entity.field_70127_C) : (renderpitch = entity.field_70127_C + (entity.field_70125_A - entity.field_70127_C) * partialTicks);
            float f4 = Minecraft.func_71410_x().field_71474_y.field_74320_O != 0 && rotations.getState() && (Boolean)rotations.getSilentValue().get() != false && entity == Minecraft.func_71410_x().field_71439_g ? entity.field_70126_B + ((RotationUtils.serverRotation.getYaw() != 0.0f ? RotationUtils.serverRotation.getYaw() : entity.field_70177_z) - entity.field_70126_B) : (renderyaw = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks);
            if (rotations.getState() && ((Boolean)rotations.getSilentValue().get()).booleanValue() && entity.equals((Object)Minecraft.func_71410_x().field_71439_g) && rotations.shouldRotate()) {
                GL11.glPushMatrix();
                GL11.glPushAttrib((int)1048575);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)3553);
                GL11.glDisable((int)3553);
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glDisable((int)2896);
                GL11.glPolygonMode((int)1032, (int)6914);
                if (Minecraft.func_71410_x().field_71439_g.field_70737_aN > 0) {
                    GL11.glColor4f((float)255.0f, (float)0.0f, (float)0.0f, (float)8.0f);
                } else {
                    GL11.glColor4f((float)255.0f, (float)200.0f, (float)0.0f, (float)8.0f);
                }
                GL11.glRotatef((float)(renderyaw - f), (float)0.0f, (float)0.001f, (float)0.0f);
                this.field_77045_g.func_78088_a((Entity)Minecraft.func_71410_x().field_71439_g, f6, f5, renderpitch, f2, renderpitch, 0.0625f);
                GL11.glEnable((int)2896);
                GL11.glDisable((int)3042);
                GL11.glEnable((int)3553);
                GL11.glEnable((int)2929);
                GL11.glColor3d((double)1.0, (double)1.0, (double)1.0);
                GL11.glPopAttrib();
                GL11.glPopMatrix();
            }
            GlStateManager.func_179101_C();
        }
        catch (Exception exception) {
            field_147923_a.error("Couldn't render entity", (Throwable)exception);
        }
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77476_b);
        GlStateManager.func_179098_w();
        GlStateManager.func_179138_g((int)OpenGlHelper.field_77478_a);
        GlStateManager.func_179089_o();
        GlStateManager.func_179121_F();
        if (!this.field_177098_i) {
            super.doRenders((Entity)entity, x, y, z, entityYaw, partialTicks);
        }
    }

    @Overwrite
    protected <T extends EntityLivingBase> void func_77036_a(T entitylivingbaseIn, float p_77036_2_, float p_77036_3_, float p_77036_4_, float p_77036_5_, float p_77036_6_, float scaleFactor) {
        boolean silent;
        boolean visible = !entitylivingbaseIn.func_82150_aj();
        boolean semiVisible = !visible && !entitylivingbaseIn.func_98034_c((EntityPlayer)Minecraft.func_71410_x().field_71439_g);
        boolean bl = silent = entitylivingbaseIn == Minecraft.func_71410_x().field_71439_g && Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).getState() && (Boolean)Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).getSilentValue().get() != false && Objects.requireNonNull(Client.moduleManager.getModule(SilentView.class)).shouldRotate();
        if (visible || semiVisible || silent) {
            if (!this.func_180548_c(entitylivingbaseIn)) {
                return;
            }
            if (semiVisible) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)0.15f);
                GlStateManager.func_179132_a((boolean)false);
                GlStateManager.func_179147_l();
                GlStateManager.func_179112_b((int)770, (int)771);
                GlStateManager.func_179092_a((int)516, (float)0.003921569f);
            }
            if (silent) {
                GlStateManager.func_179094_E();
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)0.1f);
                GlStateManager.func_179132_a((boolean)false);
                GlStateManager.func_179147_l();
                GlStateManager.func_179112_b((int)770, (int)771);
                GlStateManager.func_179092_a((int)516, (float)0.003921569f);
            }
            this.field_77045_g.func_78088_a(entitylivingbaseIn, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, scaleFactor);
            if (semiVisible) {
                GlStateManager.func_179084_k();
                GlStateManager.func_179092_a((int)516, (float)0.1f);
                GlStateManager.func_179121_F();
                GlStateManager.func_179132_a((boolean)true);
            }
            if (silent) {
                GlStateManager.func_179084_k();
                GlStateManager.func_179092_a((int)516, (float)0.05f);
                GlStateManager.func_179121_F();
                GlStateManager.func_179132_a((boolean)true);
            }
        }
    }
}

