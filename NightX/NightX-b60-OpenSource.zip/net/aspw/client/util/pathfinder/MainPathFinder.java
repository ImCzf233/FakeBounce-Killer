/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockBarrier
 *  net.minecraft.block.BlockBed
 *  net.minecraft.block.BlockCactus
 *  net.minecraft.block.BlockCarpet
 *  net.minecraft.block.BlockChest
 *  net.minecraft.block.BlockEndPortal
 *  net.minecraft.block.BlockEndPortalFrame
 *  net.minecraft.block.BlockEnderChest
 *  net.minecraft.block.BlockFence
 *  net.minecraft.block.BlockGlass
 *  net.minecraft.block.BlockLadder
 *  net.minecraft.block.BlockPane
 *  net.minecraft.block.BlockPistonBase
 *  net.minecraft.block.BlockPistonExtension
 *  net.minecraft.block.BlockPistonMoving
 *  net.minecraft.block.BlockSkull
 *  net.minecraft.block.BlockSlab
 *  net.minecraft.block.BlockStainedGlass
 *  net.minecraft.block.BlockStairs
 *  net.minecraft.block.BlockTrapDoor
 *  net.minecraft.block.BlockWall
 *  net.minecraft.block.BlockWeb
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.Minecraft
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 */
package net.aspw.client.util.pathfinder;

import java.util.ArrayList;
import java.util.Comparator;
import net.aspw.client.util.pathfinder.PathFinder;
import net.aspw.client.util.pathfinder.PathHub;
import net.aspw.client.util.pathfinder.Vec3;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBarrier;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockCactus;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockEndPortal;
import net.minecraft.block.BlockEndPortalFrame;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.block.BlockFence;
import net.minecraft.block.BlockGlass;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.BlockPistonExtension;
import net.minecraft.block.BlockPistonMoving;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockStainedGlass;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.BlockTrapDoor;
import net.minecraft.block.BlockWall;
import net.minecraft.block.BlockWeb;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;

public class MainPathFinder {
    private final Vec3 startVec3;
    private final Vec3 endVec3;
    private ArrayList<Vec3> path = new ArrayList();
    private final ArrayList<PathHub> pathHubs = new ArrayList();
    private final ArrayList<PathHub> workingPathHubList = new ArrayList();
    private static final Vec3[] directions = new Vec3[]{new Vec3(1.0, 0.0, 0.0), new Vec3(-1.0, 0.0, 0.0), new Vec3(0.0, 0.0, 1.0), new Vec3(0.0, 0.0, -1.0)};

    public MainPathFinder(Vec3 startVec3, Vec3 endVec3) {
        this.startVec3 = startVec3.addVector(0.0, 0.0, 0.0).floor();
        this.endVec3 = endVec3.addVector(0.0, 0.0, 0.0).floor();
    }

    public ArrayList<Vec3> getPath() {
        return this.path;
    }

    public void compute(int loops, int depth) {
        this.path.clear();
        this.workingPathHubList.clear();
        ArrayList<Vec3> initPath = new ArrayList<Vec3>();
        initPath.add(this.startVec3);
        this.workingPathHubList.add(new PathHub(this.startVec3, null, initPath, this.startVec3.squareDistanceTo(this.endVec3), 0.0, 0.0));
        block0: for (int i = 0; i < loops; ++i) {
            this.workingPathHubList.sort(new CompareHub());
            int j = 0;
            if (this.workingPathHubList.size() == 0) break;
            for (PathHub pathHub : new ArrayList<PathHub>(this.workingPathHubList)) {
                Vec3 loc2;
                if (++j > depth) continue block0;
                this.workingPathHubList.remove(pathHub);
                this.pathHubs.add(pathHub);
                for (Vec3 direction : directions) {
                    Vec3 loc = pathHub.getLoc().add(direction).floor();
                    if (MainPathFinder.isValid(loc, false) && this.putHub(pathHub, loc, 0.0)) break block0;
                }
                Vec3 loc1 = pathHub.getLoc().addVector(0.0, 1.0, 0.0).floor();
                if ((!MainPathFinder.isValid(loc1, false) || !this.putHub(pathHub, loc1, 0.0)) && (!MainPathFinder.isValid(loc2 = pathHub.getLoc().addVector(0.0, -1.0, 0.0).floor(), false) || !this.putHub(pathHub, loc2, 0.0))) continue;
                break block0;
            }
        }
        this.pathHubs.sort(new CompareHub());
        this.path = this.pathHubs.get(0).getPathway();
    }

    public static boolean isValid(Vec3 loc, boolean checkGround) {
        return MainPathFinder.isValid((int)loc.getX(), (int)loc.getY(), (int)loc.getZ(), checkGround);
    }

    public static boolean isValid(int x, int y, int z, boolean checkGround) {
        BlockPos block1 = new BlockPos(x, y, z);
        BlockPos block2 = new BlockPos(x, y + 1, z);
        BlockPos block3 = new BlockPos(x, y - 1, z);
        return !MainPathFinder.isNotPassable(block1) && !MainPathFinder.isNotPassable(block2) && (MainPathFinder.isNotPassable(block3) || !checkGround) && MainPathFinder.canWalkOn(block3);
    }

    private static boolean isNotPassable(BlockPos block) {
        Block b = Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(block.func_177958_n(), block.func_177956_o(), block.func_177952_p())).func_177230_c();
        return b.func_149730_j() || b instanceof BlockSlab || b instanceof BlockStairs || b instanceof BlockCactus || b instanceof BlockChest || b instanceof BlockEnderChest || b instanceof BlockSkull || b instanceof BlockPane || b instanceof BlockFence || b instanceof BlockWall || b instanceof BlockGlass || b instanceof BlockPistonBase || b instanceof BlockPistonExtension || b instanceof BlockPistonMoving || b instanceof BlockStainedGlass || b instanceof BlockTrapDoor || b instanceof BlockEndPortalFrame || b instanceof BlockEndPortal || b instanceof BlockBed || b instanceof BlockWeb || b instanceof BlockBarrier || b instanceof BlockLadder || b instanceof BlockCarpet;
    }

    private static boolean canWalkOn(BlockPos block) {
        return !(Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(block.func_177958_n(), block.func_177956_o(), block.func_177952_p())).func_177230_c() instanceof BlockFence) && !(Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(block.func_177958_n(), block.func_177956_o(), block.func_177952_p())).func_177230_c() instanceof BlockWall);
    }

    public PathHub doesHubExistAt(Vec3 loc) {
        for (PathHub pathHub : this.pathHubs) {
            if (pathHub.getLoc().getX() != loc.getX() || pathHub.getLoc().getY() != loc.getY() || pathHub.getLoc().getZ() != loc.getZ()) continue;
            return pathHub;
        }
        for (PathHub pathHub : this.workingPathHubList) {
            if (pathHub.getLoc().getX() != loc.getX() || pathHub.getLoc().getY() != loc.getY() || pathHub.getLoc().getZ() != loc.getZ()) continue;
            return pathHub;
        }
        return null;
    }

    public boolean putHub(PathHub parent, Vec3 loc, double cost) {
        PathHub existingPathHub = this.doesHubExistAt(loc);
        double totalCost = cost;
        if (parent != null) {
            totalCost += parent.getMaxCost();
        }
        if (existingPathHub == null) {
            double minDistanceSquared = 9.5;
            if (loc.getX() == this.endVec3.getX() && loc.getY() == this.endVec3.getY() && loc.getZ() == this.endVec3.getZ() || loc.squareDistanceTo(this.endVec3) <= 9.5) {
                this.path.clear();
                this.path = parent.getPathway();
                this.path.add(loc);
                return true;
            }
            ArrayList<Vec3> path = new ArrayList<Vec3>(parent.getPathway());
            path.add(loc);
            this.workingPathHubList.add(new PathHub(loc, parent, path, loc.squareDistanceTo(this.endVec3), cost, totalCost));
        } else if (existingPathHub.getCurrentCost() > cost) {
            ArrayList<Vec3> path = new ArrayList<Vec3>(parent.getPathway());
            path.add(loc);
            existingPathHub.setLoc(loc);
            existingPathHub.setParentPathHub(parent);
            existingPathHub.setPathway(path);
            existingPathHub.setSqDist(loc.squareDistanceTo(this.endVec3));
            existingPathHub.setCurrentCost(cost);
            existingPathHub.setMaxCost(totalCost);
        }
        return false;
    }

    public static boolean canPassThrough(BlockPos pos) {
        Block block = Minecraft.func_71410_x().field_71441_e.func_180495_p(new BlockPos(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p())).func_177230_c();
        return block.func_149688_o() == Material.field_151579_a || block.func_149688_o() == Material.field_151585_k || block.func_149688_o() == Material.field_151582_l || block == Blocks.field_150468_ap || block == Blocks.field_150355_j || block == Blocks.field_150358_i || block == Blocks.field_150444_as || block == Blocks.field_150472_an;
    }

    public static ArrayList<Vec3> computePath(Vec3 topFrom, Vec3 to) {
        if (!MainPathFinder.canPassThrough(new BlockPos(topFrom.mc()))) {
            topFrom = topFrom.addVector(0.0, 1.0, 0.0);
        }
        PathFinder pathfinder = new PathFinder(topFrom, to);
        pathfinder.compute();
        int i = 0;
        Vec3 lastLoc = null;
        Vec3 lastDashLoc = null;
        ArrayList<Vec3> path = new ArrayList<Vec3>();
        ArrayList<Vec3> pathFinderPath = pathfinder.getPath();
        for (Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0.0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 25.0) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    int x = (int)smallX;
                    block1: while ((double)x <= bigX) {
                        int y2 = (int)smallY;
                        while ((double)y2 <= bigY) {
                            int z = (int)smallZ;
                            while ((double)z <= bigZ) {
                                if (!MainPathFinder.isValid(x, y2, z, false)) {
                                    canContinue = false;
                                    break block1;
                                }
                                ++z;
                            }
                            ++y2;
                        }
                        ++x;
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            ++i;
        }
        return path;
    }

    public static class CompareHub
    implements Comparator<PathHub> {
        @Override
        public int compare(PathHub o1, PathHub o2) {
            return (int)(o1.getSqDist() + o1.getMaxCost() - (o2.getSqDist() + o2.getMaxCost()));
        }
    }
}

