/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 */
package net.aspw.client.util.render;

import kotlin.jvm.JvmStatic;

public final class EaseUtils {
    public static final EaseUtils INSTANCE = new EaseUtils();

    private EaseUtils() {
    }

    @JvmStatic
    public static final double easeOutQuart(double x) {
        return 1.0 - Math.pow(1.0 - x, 4);
    }

    @JvmStatic
    public static final double easeOutBack(double x) {
        double c1 = 1.70158;
        double c3 = c1 + 1.0;
        return 1.0 + c3 * Math.pow(x - 1.0, 3) + c1 * Math.pow(x - 1.0, 2);
    }
}

