/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Charsets
 *  kotlin.text.StringsKt
 *  net.minecraft.util.Session
 */
package net.aspw.client.util.login;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Base64;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.login.UserUtils;
import net.minecraft.util.Session;

public final class LoginUtils
extends MinecraftInstance {
    public static final LoginUtils INSTANCE = new LoginUtils();

    private LoginUtils() {
    }

    @JvmStatic
    public static final LoginResult loginSessionId(String sessionId) {
        JsonObject e2;
        Object object;
        Intrinsics.checkNotNullParameter((Object)sessionId, (String)"sessionId");
        try {
            String[] stringArray = new String[]{"."};
            object = Base64.getDecoder().decode((String)StringsKt.split$default((CharSequence)sessionId, (String[])stringArray, (boolean)false, (int)0, (int)6, null).get(1));
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDecoder().decode(sessionId.split(\".\")[1])");
            object = new String((byte[])object, Charsets.UTF_8);
        }
        catch (Exception e2) {
            return LoginResult.FAILED_PARSE_TOKEN;
        }
        Object decodedSessionData = object;
        try {
            e2 = new JsonParser().parse((String)decodedSessionData).getAsJsonObject();
        }
        catch (Exception e3) {
            return LoginResult.FAILED_PARSE_TOKEN;
        }
        JsonObject sessionObject = e2;
        String uuid = sessionObject.get("spr").getAsString();
        String accessToken = sessionObject.get("yggt").getAsString();
        Intrinsics.checkNotNullExpressionValue((Object)accessToken, (String)"accessToken");
        if (!UserUtils.INSTANCE.isValidToken(accessToken)) {
            return LoginResult.INVALID_ACCOUNT_DATA;
        }
        Intrinsics.checkNotNullExpressionValue((Object)uuid, (String)"uuid");
        String string = UserUtils.INSTANCE.getUsername(uuid);
        if (string == null) {
            return LoginResult.INVALID_ACCOUNT_DATA;
        }
        String username = string;
        MinecraftInstance.mc.field_71449_j = new Session(username, uuid, accessToken, "mojang");
        Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
        return LoginResult.LOGGED;
    }

    public static final class LoginResult
    extends Enum<LoginResult> {
        public static final /* enum */ LoginResult INVALID_ACCOUNT_DATA = new LoginResult();
        public static final /* enum */ LoginResult LOGGED = new LoginResult();
        public static final /* enum */ LoginResult FAILED_PARSE_TOKEN = new LoginResult();
        private static final /* synthetic */ LoginResult[] $VALUES;

        public static LoginResult[] values() {
            return (LoginResult[])$VALUES.clone();
        }

        public static LoginResult valueOf(String value) {
            return Enum.valueOf(LoginResult.class, value);
        }

        static {
            $VALUES = loginResultArray = new LoginResult[]{LoginResult.INVALID_ACCOUNT_DATA, LoginResult.LOGGED, LoginResult.FAILED_PARSE_TOKEN};
        }
    }
}

