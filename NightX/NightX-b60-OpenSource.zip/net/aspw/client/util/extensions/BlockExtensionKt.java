/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.util.extensions;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.block.BlockUtils;
import net.minecraft.block.Block;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

public final class BlockExtensionKt {
    public static final Block getBlock(BlockPos $this$getBlock) {
        Intrinsics.checkNotNullParameter((Object)$this$getBlock, (String)"<this>");
        return BlockUtils.getBlock($this$getBlock);
    }

    public static final Vec3 getVec(BlockPos $this$getVec) {
        Intrinsics.checkNotNullParameter((Object)$this$getVec, (String)"<this>");
        return new Vec3((double)$this$getVec.func_177958_n() + 0.5, (double)$this$getVec.func_177956_o() + 0.5, (double)$this$getVec.func_177952_p() + 0.5);
    }
}

