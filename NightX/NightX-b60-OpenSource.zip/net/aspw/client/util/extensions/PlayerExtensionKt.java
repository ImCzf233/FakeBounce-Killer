/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.util.extensions;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.Rotation;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.Vec3;

public final class PlayerExtensionKt {
    public static final double getDistanceToEntityBox(Entity $this$getDistanceToEntityBox, Entity entity) {
        Intrinsics.checkNotNullParameter((Object)$this$getDistanceToEntityBox, (String)"<this>");
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        return PlayerExtensionKt.getEyes($this$getDistanceToEntityBox).func_72438_d(PlayerExtensionKt.getNearestPointBB(PlayerExtensionKt.getEyes($this$getDistanceToEntityBox), PlayerExtensionKt.getHitBox(entity)));
    }

    public static final Vec3 getNearestPointBB(Vec3 eye, AxisAlignedBB box) {
        Intrinsics.checkNotNullParameter((Object)eye, (String)"eye");
        Intrinsics.checkNotNullParameter((Object)box, (String)"box");
        double[] dArray = new double[]{eye.field_72450_a, eye.field_72448_b, eye.field_72449_c};
        double[] origin = dArray;
        double[] dArray2 = new double[]{box.field_72340_a, box.field_72338_b, box.field_72339_c};
        double[] destMins = dArray2;
        double[] dArray3 = new double[]{box.field_72336_d, box.field_72337_e, box.field_72334_f};
        double[] destMaxs = dArray3;
        int n = 0;
        while (n < 3) {
            int i;
            if (origin[i = n++] > destMaxs[i]) {
                origin[i] = destMaxs[i];
                continue;
            }
            if (!(origin[i] < destMins[i])) continue;
            origin[i] = destMins[i];
        }
        return new Vec3(origin[0], origin[1], origin[2]);
    }

    public static final AxisAlignedBB getHitBox(Entity $this$hitBox) {
        Intrinsics.checkNotNullParameter((Object)$this$hitBox, (String)"<this>");
        double borderSize = $this$hitBox.func_70111_Y();
        AxisAlignedBB axisAlignedBB = $this$hitBox.func_174813_aQ().func_72314_b(borderSize, borderSize, borderSize);
        Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"entityBoundingBox.expand\u2026, borderSize, borderSize)");
        return axisAlignedBB;
    }

    public static final Vec3 getEyes(Entity $this$eyes) {
        Intrinsics.checkNotNullParameter((Object)$this$eyes, (String)"<this>");
        Vec3 vec3 = $this$eyes.func_174824_e(1.0f);
        Intrinsics.checkNotNullExpressionValue((Object)vec3, (String)"getPositionEyes(1f)");
        return vec3;
    }

    public static final Rotation getRotation(Entity $this$rotation) {
        Intrinsics.checkNotNullParameter((Object)$this$rotation, (String)"<this>");
        return new Rotation($this$rotation.field_70177_z, $this$rotation.field_70125_A);
    }
}

