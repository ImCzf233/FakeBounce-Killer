/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.client.C16PacketClientStatus
 *  net.minecraft.network.play.client.C16PacketClientStatus$EnumState
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 */
package net.aspw.client.util;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.ClickWindowEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public final class InventoryHelper
extends MinecraftInstance
implements Listenable {
    public static final InventoryHelper INSTANCE = new InventoryHelper();
    private static final MSTimer CLICK_TIMER = new MSTimer();
    private static final List<Block> BLOCK_BLACKLIST;

    private InventoryHelper() {
    }

    public final MSTimer getCLICK_TIMER() {
        return CLICK_TIMER;
    }

    public final List<Block> getBLOCK_BLACKLIST() {
        return BLOCK_BLACKLIST;
    }

    public final boolean isBlockListBlock(ItemBlock itemBlock) {
        Intrinsics.checkNotNullParameter((Object)itemBlock, (String)"itemBlock");
        Block block = itemBlock.func_179223_d();
        return BLOCK_BLACKLIST.contains(block) || !block.func_149686_d();
    }

    @EventTarget
    public final void onClickWindow(ClickWindowEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        CLICK_TIMER.reset();
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C08PacketPlayerBlockPlacement) {
            CLICK_TIMER.reset();
        }
    }

    public final void openPacket() {
        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
    }

    public final void closePacket() {
        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0DPacketCloseWindow());
    }

    public final boolean isPositivePotionEffect(int id) {
        return id == Potion.field_76428_l.field_76415_H || id == Potion.field_76424_c.field_76415_H || id == Potion.field_76432_h.field_76415_H || id == Potion.field_76439_r.field_76415_H || id == Potion.field_76430_j.field_76415_H || id == Potion.field_76441_p.field_76415_H || id == Potion.field_76429_m.field_76415_H || id == Potion.field_76427_o.field_76415_H || id == Potion.field_76444_x.field_76415_H || id == Potion.field_76422_e.field_76415_H || id == Potion.field_76420_g.field_76415_H || id == Potion.field_180152_w.field_76415_H || id == Potion.field_76426_n.field_76415_H;
    }

    public final boolean isPositivePotion(ItemPotion item, ItemStack stack) {
        Intrinsics.checkNotNullParameter((Object)item, (String)"item");
        Intrinsics.checkNotNullParameter((Object)stack, (String)"stack");
        List list = item.func_77832_l(stack);
        Intrinsics.checkNotNullExpressionValue((Object)list, (String)"item.getEffects(stack)");
        Iterable $this$forEach$iv = list;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            PotionEffect it = (PotionEffect)element$iv;
            boolean bl = false;
            if (!INSTANCE.isPositivePotionEffect(it.func_76456_a())) continue;
            return true;
        }
        return false;
    }

    @Override
    public boolean handleEvents() {
        return true;
    }

    static {
        Object[] objectArray = new Block[]{Blocks.field_150381_bn, (Block)Blocks.field_150486_ae, Blocks.field_150477_bB, Blocks.field_150447_bR, Blocks.field_150467_bQ, (Block)Blocks.field_150354_m, Blocks.field_150321_G, Blocks.field_150478_aa, Blocks.field_150462_ai, Blocks.field_150460_al, Blocks.field_150392_bi, Blocks.field_150367_z, Blocks.field_150456_au, Blocks.field_150452_aw, Blocks.field_150323_B, Blocks.field_150409_cd, Blocks.field_150335_W, Blocks.field_180393_cK, Blocks.field_180394_cL, Blocks.field_150429_aA, Blocks.field_150351_n, (Block)Blocks.field_150434_aF, Blocks.field_150324_C, Blocks.field_150442_at, Blocks.field_150472_an, Blocks.field_150444_as, Blocks.field_150421_aI, Blocks.field_180407_aO, Blocks.field_180408_aP, Blocks.field_180404_aQ, Blocks.field_180403_aR, Blocks.field_180406_aS, Blocks.field_180390_bo, Blocks.field_180391_bp, Blocks.field_180392_bq, Blocks.field_180386_br, Blocks.field_180385_bs, Blocks.field_150386_bk, Blocks.field_150415_aT, Blocks.field_150440_ba, Blocks.field_150382_bo, (Block)Blocks.field_150383_bp, (Block)Blocks.field_150465_bP, (Block)Blocks.field_150438_bZ, Blocks.field_150404_cg, (Block)Blocks.field_150488_af, Blocks.field_150445_bS, Blocks.field_150443_bT, (Block)Blocks.field_150453_bW};
        BLOCK_BLACKLIST = CollectionsKt.listOf((Object[])objectArray);
    }
}

