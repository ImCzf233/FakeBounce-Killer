/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.jvm.internal.Intrinsics;

public final class RegexUtils {
    public static final RegexUtils INSTANCE = new RegexUtils();

    private RegexUtils() {
    }

    public final String[] match(Matcher matcher) {
        Intrinsics.checkNotNullParameter((Object)matcher, (String)"matcher");
        List result = new ArrayList();
        while (matcher.find()) {
            String string = matcher.group();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"matcher.group()");
            result.add(string);
        }
        Collection $this$toTypedArray$iv = result;
        boolean $i$f$toTypedArray = false;
        Collection thisCollection$iv = $this$toTypedArray$iv;
        String[] stringArray = thisCollection$iv.toArray(new String[0]);
        if (stringArray == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
        }
        return stringArray;
    }

    public final String[] match(String text, Pattern pattern) {
        Intrinsics.checkNotNullParameter((Object)text, (String)"text");
        Intrinsics.checkNotNullParameter((Object)pattern, (String)"pattern");
        Matcher matcher = pattern.matcher(text);
        Intrinsics.checkNotNullExpressionValue((Object)matcher, (String)"pattern.matcher(text)");
        return this.match(matcher);
    }

    public final String[] match(String text, String pattern) {
        Intrinsics.checkNotNullParameter((Object)text, (String)"text");
        Intrinsics.checkNotNullParameter((Object)pattern, (String)"pattern");
        Pattern pattern2 = Pattern.compile(pattern);
        Intrinsics.checkNotNullExpressionValue((Object)pattern2, (String)"compile(pattern)");
        return this.match(text, pattern2);
    }

    public final double round(double value, int places) {
        if (!(places >= 0)) {
            String string = "Failed requirement.";
            throw new IllegalArgumentException(string.toString());
        }
        return BigDecimal.valueOf(value).setScale(places, RoundingMode.HALF_UP).doubleValue();
    }
}

