/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.util.item;

import kotlin.jvm.internal.Intrinsics;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public final class ArmorPart {
    private final ItemStack itemStack;
    private final int slot;
    private final int armorType;

    public ArmorPart(ItemStack itemStack, int slot) {
        Intrinsics.checkNotNullParameter((Object)itemStack, (String)"itemStack");
        this.itemStack = itemStack;
        this.slot = slot;
        Item item = this.itemStack.func_77973_b();
        if (item == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemArmor");
        }
        this.armorType = ((ItemArmor)item).field_77881_a;
    }

    public final ItemStack getItemStack() {
        return this.itemStack;
    }

    public final int getSlot() {
        return this.slot;
    }

    public final int getArmorType() {
        return this.armorType;
    }
}

