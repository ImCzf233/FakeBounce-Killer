/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 *  net.minecraft.nbt.NBTTagCompound
 */
package net.aspw.client.util.item;

import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import net.aspw.client.util.RegexUtils;
import net.aspw.client.util.item.ArmorPart;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;

public final class ItemHelper {
    public static final ItemHelper INSTANCE = new ItemHelper();
    private static final Enchant[] armorDamageReduceEnchantments;
    private static final Enchant[] otherArmorEnchantments;

    private ItemHelper() {
    }

    public final int getEnchantment(ItemStack itemStack, Enchantment enchantment) {
        Intrinsics.checkNotNullParameter((Object)itemStack, (String)"itemStack");
        Intrinsics.checkNotNullParameter((Object)enchantment, (String)"enchantment");
        if (itemStack.func_77986_q() == null || itemStack.func_77986_q().func_82582_d()) {
            return 0;
        }
        int n = 0;
        int n2 = itemStack.func_77986_q().func_74745_c();
        while (n < n2) {
            int i = n++;
            NBTTagCompound tagCompound = itemStack.func_77986_q().func_150305_b(i);
            if ((!tagCompound.func_74764_b("ench") || tagCompound.func_74765_d("ench") != enchantment.field_77352_x) && (!tagCompound.func_74764_b("id") || tagCompound.func_74765_d("id") != enchantment.field_77352_x)) continue;
            return tagCompound.func_74765_d("lvl");
        }
        return 0;
    }

    public final int getEnchantmentCount(ItemStack itemStack) {
        Intrinsics.checkNotNullParameter((Object)itemStack, (String)"itemStack");
        if (itemStack.func_77986_q() == null || itemStack.func_77986_q().func_82582_d()) {
            return 0;
        }
        int c = 0;
        int n = 0;
        int n2 = itemStack.func_77986_q().func_74745_c();
        while (n < n2) {
            int i = n++;
            NBTTagCompound tagCompound = itemStack.func_77986_q().func_150305_b(i);
            if (!tagCompound.func_74764_b("ench") && !tagCompound.func_74764_b("id")) continue;
            int n3 = c;
            c = n3 + 1;
        }
        return c;
    }

    public final double getWeaponEnchantFactor(ItemStack stack, float nbtedPriority, EnumNBTPriorityType goal) {
        Intrinsics.checkNotNullParameter((Object)stack, (String)"stack");
        Intrinsics.checkNotNullParameter((Object)((Object)goal), (String)"goal");
        Enchantment enchantment = Enchantment.field_180314_l;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"sharpness");
        double d = 1.25 * (double)this.getEnchantment(stack, enchantment);
        enchantment = Enchantment.field_77334_n;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"fireAspect");
        return d + 1.0 * (double)this.getEnchantment(stack, enchantment) + (double)(this.hasNBTGoal(stack, goal) ? nbtedPriority : 0.0f);
    }

    public static /* synthetic */ double getWeaponEnchantFactor$default(ItemHelper itemHelper, ItemStack itemStack, float f, EnumNBTPriorityType enumNBTPriorityType, int n, Object object) {
        if ((n & 2) != 0) {
            f = 0.0f;
        }
        if ((n & 4) != 0) {
            enumNBTPriorityType = EnumNBTPriorityType.NONE;
        }
        return itemHelper.getWeaponEnchantFactor(itemStack, f, enumNBTPriorityType);
    }

    public final int compareArmor(ArmorPart o1, ArmorPart o2, float nbtedPriority, EnumNBTPriorityType goal) {
        Intrinsics.checkNotNullParameter((Object)o1, (String)"o1");
        Intrinsics.checkNotNullParameter((Object)o2, (String)"o2");
        Intrinsics.checkNotNullParameter((Object)((Object)goal), (String)"goal");
        int compare = Double.compare(RegexUtils.INSTANCE.round((double)this.getArmorThresholdedDamageReduction(o2.getItemStack()) - (double)(this.hasNBTGoal(o2.getItemStack(), goal) ? nbtedPriority / 5.0f : 0.0f), 3), RegexUtils.INSTANCE.round((double)this.getArmorThresholdedDamageReduction(o1.getItemStack()) - (double)(this.hasNBTGoal(o1.getItemStack(), goal) ? nbtedPriority / 5.0f : 0.0f), 3));
        if (compare == 0) {
            int otherEnchantmentCmp = Double.compare(RegexUtils.INSTANCE.round(this.getArmorEnchantmentThreshold(o1.getItemStack()), 3), RegexUtils.INSTANCE.round(this.getArmorEnchantmentThreshold(o2.getItemStack()), 3));
            if (otherEnchantmentCmp == 0) {
                int enchantmentCountCmp = Intrinsics.compare((int)this.getEnchantmentCount(o1.getItemStack()), (int)this.getEnchantmentCount(o2.getItemStack()));
                if (enchantmentCountCmp != 0) {
                    return enchantmentCountCmp;
                }
                Item item = o1.getItemStack().func_77973_b();
                if (item == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemArmor");
                }
                ItemArmor o1a = (ItemArmor)item;
                Item item2 = o2.getItemStack().func_77973_b();
                if (item2 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemArmor");
                }
                ItemArmor o2a = (ItemArmor)item2;
                int durabilityCmp = Intrinsics.compare((int)o1a.func_82812_d().func_78046_a(o1a.field_77881_a), (int)o2a.func_82812_d().func_78046_a(o2a.field_77881_a));
                return durabilityCmp != 0 ? durabilityCmp : Intrinsics.compare((int)o1a.func_82812_d().func_78045_a(), (int)o2a.func_82812_d().func_78045_a());
            }
            return otherEnchantmentCmp;
        }
        return compare;
    }

    public static /* synthetic */ int compareArmor$default(ItemHelper itemHelper, ArmorPart armorPart, ArmorPart armorPart2, float f, EnumNBTPriorityType enumNBTPriorityType, int n, Object object) {
        if ((n & 4) != 0) {
            f = 0.0f;
        }
        if ((n & 8) != 0) {
            enumNBTPriorityType = EnumNBTPriorityType.NONE;
        }
        return itemHelper.compareArmor(armorPart, armorPart2, f, enumNBTPriorityType);
    }

    private final float getArmorThresholdedDamageReduction(ItemStack itemStack) {
        Item item = itemStack.func_77973_b();
        if (item == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemArmor");
        }
        ItemArmor item2 = (ItemArmor)item;
        return this.getArmorDamageReduction(item2.func_82812_d().func_78044_b(item2.field_77881_a), 0) * (1.0f - this.getArmorThresholdedEnchantmentDamageReduction(itemStack));
    }

    private final float getArmorDamageReduction(int defensePoints, int toughness) {
        return 1.0f - RangesKt.coerceAtMost((float)20.0f, (float)RangesKt.coerceAtLeast((float)((float)defensePoints / 5.0f), (float)((float)defensePoints - 1.0f / ((float)2 + (float)toughness / 4.0f)))) / 25.0f;
    }

    private final float getArmorThresholdedEnchantmentDamageReduction(ItemStack itemStack) {
        float sum = 0.0f;
        int n = 0;
        int n2 = armorDamageReduceEnchantments.length;
        while (n < n2) {
            int i = n++;
            sum += (float)this.getEnchantment(itemStack, armorDamageReduceEnchantments[i].getEnchantment()) * armorDamageReduceEnchantments[i].getFactor();
        }
        return sum;
    }

    private final float getArmorEnchantmentThreshold(ItemStack itemStack) {
        float sum = 0.0f;
        int n = 0;
        int n2 = otherArmorEnchantments.length;
        while (n < n2) {
            int i = n++;
            sum += (float)this.getEnchantment(itemStack, otherArmorEnchantments[i].getEnchantment()) * otherArmorEnchantments[i].getFactor();
        }
        return sum;
    }

    public final boolean hasNBTGoal(ItemStack stack, EnumNBTPriorityType goal) {
        Intrinsics.checkNotNullParameter((Object)stack, (String)"stack");
        Intrinsics.checkNotNullParameter((Object)((Object)goal), (String)"goal");
        if (stack.func_77942_o() && stack.func_77978_p().func_150297_b("display", 10)) {
            NBTTagCompound display = stack.func_77978_p().func_74775_l("display");
            if (goal == EnumNBTPriorityType.HAS_DISPLAY_TAG) {
                return true;
            }
            if (goal == EnumNBTPriorityType.HAS_NAME) {
                return display.func_74764_b("Name");
            }
            if (goal == EnumNBTPriorityType.HAS_LORE) {
                return display.func_74764_b("Lore") && display.func_150295_c("Lore", 8).func_74745_c() > 0;
            }
        }
        return false;
    }

    static {
        Enchant[] enchantArray = new Enchant[4];
        Enchantment enchantment = Enchantment.field_180310_c;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"protection");
        enchantArray[0] = new Enchant(enchantment, 0.06f);
        enchantment = Enchantment.field_180308_g;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"projectileProtection");
        enchantArray[1] = new Enchant(enchantment, 0.032f);
        enchantment = Enchantment.field_77329_d;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"fireProtection");
        enchantArray[2] = new Enchant(enchantment, 0.0585f);
        enchantment = Enchantment.field_77327_f;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"blastProtection");
        enchantArray[3] = new Enchant(enchantment, 0.0304f);
        armorDamageReduceEnchantments = enchantArray;
        enchantArray = new Enchant[5];
        enchantment = Enchantment.field_180309_e;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"featherFalling");
        enchantArray[0] = new Enchant(enchantment, 3.0f);
        enchantment = Enchantment.field_92091_k;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"thorns");
        enchantArray[1] = new Enchant(enchantment, 1.0f);
        enchantment = Enchantment.field_180317_h;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"respiration");
        enchantArray[2] = new Enchant(enchantment, 0.1f);
        enchantment = Enchantment.field_77341_i;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"aquaAffinity");
        enchantArray[3] = new Enchant(enchantment, 0.05f);
        enchantment = Enchantment.field_77347_r;
        Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"unbreaking");
        enchantArray[4] = new Enchant(enchantment, 0.01f);
        otherArmorEnchantments = enchantArray;
    }

    public static final class Enchant {
        private final Enchantment enchantment;
        private final float factor;

        public Enchant(Enchantment enchantment, float factor) {
            Intrinsics.checkNotNullParameter((Object)enchantment, (String)"enchantment");
            this.enchantment = enchantment;
            this.factor = factor;
        }

        public final Enchantment getEnchantment() {
            return this.enchantment;
        }

        public final float getFactor() {
            return this.factor;
        }
    }

    public static final class EnumNBTPriorityType
    extends Enum<EnumNBTPriorityType> {
        public static final /* enum */ EnumNBTPriorityType HAS_NAME = new EnumNBTPriorityType();
        public static final /* enum */ EnumNBTPriorityType HAS_LORE = new EnumNBTPriorityType();
        public static final /* enum */ EnumNBTPriorityType HAS_DISPLAY_TAG = new EnumNBTPriorityType();
        public static final /* enum */ EnumNBTPriorityType NONE = new EnumNBTPriorityType();
        private static final /* synthetic */ EnumNBTPriorityType[] $VALUES;

        public static EnumNBTPriorityType[] values() {
            return (EnumNBTPriorityType[])$VALUES.clone();
        }

        public static EnumNBTPriorityType valueOf(String value) {
            return Enum.valueOf(EnumNBTPriorityType.class, value);
        }

        static {
            $VALUES = enumNBTPriorityTypeArray = new EnumNBTPriorityType[]{EnumNBTPriorityType.HAS_NAME, EnumNBTPriorityType.HAS_LORE, EnumNBTPriorityType.HAS_DISPLAY_TAG, EnumNBTPriorityType.NONE};
        }
    }
}

