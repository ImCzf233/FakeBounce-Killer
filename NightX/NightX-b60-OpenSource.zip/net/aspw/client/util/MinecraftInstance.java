/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 */
package net.aspw.client.util;

import net.minecraft.client.Minecraft;

public class MinecraftInstance {
    public static final Minecraft mc = Minecraft.func_71410_x();
}

