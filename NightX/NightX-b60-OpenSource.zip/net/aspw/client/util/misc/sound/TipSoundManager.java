/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.util.misc.sound;

import java.io.File;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.util.FileUtils;
import net.aspw.client.util.misc.sound.TipSoundPlayer;

public final class TipSoundManager {
    private TipSoundPlayer enableSound;
    private TipSoundPlayer disableSound;
    private TipSoundPlayer popSound;
    private TipSoundPlayer swingSound;
    private TipSoundPlayer hwidSound;

    public TipSoundManager() {
        File enableSoundFile = new File(Client.INSTANCE.getFileManager().soundsDir, "enable.wav");
        File disableSoundFile = new File(Client.INSTANCE.getFileManager().soundsDir, "disable.wav");
        File popSoundFile = new File(Client.INSTANCE.getFileManager().soundsDir, "pop.wav");
        File swingSoundFile = new File(Client.INSTANCE.getFileManager().soundsDir, "swing.wav");
        File hwidSoundFile = new File(Client.INSTANCE.getFileManager().soundsDir, "hwid.wav");
        if (!enableSoundFile.exists()) {
            FileUtils.unpackFile(enableSoundFile, "assets/minecraft/client/sound/enable.wav");
        }
        if (!disableSoundFile.exists()) {
            FileUtils.unpackFile(disableSoundFile, "assets/minecraft/client/sound/disable.wav");
        }
        if (!popSoundFile.exists()) {
            FileUtils.unpackFile(popSoundFile, "assets/minecraft/client/sound/pop.wav");
        }
        if (!swingSoundFile.exists()) {
            FileUtils.unpackFile(swingSoundFile, "assets/minecraft/client/sound/swing.wav");
        }
        if (!hwidSoundFile.exists()) {
            FileUtils.unpackFile(hwidSoundFile, "assets/minecraft/client/sound/hwid.wav");
        }
        this.enableSound = new TipSoundPlayer(enableSoundFile);
        this.disableSound = new TipSoundPlayer(disableSoundFile);
        this.popSound = new TipSoundPlayer(popSoundFile);
        this.swingSound = new TipSoundPlayer(swingSoundFile);
        this.hwidSound = new TipSoundPlayer(hwidSoundFile);
    }

    public final TipSoundPlayer getEnableSound() {
        return this.enableSound;
    }

    public final void setEnableSound(TipSoundPlayer tipSoundPlayer) {
        Intrinsics.checkNotNullParameter((Object)tipSoundPlayer, (String)"<set-?>");
        this.enableSound = tipSoundPlayer;
    }

    public final TipSoundPlayer getDisableSound() {
        return this.disableSound;
    }

    public final void setDisableSound(TipSoundPlayer tipSoundPlayer) {
        Intrinsics.checkNotNullParameter((Object)tipSoundPlayer, (String)"<set-?>");
        this.disableSound = tipSoundPlayer;
    }

    public final TipSoundPlayer getPopSound() {
        return this.popSound;
    }

    public final void setPopSound(TipSoundPlayer tipSoundPlayer) {
        Intrinsics.checkNotNullParameter((Object)tipSoundPlayer, (String)"<set-?>");
        this.popSound = tipSoundPlayer;
    }

    public final TipSoundPlayer getSwingSound() {
        return this.swingSound;
    }

    public final void setSwingSound(TipSoundPlayer tipSoundPlayer) {
        Intrinsics.checkNotNullParameter((Object)tipSoundPlayer, (String)"<set-?>");
        this.swingSound = tipSoundPlayer;
    }

    public final TipSoundPlayer getHwidSound() {
        return this.hwidSound;
    }

    public final void setHwidSound(TipSoundPlayer tipSoundPlayer) {
        Intrinsics.checkNotNullParameter((Object)tipSoundPlayer, (String)"<set-?>");
        this.hwidSound = tipSoundPlayer;
    }
}

