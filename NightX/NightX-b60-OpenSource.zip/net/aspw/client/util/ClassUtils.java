/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.AxisAlignedBB
 */
package net.aspw.client.util;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;

public final class ClassUtils {
    public static final ClassUtils INSTANCE = new ClassUtils();
    private static final Map<String, Boolean> cachedClasses = new LinkedHashMap();

    private ClassUtils() {
    }

    @JvmStatic
    public static final boolean hasClass(String className) {
        boolean bl;
        Intrinsics.checkNotNullParameter((Object)className, (String)"className");
        if (cachedClasses.containsKey(className)) {
            Boolean bl2 = cachedClasses.get(className);
            Intrinsics.checkNotNull((Object)bl2);
            bl = bl2;
        } else {
            boolean bl3;
            try {
                Class.forName(className);
                Map<String, Boolean> map = cachedClasses;
                Boolean bl4 = true;
                map.put(className, bl4);
                bl3 = true;
            }
            catch (ClassNotFoundException e) {
                Map<String, Boolean> map = cachedClasses;
                Boolean bl5 = false;
                map.put(className, bl5);
                bl3 = false;
            }
            bl = bl3;
        }
        return bl;
    }

    public final boolean hasForge() {
        return ClassUtils.hasClass("net.minecraftforge.common.MinecraftForge");
    }

    public final boolean isBlockUnder() {
        if (Minecraft.func_71410_x().field_71439_g.field_70163_u < 0.0) {
            return false;
        }
        for (int off = 0; off < (int)Minecraft.func_71410_x().field_71439_g.field_70163_u + 2; off += 2) {
            Object object = Minecraft.func_71410_x().field_71439_g.func_174813_aQ().func_72317_d(0.0, -((double)off), 0.0);
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getMinecraft().thePlayer\u2026.0, -off.toDouble(), 0.0)");
            AxisAlignedBB bb = object;
            object = Minecraft.func_71410_x().field_71441_e.func_72945_a((Entity)Minecraft.func_71410_x().field_71439_g, bb);
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getMinecraft().theWorld.\u2026     bb\n                )");
            if (!(!((Collection)object).isEmpty())) continue;
            return true;
        }
        return false;
    }
}

