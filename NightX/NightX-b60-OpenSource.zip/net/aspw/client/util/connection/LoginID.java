/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.util.connection;

import kotlin.jvm.internal.Intrinsics;

public final class LoginID {
    public static final LoginID INSTANCE = new LoginID();
    private static String id = "";
    private static String password = "";
    private static String uid = "";
    private static String hwid = "";
    private static String currentHWID = "";
    private static boolean loggedIn;
    private static boolean isPremium;

    private LoginID() {
    }

    public final String getId() {
        return id;
    }

    public final void setId(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        id = string;
    }

    public final String getPassword() {
        return password;
    }

    public final void setPassword(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        password = string;
    }

    public final String getUid() {
        return uid;
    }

    public final void setUid(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        uid = string;
    }

    public final String getHwid() {
        return hwid;
    }

    public final void setHwid(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        hwid = string;
    }

    public final String getCurrentHWID() {
        return currentHWID;
    }

    public final void setCurrentHWID(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        currentHWID = string;
    }

    public final boolean getLoggedIn() {
        return loggedIn;
    }

    public final void setLoggedIn(boolean bl) {
        loggedIn = bl;
    }

    public final boolean isPremium() {
        return isPremium;
    }

    public final void setPremium(boolean bl) {
        isPremium = bl;
    }
}

