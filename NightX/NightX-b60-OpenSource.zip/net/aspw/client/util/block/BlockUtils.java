/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.util.block;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public final class BlockUtils
extends MinecraftInstance {
    public static final BlockUtils INSTANCE = new BlockUtils();

    private BlockUtils() {
    }

    @JvmStatic
    public static final Block getBlock(@Nullable BlockPos blockPos) {
        Object object;
        WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
        if (worldClient == null) {
            object = null;
        } else {
            IBlockState iBlockState = worldClient.func_180495_p(blockPos);
            object = iBlockState == null ? null : iBlockState.func_177230_c();
        }
        return object;
    }

    @JvmStatic
    public static final Material getMaterial(@Nullable BlockPos blockPos) {
        Block block = BlockUtils.getBlock(blockPos);
        return block == null ? null : block.func_149688_o();
    }

    @JvmStatic
    public static final boolean isReplaceable(@Nullable BlockPos blockPos) {
        boolean bl;
        Material material = BlockUtils.getMaterial(blockPos);
        return material == null ? false : (bl = material.func_76222_j());
    }

    @JvmStatic
    public static final IBlockState getState(@Nullable BlockPos blockPos) {
        IBlockState iBlockState = MinecraftInstance.mc.field_71441_e.func_180495_p(blockPos);
        Intrinsics.checkNotNullExpressionValue((Object)iBlockState, (String)"mc.theWorld.getBlockState(blockPos)");
        return iBlockState;
    }

    @JvmStatic
    public static final boolean canBeClicked(@Nullable BlockPos blockPos) {
        boolean bl;
        Block block = BlockUtils.getBlock(blockPos);
        boolean bl2 = block == null ? false : (bl = block.func_176209_a(BlockUtils.getState(blockPos), false));
        return bl2 && MinecraftInstance.mc.field_71441_e.func_175723_af().func_177746_a(blockPos);
    }

    @JvmStatic
    public static final String getBlockName(int id) {
        String string = Block.func_149729_e((int)id).func_149732_F();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"getBlockById(id).localizedName");
        return string;
    }

    @JvmStatic
    public static final boolean isFullBlock(@Nullable BlockPos blockPos) {
        AxisAlignedBB axisAlignedBB;
        Block block = BlockUtils.getBlock(blockPos);
        AxisAlignedBB axisAlignedBB2 = block == null ? null : (axisAlignedBB = block.func_180640_a((World)MinecraftInstance.mc.field_71441_e, blockPos, BlockUtils.getState(blockPos)));
        if (axisAlignedBB == null) {
            return false;
        }
        AxisAlignedBB axisAlignedBB3 = axisAlignedBB;
        return axisAlignedBB3.field_72336_d - axisAlignedBB3.field_72340_a == 1.0 && axisAlignedBB3.field_72337_e - axisAlignedBB3.field_72338_b == 1.0 && axisAlignedBB3.field_72334_f - axisAlignedBB3.field_72339_c == 1.0;
    }

    @JvmStatic
    public static final double getCenterDistance(BlockPos blockPos) {
        Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
        return MinecraftInstance.mc.field_71439_g.func_70011_f((double)blockPos.func_177958_n() + 0.5, (double)blockPos.func_177956_o() + 0.5, (double)blockPos.func_177952_p() + 0.5);
    }

    @JvmStatic
    public static final Map<BlockPos, Block> searchBlocks(int radius) {
        Map blocks = new LinkedHashMap();
        int n = -radius + 1;
        int n2 = radius;
        if (n <= n2) {
            int x;
            do {
                int y;
                x = n2--;
                int n3 = -radius + 1;
                int n4 = radius;
                if (n3 > n4) continue;
                do {
                    int z;
                    y = n4--;
                    int n5 = -radius + 1;
                    int n6 = radius;
                    if (n5 > n6) continue;
                    do {
                        Block block;
                        z = n6--;
                        BlockPos blockPos = new BlockPos((int)MinecraftInstance.mc.field_71439_g.field_70165_t + x, (int)MinecraftInstance.mc.field_71439_g.field_70163_u + y, (int)MinecraftInstance.mc.field_71439_g.field_70161_v + z);
                        if (BlockUtils.getBlock(blockPos) == null) continue;
                        blocks.put(blockPos, block);
                    } while (z != n5);
                } while (y != n3);
            } while (x != n);
        }
        return blocks;
    }

    @JvmStatic
    public static final boolean collideBlock(AxisAlignedBB axisAlignedBB, Function1<? super Block, Boolean> collide) {
        Intrinsics.checkNotNullParameter((Object)axisAlignedBB, (String)"axisAlignedBB");
        Intrinsics.checkNotNullParameter(collide, (String)"collide");
        int n = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72340_a);
        int n2 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72336_d) + 1;
        while (n < n2) {
            int x = n++;
            int n3 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72339_c);
            int n4 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72334_f) + 1;
            while (n3 < n4) {
                int z = n3++;
                Block block = BlockUtils.getBlock(new BlockPos((double)x, axisAlignedBB.field_72338_b, (double)z));
                if (((Boolean)collide.invoke((Object)block)).booleanValue()) continue;
                return false;
            }
        }
        return true;
    }

    @JvmStatic
    public static final boolean collideBlockIntersects(AxisAlignedBB axisAlignedBB, Function1<? super Block, Boolean> collide) {
        Intrinsics.checkNotNullParameter((Object)axisAlignedBB, (String)"axisAlignedBB");
        Intrinsics.checkNotNullParameter(collide, (String)"collide");
        int n = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72340_a);
        int n2 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72336_d) + 1;
        while (n < n2) {
            int x = n++;
            int n3 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72339_c);
            int n4 = MathHelper.func_76128_c((double)MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72334_f) + 1;
            while (n3 < n4) {
                AxisAlignedBB axisAlignedBB2;
                int z = n3++;
                BlockPos blockPos = new BlockPos((double)x, axisAlignedBB.field_72338_b, (double)z);
                Block block = BlockUtils.getBlock(blockPos);
                if (!((Boolean)collide.invoke((Object)block)).booleanValue()) continue;
                Block block2 = block;
                AxisAlignedBB axisAlignedBB3 = block2 == null ? null : (axisAlignedBB2 = block2.func_180640_a((World)MinecraftInstance.mc.field_71441_e, blockPos, BlockUtils.getState(blockPos)));
                if (axisAlignedBB2 == null) continue;
                AxisAlignedBB boundingBox = axisAlignedBB2;
                if (!MinecraftInstance.mc.field_71439_g.func_174813_aQ().func_72326_a(boundingBox)) continue;
                return true;
            }
        }
        return false;
    }

    @JvmStatic
    public static final Vec3 floorVec3(Vec3 vec3) {
        Intrinsics.checkNotNullParameter((Object)vec3, (String)"vec3");
        return new Vec3(Math.floor(vec3.field_72450_a), Math.floor(vec3.field_72448_b), Math.floor(vec3.field_72449_c));
    }
}

