/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.util.block;

import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.block.BlockUtils;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public final class PlaceInfo {
    public static final Companion Companion = new Companion(null);
    private final BlockPos blockPos;
    private final EnumFacing enumFacing;
    private Vec3 vec3;

    public PlaceInfo(BlockPos blockPos, EnumFacing enumFacing, Vec3 vec3) {
        Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
        Intrinsics.checkNotNullParameter((Object)enumFacing, (String)"enumFacing");
        Intrinsics.checkNotNullParameter((Object)vec3, (String)"vec3");
        this.blockPos = blockPos;
        this.enumFacing = enumFacing;
        this.vec3 = vec3;
    }

    public /* synthetic */ PlaceInfo(BlockPos blockPos, EnumFacing enumFacing, Vec3 vec3, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 4) != 0) {
            vec3 = new Vec3((double)blockPos.func_177958_n() + 0.5, (double)blockPos.func_177956_o() + 0.5, (double)blockPos.func_177952_p() + 0.5);
        }
        this(blockPos, enumFacing, vec3);
    }

    public final BlockPos getBlockPos() {
        return this.blockPos;
    }

    public final EnumFacing getEnumFacing() {
        return this.enumFacing;
    }

    public final Vec3 getVec3() {
        return this.vec3;
    }

    public final void setVec3(Vec3 vec3) {
        Intrinsics.checkNotNullParameter((Object)vec3, (String)"<set-?>");
        this.vec3 = vec3;
    }

    @JvmStatic
    public static final PlaceInfo get(BlockPos blockPos) {
        return Companion.get(blockPos);
    }

    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final PlaceInfo get(BlockPos blockPos) {
            PlaceInfo placeInfo;
            Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
            if (BlockUtils.canBeClicked(blockPos.func_177982_a(0, -1, 0))) {
                BlockPos blockPos2 = blockPos.func_177982_a(0, -1, 0);
                Intrinsics.checkNotNullExpressionValue((Object)blockPos2, (String)"blockPos.add(0, -1, 0)");
                return new PlaceInfo(blockPos2, EnumFacing.UP, null, 4, null);
            }
            if (BlockUtils.canBeClicked(blockPos.func_177982_a(0, 0, 1))) {
                BlockPos blockPos3 = blockPos.func_177982_a(0, 0, 1);
                Intrinsics.checkNotNullExpressionValue((Object)blockPos3, (String)"blockPos.add(0, 0, 1)");
                return new PlaceInfo(blockPos3, EnumFacing.NORTH, null, 4, null);
            }
            if (BlockUtils.canBeClicked(blockPos.func_177982_a(-1, 0, 0))) {
                BlockPos blockPos4 = blockPos.func_177982_a(-1, 0, 0);
                Intrinsics.checkNotNullExpressionValue((Object)blockPos4, (String)"blockPos.add(-1, 0, 0)");
                return new PlaceInfo(blockPos4, EnumFacing.EAST, null, 4, null);
            }
            if (BlockUtils.canBeClicked(blockPos.func_177982_a(0, 0, -1))) {
                BlockPos blockPos5 = blockPos.func_177982_a(0, 0, -1);
                Intrinsics.checkNotNullExpressionValue((Object)blockPos5, (String)"blockPos.add(0, 0, -1)");
                return new PlaceInfo(blockPos5, EnumFacing.SOUTH, null, 4, null);
            }
            if (BlockUtils.canBeClicked(blockPos.func_177982_a(1, 0, 0))) {
                BlockPos blockPos6 = blockPos.func_177982_a(1, 0, 0);
                Intrinsics.checkNotNullExpressionValue((Object)blockPos6, (String)"blockPos.add(1, 0, 0)");
                PlaceInfo placeInfo2 = new PlaceInfo(blockPos6, EnumFacing.WEST, null, 4, null);
                placeInfo = placeInfo2;
            } else {
                placeInfo = null;
            }
            return placeInfo;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

