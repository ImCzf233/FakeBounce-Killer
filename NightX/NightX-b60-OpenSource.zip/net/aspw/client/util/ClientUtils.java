/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.util.IChatComponent$Serializer
 *  org.apache.logging.log4j.LogManager
 *  org.apache.logging.log4j.Logger
 */
package net.aspw.client.util;

import com.google.gson.JsonObject;
import java.lang.reflect.Field;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.IChatComponent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public final class ClientUtils
extends MinecraftInstance {
    private static final Logger logger = LogManager.getLogger((String)"Client");
    private static Field fastRenderField;

    public static Logger getLogger() {
        return logger;
    }

    public static void disableFastRender() {
        try {
            if (fastRenderField != null) {
                if (!fastRenderField.isAccessible()) {
                    fastRenderField.setAccessible(true);
                }
                fastRenderField.setBoolean(ClientUtils.mc.field_71474_y, false);
            }
        }
        catch (IllegalAccessException illegalAccessException) {
            // empty catch block
        }
    }

    public static void displayChatMessage(String message) {
        if (ClientUtils.mc.field_71439_g == null) {
            ClientUtils.getLogger().info("(MCChat)" + message);
            return;
        }
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("text", message);
        ClientUtils.mc.field_71439_g.func_145747_a(IChatComponent.Serializer.func_150699_a((String)jsonObject.toString()));
    }

    static {
        try {
            fastRenderField = GameSettings.class.getDeclaredField("ofFastRender");
            if (!fastRenderField.isAccessible()) {
                fastRenderField.setAccessible(true);
            }
        }
        catch (NoSuchFieldException noSuchFieldException) {
            // empty catch block
        }
    }
}

