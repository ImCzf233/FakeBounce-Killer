/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiMultiplayer
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.multiplayer.GuiConnecting
 *  net.minecraft.client.multiplayer.ServerData
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.util;

import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.visual.client.GuiMainMenu;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.entity.Entity;

public final class ServerUtils
extends MinecraftInstance {
    public static ServerData serverData;

    public static void connectToLastServer() {
        if (serverData == null) {
            return;
        }
        mc.func_147108_a((GuiScreen)new GuiConnecting((GuiScreen)new GuiMultiplayer((GuiScreen)new GuiMainMenu()), mc, serverData));
    }

    public static String getRemoteIp() {
        ServerData serverData;
        if (ServerUtils.mc.field_71441_e == null) {
            return "Undefined";
        }
        String serverIp = "Singleplayer";
        if (ServerUtils.mc.field_71441_e.field_72995_K && (serverData = mc.func_147104_D()) != null) {
            serverIp = serverData.field_78845_b;
        }
        return serverIp;
    }

    public static boolean isHypixelLobby() {
        if (ServerUtils.mc.field_71441_e == null) {
            return false;
        }
        String target = "CLICK TO PLAY";
        for (Entity entity : ServerUtils.mc.field_71441_e.field_72996_f) {
            if (!entity.func_70005_c_().startsWith("\u00a7e\u00a7l") || !entity.func_70005_c_().equals("\u00a7e\u00a7l" + target)) continue;
            return true;
        }
        return false;
    }
}

