/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 */
package net.aspw.client.util;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public final class WorldUtils {
    private static final Minecraft MC = Minecraft.func_71410_x();

    public static boolean isAir(BlockPos blockPos) {
        return WorldUtils.MC.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150350_a;
    }

    public static double distanceToGround() {
        double playerY = WorldUtils.MC.field_71439_g.field_70163_u;
        return playerY - (double)WorldUtils.getBlockBellow().func_177956_o() - 1.0;
    }

    public static double distanceToGround(Vec3 vec3) {
        double playerY = vec3.field_72448_b;
        return playerY - (double)WorldUtils.getBlockBellow(vec3).func_177956_o() - 1.0;
    }

    public static BlockPos getBlockBellow(Vec3 playerPos) {
        while (playerPos.field_72448_b > 0.0) {
            BlockPos blockPos = new BlockPos(playerPos);
            if (!WorldUtils.isAir(blockPos)) {
                return blockPos;
            }
            playerPos = playerPos.func_72441_c(0.0, -1.0, 0.0);
        }
        return BlockPos.field_177992_a;
    }

    public static BlockPos getBlockBellow() {
        Vec3 playerPos = WorldUtils.MC.field_71439_g.func_174824_e(1.0f);
        while (playerPos.field_72448_b > 0.0) {
            BlockPos blockPos = new BlockPos(playerPos);
            if (!WorldUtils.isAir(blockPos)) {
                return blockPos;
            }
            playerPos = playerPos.func_72441_c(0.0, -1.0, 0.0);
        }
        return BlockPos.field_177992_a;
    }

    public static boolean isStandAble(BlockPos blockPos) {
        return !WorldUtils.canCollide(blockPos) && !WorldUtils.canCollide(blockPos.func_177982_a(0, 1, 0));
    }

    public static boolean canCollide(BlockPos blockPos) {
        IBlockState blockState = WorldUtils.MC.field_71441_e.func_180495_p(blockPos);
        return blockState.func_177230_c().func_180640_a((World)WorldUtils.MC.field_71441_e, blockPos, blockState) != null;
    }
}

