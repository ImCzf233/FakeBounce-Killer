/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.util;

import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;

public final class MovementUtilsFix
extends MinecraftInstance {
    public static final MovementUtilsFix INSTANCE = new MovementUtilsFix();

    private MovementUtilsFix() {
    }

    public final double getDirection() {
        float rotationYaw = Minecraft.func_71410_x().field_71439_g.field_70177_z;
        if (Minecraft.func_71410_x().field_71439_g.field_70701_bs < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.func_71410_x().field_71439_g.field_70701_bs < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.func_71410_x().field_71439_g.field_70701_bs > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.func_71410_x().field_71439_g.field_70702_br > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (Minecraft.func_71410_x().field_71439_g.field_70702_br < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    private final double getFunDirection() {
        float rotationYaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
        if (MinecraftInstance.mc.field_71439_g.field_70701_bs < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (MinecraftInstance.mc.field_71439_g.field_70701_bs < 0.0f) {
            forward = -0.5f;
        } else if (MinecraftInstance.mc.field_71439_g.field_70701_bs > 0.0f) {
            forward = 0.5f;
        }
        if (MinecraftInstance.mc.field_71439_g.field_70702_br > 0.0f) {
            rotationYaw -= (float)70 * forward;
        }
        if (MinecraftInstance.mc.field_71439_g.field_70702_br < 0.0f) {
            rotationYaw += (float)70 * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public final double defaultSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.func_71410_x().field_71439_g.func_70644_a(Potion.field_76424_c)) {
            int amplifier = Minecraft.func_71410_x().field_71439_g.func_70660_b(Potion.field_76424_c).func_76458_c();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public final void theStrafe(double speed2) {
        if (!MovementUtils.isMoving()) {
            return;
        }
        MinecraftInstance.mc.field_71439_g.field_70159_w = (double)(-MathHelper.func_76126_a((float)((float)this.getFunDirection()))) * speed2;
        MinecraftInstance.mc.field_71439_g.field_70179_y = (double)MathHelper.func_76134_b((float)((float)this.getFunDirection())) * speed2;
    }

    public final float getMovingYaw() {
        return (float)(this.getDirection() * (double)180.0f / Math.PI);
    }
}

