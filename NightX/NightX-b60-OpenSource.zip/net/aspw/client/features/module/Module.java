/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.features.module;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.Listenable;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.Value;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.util.ResourceLocation;

public abstract class Module
extends MinecraftInstance
implements Listenable {
    private String name;
    private String spacedName;
    private String description;
    private ModuleCategory category;
    private int keyBind;
    private boolean array = true;
    private final boolean canEnable;
    private final boolean onlyEnable;
    private final boolean forceNoSound;
    private float slideStep;
    private boolean state;
    private final float hue;
    private float slide;
    private float arrayY;

    public Module() {
        ModuleInfo moduleInfo = this.getClass().getAnnotation(ModuleInfo.class);
        Intrinsics.checkNotNull((Object)moduleInfo);
        ModuleInfo moduleInfo2 = moduleInfo;
        this.name = moduleInfo2.name();
        this.spacedName = moduleInfo2.spacedName().equals("") ? this.name : moduleInfo2.spacedName();
        this.description = moduleInfo2.description();
        this.category = moduleInfo2.category();
        this.setKeyBind(moduleInfo2.keyBind());
        this.setArray(moduleInfo2.array());
        this.canEnable = moduleInfo2.canEnable();
        this.onlyEnable = moduleInfo2.onlyEnable();
        this.forceNoSound = moduleInfo2.forceNoSound();
        this.hue = (float)Math.random();
    }

    public final String getName() {
        return this.name;
    }

    public final void setName(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.name = string;
    }

    public final String getSpacedName() {
        return this.spacedName;
    }

    public final void setSpacedName(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.spacedName = string;
    }

    public final String getDescription() {
        return this.description;
    }

    public final void setDescription(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.description = string;
    }

    public final ModuleCategory getCategory() {
        return this.category;
    }

    public final void setCategory(ModuleCategory moduleCategory) {
        Intrinsics.checkNotNullParameter((Object)((Object)moduleCategory), (String)"<set-?>");
        this.category = moduleCategory;
    }

    public final int getKeyBind() {
        return this.keyBind;
    }

    public final void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
        if (!Client.INSTANCE.isStarting()) {
            Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().modulesConfig);
        }
    }

    public final boolean getArray() {
        return this.array;
    }

    public final void setArray(boolean array) {
        this.array = array;
        if (!Client.INSTANCE.isStarting()) {
            Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().modulesConfig);
        }
    }

    public final float getSlideStep() {
        return this.slideStep;
    }

    public final void setSlideStep(float f) {
        this.slideStep = f;
    }

    public final boolean getState() {
        return this.state;
    }

    public final void setState(boolean value) {
        if (this.state == value || !this.canEnable) {
            return;
        }
        this.onToggle(value);
        if (!Client.INSTANCE.isStarting() && !this.forceNoSound) {
            switch (Client.INSTANCE.getModuleManager().getToggleSoundMode()) {
                case 1: {
                    MinecraftInstance.mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a((ResourceLocation)new ResourceLocation("random.click"), (float)1.0f));
                    break;
                }
                case 2: {
                    (value ? Client.INSTANCE.getTipSoundManager().getEnableSound() : Client.INSTANCE.getTipSoundManager().getDisableSound()).asyncPlay(Client.INSTANCE.getModuleManager().getToggleVolume());
                }
            }
            if (Client.INSTANCE.getModuleManager().getShouldNotify()) {
                Client.INSTANCE.getHud().addNotification(new Notification((value ? "Enabled" : "Disabled") + " \u00a7r" + this.name + '!', value ? Notification.Type.SUCCESS : Notification.Type.ERROR, 1000L));
            }
        }
        if (value) {
            this.onEnable();
            if (!this.onlyEnable) {
                this.state = true;
            }
        } else {
            this.onDisable();
            this.state = false;
        }
        Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().modulesConfig);
    }

    public final float getHue() {
        return this.hue;
    }

    public final float getSlide() {
        return this.slide;
    }

    public final void setSlide(float f) {
        this.slide = f;
    }

    public final float getArrayY() {
        return this.arrayY;
    }

    public final void setArrayY(float f) {
        this.arrayY = f;
    }

    public String getTag() {
        return null;
    }

    public final void toggle() {
        this.setState(!this.state);
    }

    protected final void chat(String msg) {
        Intrinsics.checkNotNullParameter((Object)msg, (String)"msg");
        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a7c", (Object)msg));
    }

    public void onToggle(boolean state) {
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onInitialize() {
    }

    public Value<?> getValue(String valueName) {
        Object v0;
        block1: {
            Intrinsics.checkNotNullParameter((Object)valueName, (String)"valueName");
            for (Object t : (Iterable)this.getValues()) {
                Value it = (Value)t;
                boolean bl = false;
                if (!StringsKt.equals((String)it.getName(), (String)valueName, (boolean)true)) continue;
                v0 = t;
                break block1;
            }
            v0 = null;
        }
        return v0;
    }

    /*
     * WARNING - void declaration
     */
    public List<Value<?>> getValues() {
        void $this$filterIsInstanceTo$iv$iv;
        Iterable $this$mapTo$iv$iv;
        Field[] fieldArray = this.getClass().getDeclaredFields();
        Intrinsics.checkNotNullExpressionValue((Object)fieldArray, (String)"javaClass.declaredFields");
        Object[] $this$map$iv = fieldArray;
        boolean $i$f$map = false;
        Object[] objectArray = $this$map$iv;
        Collection destination$iv$iv = new ArrayList($this$map$iv.length);
        boolean $i$f$mapTo = false;
        for (void item$iv$iv : $this$mapTo$iv$iv) {
            void valueField;
            Field field = (Field)item$iv$iv;
            Collection collection = destination$iv$iv;
            boolean bl = false;
            valueField.setAccessible(true);
            collection.add(valueField.get(this));
        }
        Iterable $this$filterIsInstance$iv = (List)destination$iv$iv;
        boolean $i$f$filterIsInstance = false;
        $this$mapTo$iv$iv = $this$filterIsInstance$iv;
        destination$iv$iv = new ArrayList();
        boolean $i$f$filterIsInstanceTo = false;
        for (Object element$iv$iv : $this$filterIsInstanceTo$iv$iv) {
            if (!(element$iv$iv instanceof Value)) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        return (List)destination$iv$iv;
    }

    @Override
    public boolean handleEvents() {
        return this.state;
    }
}

