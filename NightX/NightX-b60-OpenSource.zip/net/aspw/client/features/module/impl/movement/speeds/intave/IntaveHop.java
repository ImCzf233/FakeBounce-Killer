/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.intave;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class IntaveHop
extends SpeedMode {
    public IntaveHop() {
        super("IntaveHop");
    }

    @Override
    public void onUpdate() {
        SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
        if (MovementUtils.isMoving()) {
            if (SpeedMode.mc.field_71439_g.field_70122_E) {
                SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
                SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
                SpeedMode.mc.field_71439_g.func_70664_aZ();
            }
            if (SpeedMode.mc.field_71439_g.field_70181_x > 0.003) {
                EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
                entityPlayerSP.field_70159_w *= 1.0015;
                entityPlayerSP = SpeedMode.mc.field_71439_g;
                entityPlayerSP.field_70179_y *= 1.0015;
                SpeedMode.mc.field_71428_T.field_74278_d = 1.06f;
            }
        }
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        super.onEnable();
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

