/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockAir
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.minecraft.block.BlockAir;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public class AACPort
extends SpeedMode {
    public AACPort() {
        super("AACPort");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        float f = AACPort.mc.field_71439_g.field_70177_z * ((float)Math.PI / 180);
        for (double d = 0.2; d <= (double)((Float)Client.moduleManager.getModule(Speed.class).portMax.get()).floatValue(); d += 0.2) {
            double x = AACPort.mc.field_71439_g.field_70165_t - (double)MathHelper.func_76126_a((float)f) * d;
            double z = AACPort.mc.field_71439_g.field_70161_v + (double)MathHelper.func_76134_b((float)f) * d;
            if (AACPort.mc.field_71439_g.field_70163_u < (double)((int)AACPort.mc.field_71439_g.field_70163_u) + 0.5 && !(BlockUtils.getBlock(new BlockPos(x, AACPort.mc.field_71439_g.field_70163_u, z)) instanceof BlockAir)) break;
            AACPort.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, AACPort.mc.field_71439_g.field_70163_u, z, true));
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

