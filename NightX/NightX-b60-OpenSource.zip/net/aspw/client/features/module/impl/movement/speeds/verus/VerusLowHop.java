/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.verus;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class VerusLowHop
extends SpeedMode {
    public VerusLowHop() {
        super("VerusLowHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!VerusLowHop.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            VerusLowHop.mc.field_71439_g.field_70159_w = 0.0;
            VerusLowHop.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        if (!(VerusLowHop.mc.field_71439_g.field_70134_J || VerusLowHop.mc.field_71439_g.func_180799_ab() || VerusLowHop.mc.field_71439_g.func_70090_H() || VerusLowHop.mc.field_71439_g.func_70617_f_() || VerusLowHop.mc.field_71439_g.field_70154_o != null || !MovementUtils.isMoving())) {
            VerusLowHop.mc.field_71474_y.field_74314_A.field_74513_e = false;
            if (VerusLowHop.mc.field_71439_g.field_70122_E) {
                VerusLowHop.mc.field_71439_g.func_70664_aZ();
                VerusLowHop.mc.field_71439_g.field_70181_x = 0.0;
                MovementUtils.strafe(0.61f);
                event.setY(0.41999998688698);
            }
            MovementUtils.strafe();
        }
    }
}

