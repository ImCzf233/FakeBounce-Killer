/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.ArraysKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.network.play.client.C14PacketTabComplete
 *  net.minecraft.network.play.server.S2EPacketCloseWindow
 *  net.minecraft.network.play.server.S3APacketTabComplete
 *  net.minecraft.network.play.server.S45PacketTitle
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import java.util.List;
import kotlin.collections.ArraysKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.TickEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.AnimationUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.FontValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.value.TextValue;
import net.aspw.client.visual.client.clickgui.dropdown.ClickGui;
import net.aspw.client.visual.client.clickgui.tab.NewUi;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.network.play.server.S2EPacketCloseWindow;
import net.minecraft.network.play.server.S3APacketTabComplete;
import net.minecraft.network.play.server.S45PacketTitle;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Hud", description="", category=ModuleCategory.VISUAL, array=false)
public final class Hud
extends Module {
    private final TextValue clientNameValue = new TextValue("ClientName", "N:ightX");
    private final BoolValue nof5crossHair = new BoolValue("NoF5-Crosshair", true);
    private final BoolValue f5nameTag = new BoolValue("F5-NameTag", false);
    private final BoolValue animHotbarValue = new BoolValue("Hotbar-Animation", false);
    private final FloatValue animHotbarSpeedValue = new FloatValue("Hotbar-AnimationSpeed", 0.03f, 0.01f, 0.2f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ Hud this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getAnimHotbarValue().get();
        }
    }));
    private final BoolValue blackHotbarValue = new BoolValue("Black-Hotbar", false);
    private final BoolValue noInvClose = new BoolValue("NoInvClose", true);
    private final BoolValue noTitle = new BoolValue("NoTitle", false);
    private final BoolValue antiTabComplete = new BoolValue("AntiTabComplete", false);
    private final BoolValue customFov = new BoolValue("CustomFov", false);
    private final FloatValue customFovModifier = new FloatValue("Fov", 1.3f, 0.8f, 1.5f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ Hud this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getCustomFov().get();
        }
    }));
    private final BoolValue fontChatValue = new BoolValue("FontChat", false);
    private final FontValue fontType;
    private final BoolValue chatRectValue;
    private final BoolValue chatAnimationValue;
    private final FloatValue chatAnimationSpeedValue;
    private final BoolValue toggleMessageValue;
    private final ListValue toggleSoundValue;
    private final BoolValue flagSoundValue;
    private final BoolValue swingSoundValue;
    private final BoolValue containerBackground;
    private final BoolValue invEffectOffset;
    private float hotBarX;
    private String rainbow;
    private String white;

    public Hud() {
        String[] stringArray = Fonts.fontSFUI37;
        Intrinsics.checkNotNullExpressionValue((Object)stringArray, (String)"fontSFUI37");
        this.fontType = new FontValue("Font", (FontRenderer)stringArray, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Hud this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)this.this$0.getFontChatValue().get();
            }
        }));
        this.chatRectValue = new BoolValue("ChatRect", true);
        this.chatAnimationValue = new BoolValue("Chat-Animation", true);
        this.chatAnimationSpeedValue = new FloatValue("Chat-AnimationSpeed", 0.06f, 0.01f, 0.5f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Hud this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)this.this$0.getChatAnimationValue().get();
            }
        }));
        this.toggleMessageValue = new BoolValue("Toggle-Notification", false);
        stringArray = new String[]{"None", "Default", "Custom"};
        this.toggleSoundValue = new ListValue("Toggle-Sound", stringArray, "None");
        this.flagSoundValue = new BoolValue("Pop-Sound", true);
        this.swingSoundValue = new BoolValue("Swing-Sound", false);
        this.containerBackground = new BoolValue("Gui-Background", true);
        this.invEffectOffset = new BoolValue("InventoryEffect-Moveable", false);
        this.rainbow = "";
        this.white = "";
        this.setState(true);
    }

    public final TextValue getClientNameValue() {
        return this.clientNameValue;
    }

    public final BoolValue getNof5crossHair() {
        return this.nof5crossHair;
    }

    public final BoolValue getF5nameTag() {
        return this.f5nameTag;
    }

    public final BoolValue getAnimHotbarValue() {
        return this.animHotbarValue;
    }

    public final FloatValue getAnimHotbarSpeedValue() {
        return this.animHotbarSpeedValue;
    }

    public final BoolValue getBlackHotbarValue() {
        return this.blackHotbarValue;
    }

    public final BoolValue getNoInvClose() {
        return this.noInvClose;
    }

    public final BoolValue getNoTitle() {
        return this.noTitle;
    }

    public final BoolValue getAntiTabComplete() {
        return this.antiTabComplete;
    }

    public final BoolValue getCustomFov() {
        return this.customFov;
    }

    public final FloatValue getCustomFovModifier() {
        return this.customFovModifier;
    }

    public final BoolValue getFontChatValue() {
        return this.fontChatValue;
    }

    public final FontValue getFontType() {
        return this.fontType;
    }

    public final BoolValue getChatRectValue() {
        return this.chatRectValue;
    }

    public final BoolValue getChatAnimationValue() {
        return this.chatAnimationValue;
    }

    public final FloatValue getChatAnimationSpeedValue() {
        return this.chatAnimationSpeedValue;
    }

    public final BoolValue getFlagSoundValue() {
        return this.flagSoundValue;
    }

    public final BoolValue getSwingSoundValue() {
        return this.swingSoundValue;
    }

    public final BoolValue getContainerBackground() {
        return this.containerBackground;
    }

    public final BoolValue getInvEffectOffset() {
        return this.invEffectOffset;
    }

    public final String getRainbow() {
        return this.rainbow;
    }

    public final void setRainbow(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.rainbow = string;
    }

    public final String getWhite() {
        return this.white;
    }

    public final void setWhite(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.white = string;
    }

    private final void slashName() {
        String input = (String)this.clientNameValue.get();
        String[] stringArray = new String[]{":"};
        List splitInput = StringsKt.split$default((CharSequence)input, (String[])stringArray, (boolean)false, (int)0, (int)6, null);
        this.rainbow = (String)splitInput.get(0);
        this.white = (String)splitInput.get(1);
    }

    @EventTarget
    public final void onRender2D(Render2DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Client.INSTANCE.getHud().render(false);
        this.slashName();
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.noTitle.get()).booleanValue() && event.getPacket() instanceof S45PacketTitle) {
            event.cancelEvent();
        }
        if (((Boolean)this.antiTabComplete.get()).booleanValue() && (event.getPacket() instanceof C14PacketTabComplete || event.getPacket() instanceof S3APacketTabComplete)) {
            event.cancelEvent();
        }
        if (MinecraftInstance.mc.field_71441_e == null || MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        if (((Boolean)this.noInvClose.get()).booleanValue() && event.getPacket() instanceof S2EPacketCloseWindow && (MinecraftInstance.mc.field_71462_r instanceof GuiInventory || MinecraftInstance.mc.field_71462_r instanceof NewUi || MinecraftInstance.mc.field_71462_r instanceof ClickGui || MinecraftInstance.mc.field_71462_r instanceof GuiChat)) {
            event.cancelEvent();
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onTick(TickEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (Client.INSTANCE.getModuleManager().getShouldNotify() != ((Boolean)this.toggleMessageValue.get()).booleanValue()) {
            Client.INSTANCE.getModuleManager().setShouldNotify((Boolean)this.toggleMessageValue.get());
        }
        if (Client.INSTANCE.getModuleManager().getToggleSoundMode() != ArraysKt.indexOf((Object[])this.toggleSoundValue.getValues(), this.toggleSoundValue.get())) {
            Client.INSTANCE.getModuleManager().setToggleSoundMode(ArraysKt.indexOf((Object[])this.toggleSoundValue.getValues(), this.toggleSoundValue.get()));
        }
        if (!(Client.INSTANCE.getModuleManager().getToggleVolume() == 90.0f)) {
            Client.INSTANCE.getModuleManager().setToggleVolume(90.0f);
        }
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        Client.INSTANCE.getHud().update();
    }

    @EventTarget
    public final void onKey(KeyEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Client.INSTANCE.getHud().handleKey('a', event.getKey());
    }

    public final float getAnimPos(float pos) {
        this.hotBarX = this.getState() && (Boolean)this.animHotbarValue.get() != false ? AnimationUtils.animate(pos, this.hotBarX, ((Number)this.animHotbarSpeedValue.get()).floatValue() * (float)RenderUtils.deltaTime) : pos;
        return this.hotBarX;
    }
}

