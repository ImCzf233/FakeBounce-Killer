/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.potion.Potion
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.potion.Potion;

public final class NCPSemiStrafe
extends SpeedMode {
    public NCPSemiStrafe() {
        super("NCPSemiStrafe");
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        if (!SpeedMode.mc.field_71439_g.func_70093_af()) {
            Scaffold scaffold2 = scaffold;
            Intrinsics.checkNotNull((Object)scaffold2);
            if (!scaffold2.getState()) {
                SpeedMode.mc.field_71439_g.field_70159_w = 0.0;
                SpeedMode.mc.field_71439_g.field_70179_y = 0.0;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onMotion(MotionEvent eventMotion) {
        Intrinsics.checkNotNullParameter((Object)eventMotion, (String)"eventMotion");
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null || eventMotion.getEventState() != EventState.PRE || SpeedMode.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (SpeedMode.mc.field_71439_g.field_70122_E) {
                SpeedMode.mc.field_71439_g.field_70181_x = 0.41999998688698;
            } else {
                if (SpeedMode.mc.field_71439_g.func_70644_a(Potion.field_76424_c)) {
                    MovementUtils.strafe(0.265f);
                } else {
                    MovementUtils.strafe(0.145f);
                }
                SpeedMode.mc.field_71439_g.field_70747_aH = 0.14f;
            }
        }
    }
}

