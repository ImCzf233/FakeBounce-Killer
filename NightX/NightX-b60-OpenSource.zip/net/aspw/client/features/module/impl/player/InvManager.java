/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.MapsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.ai.attributes.AttributeModifier
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemAppleGold
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemAxe
 *  net.minecraft.item.ItemBed
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemBoat
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemBucket
 *  net.minecraft.item.ItemEnderPearl
 *  net.minecraft.item.ItemFood
 *  net.minecraft.item.ItemMinecart
 *  net.minecraft.item.ItemPickaxe
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.item.ItemTool
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.injection.implementations.IItemStack;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.InventoryHelper;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.item.ArmorPart;
import net.aspw.client.util.item.ItemHelper;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBed;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBoat;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemMinecart;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="InvManager", spacedName="Inv Manager", description="", category=ModuleCategory.PLAYER)
public final class InvManager
extends Module {
    private final IntegerValue maxDelayValue = new IntegerValue(this){
        final /* synthetic */ InvManager this$0;
        {
            this.this$0 = $receiver;
            super("MaxDelay", 14, 0, 1000, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int minCPS2 = ((Number)InvManager.access$getMinDelayValue$p(this.this$0).get()).intValue();
            if (minCPS2 > newValue) {
                this.set(minCPS2);
            }
        }
    };
    private final IntegerValue minDelayValue = new IntegerValue(this){
        final /* synthetic */ InvManager this$0;
        {
            this.this$0 = $receiver;
            super("MinDelay", 10, 0, 1000, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int maxDelay = ((Number)InvManager.access$getMaxDelayValue$p(this.this$0).get()).intValue();
            if (maxDelay < newValue) {
                this.set(maxDelay);
            }
        }
    };
    private final BoolValue invOpenValue = new BoolValue("InvOpen", false);
    private final BoolValue invSpoof = new BoolValue("InvSpoof", false);
    private final BoolValue invSpoofOld = new BoolValue("InvSpoof-Old", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ InvManager this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)InvManager.access$getInvSpoof$p(this.this$0).get();
        }
    }));
    private final BoolValue animationValue = new BoolValue("Animation", false);
    private final BoolValue noMoveValue = new BoolValue("NoMove", false);
    private final BoolValue hotbarValue = new BoolValue("Hotbar", false);
    private final BoolValue randomSlotValue = new BoolValue("RandomSlot", false);
    private final BoolValue sortValue = new BoolValue("Sort", true);
    private final BoolValue cleanGarbageValue = new BoolValue("CleanGarbage", true);
    private final BoolValue ignoreVehiclesValue = new BoolValue("IgnoreVehicles", true);
    private final BoolValue onlyPositivePotionValue = new BoolValue("OnlyPositivePotion", true);
    private final ListValue nbtGoalValue;
    private final BoolValue nbtItemNotGarbage;
    private final FloatValue nbtArmorPriority;
    private final FloatValue nbtWeaponPriority;
    private final String[] items;
    private final ListValue sortSlot1Value;
    private final ListValue sortSlot2Value;
    private final ListValue sortSlot3Value;
    private final ListValue sortSlot4Value;
    private final ListValue sortSlot5Value;
    private final ListValue sortSlot6Value;
    private final ListValue sortSlot7Value;
    private final ListValue sortSlot8Value;
    private final ListValue sortSlot9Value;
    private Map<Integer, ItemStack> garbageQueue;
    private ArmorPart[] armorQueue;
    private boolean spoofInventory;
    private long delay;

    /*
     * WARNING - void declaration
     */
    public InvManager() {
        Collection<String> collection;
        void $this$mapTo$iv$iv;
        void $this$map$iv;
        Object[] objectArray = ItemHelper.EnumNBTPriorityType.values();
        String string = "NBTGoal";
        InvManager invManager = this;
        boolean $i$f$map = false;
        void var3_5 = $this$map$iv;
        Collection destination$iv$iv = new ArrayList(((void)$this$map$iv).length);
        boolean $i$f$mapTo = false;
        for (void item$iv$iv : $this$mapTo$iv$iv) {
            void it;
            void var10_12 = item$iv$iv;
            collection = destination$iv$iv;
            boolean bl = false;
            collection.add(it.toString());
        }
        collection = (List)destination$iv$iv;
        Collection $this$toTypedArray$iv = collection;
        boolean $i$f$toTypedArray = false;
        Collection thisCollection$iv = $this$toTypedArray$iv;
        String[] stringArray = thisCollection$iv.toArray(new String[0]);
        if (stringArray == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
        }
        String string2 = "NONE";
        String[] stringArray2 = stringArray;
        String string3 = string;
        invManager.nbtGoalValue = new ListValue(string3, stringArray2, string2);
        this.nbtItemNotGarbage = new BoolValue("NBTItemNotGarbage", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !InvManager.access$getNbtGoalValue$p(this.this$0).equals("NONE");
            }
        }));
        this.nbtArmorPriority = new FloatValue("NBTArmorPriority", 0.0f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !InvManager.access$getNbtGoalValue$p(this.this$0).equals("NONE");
            }
        }));
        this.nbtWeaponPriority = new FloatValue("NBTWeaponPriority", 0.0f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !InvManager.access$getNbtGoalValue$p(this.this$0).equals("NONE");
            }
        }));
        objectArray = new String[]{"None", "Ignore", "Sword", "Bow", "Pickaxe", "Axe", "Food", "Block", "Water", "Gapple", "Pearl", "Potion"};
        this.items = objectArray;
        this.sortSlot1Value = new ListValue("SortSlot-1", this.items, "Sword", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot2Value = new ListValue("SortSlot-2", this.items, "Pickaxe", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot3Value = new ListValue("SortSlot-3", this.items, "Axe", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot4Value = new ListValue("SortSlot-4", this.items, "None", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot5Value = new ListValue("SortSlot-5", this.items, "Gapple", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot6Value = new ListValue("SortSlot-6", this.items, "None", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot7Value = new ListValue("SortSlot-7", this.items, "Bow", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot8Value = new ListValue("SortSlot-8", this.items, "Block", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.sortSlot9Value = new ListValue("SortSlot-9", this.items, "Potion", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ InvManager this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)InvManager.access$getSortValue$p(this.this$0).get();
            }
        }));
        this.garbageQueue = new LinkedHashMap();
        this.armorQueue = new ArmorPart[0];
    }

    private final ItemHelper.EnumNBTPriorityType getGoal() {
        return ItemHelper.EnumNBTPriorityType.valueOf((String)this.nbtGoalValue.get());
    }

    private final void setSpoofInventory(boolean value) {
        if (value != this.spoofInventory && !((Boolean)this.invOpenValue.get()).booleanValue()) {
            if (value) {
                InventoryHelper.INSTANCE.openPacket();
            } else {
                InventoryHelper.INSTANCE.closePacket();
            }
        }
        this.spoofInventory = value;
    }

    @Override
    public void onEnable() {
        if (((Boolean)this.invSpoof.get()).booleanValue() && !((Boolean)this.invSpoofOld.get()).booleanValue()) {
            this.setSpoofInventory(false);
        }
        this.garbageQueue.clear();
        this.armorQueue = new ArmorPart[0];
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.invSpoof.get()).booleanValue() && !((Boolean)this.invSpoofOld.get()).booleanValue()) {
            this.setSpoofInventory(false);
        }
        this.garbageQueue.clear();
        this.armorQueue = new ArmorPart[0];
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.performManager();
    }

    public final void performManager() {
        if (!InventoryUtils.CLICK_TIMER.hasTimePassed(this.delay) || ((Boolean)this.noMoveValue.get()).booleanValue() && MovementUtils.isMoving() || MinecraftInstance.mc.field_71439_g.field_71070_bA != null && MinecraftInstance.mc.field_71439_g.field_71070_bA.field_75152_c != 0) {
            return;
        }
        this.findQueueItems();
        if (((Boolean)this.hotbarValue.get()).booleanValue() && !this.spoofInventory && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory)) {
            int n = 0;
            while (n < 9) {
                ItemStack bestItem;
                int index;
                if (MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(index = n++) == null || bestItem.func_77973_b() == null || !this.garbageQueue.containsValue(bestItem)) continue;
                if (index != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(index));
                }
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.DROP_ALL_ITEMS, BlockPos.field_177992_a, EnumFacing.DOWN));
                if (index != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
                }
                this.garbageQueue.remove(index, bestItem);
            }
        }
        if (!(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && ((Boolean)this.invOpenValue.get()).booleanValue() && !((Boolean)this.invSpoof.get()).booleanValue()) {
            return;
        }
        if (this.garbageQueue.isEmpty() && this.armorQueue.length <= 0) {
            if (((Boolean)this.invSpoof.get()).booleanValue() && !((Boolean)this.invSpoofOld.get()).booleanValue()) {
                this.setSpoofInventory(false);
            }
            return;
        }
        if (((Boolean)this.sortValue.get()).booleanValue()) {
            this.sortHotbar();
        }
        if (((Boolean)this.invSpoof.get()).booleanValue() && !((Boolean)this.invSpoofOld.get()).booleanValue()) {
            this.setSpoofInventory(true);
        }
        if (((Boolean)this.cleanGarbageValue.get()).booleanValue()) {
            while (InventoryUtils.CLICK_TIMER.hasTimePassed(this.delay)) {
                boolean openInventory;
                List garbageItems = CollectionsKt.toMutableList((Collection)this.garbageQueue.keySet());
                if (((Boolean)this.randomSlotValue.get()).booleanValue()) {
                    Collections.shuffle(garbageItems);
                }
                Integer n = (Integer)CollectionsKt.firstOrNull((List)garbageItems);
                if (n == null) break;
                int garbageItem = n;
                boolean bl = openInventory = !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && (Boolean)this.invSpoof.get() != false && (Boolean)this.invSpoofOld.get() != false;
                if (openInventory) {
                    InventoryHelper.INSTANCE.openPacket();
                }
                MinecraftInstance.mc.field_71442_b.func_78753_a(MinecraftInstance.mc.field_71439_g.field_71070_bA.field_75152_c, garbageItem, 1, 4, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                if (((Boolean)this.animationValue.get()).booleanValue()) {
                    MinecraftInstance.mc.func_175597_ag().func_78445_c();
                }
                if (openInventory) {
                    InventoryHelper.INSTANCE.closePacket();
                }
                this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
                if (this.delay != 0L && !InventoryUtils.CLICK_TIMER.hasTimePassed(this.delay)) continue;
                break;
            }
        }
    }

    private final void sortHotbar() {
        int n = 0;
        while (n < 9) {
            boolean openInventory;
            int bestItem;
            int index = n++;
            Integer n2 = this.findBetterItem(index, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(index));
            if (n2 == null || (bestItem = n2.intValue()) == index) continue;
            boolean bl = openInventory = !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && (Boolean)this.invSpoof.get() != false && (Boolean)this.invSpoofOld.get() != false;
            if (openInventory) {
                InventoryHelper.INSTANCE.openPacket();
            }
            MinecraftInstance.mc.field_71442_b.func_78753_a(0, bestItem < 9 ? bestItem + 36 : bestItem, index, 2, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
            if (openInventory) {
                InventoryHelper.INSTANCE.closePacket();
            }
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            break;
        }
    }

    /*
     * WARNING - void declaration
     */
    private final void findQueueItems() {
        void $this$filterTo$iv$iv;
        void $this$filter$iv;
        this.garbageQueue.clear();
        Map<Integer, ItemStack> map = this.items(9, 45);
        InvManager invManager = this;
        boolean $i$f$filter = false;
        void var3_4 = $this$filter$iv;
        Map destination$iv$iv = new LinkedHashMap();
        boolean $i$f$filterTo = false;
        Iterator iterator = $this$filterTo$iv$iv.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry element$iv$iv;
            Map.Entry it = element$iv$iv = iterator.next();
            boolean bl = false;
            if (!(!this.isUseful((ItemStack)it.getValue(), ((Number)it.getKey()).intValue()))) continue;
            destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
        }
        invManager.garbageQueue = MapsKt.toMutableMap((Map)destination$iv$iv);
    }

    public final boolean move(int item, boolean isArmorSlot) {
        if (!isArmorSlot && item < 9 && ((Boolean)this.hotbarValue.get()).booleanValue() && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && !this.spoofInventory) {
            if (item != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(item));
            }
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(item).func_75211_c()));
            if (item != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
            }
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            return true;
        }
        if (!(((Boolean)this.noMoveValue.get()).booleanValue() && MovementUtils.isMoving() || ((Boolean)this.invOpenValue.get()).booleanValue() && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) || item == -1)) {
            boolean openInventory;
            boolean bl = openInventory = (Boolean)this.invSpoof.get() != false && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && (Boolean)this.invSpoofOld.get() == false;
            if (openInventory) {
                InventoryHelper.INSTANCE.openPacket();
            }
            MinecraftInstance.mc.field_71442_b.func_78753_a(MinecraftInstance.mc.field_71439_g.field_71069_bz.field_75152_c, isArmorSlot ? item : (item < 9 ? item + 36 : item), 0, 1, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            if (openInventory) {
                InventoryHelper.INSTANCE.closePacket();
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean isUseful(ItemStack itemStack, int slot) {
        Intrinsics.checkNotNullParameter((Object)itemStack, (String)"itemStack");
        try {
            Map.Entry element$iv;
            ItemStack stack;
            Item item = itemStack.func_77973_b();
            if (item instanceof ItemSword || item instanceof ItemTool) {
                boolean bl;
                double d;
                int n;
                if (slot >= 36) {
                    Integer n2 = this.findBetterItem(slot - 36, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(slot - 36));
                    n = slot - 36;
                    if (n2 != null && n2 == n) {
                        return true;
                    }
                }
                n = 0;
                while (n < 9) {
                    int i;
                    if (!(StringsKt.equals((String)this.type(i = n++), (String)"sword", (boolean)true) && item instanceof ItemSword || StringsKt.equals((String)this.type(i), (String)"pickaxe", (boolean)true) && item instanceof ItemPickaxe) && (!StringsKt.equals((String)this.type(i), (String)"axe", (boolean)true) || !(item instanceof ItemAxe)) || this.findBetterItem(i, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(i)) != null) continue;
                    return true;
                }
                Collection collection = itemStack.func_111283_C().get((Object)"generic.attackDamage");
                Intrinsics.checkNotNullExpressionValue((Object)collection, (String)"itemStack.attributeModif\u2026s[\"generic.attackDamage\"]");
                AttributeModifier attributeModifier = (AttributeModifier)CollectionsKt.firstOrNull((Iterable)collection);
                double damage = (attributeModifier == null ? 0.0 : (d = attributeModifier.func_111164_d())) + ItemHelper.INSTANCE.getWeaponEnchantFactor(itemStack, ((Number)this.nbtWeaponPriority.get()).floatValue(), this.getGoal());
                Map<Integer, ItemStack> $this$none$iv = this.items(0, 45);
                boolean $i$f$none2 = false;
                if ($this$none$iv.isEmpty()) {
                    return true;
                }
                Iterator<Map.Entry<Integer, ItemStack>> iterator = $this$none$iv.entrySet().iterator();
                do {
                    Map.Entry<Integer, ItemStack> element$iv2;
                    if (!iterator.hasNext()) return true;
                    Map.Entry<Integer, ItemStack> $dstr$_u24__u24$stack = element$iv2 = iterator.next();
                    boolean bl2 = false;
                    stack = $dstr$_u24__u24$stack.getValue();
                    if (!stack.equals(itemStack) && stack.getClass().equals(itemStack.getClass())) {
                        double d2;
                        Collection collection2 = stack.func_111283_C().get((Object)"generic.attackDamage");
                        Intrinsics.checkNotNullExpressionValue((Object)collection2, (String)"stack.attributeModifiers[\"generic.attackDamage\"]");
                        AttributeModifier attributeModifier2 = (AttributeModifier)CollectionsKt.firstOrNull((Iterable)collection2);
                        double d3 = attributeModifier2 == null ? 0.0 : (d2 = attributeModifier2.func_111164_d());
                        if (damage <= d3 + ItemHelper.INSTANCE.getWeaponEnchantFactor(stack, ((Number)this.nbtWeaponPriority.get()).floatValue(), this.getGoal())) {
                            return false;
                        }
                    }
                    bl = false;
                } while (!bl);
                return false;
            }
            if (item instanceof ItemBow) {
                boolean bl;
                Enchantment i = Enchantment.field_77345_t;
                Intrinsics.checkNotNullExpressionValue((Object)i, (String)"power");
                int currPower = ItemHelper.INSTANCE.getEnchantment(itemStack, i);
                Map $this$none$iv = InvManager.items$default(this, 0, 0, 3, null);
                boolean $i$f$none = false;
                if ($this$none$iv.isEmpty()) {
                    return true;
                }
                Iterator $i$f$none2 = $this$none$iv.entrySet().iterator();
                do {
                    if (!$i$f$none2.hasNext()) return true;
                    Map.Entry $dstr$_u24__u24$stack = element$iv = $i$f$none2.next();
                    boolean bl3 = false;
                    ItemStack stack2 = (ItemStack)$dstr$_u24__u24$stack.getValue();
                    if (!itemStack.equals(stack2) && stack2.func_77973_b() instanceof ItemBow) {
                        stack = Enchantment.field_77345_t;
                        Intrinsics.checkNotNullExpressionValue((Object)stack, (String)"power");
                        if (currPower <= ItemHelper.INSTANCE.getEnchantment(stack2, (Enchantment)stack)) {
                            return false;
                        }
                    }
                    bl = false;
                } while (!bl);
                return false;
            }
            if (item instanceof ItemArmor) {
                boolean bl;
                ArmorPart currArmor = new ArmorPart(itemStack, slot);
                Map $this$none$iv = InvManager.items$default(this, 0, 0, 3, null);
                boolean $i$f$none = false;
                if ($this$none$iv.isEmpty()) {
                    return true;
                }
                Iterator $i$f$none2 = $this$none$iv.entrySet().iterator();
                do {
                    if (!$i$f$none2.hasNext()) return true;
                    Map.Entry $dstr$slot$stack = element$iv = $i$f$none2.next();
                    boolean bl4 = false;
                    int slot2 = ((Number)$dstr$slot$stack.getKey()).intValue();
                    stack = (ItemStack)$dstr$slot$stack.getValue();
                    if (!stack.equals(itemStack) && stack.func_77973_b() instanceof ItemArmor) {
                        ArmorPart armor = new ArmorPart(stack, slot2);
                        if (armor.getArmorType() != currArmor.getArmorType()) {
                            bl = false;
                            continue;
                        }
                        if (ItemHelper.INSTANCE.compareArmor(currArmor, armor, ((Number)this.nbtArmorPriority.get()).floatValue(), this.getGoal()) <= 0) {
                            return false;
                        }
                        bl = false;
                        continue;
                    }
                    bl = false;
                } while (!bl);
                return false;
            }
            if (itemStack.func_77977_a().equals("item.compass")) {
                boolean bl;
                Map<Integer, ItemStack> $this$none$iv = this.items(0, 45);
                boolean $i$f$none = false;
                if ($this$none$iv.isEmpty()) {
                    return true;
                }
                Iterator<Map.Entry<Integer, ItemStack>> iterator = $this$none$iv.entrySet().iterator();
                do {
                    Map.Entry<Integer, ItemStack> element$iv3;
                    if (!iterator.hasNext()) return true;
                    Map.Entry<Integer, ItemStack> $dstr$_u24__u24$stack = element$iv3 = iterator.next();
                    boolean bl5 = false;
                    ItemStack stack3 = $dstr$_u24__u24$stack.getValue();
                    if (!itemStack.equals(stack3) && stack3.func_77977_a().equals("item.compass")) {
                        return false;
                    }
                    bl = false;
                } while (!bl);
                return false;
            }
            if (((Boolean)this.nbtItemNotGarbage.get()).booleanValue()) {
                if (ItemHelper.INSTANCE.hasNBTGoal(itemStack, this.getGoal())) return true;
            }
            if (item instanceof ItemFood) return true;
            if (itemStack.func_77977_a().equals("item.arrow")) return true;
            if (item instanceof ItemBlock) {
                if (!InventoryHelper.INSTANCE.isBlockListBlock((ItemBlock)item)) return true;
            }
            if (item instanceof ItemBed) return true;
            if (item instanceof ItemPotion) {
                if ((Boolean)this.onlyPositivePotionValue.get() == false) return true;
                if (InventoryHelper.INSTANCE.isPositivePotion((ItemPotion)item, itemStack)) return true;
            }
            if (item instanceof ItemEnderPearl) return true;
            if (item instanceof ItemBucket) return true;
            if ((Boolean)this.ignoreVehiclesValue.get() == false) return false;
            if (item instanceof ItemBoat) return true;
            if (!(item instanceof ItemMinecart)) return false;
            return true;
        }
        catch (Exception ex) {
            ClientUtils.getLogger().error("\u00a7c\u00a7l>> \u00a7r\u00a7fFailed to check item: " + itemStack.func_77977_a() + '.', (Throwable)ex);
            return true;
        }
    }

    /*
     * WARNING - void declaration
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final Integer findBetterItem(int targetSlot, ItemStack slotStack) {
        String type = this.type(targetSlot);
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string = type.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string) {
            case "sword": 
            case "pickaxe": 
            case "axe": {
                Class<Object> clazz;
                Class<ItemSword> clazz2;
                if (StringsKt.equals((String)type, (String)"Sword", (boolean)true)) {
                    clazz2 = ItemSword.class;
                } else if (StringsKt.equals((String)type, (String)"Pickaxe", (boolean)true)) {
                    clazz2 = ItemPickaxe.class;
                } else {
                    if (!StringsKt.equals((String)type, (String)"Axe", (boolean)true)) return null;
                    clazz2 = ItemAxe.class;
                }
                Class<ItemSword> clazz3 = clazz2;
                int bestWeapon = 0;
                ItemStack itemStack = slotStack;
                if (itemStack == null) {
                    clazz = null;
                } else {
                    Item item = itemStack.func_77973_b();
                    clazz = item == null ? null : item.getClass();
                }
                bestWeapon = clazz.equals(clazz3) ? targetSlot : -1;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean bl = false;
                int index$iv = 0;
                for (Object item$iv : objectArray) {
                    double d;
                    ItemStack bestStack;
                    double d2;
                    void itemStack2;
                    int n = index$iv;
                    index$iv = n + 1;
                    ItemStack itemStack3 = (ItemStack)item$iv;
                    int index = n;
                    boolean bl2 = false;
                    if (itemStack2 == null || !itemStack2.func_77973_b().getClass().equals(clazz3) || StringsKt.equals((String)this.type(index), (String)type, (boolean)true)) continue;
                    if (bestWeapon == -1) {
                        bestWeapon = index;
                        continue;
                    }
                    Collection collection = itemStack2.func_111283_C().get((Object)"generic.attackDamage");
                    Intrinsics.checkNotNullExpressionValue((Object)collection, (String)"itemStack.attributeModif\u2026s[\"generic.attackDamage\"]");
                    AttributeModifier attributeModifier = (AttributeModifier)CollectionsKt.firstOrNull((Iterable)collection);
                    double currDamage = (attributeModifier == null ? 0.0 : (d2 = attributeModifier.func_111164_d())) + ItemHelper.INSTANCE.getWeaponEnchantFactor((ItemStack)itemStack2, ((Number)this.nbtWeaponPriority.get()).floatValue(), this.getGoal());
                    if (MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(bestWeapon) == null) continue;
                    Collection collection2 = bestStack.func_111283_C().get((Object)"generic.attackDamage");
                    Intrinsics.checkNotNullExpressionValue((Object)collection2, (String)"bestStack.attributeModif\u2026s[\"generic.attackDamage\"]");
                    AttributeModifier attributeModifier2 = (AttributeModifier)CollectionsKt.firstOrNull((Iterable)collection2);
                    double d3 = attributeModifier2 == null ? 0.0 : (d = attributeModifier2.func_111164_d());
                    double bestDamage = d3 + ItemHelper.INSTANCE.getWeaponEnchantFactor(bestStack, ((Number)this.nbtWeaponPriority.get()).floatValue(), this.getGoal());
                    if (!(bestDamage < currDamage)) continue;
                    bestWeapon = index;
                }
                if (bestWeapon == -1) {
                    if (bestWeapon != targetSlot) return null;
                }
                Integer n = bestWeapon;
                return n;
            }
            case "bow": {
                int n;
                int n2;
                boolean bl = false;
                ItemStack itemStack = slotStack;
                int n3 = (itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemBow ? targetSlot : -1;
                int bestPower = 0;
                if (n3 != -1) {
                    ItemStack itemStack4 = slotStack;
                    Intrinsics.checkNotNull((Object)itemStack4);
                    Enchantment enchantment = Enchantment.field_77345_t;
                    Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"power");
                    n2 = ItemHelper.INSTANCE.getEnchantment(itemStack4, enchantment);
                } else {
                    n2 = 0;
                }
                bestPower = n2;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean bl3 = false;
                int index$iv = 0;
                for (Object item$iv2 : objectArray) {
                    int n4 = index$iv;
                    index$iv = n4 + 1;
                    ItemStack itemStack2 = (ItemStack)item$iv2;
                    int index = n4;
                    boolean bl4 = false;
                    ItemStack itemStack5 = itemStack2;
                    if (!((itemStack5 == null ? null : itemStack5.func_77973_b()) instanceof ItemBow) || StringsKt.equals((String)this.type(index), (String)type, (boolean)true)) continue;
                    if (n == -1) {
                        n = index;
                        continue;
                    }
                    Intrinsics.checkNotNullExpressionValue((Object)itemStack2, (String)"itemStack");
                    Enchantment enchantment = Enchantment.field_77345_t;
                    Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"power");
                    int power = ItemHelper.INSTANCE.getEnchantment(itemStack2, enchantment);
                    enchantment = Enchantment.field_77345_t;
                    Intrinsics.checkNotNullExpressionValue((Object)enchantment, (String)"power");
                    if (ItemHelper.INSTANCE.getEnchantment(itemStack2, enchantment) <= bestPower) continue;
                    n = index;
                    bestPower = power;
                }
                if (n == -1) return null;
                Integer n5 = n;
                return n5;
            }
            case "food": {
                void index;
                void v11;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray2 = objectArray;
                int n = 0;
                int n6 = objectArray2.length;
                do {
                    void stack;
                    void var7_21;
                    if (n >= n6) return null;
                    Object item$iv = objectArray2[n];
                    ++n;
                    void var12_83 = var7_21;
                    var7_21 = var12_83 + true;
                    ItemStack item$iv2 = (ItemStack)item$iv;
                    index = var12_83;
                    boolean bl5 = false;
                    v11 = stack;
                } while (!((item = v11 == null ? null : v11.func_77973_b()) instanceof ItemFood) || item instanceof ItemAppleGold || StringsKt.equals((String)this.type((int)index), (String)"Food", (boolean)true));
                if (slotStack != null) {
                    if (slotStack.func_77973_b() instanceof ItemFood) return null;
                }
                boolean bl6 = true;
                boolean replaceCurr = bl6;
                if (!replaceCurr) return null;
                Integer n7 = (int)index;
                return n7;
            }
            case "block": {
                void index;
                ItemStack itemStack;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray3 = objectArray;
                int n = 0;
                int n8 = objectArray3.length;
                do {
                    void var7_23;
                    if (n >= n8) return null;
                    Object item$iv = objectArray3[n];
                    ++n;
                    void var12_84 = var7_23;
                    var7_23 = var12_84 + true;
                    ItemStack stack = (ItemStack)item$iv;
                    index = var12_84;
                    boolean bl7 = false;
                    itemStack = stack;
                } while (!((item = itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemBlock) || InventoryHelper.INSTANCE.isBlockListBlock((ItemBlock)item) || StringsKt.equals((String)this.type((int)index), (String)"Block", (boolean)true));
                if (slotStack != null) {
                    if (slotStack.func_77973_b() instanceof ItemBlock) return null;
                }
                boolean bl8 = true;
                boolean replaceCurr = bl8;
                if (!replaceCurr) return null;
                Integer n9 = (int)index;
                return n9;
            }
            case "water": {
                void index;
                ItemStack itemStack;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray4 = objectArray;
                int n = 0;
                int n10 = objectArray4.length;
                do {
                    void var7_25;
                    if (n >= n10) return null;
                    Object item$iv = objectArray4[n];
                    ++n;
                    void var12_85 = var7_25;
                    var7_25 = var12_85 + true;
                    ItemStack stack = (ItemStack)item$iv;
                    index = var12_85;
                    boolean bl9 = false;
                    itemStack = stack;
                } while (!((item = itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemBucket) || !((ItemBucket)item).field_77876_a.equals(Blocks.field_150358_i) || StringsKt.equals((String)this.type((int)index), (String)"Water", (boolean)true));
                if (slotStack != null && slotStack.func_77973_b() instanceof ItemBucket) {
                    Item item2 = slotStack.func_77973_b();
                    if (item2 == null) {
                        throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemBucket");
                    }
                    if (((ItemBucket)item2).field_77876_a.equals(Blocks.field_150358_i)) return null;
                }
                boolean bl10 = true;
                boolean replaceCurr = bl10;
                if (!replaceCurr) return null;
                Integer n11 = (int)index;
                return n11;
            }
            case "gapple": {
                void index;
                ItemStack itemStack;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray5 = objectArray;
                int n = 0;
                int n12 = objectArray5.length;
                do {
                    void var7_27;
                    if (n >= n12) return null;
                    Object item$iv = objectArray5[n];
                    ++n;
                    void var12_86 = var7_27;
                    var7_27 = var12_86 + true;
                    ItemStack stack = (ItemStack)item$iv;
                    index = var12_86;
                    boolean bl11 = false;
                    itemStack = stack;
                } while (!((item = itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemAppleGold) || StringsKt.equals((String)this.type((int)index), (String)"Gapple", (boolean)true));
                if (slotStack != null) {
                    if (slotStack.func_77973_b() instanceof ItemAppleGold) return null;
                }
                boolean bl12 = true;
                boolean replaceCurr = bl12;
                if (!replaceCurr) return null;
                Integer n13 = (int)index;
                return n13;
            }
            case "pearl": {
                void index;
                ItemStack itemStack;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray6 = objectArray;
                int n = 0;
                int n14 = objectArray6.length;
                do {
                    void var7_29;
                    if (n >= n14) return null;
                    Object item$iv = objectArray6[n];
                    ++n;
                    void var12_87 = var7_29;
                    var7_29 = var12_87 + true;
                    ItemStack stack = (ItemStack)item$iv;
                    index = var12_87;
                    boolean bl13 = false;
                    itemStack = stack;
                } while (!((item = itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemEnderPearl) || StringsKt.equals((String)this.type((int)index), (String)"Pearl", (boolean)true));
                if (slotStack != null) {
                    if (slotStack.func_77973_b() instanceof ItemEnderPearl) return null;
                }
                boolean bl14 = true;
                boolean replaceCurr = bl14;
                if (!replaceCurr) return null;
                Integer n15 = (int)index;
                return n15;
            }
            case "potion": {
                void index;
                ItemStack stack;
                ItemStack itemStack;
                Item item;
                ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object[] objectArray = itemStackArray;
                boolean $i$f$forEachIndexed = false;
                boolean bl = false;
                Object[] objectArray7 = objectArray;
                int n = 0;
                int n16 = objectArray7.length;
                do {
                    void var7_31;
                    if (n >= n16) return null;
                    Object item$iv = objectArray7[n];
                    ++n;
                    void var12_88 = var7_31;
                    var7_31 = var12_88 + true;
                    stack = (ItemStack)item$iv;
                    index = var12_88;
                    boolean bl15 = false;
                    itemStack = stack;
                } while (!((item = itemStack == null ? null : itemStack.func_77973_b()) instanceof ItemPotion) || !ItemPotion.func_77831_g((int)stack.func_77952_i()) || StringsKt.equals((String)this.type((int)index), (String)"Potion", (boolean)true));
                if (slotStack != null && slotStack.func_77973_b() instanceof ItemPotion) {
                    if (ItemPotion.func_77831_g((int)slotStack.func_77952_i())) return null;
                }
                boolean bl16 = true;
                boolean replaceCurr = bl16;
                if (!replaceCurr) return null;
                Integer n17 = (int)index;
                return n17;
            }
        }
        return null;
    }

    private final Map<Integer, ItemStack> items(int start, int end) {
        Map items = new LinkedHashMap();
        int n = end - 1;
        if (start <= n) {
            int i;
            do {
                ItemStack itemStack;
                if (MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(i = n--).func_75211_c() == null || itemStack.func_77973_b() == null) continue;
                if ((36 <= i ? i < 45 : false) && StringsKt.equals((String)this.type(i), (String)"Ignore", (boolean)true) || System.currentTimeMillis() - ((IItemStack)itemStack).getItemDelay() < 100L) continue;
                Map map = items;
                Integer n2 = i;
                map.put(n2, itemStack);
            } while (i != start);
        }
        return items;
    }

    static /* synthetic */ Map items$default(InvManager invManager, int n, int n2, int n3, Object object) {
        if ((n3 & 1) != 0) {
            n = 0;
        }
        if ((n3 & 2) != 0) {
            n2 = 45;
        }
        return invManager.items(n, n2);
    }

    private final String type(int targetSlot) {
        String string;
        switch (targetSlot) {
            case 0: {
                string = (String)this.sortSlot1Value.get();
                break;
            }
            case 1: {
                string = (String)this.sortSlot2Value.get();
                break;
            }
            case 2: {
                string = (String)this.sortSlot3Value.get();
                break;
            }
            case 3: {
                string = (String)this.sortSlot4Value.get();
                break;
            }
            case 4: {
                string = (String)this.sortSlot5Value.get();
                break;
            }
            case 5: {
                string = (String)this.sortSlot6Value.get();
                break;
            }
            case 6: {
                string = (String)this.sortSlot7Value.get();
                break;
            }
            case 7: {
                string = (String)this.sortSlot8Value.get();
                break;
            }
            case 8: {
                string = (String)this.sortSlot9Value.get();
                break;
            }
            default: {
                string = "";
            }
        }
        return string;
    }

    public static final /* synthetic */ IntegerValue access$getMinDelayValue$p(InvManager $this) {
        return $this.minDelayValue;
    }

    public static final /* synthetic */ IntegerValue access$getMaxDelayValue$p(InvManager $this) {
        return $this.maxDelayValue;
    }

    public static final /* synthetic */ BoolValue access$getInvSpoof$p(InvManager $this) {
        return $this.invSpoof;
    }

    public static final /* synthetic */ ListValue access$getNbtGoalValue$p(InvManager $this) {
        return $this.nbtGoalValue;
    }

    public static final /* synthetic */ BoolValue access$getSortValue$p(InvManager $this) {
        return $this.sortValue;
    }
}

