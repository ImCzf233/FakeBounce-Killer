/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

@ModuleInfo(name="AntiAFK", spacedName="Anti AFK", description="", category=ModuleCategory.MOVEMENT)
public final class AntiAFK
extends Module {
    private final MSTimer swingDelayTimer = new MSTimer();
    private final MSTimer delayTimer = new MSTimer();
    private final ListValue modeValue;
    private final IntegerValue swingDelayValue;
    private final IntegerValue rotationDelayValue;
    private final FloatValue rotationAngleValue;
    private final BoolValue jumpValue;
    private final BoolValue moveValue;
    private final BoolValue rotateValue;
    private final BoolValue swingValue;
    private boolean shouldMove;
    private long randomTimerDelay;

    public AntiAFK() {
        String[] stringArray = new String[]{"Old", "Random", "Custom"};
        this.modeValue = new ListValue("Mode", stringArray, "Random");
        this.swingDelayValue = new IntegerValue("SwingDelay", 100, 0, 1000);
        this.rotationDelayValue = new IntegerValue("RotationDelay", 100, 0, 1000);
        this.rotationAngleValue = new FloatValue("RotationAngle", 1.0f, -180.0f, 180.0f);
        this.jumpValue = new BoolValue("Jump", true);
        this.moveValue = new BoolValue("Move", true);
        this.rotateValue = new BoolValue("Rotate", true);
        this.swingValue = new BoolValue("Swing", true);
        this.randomTimerDelay = 500L;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "old": {
                MinecraftInstance.mc.field_71474_y.field_74351_w.field_74513_e = true;
                if (!this.delayTimer.hasTimePassed(500L)) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70177_z += 180.0f;
                this.delayTimer.reset();
                break;
            }
            case "random": {
                KeyBinding.func_74510_a((int)this.getRandomMoveKeyBind(), (boolean)this.shouldMove);
                if (!this.delayTimer.hasTimePassed(this.randomTimerDelay)) {
                    return;
                }
                this.shouldMove = false;
                this.randomTimerDelay = 500L;
                switch (RandomUtils.nextInt(0, 6)) {
                    case 0: {
                        if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                            MinecraftInstance.mc.field_71439_g.func_70664_aZ();
                        }
                        this.delayTimer.reset();
                        break;
                    }
                    case 1: {
                        if (!MinecraftInstance.mc.field_71439_g.field_82175_bq) {
                            MinecraftInstance.mc.field_71439_g.func_71038_i();
                        }
                        this.delayTimer.reset();
                        break;
                    }
                    case 2: {
                        this.randomTimerDelay = RandomUtils.nextInt(0, 1000);
                        this.shouldMove = true;
                        this.delayTimer.reset();
                        break;
                    }
                    case 3: {
                        MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = RandomUtils.nextInt(0, 9);
                        MinecraftInstance.mc.field_71442_b.func_78765_e();
                        this.delayTimer.reset();
                        break;
                    }
                    case 4: {
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70177_z += RandomUtils.nextFloat(-180.0f, 180.0f);
                        this.delayTimer.reset();
                        break;
                    }
                    case 5: {
                        if (MinecraftInstance.mc.field_71439_g.field_70125_A <= -90.0f || MinecraftInstance.mc.field_71439_g.field_70125_A >= 90.0f) {
                            MinecraftInstance.mc.field_71439_g.field_70125_A = 0.0f;
                        }
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70125_A += RandomUtils.nextFloat(-10.0f, 10.0f);
                        this.delayTimer.reset();
                    }
                }
                break;
            }
            case "custom": {
                if (((Boolean)this.moveValue.get()).booleanValue()) {
                    MinecraftInstance.mc.field_71474_y.field_74351_w.field_74513_e = true;
                }
                if (((Boolean)this.jumpValue.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.field_70122_E) {
                    MinecraftInstance.mc.field_71439_g.func_70664_aZ();
                }
                if (((Boolean)this.rotateValue.get()).booleanValue() && this.delayTimer.hasTimePassed(((Number)this.rotationDelayValue.get()).intValue())) {
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70177_z += ((Number)this.rotationAngleValue.get()).floatValue();
                    if (MinecraftInstance.mc.field_71439_g.field_70125_A <= -90.0f || MinecraftInstance.mc.field_71439_g.field_70125_A >= 90.0f) {
                        MinecraftInstance.mc.field_71439_g.field_70125_A = 0.0f;
                    }
                    entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70125_A += RandomUtils.nextFloat(0.0f, 1.0f) * (float)2 - 1.0f;
                    this.delayTimer.reset();
                }
                if (!((Boolean)this.swingValue.get()).booleanValue() || MinecraftInstance.mc.field_71439_g.field_82175_bq || !this.swingDelayTimer.hasTimePassed(((Number)this.swingDelayValue.get()).intValue())) break;
                MinecraftInstance.mc.field_71439_g.func_71038_i();
                this.swingDelayTimer.reset();
            }
        }
    }

    private final int getRandomMoveKeyBind() {
        switch (RandomUtils.nextInt(0, 4)) {
            case 0: {
                return MinecraftInstance.mc.field_71474_y.field_74366_z.func_151463_i();
            }
            case 1: {
                return MinecraftInstance.mc.field_71474_y.field_74370_x.func_151463_i();
            }
            case 2: {
                return MinecraftInstance.mc.field_71474_y.field_74368_y.func_151463_i();
            }
            case 3: {
                return MinecraftInstance.mc.field_71474_y.field_74351_w.func_151463_i();
            }
        }
        return 0;
    }

    @Override
    public void onDisable() {
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74351_w)) {
            MinecraftInstance.mc.field_71474_y.field_74351_w.field_74513_e = false;
        }
    }
}

