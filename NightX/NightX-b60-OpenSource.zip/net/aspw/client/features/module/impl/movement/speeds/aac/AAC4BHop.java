/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC4BHop
extends SpeedMode {
    private boolean legitHop;

    public AAC4BHop() {
        super("AAC4BHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onEnable() {
        this.legitHop = true;
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onTick() {
        if (MovementUtils.isMoving()) {
            if (this.legitHop) {
                if (AAC4BHop.mc.field_71439_g.field_70122_E) {
                    AAC4BHop.mc.field_71439_g.func_70664_aZ();
                    AAC4BHop.mc.field_71439_g.field_70122_E = false;
                    this.legitHop = false;
                }
                return;
            }
            if (AAC4BHop.mc.field_71439_g.field_70122_E) {
                AAC4BHop.mc.field_71439_g.field_70122_E = false;
                MovementUtils.strafe(0.375f);
                AAC4BHop.mc.field_71439_g.func_70664_aZ();
                AAC4BHop.mc.field_71439_g.field_70181_x = 0.41;
            } else {
                AAC4BHop.mc.field_71439_g.field_71102_ce = 0.0211f;
            }
        } else {
            this.legitHop = true;
        }
    }
}

