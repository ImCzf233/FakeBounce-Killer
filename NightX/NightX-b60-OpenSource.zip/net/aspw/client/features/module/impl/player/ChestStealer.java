/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.random.Random
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.inventory.GuiChest
 *  net.minecraft.inventory.Slot
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0EPacketClickWindow
 *  net.minecraft.network.play.server.S30PacketWindowItems
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.player.InvManager;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraft.util.ResourceLocation;

@ModuleInfo(name="ChestStealer", spacedName="Chest Stealer", description="", category=ModuleCategory.PLAYER)
public final class ChestStealer
extends Module {
    private final IntegerValue maxDelayValue = new IntegerValue(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super("MaxDelay", 80, 0, 400, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int i = ((Number)ChestStealer.access$getMinDelayValue$p(this.this$0).get()).intValue();
            if (i > newValue) {
                this.set(i);
            }
            ChestStealer.access$setNextDelay$p(this.this$0, TimeUtils.randomDelay(((Number)ChestStealer.access$getMinDelayValue$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
        }
    };
    private final IntegerValue minDelayValue = new IntegerValue(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super("MinDelay", 60, 0, 400, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int i = ((Number)ChestStealer.access$getMaxDelayValue$p(this.this$0).get()).intValue();
            if (i < newValue) {
                this.set(i);
            }
            ChestStealer.access$setNextDelay$p(this.this$0, TimeUtils.randomDelay(((Number)this.get()).intValue(), ((Number)ChestStealer.access$getMaxDelayValue$p(this.this$0).get()).intValue()));
        }
    };
    private final BoolValue animationValue = new BoolValue("Animation", false);
    private final BoolValue takeRandomizedValue = new BoolValue("TakeRandomized", true);
    private final BoolValue onlyItemsValue = new BoolValue("OnlyItems", false);
    private final BoolValue noCompassValue = new BoolValue("NoCompass", false);
    private final BoolValue noDuplicateValue = new BoolValue("NoDuplicateNonStackable", false);
    private final BoolValue instantValue = new BoolValue("Instant", false);
    private final BoolValue autoCloseValue = new BoolValue("AutoClose", true);
    private final BoolValue silenceValue = new BoolValue("SilentMode", true);
    private final BoolValue showStringValue = new BoolValue("Silent-ShowString", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getSilenceValue().get();
        }
    }));
    private final BoolValue stillDisplayValue = new BoolValue("Silent-StillDisplay", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getSilenceValue().get();
        }
    }));
    private final IntegerValue autoCloseMaxDelayValue = new IntegerValue(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super("AutoCloseMaxDelay", 5, 0, 400, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int i = ((Number)ChestStealer.access$getAutoCloseMinDelayValue$p(this.this$0).get()).intValue();
            if (i > newValue) {
                this.set(i);
            }
            ChestStealer.access$setNextCloseDelay$p(this.this$0, TimeUtils.randomDelay(((Number)ChestStealer.access$getAutoCloseMinDelayValue$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
        }
    };
    private final IntegerValue autoCloseMinDelayValue = new IntegerValue(this){
        final /* synthetic */ ChestStealer this$0;
        {
            this.this$0 = $receiver;
            super("AutoCloseMinDelay", 5, 0, 400, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int i = ((Number)ChestStealer.access$getAutoCloseMaxDelayValue$p(this.this$0).get()).intValue();
            if (i < newValue) {
                this.set(i);
            }
            ChestStealer.access$setNextCloseDelay$p(this.this$0, TimeUtils.randomDelay(((Number)this.get()).intValue(), ((Number)ChestStealer.access$getAutoCloseMaxDelayValue$p(this.this$0).get()).intValue()));
        }
    };
    private final BoolValue closeOnFullValue = new BoolValue("CloseOnFull", true);
    private final BoolValue chestTitleValue = new BoolValue("ChestTitle", false);
    private final MSTimer delayTimer = new MSTimer();
    private long nextDelay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
    private final MSTimer autoCloseTimer = new MSTimer();
    private long nextCloseDelay = TimeUtils.randomDelay(((Number)this.autoCloseMinDelayValue.get()).intValue(), ((Number)this.autoCloseMaxDelayValue.get()).intValue());
    private int contentReceived;
    private boolean once;

    public final BoolValue getSilenceValue() {
        return this.silenceValue;
    }

    public final BoolValue getShowStringValue() {
        return this.showStringValue;
    }

    public final BoolValue getStillDisplayValue() {
        return this.stillDisplayValue;
    }

    public final int getContentReceived() {
        return this.contentReceived;
    }

    public final void setContentReceived(int n) {
        this.contentReceived = n;
    }

    public final boolean getOnce() {
        return this.once;
    }

    public final void setOnce(boolean bl) {
        this.once = bl;
    }

    @Override
    public void onDisable() {
        this.once = false;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.instantValue.get()).booleanValue() && MinecraftInstance.mc.field_71462_r instanceof GuiChest) {
            GuiScreen guiScreen = MinecraftInstance.mc.field_71462_r;
            if (guiScreen == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.client.gui.inventory.GuiChest");
            }
            GuiChest chest = (GuiChest)guiScreen;
            int rows = chest.field_147018_x * 9;
            int n = 0;
            while (n < rows) {
                int i;
                Slot slot;
                if (!(slot = chest.field_147002_h.func_75139_a(i = n++)).func_75216_d()) continue;
                MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C0EPacketClickWindow(chest.field_147002_h.field_75152_c, i, 0, 1, slot.func_75211_c(), 1));
            }
            MinecraftInstance.mc.field_71439_g.func_71053_j();
        }
        GuiScreen guiScreen = MinecraftInstance.mc.field_71462_r;
        if (guiScreen == null) {
            return;
        }
        GuiScreen screen = guiScreen;
        this.performStealer(screen);
    }

    /*
     * WARNING - void declaration
     */
    public final void performStealer(GuiScreen screen) {
        block27: {
            block28: {
                Intrinsics.checkNotNullParameter((Object)screen, (String)"screen");
                if (this.once && !(screen instanceof GuiChest)) {
                    this.setState(false);
                    return;
                }
                if (!(screen instanceof GuiChest) || !this.delayTimer.hasTimePassed(this.nextDelay)) {
                    this.autoCloseTimer.reset();
                    return;
                }
                if (!this.once && ((Boolean)this.noCompassValue.get()).booleanValue()) {
                    String string;
                    ItemStack itemStack = MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g();
                    if (itemStack == null) {
                        string = null;
                    } else {
                        Item item = itemStack.func_77973_b();
                        string = item == null ? null : item.func_77658_a();
                    }
                    if (string.equals("item.compass")) {
                        return;
                    }
                }
                if (this.once || !((Boolean)this.chestTitleValue.get()).booleanValue()) break block27;
                if (((GuiChest)screen).field_147015_w == null) break block28;
                String string = ((GuiChest)screen).field_147015_w.func_70005_c_();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"screen.lowerChestInventory.name");
                String string2 = string;
                string = new ItemStack((Item)Item.field_150901_e.func_82594_a((Object)new ResourceLocation("minecraft:chest"))).func_82833_r();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"ItemStack(Item.itemRegis\u2026aft:chest\"))).displayName");
                if (string2.equals(string)) break block27;
            }
            return;
        }
        InvManager invManager = Client.INSTANCE.getModuleManager().get(InvManager.class);
        if (invManager == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.InvManager");
        }
        InvManager inventoryCleaner = invManager;
        if (!(this.isEmpty((GuiChest)screen) || ((Boolean)this.closeOnFullValue.get()).booleanValue() && this.getFullInventory())) {
            this.autoCloseTimer.reset();
            if (((Boolean)this.takeRandomizedValue.get()).booleanValue()) {
                List items;
                boolean noLoop = false;
                do {
                    items = new ArrayList();
                    int n = 0;
                    int n2 = ((GuiChest)screen).field_147018_x * 9;
                    while (n < n2) {
                        ItemStack $this$map$iv2;
                        int slotIndex2;
                        Slot slot;
                        if ((slot = (Slot)((GuiChest)screen).field_147002_h.field_75151_b.get(slotIndex2 = n++)).func_75211_c() == null || ((Boolean)this.onlyItemsValue.get()).booleanValue() && slot.func_75211_c().func_77973_b() instanceof ItemBlock) continue;
                        if (((Boolean)this.noDuplicateValue.get()).booleanValue() && slot.func_75211_c().func_77976_d() <= 1) {
                            void $this$mapTo$iv$iv;
                            ItemStack $this$filterTo$iv$iv;
                            ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                            Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                            Object $this$filter$iv = itemStackArray;
                            boolean $i$f$filter = false;
                            Object[] objectArray = $this$filter$iv;
                            Collection destination$iv$iv = new ArrayList();
                            boolean $i$f$filterTo = false;
                            for (void element$iv$iv : $this$filterTo$iv$iv) {
                                ItemStack it = (ItemStack)element$iv$iv;
                                boolean bl = false;
                                if (!(it != null && it.func_77973_b() != null)) continue;
                                destination$iv$iv.add(element$iv$iv);
                            }
                            $this$filter$iv = (List)destination$iv$iv;
                            boolean $i$f$map = false;
                            $this$filterTo$iv$iv = $this$map$iv2;
                            destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv2, (int)10));
                            boolean $i$f$mapTo = false;
                            for (Object item$iv$iv : $this$mapTo$iv$iv) {
                                void it;
                                ItemStack itemStack = (ItemStack)item$iv$iv;
                                Collection collection = destination$iv$iv;
                                boolean bl = false;
                                Item item = it.func_77973_b();
                                Intrinsics.checkNotNull((Object)item);
                                collection.add(item);
                            }
                            if (((List)destination$iv$iv).contains(slot.func_75211_c().func_77973_b())) continue;
                        }
                        if (inventoryCleaner.getState()) {
                            $this$map$iv2 = slot.func_75211_c();
                            Intrinsics.checkNotNullExpressionValue((Object)$this$map$iv2, (String)"slot.stack");
                            if (!inventoryCleaner.isUseful($this$map$iv2, -1)) continue;
                        }
                        Intrinsics.checkNotNullExpressionValue((Object)slot, (String)"slot");
                        items.add(slot);
                    }
                    int randomSlot = Random.Default.nextInt(items.size());
                    Slot slot = (Slot)items.get(randomSlot);
                    this.move((GuiChest)screen, slot);
                    if (this.nextDelay != 0L && !this.delayTimer.hasTimePassed(this.nextDelay)) continue;
                    noLoop = true;
                } while (this.delayTimer.hasTimePassed(this.nextDelay) && !((Collection)items).isEmpty() && !noLoop);
                return;
            }
            int n = 0;
            int n3 = ((GuiChest)screen).field_147018_x * 9;
            while (n < n3) {
                int slotIndex = n++;
                Slot slot = (Slot)((GuiChest)screen).field_147002_h.field_75151_b.get(slotIndex);
                if (!this.delayTimer.hasTimePassed(this.nextDelay) || slot.func_75211_c() == null || ((Boolean)this.onlyItemsValue.get()).booleanValue() && slot.func_75211_c().func_77973_b() instanceof ItemBlock) continue;
                if (((Boolean)this.noDuplicateValue.get()).booleanValue() && slot.func_75211_c().func_77976_d() <= 1) {
                    void $this$mapTo$iv$iv;
                    void $this$map$iv;
                    void $this$filterTo$iv$iv;
                    ItemStack[] slotIndex2 = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                    Intrinsics.checkNotNullExpressionValue((Object)slotIndex2, (String)"mc.thePlayer.inventory.mainInventory");
                    Object $this$filter$iv = slotIndex2;
                    boolean $i$f$filter = false;
                    Object[] $this$map$iv2 = $this$filter$iv;
                    Collection destination$iv$iv = new ArrayList();
                    boolean $i$f$filterTo = false;
                    for (void element$iv$iv : $this$filterTo$iv$iv) {
                        ItemStack it = (ItemStack)element$iv$iv;
                        boolean bl = false;
                        if (!(it != null && it.func_77973_b() != null)) continue;
                        destination$iv$iv.add(element$iv$iv);
                    }
                    $this$filter$iv = (List)destination$iv$iv;
                    boolean $i$f$map = false;
                    $this$filterTo$iv$iv = $this$map$iv;
                    destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv, (int)10));
                    boolean $i$f$mapTo = false;
                    for (Object item$iv$iv : $this$mapTo$iv$iv) {
                        void it;
                        ItemStack itemStack = (ItemStack)item$iv$iv;
                        Collection collection = destination$iv$iv;
                        boolean bl = false;
                        Item item = it.func_77973_b();
                        Intrinsics.checkNotNull((Object)item);
                        collection.add(item);
                    }
                    if (((List)destination$iv$iv).contains(slot.func_75211_c().func_77973_b())) continue;
                }
                if (inventoryCleaner.getState()) {
                    ItemStack itemStack = slot.func_75211_c();
                    Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"slot.stack");
                    if (!inventoryCleaner.isUseful(itemStack, -1)) continue;
                }
                GuiChest guiChest = (GuiChest)screen;
                Intrinsics.checkNotNullExpressionValue((Object)slot, (String)"slot");
                this.move(guiChest, slot);
            }
        } else if (((Boolean)this.autoCloseValue.get()).booleanValue() && ((GuiChest)screen).field_147002_h.field_75152_c == this.contentReceived && this.autoCloseTimer.hasTimePassed(this.nextCloseDelay)) {
            MinecraftInstance.mc.field_71439_g.func_71053_j();
            if (((Boolean)this.silenceValue.get()).booleanValue() && !((Boolean)this.stillDisplayValue.get()).booleanValue()) {
                Client.INSTANCE.getHud().addNotification(new Notification("Closed chest.", Notification.Type.INFO));
            }
            this.nextCloseDelay = TimeUtils.randomDelay(((Number)this.autoCloseMinDelayValue.get()).intValue(), ((Number)this.autoCloseMaxDelayValue.get()).intValue());
            if (this.once) {
                this.once = false;
                this.setState(false);
                return;
            }
        }
    }

    @EventTarget
    private final void onPacket(PacketEvent event) {
        Packet<?> packet = event.getPacket();
        if (packet instanceof S30PacketWindowItems) {
            this.contentReceived = ((S30PacketWindowItems)packet).func_148911_c();
        }
    }

    private final void move(GuiChest screen, Slot slot) {
        screen.func_146984_a(slot, slot.field_75222_d, 0, 1);
        if (((Boolean)this.animationValue.get()).booleanValue()) {
            MinecraftInstance.mc.func_175597_ag().func_78445_c();
        }
        this.delayTimer.reset();
        this.nextDelay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
    }

    /*
     * WARNING - void declaration
     */
    private final boolean isEmpty(GuiChest chest) {
        InvManager invManager = Client.INSTANCE.getModuleManager().get(InvManager.class);
        if (invManager == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.InvManager");
        }
        InvManager inventoryCleaner = invManager;
        int n = 0;
        int n2 = chest.field_147018_x * 9;
        while (n < n2) {
            ItemStack[] itemStackArray;
            int i;
            Slot slot;
            if ((slot = (Slot)chest.field_147002_h.field_75151_b.get(i = n++)).func_75211_c() == null || ((Boolean)this.onlyItemsValue.get()).booleanValue() && slot.func_75211_c().func_77973_b() instanceof ItemBlock) continue;
            if (((Boolean)this.noDuplicateValue.get()).booleanValue() && slot.func_75211_c().func_77976_d() <= 1) {
                void $this$mapTo$iv$iv;
                void $this$map$iv;
                void $this$filterTo$iv$iv;
                itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
                Object $this$filter$iv = itemStackArray;
                boolean $i$f$filter = false;
                Object[] objectArray = $this$filter$iv;
                Collection destination$iv$iv = new ArrayList();
                boolean $i$f$filterTo = false;
                for (void element$iv$iv : $this$filterTo$iv$iv) {
                    ItemStack it = (ItemStack)element$iv$iv;
                    boolean bl = false;
                    if (!(it != null && it.func_77973_b() != null)) continue;
                    destination$iv$iv.add(element$iv$iv);
                }
                $this$filter$iv = (List)destination$iv$iv;
                boolean $i$f$map = false;
                $this$filterTo$iv$iv = $this$map$iv;
                destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv, (int)10));
                boolean $i$f$mapTo = false;
                for (Object item$iv$iv : $this$mapTo$iv$iv) {
                    void it;
                    ItemStack itemStack = (ItemStack)item$iv$iv;
                    Collection collection = destination$iv$iv;
                    boolean bl = false;
                    Item item = it.func_77973_b();
                    Intrinsics.checkNotNull((Object)item);
                    collection.add(item);
                }
                if (((List)destination$iv$iv).contains(slot.func_75211_c().func_77973_b())) continue;
            }
            if (inventoryCleaner.getState()) {
                itemStackArray = slot.func_75211_c();
                Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"slot.stack");
                if (!inventoryCleaner.isUseful((ItemStack)itemStackArray, -1)) continue;
            }
            return false;
        }
        return true;
    }

    private final boolean getFullInventory() {
        boolean bl;
        block1: {
            ItemStack[] itemStackArray = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a;
            Intrinsics.checkNotNullExpressionValue((Object)itemStackArray, (String)"mc.thePlayer.inventory.mainInventory");
            Object[] $this$none$iv = itemStackArray;
            boolean $i$f$none = false;
            for (Object element$iv : $this$none$iv) {
                ItemStack it = (ItemStack)element$iv;
                boolean bl2 = false;
                if (!(it == null)) continue;
                bl = false;
                break block1;
            }
            bl = true;
        }
        return bl;
    }

    public static final /* synthetic */ IntegerValue access$getMinDelayValue$p(ChestStealer $this) {
        return $this.minDelayValue;
    }

    public static final /* synthetic */ void access$setNextDelay$p(ChestStealer $this, long l) {
        $this.nextDelay = l;
    }

    public static final /* synthetic */ IntegerValue access$getMaxDelayValue$p(ChestStealer $this) {
        return $this.maxDelayValue;
    }

    public static final /* synthetic */ IntegerValue access$getAutoCloseMinDelayValue$p(ChestStealer $this) {
        return $this.autoCloseMinDelayValue;
    }

    public static final /* synthetic */ void access$setNextCloseDelay$p(ChestStealer $this, long l) {
        $this.nextCloseDelay = l;
    }

    public static final /* synthetic */ IntegerValue access$getAutoCloseMaxDelayValue$p(ChestStealer $this) {
        return $this.autoCloseMaxDelayValue;
    }
}

