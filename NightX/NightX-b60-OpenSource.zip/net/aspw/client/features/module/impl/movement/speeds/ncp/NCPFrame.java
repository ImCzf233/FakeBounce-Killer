/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.timer.TickTimer;

public class NCPFrame
extends SpeedMode {
    private final TickTimer tickTimer = new TickTimer();
    private int motionTicks;
    private boolean move;

    public NCPFrame() {
        super("NCPFrame");
    }

    @Override
    public void onMotion() {
        if (NCPFrame.mc.field_71439_g.field_71158_b.field_78900_b > 0.0f || NCPFrame.mc.field_71439_g.field_71158_b.field_78902_a > 0.0f) {
            double speed2 = 4.25;
            if (NCPFrame.mc.field_71439_g.field_70122_E) {
                NCPFrame.mc.field_71439_g.func_70664_aZ();
                if (this.motionTicks == 1) {
                    this.tickTimer.reset();
                    if (this.move) {
                        NCPFrame.mc.field_71439_g.field_70159_w = 0.0;
                        NCPFrame.mc.field_71439_g.field_70179_y = 0.0;
                        this.move = false;
                    }
                    this.motionTicks = 0;
                } else {
                    this.motionTicks = 1;
                }
            } else if (!this.move && this.motionTicks == 1 && this.tickTimer.hasTimePassed(5)) {
                NCPFrame.mc.field_71439_g.field_70159_w *= 4.25;
                NCPFrame.mc.field_71439_g.field_70179_y *= 4.25;
                this.move = true;
            }
            if (!NCPFrame.mc.field_71439_g.field_70122_E) {
                MovementUtils.strafe();
            }
            this.tickTimer.update();
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPFrame.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPFrame.mc.field_71439_g.field_70159_w = 0.0;
            NCPFrame.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

