/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPFHop
extends SpeedMode {
    public NCPFHop() {
        super("NCPFHop");
    }

    @Override
    public void onEnable() {
        NCPFHop.mc.field_71428_T.field_74278_d = 1.0866f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        NCPFHop.mc.field_71428_T.field_74278_d = 1.0f;
        super.onDisable();
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPFHop.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPFHop.mc.field_71439_g.field_70159_w = 0.0;
            NCPFHop.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (NCPFHop.mc.field_71439_g.field_70122_E) {
                NCPFHop.mc.field_71439_g.func_70664_aZ();
                NCPFHop.mc.field_71439_g.field_70159_w *= 1.01;
                NCPFHop.mc.field_71439_g.field_70179_y *= 1.01;
                NCPFHop.mc.field_71439_g.field_71102_ce = 0.0223f;
            }
            NCPFHop.mc.field_71439_g.field_70181_x -= 9.9999E-4;
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

