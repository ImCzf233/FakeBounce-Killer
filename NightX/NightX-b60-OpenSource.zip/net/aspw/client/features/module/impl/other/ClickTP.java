/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.renderer.entity.RenderManager
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MovingObjectPosition
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.features.module.impl.other;

import java.util.ArrayList;
import java.util.Arrays;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.pathfinder.Vec3;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.material.Material;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Mouse;

@ModuleInfo(name="ClickTP", spacedName="Click TP", description="", category=ModuleCategory.OTHER)
public class ClickTP
extends Module {
    private final ListValue buttonValue = new ListValue("Button", new String[]{"Left", "Right", "Middle"}, "Middle");
    private int delay;
    private BlockPos endPos;
    private MovingObjectPosition objectPosition;

    @Override
    public void onDisable() {
        this.delay = 0;
        this.endPos = null;
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (ClickTP.mc.field_71462_r == null && Mouse.isButtonDown((int)Arrays.asList(this.buttonValue.getValues()).indexOf(this.buttonValue.get())) && this.delay <= 0) {
            this.endPos = this.objectPosition.func_178782_a();
            if (BlockUtils.getBlock(this.endPos).func_149688_o() == Material.field_151579_a) {
                this.endPos = null;
                return;
            }
            Client.hud.addNotification(new Notification("Successfully Teleported to X: " + this.endPos.func_177958_n() + ", Y: " + this.endPos.func_177956_o() + ", Z: " + this.endPos.func_177952_p(), Notification.Type.SUCCESS));
            this.delay = 6;
        }
        if (this.delay > 0) {
            --this.delay;
        }
        if (this.endPos != null) {
            double endX = (double)this.endPos.func_177958_n() + 0.5;
            double endY = (double)this.endPos.func_177956_o() + 1.0;
            double endZ = (double)this.endPos.func_177952_p() + 0.5;
            new Thread(() -> {
                ArrayList<Vec3> path = MainPathFinder.computePath(new Vec3(ClickTP.mc.field_71439_g.field_70165_t, ClickTP.mc.field_71439_g.field_70163_u, ClickTP.mc.field_71439_g.field_70161_v), new Vec3(endX, endY, endZ));
                for (Vec3 point : path) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true));
                }
                ClickTP.mc.field_71439_g.func_70107_b(endX, endY, endZ);
            }).start();
            if (((Boolean)Client.moduleManager.getModule(Hud.class).getFlagSoundValue().get()).booleanValue()) {
                Client.tipSoundManager.getPopSound().asyncPlay(Client.moduleManager.getPopSoundPower());
            }
            this.endPos = null;
        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent event) {
        this.objectPosition = ClickTP.mc.field_71439_g.func_174822_a(1000.0, event.getPartialTicks());
        if (this.objectPosition.func_178782_a() == null) {
            return;
        }
        int x = this.objectPosition.func_178782_a().func_177958_n();
        int y = this.objectPosition.func_178782_a().func_177956_o();
        int z = this.objectPosition.func_178782_a().func_177952_p();
        if (BlockUtils.getBlock(this.objectPosition.func_178782_a()).func_149688_o() != Material.field_151579_a) {
            RenderManager renderManager = mc.func_175598_ae();
        }
    }
}

