/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPHop
extends SpeedMode {
    public NCPHop() {
        super("NCPHop");
    }

    @Override
    public void onEnable() {
        NCPHop.mc.field_71428_T.field_74278_d = 1.0865f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        NCPHop.mc.field_71428_T.field_74278_d = 1.0f;
        super.onDisable();
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPHop.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPHop.mc.field_71439_g.field_70159_w = 0.0;
            NCPHop.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (NCPHop.mc.field_71439_g.field_70122_E) {
                NCPHop.mc.field_71439_g.func_70664_aZ();
                NCPHop.mc.field_71439_g.field_71102_ce = 0.0223f;
            }
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

