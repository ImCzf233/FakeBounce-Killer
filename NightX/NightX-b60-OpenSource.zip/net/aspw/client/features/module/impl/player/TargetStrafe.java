/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.player;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.movement.LongJump;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;

@ModuleInfo(name="TargetStrafe", spacedName="Target Strafe", description="", category=ModuleCategory.PLAYER)
public final class TargetStrafe
extends Module {
    private final FloatValue range = new FloatValue("Range", 2.5f, 0.1f, 4.0f, "m", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ TargetStrafe this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)this.this$0.getBehind().get() == false;
        }
    }));
    private final ListValue modeValue;
    private final BoolValue safewalk;
    private final BoolValue behind;
    private final BoolValue thirdPerson;
    private final KillAura killAura;
    private final Speed speed;
    private final LongJump longJump;
    private final Flight flight;
    private int direction;
    private int lastView;
    private boolean hasChangedThirdPerson;

    public TargetStrafe() {
        String[] stringArray = new String[]{"Jump", "None"};
        this.modeValue = new ListValue("KeyMode", stringArray, "Jump");
        this.safewalk = new BoolValue("SafeWalk", true);
        this.behind = new BoolValue("Behind", false);
        this.thirdPerson = new BoolValue("ThirdPerson", false);
        this.killAura = Client.INSTANCE.getModuleManager().getModule(KillAura.class);
        this.speed = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        this.longJump = Client.INSTANCE.getModuleManager().getModule(LongJump.class);
        this.flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
        this.direction = 1;
        this.hasChangedThirdPerson = true;
    }

    public final FloatValue getRange() {
        return this.range;
    }

    public final BoolValue getBehind() {
        return this.behind;
    }

    public final BoolValue getThirdPerson() {
        return this.thirdPerson;
    }

    public final KillAura getKillAura() {
        return this.killAura;
    }

    public final Speed getSpeed() {
        return this.speed;
    }

    public final LongJump getLongJump() {
        return this.longJump;
    }

    public final Flight getFlight() {
        return this.flight;
    }

    public final int getDirection() {
        return this.direction;
    }

    public final void setDirection(int n) {
        this.direction = n;
    }

    public final int getLastView() {
        return this.lastView;
    }

    public final void setLastView(int n) {
        this.lastView = n;
    }

    public final boolean getHasChangedThirdPerson() {
        return this.hasChangedThirdPerson;
    }

    public final void setHasChangedThirdPerson(boolean bl) {
        this.hasChangedThirdPerson = bl;
    }

    @Override
    public void onEnable() {
        this.hasChangedThirdPerson = true;
        this.lastView = MinecraftInstance.mc.field_71474_y.field_74320_O;
    }

    @Override
    public String getTag() {
        return (Boolean)this.behind.get() != false ? "Behind" : "Adaptive";
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        block8: {
            block9: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (((Boolean)this.thirdPerson.get()).booleanValue()) {
                    if (this.getCanStrafe()) {
                        if (this.hasChangedThirdPerson) {
                            this.lastView = MinecraftInstance.mc.field_71474_y.field_74320_O;
                        }
                        MinecraftInstance.mc.field_71474_y.field_74320_O = 1;
                        this.hasChangedThirdPerson = false;
                    } else if (!this.hasChangedThirdPerson) {
                        MinecraftInstance.mc.field_71474_y.field_74320_O = this.lastView;
                        this.hasChangedThirdPerson = true;
                    }
                }
                if (event.getEventState() != EventState.PRE) break block8;
                if (MinecraftInstance.mc.field_71439_g.field_70123_F) break block9;
                if (!((Boolean)this.safewalk.get()).booleanValue() || !this.checkVoid()) break block8;
                Flight flight = this.flight;
                Intrinsics.checkNotNull((Object)flight);
                if (flight.getState()) break block8;
            }
            this.direction = -this.direction;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.getCanStrafe()) {
            this.strafe(event, MovementUtils.getSpeed(event.getX(), event.getZ()));
            if (((Boolean)this.safewalk.get()).booleanValue() && this.checkVoid()) {
                Flight flight = this.flight;
                Intrinsics.checkNotNull((Object)flight);
                if (!flight.getState()) {
                    event.setSafeWalk(true);
                }
            }
        }
    }

    public final void strafe(MoveEvent event, double moveSpeed) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        KillAura killAura = this.killAura;
        if ((killAura == null ? null : killAura.getTarget()) == null) {
            return;
        }
        EntityLivingBase target = this.killAura.getTarget();
        EntityLivingBase entityLivingBase = this.killAura.getTarget();
        Intrinsics.checkNotNull((Object)entityLivingBase);
        float rotYaw = RotationUtils.getRotationsEntity(entityLivingBase).getYaw();
        if ((double)MinecraftInstance.mc.field_71439_g.func_70032_d((Entity)target) <= 1.5) {
            MovementUtils.setSpeed(event, moveSpeed, rotYaw, this.direction, 0.0);
        } else {
            MovementUtils.setSpeed(event, moveSpeed, rotYaw, this.direction, 1.0);
        }
        if (((Boolean)this.behind.get()).booleanValue()) {
            EntityLivingBase entityLivingBase2 = target;
            Intrinsics.checkNotNull((Object)entityLivingBase2);
            double xPos = entityLivingBase2.field_70165_t + -Math.sin(Math.toRadians(target.field_70177_z)) * (double)-2;
            double zPos = target.field_70161_v + Math.cos(Math.toRadians(target.field_70177_z)) * (double)-2;
            event.setX(moveSpeed * (double)(-MathHelper.func_76126_a((float)((float)Math.toRadians(RotationUtils.getRotations1(xPos, target.field_70163_u, zPos)[0])))));
            event.setZ(moveSpeed * (double)MathHelper.func_76134_b((float)((float)Math.toRadians(RotationUtils.getRotations1(xPos, target.field_70163_u, zPos)[0]))));
        } else if (MinecraftInstance.mc.field_71439_g.func_70032_d((Entity)target) <= ((Number)this.range.get()).floatValue()) {
            MovementUtils.setSpeed(event, moveSpeed, rotYaw, this.direction, 0.0);
        } else {
            MovementUtils.setSpeed(event, moveSpeed, rotYaw, this.direction, 1.0);
        }
    }

    public final boolean getKeyMode() {
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        String string3 = string2;
        return string3.equals("jump") ? GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A) : (string3.equals("none") ? !(MinecraftInstance.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) || !(MinecraftInstance.mc.field_71439_g.field_71158_b.field_78900_b == 0.0f) : false);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public final boolean getCanStrafe() {
        if (!this.getState()) return false;
        Speed speed2 = this.speed;
        Intrinsics.checkNotNull((Object)speed2);
        if (!speed2.getState()) {
            Flight flight = this.flight;
            Intrinsics.checkNotNull((Object)flight);
            if (!flight.getState()) {
                LongJump longJump = this.longJump;
                Intrinsics.checkNotNull((Object)longJump);
                if (!longJump.getState()) return false;
            }
        }
        KillAura killAura = this.killAura;
        Intrinsics.checkNotNull((Object)killAura);
        if (!killAura.getState()) return false;
        if (this.killAura.getTarget() == null) return false;
        if (MinecraftInstance.mc.field_71439_g.func_70093_af()) return false;
        if (!this.getKeyMode()) return false;
        if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d()) return false;
        if (MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d()) return false;
        if (MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d()) return false;
        if (MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) return false;
        return true;
    }

    private final boolean checkVoid() {
        int n = -1;
        while (n < 1) {
            int x = n++;
            int n2 = -1;
            while (n2 < 1) {
                int z;
                if (!this.isVoid(x, z = n2++)) continue;
                return true;
            }
        }
        return false;
    }

    private final boolean isVoid(int X, int Z) {
        if (MinecraftInstance.mc.field_71439_g.field_70163_u < 0.0) {
            return true;
        }
        for (int off = 0; off < (int)MinecraftInstance.mc.field_71439_g.field_70163_u + 2; off += 2) {
            AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.field_71439_g.func_174813_aQ().func_72317_d((double)X, (double)(-off), (double)Z);
            Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBound\u2026toDouble(), Z.toDouble())");
            AxisAlignedBB bb = axisAlignedBB;
            WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
            Intrinsics.checkNotNull((Object)worldClient);
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            if (entityPlayerSP == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.Entity");
            }
            if (worldClient.func_72945_a((Entity)entityPlayerSP, bb).isEmpty()) {
                continue;
            }
            return false;
        }
        return true;
    }
}

