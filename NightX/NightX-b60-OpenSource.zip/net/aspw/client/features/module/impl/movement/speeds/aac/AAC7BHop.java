/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC7BHop
extends SpeedMode {
    public AAC7BHop() {
        super("AAC7BHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || AAC7BHop.mc.field_71439_g.field_70154_o != null || AAC7BHop.mc.field_71439_g.field_70737_aN > 0) {
            return;
        }
        if (AAC7BHop.mc.field_71439_g.field_70122_E) {
            AAC7BHop.mc.field_71439_g.func_70664_aZ();
            AAC7BHop.mc.field_71439_g.field_70181_x = 0.405;
            AAC7BHop.mc.field_71439_g.field_70159_w *= 1.004;
            AAC7BHop.mc.field_71439_g.field_70179_y *= 1.004;
            return;
        }
        double speed2 = (double)MovementUtils.getSpeed() * 1.0072;
        double yaw = Math.toRadians(AAC7BHop.mc.field_71439_g.field_70177_z);
        AAC7BHop.mc.field_71439_g.field_70159_w = -Math.sin(yaw) * speed2;
        AAC7BHop.mc.field_71439_g.field_70179_y = Math.cos(yaw) * speed2;
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

