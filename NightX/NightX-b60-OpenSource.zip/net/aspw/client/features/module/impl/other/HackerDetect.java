/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockHopper
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import java.util.ArrayList;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockHopper;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

@ModuleInfo(name="HackerDetect", spacedName="Hacker Detect", description="", category=ModuleCategory.OTHER)
public final class HackerDetect
extends Module {
    private final ArrayList<EntityPlayer> hackers = new ArrayList();

    public HackerDetect() {
        this.setState(true);
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() != EventState.PRE) {
            return;
        }
        if (MinecraftInstance.mc.field_71439_g.field_70173_aa <= 105) {
            this.hackers.clear();
            return;
        }
        for (EntityPlayer player : MinecraftInstance.mc.field_71441_e.field_73010_i) {
            int n;
            double lastY;
            double y;
            double yDiff;
            if (player == MinecraftInstance.mc.field_71439_g || player.field_70173_aa < 105 || this.hackers.contains(player)) continue;
            Intrinsics.checkNotNullExpressionValue((Object)player, (String)"player");
            if (AntiBots.Companion.isBot((EntityLivingBase)player) || player.field_71075_bZ.field_75100_b || player.field_71075_bZ.field_75098_d) continue;
            double playerSpeed = this.getBPS((EntityLivingBase)player);
            if ((player.func_71039_bw() || player.func_70632_aY()) && player.field_70122_E && playerSpeed >= 6.5) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using NoSlow!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (player.func_70051_ag() && (player.field_70701_bs < 0.0f || player.field_70701_bs == 0.0f && !(player.field_70702_br == 0.0f))) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using Speed!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (!MinecraftInstance.mc.field_71441_e.func_72945_a((Entity)player, MinecraftInstance.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, player.field_70181_x, 0.0)).isEmpty() && player.field_70181_x > 0.0 && playerSpeed > 10.0) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using Flight!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            double d = yDiff = (y = (double)Math.abs((int)player.field_70163_u)) > (lastY = (double)Math.abs((int)player.field_70137_T)) ? y - lastY : lastY - y;
            if (yDiff > 0.0 && MinecraftInstance.mc.field_71439_g.field_70122_E && player.field_70181_x == -0.0784000015258789) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using Step!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            boolean bl = 5 <= (n = player.field_70737_aN) ? n < 9 : false;
            if (bl && MinecraftInstance.mc.field_71439_g.field_70122_E && player.field_70181_x == -0.0784000015258789 && player.field_70159_w == 0.0 && player.field_70179_y == 0.0) {
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using Anti Velocity!"), Notification.Type.INFO));
                this.hackers.add(player);
            }
            if (!(player.field_70143_R == 0.0f) || player.field_70181_x >= -0.08 || this.InsideBlock(player) || player.field_70122_E || !MinecraftInstance.mc.field_71439_g.func_70090_H()) continue;
            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue);
            if (((Boolean)boolValue.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            Client.INSTANCE.getHud().addNotification(new Notification(Intrinsics.stringPlus((String)player.func_70005_c_(), (Object)" is using No Fall!"), Notification.Type.INFO));
            this.hackers.add(player);
        }
    }

    public final int getBPS(EntityLivingBase entityIn) {
        Intrinsics.checkNotNullParameter((Object)entityIn, (String)"entityIn");
        double bps = this.getLastDist(entityIn) * 10.0;
        return (int)bps;
    }

    public final double getLastDist(EntityLivingBase entIn) {
        Intrinsics.checkNotNullParameter((Object)entIn, (String)"entIn");
        double xDist = entIn.field_70165_t - entIn.field_70169_q;
        double zDist = entIn.field_70161_v - entIn.field_70166_s;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public final boolean InsideBlock(EntityPlayer player) {
        Intrinsics.checkNotNullParameter((Object)player, (String)"player");
        int n = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72340_a);
        int n2 = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72336_d) + 1;
        while (n < n2) {
            int x = n++;
            int n3 = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72338_b);
            int n4 = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72337_e) + 1;
            while (n3 < n4) {
                int y = n3++;
                int n5 = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72339_c);
                int n6 = MathHelper.func_76128_c((double)player.func_174813_aQ().field_72334_f) + 1;
                while (n5 < n6) {
                    int z;
                    Block block;
                    if ((block = MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z = n5++)).func_177230_c()) == null || block instanceof BlockAir) continue;
                    WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
                    if (worldClient == null) {
                        throw new NullPointerException("null cannot be cast to non-null type net.minecraft.world.World");
                    }
                    AxisAlignedBB boundingBox = block.func_180640_a((World)worldClient, new BlockPos(x, y, z), MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)));
                    if (block instanceof BlockHopper) {
                        boundingBox = new AxisAlignedBB((double)x, (double)y, (double)z, (double)(x + 1), (double)(y + 1), (double)(z + 1));
                    }
                    if (boundingBox == null || !player.func_174813_aQ().func_72326_a(boundingBox)) continue;
                    return true;
                }
            }
        }
        return false;
    }
}

