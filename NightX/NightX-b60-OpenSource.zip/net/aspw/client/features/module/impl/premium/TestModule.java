/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.premium;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.connection.LoginID;

@ModuleInfo(name="TestModule", spacedName="Test Module", description="", category=ModuleCategory.PREMIUM)
public final class TestModule
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!LoginID.INSTANCE.isPremium()) {
            this.chat("You are not using NightX Premium Account!");
            this.setState(false);
            return;
        }
    }
}

