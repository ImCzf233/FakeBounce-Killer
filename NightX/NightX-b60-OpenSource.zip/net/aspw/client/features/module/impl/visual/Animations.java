/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 */
package net.aspw.client.features.module.impl.visual;

import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.Animations;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;

@ModuleInfo(name="Animations", description="", category=ModuleCategory.VISUAL, onlyEnable=true, forceNoSound=true, array=false)
public final class Animations
extends Module {
    public static final Companion Companion = new Companion(null);
    @JvmField
    public static final ListValue Sword;
    @JvmField
    public static final ListValue swingAnimValue;
    @JvmField
    public static final ListValue tabAnimations;
    @JvmField
    public static final BoolValue oldAnimations;
    @JvmField
    public static final BoolValue smoothSwing;
    @JvmField
    public static final BoolValue cancelEquip;
    @JvmField
    public static final BoolValue blockingOnly;
    @JvmField
    public static final FloatValue scale;
    @JvmField
    public static final FloatValue itemFov;
    @JvmField
    public static final FloatValue itemPosX;
    @JvmField
    public static final FloatValue itemPosY;
    @JvmField
    public static final FloatValue itemPosZ;
    @JvmField
    public static final FloatValue blockPosX;
    @JvmField
    public static final FloatValue blockPosY;
    @JvmField
    public static final FloatValue blockPosZ;
    @JvmField
    public static final IntegerValue SpeedSwing;

    static {
        String[] stringArray = new String[]{"1.8", "Hide", "Swing", "Old", "Push", "Dash", "Slash", "Slide", "Swank", "Swang", "Swonk", "Stella", "Small", "Edit", "Float", "Remix", "Winter", "Xiv", "Reverse", "Leaked", "Aqua", "Astolfo", "Moon", "MoonPush", "Smooth", "Jigsaw", "Sigma3", "Sigma4"};
        Sword = new ListValue("Mode", stringArray, "Swing");
        stringArray = new String[]{"Vanilla", "Flux"};
        swingAnimValue = new ListValue("Swing-Animation", stringArray, "Vanilla");
        stringArray = new String[]{"None", "Zoom", "Slide"};
        tabAnimations = new ListValue("Tab-Animation", stringArray, "None");
        oldAnimations = new BoolValue("Old-Animations", false);
        smoothSwing = new BoolValue("Smooth-Swing", false);
        cancelEquip = new BoolValue("CancelEquip", false);
        blockingOnly = new BoolValue("BlockingOnly", true, (Function0<Boolean>)((Function0)Companion.blockingOnly.1.INSTANCE));
        scale = new FloatValue("Scale", 0.0f, -0.5f, 0.5f);
        itemFov = new FloatValue("Fov", 0.0f, -5.0f, 5.0f);
        itemPosX = new FloatValue("ItemPos-X", 0.0f, -1.0f, 1.0f);
        itemPosY = new FloatValue("ItemPos-Y", 0.0f, -1.0f, 1.0f);
        itemPosZ = new FloatValue("ItemPos-Z", 0.0f, -1.0f, 1.0f);
        blockPosX = new FloatValue("BlockPos-X", 0.0f, -1.0f, 1.0f);
        blockPosY = new FloatValue("BlockPos-Y", 0.0f, -1.0f, 1.0f);
        blockPosZ = new FloatValue("BlockPos-Z", 0.0f, -1.0f, 1.0f);
        SpeedSwing = new IntegerValue("Swing-Speed", 0, -15, 4);
    }

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

