/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function1
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.client.network.NetHandlerPlayClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.functions.Function1;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.PushOutEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

@ModuleInfo(name="Phase", description="", category=ModuleCategory.PLAYER)
public class Phase
extends Module {
    public final ListValue modeValue = new ListValue("Mode", new String[]{"Vanilla", "Skip", "Spartan", "Clip", "AAC3.5.0", "AACv4", "Vulcan", "Packetless", "Redesky", "SmartVClip"}, "Packetless");
    private final TickTimer tickTimer = new TickTimer();
    private final TickTimer mineplexTickTimer = new TickTimer();
    private boolean mineplexClip;
    private boolean noRot;
    private int stage;

    @Override
    public void onEnable() {
        this.stage = 0;
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            Phase.mc.field_71428_T.field_74278_d = 0.1f;
        }
    }

    @Override
    public void onDisable() {
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            Phase.mc.field_71428_T.field_74278_d = 1.0f;
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("aacv4")) {
            switch (this.stage) {
                case 1: {
                    Phase.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u + -1.0E-8, Phase.mc.field_71439_g.field_70161_v, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A, false));
                    Phase.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 1.0, Phase.mc.field_71439_g.field_70161_v, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A, false));
                    break;
                }
                case 3: {
                    this.setState(false);
                }
            }
            ++this.stage;
            return;
        }
        if (((String)this.modeValue.get()).equalsIgnoreCase("redesky")) {
            switch (this.stage) {
                case 0: {
                    Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 1.0E-8, Phase.mc.field_71439_g.field_70161_v);
                    Phase.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 1.0E-8, Phase.mc.field_71439_g.field_70161_v, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A, false));
                    break;
                }
                case 1: {
                    Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 1.0, Phase.mc.field_71439_g.field_70161_v);
                    Phase.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 1.0, Phase.mc.field_71439_g.field_70161_v, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A, false));
                    break;
                }
                case 3: {
                    this.setState(false);
                }
            }
            ++this.stage;
            return;
        }
        boolean isInsideBlock2 = BlockUtils.collideBlockIntersects(Phase.mc.field_71439_g.func_174813_aQ(), (Function1<? super Block, Boolean>)((Function1)block -> !(block instanceof BlockAir)));
        if (isInsideBlock2 && !((String)this.modeValue.get()).equalsIgnoreCase("Packetless") && !((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip")) {
            Phase.mc.field_71439_g.field_70145_X = true;
            Phase.mc.field_71439_g.field_70181_x = 0.0;
            Phase.mc.field_71439_g.field_70122_E = true;
        }
        NetHandlerPlayClient netHandlerPlayClient = mc.func_147114_u();
        switch (((String)this.modeValue.get()).toLowerCase()) {
            case "vanilla": {
                if (!Phase.mc.field_71439_g.field_70122_E || !this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2 && !Phase.mc.field_71439_g.func_70093_af()) break;
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u + 0.2, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t + 0.5, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + 0.5, true));
                double yaw = Math.toRadians(Phase.mc.field_71439_g.field_70177_z);
                double x = -Math.sin(yaw) * 0.04;
                double z = Math.cos(yaw) * 0.04;
                Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t + x, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + z);
                this.tickTimer.reset();
                break;
            }
            case "skip": {
                if (!Phase.mc.field_71439_g.field_70122_E || !this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2 && !Phase.mc.field_71439_g.func_70093_af()) break;
                double direction = MovementUtils.getDirection();
                double posX = -Math.sin(direction) * 0.3;
                double posZ = Math.cos(direction) * 0.3;
                for (int i = 0; i < 3; ++i) {
                    mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u + 0.06, Phase.mc.field_71439_g.field_70161_v, true));
                    mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t + posX * (double)i, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + posZ * (double)i, true));
                }
                Phase.mc.field_71439_g.func_174826_a(Phase.mc.field_71439_g.func_174813_aQ().func_72317_d(posX, 0.0, posZ));
                Phase.mc.field_71439_g.func_70634_a(Phase.mc.field_71439_g.field_70165_t + posX, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + posZ);
                this.tickTimer.reset();
                break;
            }
            case "spartan": {
                if (!Phase.mc.field_71439_g.field_70122_E || !this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2 && !Phase.mc.field_71439_g.func_70093_af()) break;
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 0.2, Phase.mc.field_71439_g.field_70161_v, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(0.5, 0.0, 0.5, true));
                netHandlerPlayClient.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t + 0.5, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + 0.5, true));
                double yaw = Math.toRadians(Phase.mc.field_71439_g.field_70177_z);
                double x = -Math.sin(yaw) * 0.04;
                double z = Math.cos(yaw) * 0.04;
                Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t + x, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + z);
                this.tickTimer.reset();
                break;
            }
            case "clip": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2 && !Phase.mc.field_71439_g.func_70093_af()) break;
                double yaw = Math.toRadians(Phase.mc.field_71439_g.field_70177_z);
                double oldX = Phase.mc.field_71439_g.field_70165_t;
                double oldZ = Phase.mc.field_71439_g.field_70161_v;
                for (int i = 1; i <= 10; ++i) {
                    double z;
                    double x = -Math.sin(yaw) * (double)i;
                    if (!(BlockUtils.getBlock(new BlockPos(oldX + x, Phase.mc.field_71439_g.field_70163_u, oldZ + (z = Math.cos(yaw) * (double)i))) instanceof BlockAir) || !(BlockUtils.getBlock(new BlockPos(oldX + x, Phase.mc.field_71439_g.field_70163_u + 1.0, oldZ + z)) instanceof BlockAir)) continue;
                    Phase.mc.field_71439_g.func_70107_b(oldX + x, Phase.mc.field_71439_g.field_70163_u, oldZ + z);
                    break;
                }
                this.tickTimer.reset();
                break;
            }
            case "aac3.5.0": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2 && !Phase.mc.field_71439_g.func_70093_af()) break;
                double yaw = Math.toRadians(Phase.mc.field_71439_g.field_70177_z);
                double oldX = Phase.mc.field_71439_g.field_70165_t;
                double oldZ = Phase.mc.field_71439_g.field_70161_v;
                double x = -Math.sin(yaw);
                double z = Math.cos(yaw);
                Phase.mc.field_71439_g.func_70107_b(oldX + x, Phase.mc.field_71439_g.field_70163_u, oldZ + z);
                this.tickTimer.reset();
                break;
            }
            case "vulcan": {
                if (!this.tickTimer.hasTimePassed(2) || !Phase.mc.field_71439_g.field_70123_F || isInsideBlock2) break;
                double yaw = Math.toRadians(Phase.mc.field_71439_g.field_70177_z);
                double oldX = Phase.mc.field_71439_g.field_70165_t;
                double oldZ = Phase.mc.field_71439_g.field_70161_v;
                double x = -Math.sin(yaw);
                double z = Math.cos(yaw);
                Phase.mc.field_71439_g.func_70107_b(oldX + x, Phase.mc.field_71439_g.field_70163_u, oldZ + z);
                Phase.mc.field_71439_g.field_70145_X = true;
                this.tickTimer.reset();
                break;
            }
            case "smartvclip": {
                boolean cageCollision = Phase.mc.field_71441_e.func_180495_p(new BlockPos((Entity)Phase.mc.field_71439_g).func_177981_b(3)).func_177230_c() != Blocks.field_150350_a && Phase.mc.field_71441_e.func_180495_p(new BlockPos((Entity)Phase.mc.field_71439_g).func_177977_b()).func_177230_c() != Blocks.field_150350_a;
                boolean bl = this.noRot = Phase.mc.field_71439_g.field_70173_aa >= 0 && Phase.mc.field_71439_g.field_70173_aa <= 40 && cageCollision;
                if (Phase.mc.field_71439_g.field_70173_aa < 20 || Phase.mc.field_71439_g.field_70173_aa >= 40 || !cageCollision) break;
                mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 4.0, Phase.mc.field_71439_g.field_70161_v, false));
                Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u - 4.0, Phase.mc.field_71439_g.field_70161_v);
                break;
            }
            case "redesky": {
                this.setState(false);
                break;
            }
            case "redesky2": {
                this.setState(false);
            }
        }
        this.tickTimer.update();
    }

    @EventTarget
    public void onBlockBB(BlockBBEvent event) {
        if (Phase.mc.field_71439_g != null && BlockUtils.collideBlockIntersects(Phase.mc.field_71439_g.func_174813_aQ(), (Function1<? super Block, Boolean>)((Function1)block -> !(block instanceof BlockAir))) && event.getBoundingBox() != null && event.getBoundingBox().field_72337_e > Phase.mc.field_71439_g.func_174813_aQ().field_72338_b && !((String)this.modeValue.get()).equalsIgnoreCase("Packetless") && !((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip")) {
            AxisAlignedBB axisAlignedBB = event.getBoundingBox();
            event.setBoundingBox(new AxisAlignedBB(axisAlignedBB.field_72336_d, Phase.mc.field_71439_g.func_174813_aQ().field_72338_b, axisAlignedBB.field_72334_f, axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c));
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            float yaw;
            C03PacketPlayer packetPlayer = (C03PacketPlayer)packet;
            if (((String)this.modeValue.get()).equalsIgnoreCase("AAC3.5.0")) {
                yaw = (float)MovementUtils.getDirection();
                packetPlayer.field_149479_a -= (double)MathHelper.func_76126_a((float)yaw) * 1.0E-8;
                packetPlayer.field_149478_c += (double)MathHelper.func_76134_b((float)yaw) * 1.0E-8;
            }
            if (((String)this.modeValue.get()).equalsIgnoreCase("Vulcan")) {
                yaw = (float)MovementUtils.getDirection();
                packetPlayer.field_149479_a -= (double)MathHelper.func_76126_a((float)yaw) * 8.0E-8;
                packetPlayer.field_149478_c += (double)MathHelper.func_76134_b((float)yaw) * 8.0E-8;
            }
            if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot && packetPlayer.field_149481_i) {
                event.cancelEvent();
            }
        }
        if (packet instanceof C0BPacketEntityAction && ((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.cancelEvent();
        }
    }

    @EventTarget
    private void onMove(MoveEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("packetless")) {
            if (Phase.mc.field_71439_g.field_70123_F) {
                this.mineplexClip = true;
            }
            if (!this.mineplexClip) {
                return;
            }
            this.mineplexTickTimer.update();
            event.setX(0.0);
            event.setZ(0.0);
            if (this.mineplexTickTimer.hasTimePassed(3)) {
                this.mineplexTickTimer.reset();
                this.mineplexClip = false;
            } else if (this.mineplexTickTimer.hasTimePassed(1)) {
                double offset = this.mineplexTickTimer.hasTimePassed(2) ? 1.6 : 0.06;
                double direction = MovementUtils.getDirection();
                Phase.mc.field_71439_g.func_70107_b(Phase.mc.field_71439_g.field_70165_t + -Math.sin(direction) * offset, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + Math.cos(direction) * offset);
            }
        }
        if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.zeroXZ();
        }
    }

    @EventTarget
    public void onPushOut(PushOutEvent event) {
        event.cancelEvent();
    }

    @EventTarget
    public void onJump(JumpEvent event) {
        if (((String)this.modeValue.get()).equalsIgnoreCase("SmartVClip") && this.noRot) {
            event.cancelEvent();
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

