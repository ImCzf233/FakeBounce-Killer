/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.random.Random
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 */
package net.aspw.client.features.module.impl.combat;

import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.extensions.PlayerExtensionKt;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

@ModuleInfo(name="AimAssist", spacedName="Aim Assist", description="", category=ModuleCategory.COMBAT)
public final class AimAssist
extends Module {
    private final FloatValue rangeValue = new FloatValue("Range", 1000.0f, 1.0f, 1000.0f, "m");
    private final FloatValue turnSpeedValue = new FloatValue("TurnSpeed", 180.0f, 1.0f, 180.0f, "\u00b0");
    private final FloatValue fovValue = new FloatValue("FOV", 180.0f, 1.0f, 180.0f, "\u00b0");
    private final BoolValue centerValue = new BoolValue("Center", true);
    private final BoolValue lockValue = new BoolValue("Lock", true);
    private final BoolValue onClickValue = new BoolValue("OnClick", false);
    private final BoolValue jitterValue = new BoolValue("Jitter", false);
    private final MSTimer clickTimer = new MSTimer();

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    @EventTarget
    public final void onStrafe(StrafeEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71474_y.field_74312_F.func_151470_d()) {
            this.clickTimer.reset();
        }
        if (((Boolean)this.onClickValue.get()).booleanValue() && this.clickTimer.hasTimePassed(1L)) {
            return;
        }
        v0 = MinecraftInstance.mc.field_71439_g;
        if (v0 == null) {
            return;
        }
        player = v0;
        range = ((Number)this.rangeValue.get()).floatValue();
        var6_4 /* !! */  = MinecraftInstance.mc.field_71441_e.field_72996_f;
        Intrinsics.checkNotNullExpressionValue((Object)var6_4 /* !! */ , (String)"mc.theWorld.loadedEntityList");
        var6_4 /* !! */  = var6_4 /* !! */ ;
        $i$f$filter = false;
        var8_7 = $this$filter$iv;
        destination$iv$iv = new ArrayList<E>();
        $i$f$filterTo = false;
        for (T element$iv$iv : $this$filterTo$iv$iv) {
            it = (Entity)element$iv$iv;
            $i$a$-filter-AimAssist$onStrafe$entity$1 = false;
            if (!EntityUtils.isSelected(it, true) || !player.func_70685_l(it)) ** GOTO lbl-1000
            v1 = (Entity)player;
            Intrinsics.checkNotNullExpressionValue((Object)it, (String)"it");
            if (PlayerExtensionKt.getDistanceToEntityBox(v1, it) <= (double)range && RotationUtils.getRotationDifference(it) <= (double)((Number)this.fovValue.get()).floatValue()) {
                v2 = true;
            } else lbl-1000:
            // 2 sources

            {
                v2 = false;
            }
            if (!v2) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        $this$filter$iv = (List)destination$iv$iv;
        $i$f$minByOrNull = false;
        iterator$iv = $this$minByOrNull$iv.iterator();
        if (!iterator$iv.hasNext()) {
            v3 = null;
        } else {
            minElem$iv = iterator$iv.next();
            if (!iterator$iv.hasNext()) {
                v3 = minElem$iv;
            } else {
                it = (Entity)minElem$iv;
                $i$a$-minByOrNull-AimAssist$onStrafe$entity$2 = false;
                minValue$iv = RotationUtils.getRotationDifference(it);
                do {
                    e$iv = iterator$iv.next();
                    it = (Entity)e$iv;
                    $i$a$-minByOrNull-AimAssist$onStrafe$entity$2 = false;
                    v$iv = RotationUtils.getRotationDifference(it);
                    if (Double.compare(minValue$iv, v$iv) <= 0) continue;
                    minElem$iv = e$iv;
                    minValue$iv = v$iv;
                } while (iterator$iv.hasNext());
                v3 = minElem$iv;
            }
        }
        var5_23 = v3;
        if (var5_23 == null) {
            return;
        }
        entity = var5_23;
        if (!((Boolean)this.lockValue.get()).booleanValue() && RotationUtils.isFaced(entity, range)) {
            return;
        }
        boundingBox = entity.func_174813_aQ();
        if (((Boolean)this.centerValue.get()).booleanValue()) {
            v4 = RotationUtils.getCenter(boundingBox);
            if (v4 == null) {
                return;
            }
            v5 = RotationUtils.toRotation(v4, true);
        } else {
            v6 = RotationUtils.searchCenter(boundingBox, false, false, true, false, range);
            v7 /* !! */  = v6 == null ? null : v6.getRotation();
            v5 = v7 /* !! */ ;
            Intrinsics.checkNotNull((Object)v7 /* !! */ );
        }
        destinationRotation = v5;
        iterator$iv = RotationUtils.limitAngleChange(PlayerExtensionKt.getRotation((Entity)player), destinationRotation, (float)(((Number)this.turnSpeedValue.get()).doubleValue() + Math.random()));
        Intrinsics.checkNotNullExpressionValue((Object)iterator$iv, (String)"limitAngleChange(\n      \u2026om()).toFloat()\n        )");
        rotation = iterator$iv;
        rotation.toPlayer((EntityPlayer)player);
        if (((Boolean)this.jitterValue.get()).booleanValue()) {
            yaw = Random.Default.nextBoolean();
            pitch = Random.Default.nextBoolean();
            yawNegative = Random.Default.nextBoolean();
            pitchNegative = Random.Default.nextBoolean();
            if (yaw) {
                player.field_70177_z = player.field_70177_z + (yawNegative != false ? -RandomUtils.nextFloat(0.0f, 1.0f) : RandomUtils.nextFloat(0.0f, 1.0f));
            }
            if (pitch) {
                player.field_70125_A = player.field_70125_A + (pitchNegative != false ? -RandomUtils.nextFloat(0.0f, 1.0f) : RandomUtils.nextFloat(0.0f, 1.0f));
                if (player.field_70125_A > 90.0f) {
                    player.field_70125_A = 90.0f;
                } else if (player.field_70125_A < -90.0f) {
                    player.field_70125_A = -90.0f;
                }
            }
        }
    }
}

