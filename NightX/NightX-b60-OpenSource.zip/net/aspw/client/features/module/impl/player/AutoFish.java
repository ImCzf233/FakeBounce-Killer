/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemFishingRod
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.minecraft.item.ItemFishingRod;

@ModuleInfo(name="AutoFish", spacedName="Auto Fish", description="", category=ModuleCategory.PLAYER)
public final class AutoFish
extends Module {
    private final MSTimer rodOutTimer = new MSTimer();

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g.func_70694_bm() == null || !(MinecraftInstance.mc.field_71439_g.func_70694_bm().func_77973_b() instanceof ItemFishingRod)) {
            return;
        }
        if (this.rodOutTimer.hasTimePassed(500L) && MinecraftInstance.mc.field_71439_g.field_71104_cf == null || MinecraftInstance.mc.field_71439_g.field_71104_cf != null && MinecraftInstance.mc.field_71439_g.field_71104_cf.field_70159_w == 0.0 && MinecraftInstance.mc.field_71439_g.field_71104_cf.field_70179_y == 0.0 && !(MinecraftInstance.mc.field_71439_g.field_71104_cf.field_70181_x == 0.0)) {
            MinecraftInstance.mc.func_147121_ag();
            this.rodOutTimer.reset();
        }
    }
}

