/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MouseUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Mouse;

@ModuleInfo(name="GodBridge", spacedName="God Bridge", description="", category=ModuleCategory.PLAYER)
public final class GodBridge
extends Module {
    private final FloatValue dl = new FloatValue("Delay", 0.0f, 0.0f, 10.0f);
    private final BoolValue md = new BoolValue("MouseDown", true);
    private long l;
    private int f;
    private MovingObjectPosition lm;
    private BlockPos lp;

    @EventTarget
    public final void onRender(Render3DEvent event) {
        block5: {
            long n;
            Block b;
            BlockPos pos;
            MovingObjectPosition m;
            ItemStack i;
            block7: {
                block6: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    if (MinecraftInstance.mc.field_71462_r != null || MinecraftInstance.mc.field_71439_g.field_71075_bZ.field_75100_b || (i = MinecraftInstance.mc.field_71439_g.func_70694_bm()) == null || !(i.func_77973_b() instanceof ItemBlock) || ((m = MinecraftInstance.mc.field_71476_x) == null || m.field_72313_a != MovingObjectPosition.MovingObjectType.BLOCK || m.field_178784_b == EnumFacing.UP || m.field_178784_b == EnumFacing.DOWN) && m.field_178784_b != EnumFacing.NORTH && m.field_178784_b != EnumFacing.EAST && m.field_178784_b != EnumFacing.SOUTH && m.field_178784_b != EnumFacing.WEST) break block5;
                    if (this.lm == null || !((double)this.f < (double)((Number)this.dl.get()).floatValue())) break block6;
                    ++this.f;
                    break block5;
                }
                this.lm = m;
                pos = m.func_178782_a();
                if (this.lp == null) break block7;
                int n2 = pos.func_177958_n();
                BlockPos blockPos = this.lp;
                Intrinsics.checkNotNull((Object)blockPos);
                if (n2 != blockPos.func_177958_n()) break block7;
                int n3 = pos.func_177956_o();
                BlockPos blockPos2 = this.lp;
                Intrinsics.checkNotNull((Object)blockPos2);
                if (n3 != blockPos2.func_177956_o()) break block7;
                int n4 = pos.func_177952_p();
                BlockPos blockPos3 = this.lp;
                Intrinsics.checkNotNull((Object)blockPos3);
                if (n4 == blockPos3.func_177952_p()) break block5;
            }
            if (!((b = MinecraftInstance.mc.field_71441_e.func_180495_p(pos).func_177230_c()) == null || b == Blocks.field_150350_a || b instanceof BlockLiquid || ((Boolean)this.md.get()).booleanValue() && !Mouse.isButtonDown((int)1) || (n = System.currentTimeMillis()) - this.l < 25L)) {
                this.l = n;
                if (MinecraftInstance.mc.field_71442_b.func_178890_a(MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71441_e, i, pos, m.field_178784_b, m.field_72307_f)) {
                    MouseUtils.INSTANCE.setMouseButtonState(1, true);
                    MinecraftInstance.mc.field_71439_g.func_71038_i();
                    MinecraftInstance.mc.func_175597_ag().func_78444_b();
                    MouseUtils.INSTANCE.setMouseButtonState(1, false);
                    this.lp = pos;
                    this.f = 0;
                }
            }
        }
    }
}

