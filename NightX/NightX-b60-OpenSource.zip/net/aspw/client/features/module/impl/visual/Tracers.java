/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.Vec3
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="Tracers", description="", category=ModuleCategory.VISUAL, array=false)
public final class Tracers
extends Module {
    private final ListValue colorMode;
    private final FloatValue thicknessValue;
    private final IntegerValue colorRedValue;
    private final IntegerValue colorGreenValue;
    private final IntegerValue colorBlueValue;
    private final BoolValue directLineValue;
    private final ListValue fovModeValue;
    private final FloatValue fovValue;

    public Tracers() {
        String[] stringArray = new String[]{"Custom", "DistanceColor", "Rainbow"};
        this.colorMode = new ListValue("Color", stringArray, "Custom");
        this.thicknessValue = new FloatValue("Thickness", 1.0f, 1.0f, 5.0f);
        this.colorRedValue = new IntegerValue("R", 200, 0, 255);
        this.colorGreenValue = new IntegerValue("G", 0, 0, 255);
        this.colorBlueValue = new IntegerValue("B", 255, 0, 255);
        this.directLineValue = new BoolValue("Directline", false);
        stringArray = new String[]{"All", "Back", "Front"};
        this.fovModeValue = new ListValue("FOV-Mode", stringArray, "All");
        this.fovValue = new FloatValue("FOV", 180.0f, 0.0f, 180.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Tracers this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)Tracers.access$getFovModeValue$p(this.this$0).get()), (String)"all", (boolean)true);
            }
        }));
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        List list;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)((Number)this.thicknessValue.get()).floatValue());
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glBegin((int)1);
        if (StringsKt.equals((String)((String)this.fovModeValue.get()), (String)"all", (boolean)true)) {
            list = MinecraftInstance.mc.field_71441_e.field_72996_f;
        } else {
            void $this$filterTo$iv$iv;
            List list2 = MinecraftInstance.mc.field_71441_e.field_72996_f;
            Intrinsics.checkNotNullExpressionValue((Object)list2, (String)"mc.theWorld.loadedEntityList");
            Iterable $this$filter$iv = list2;
            boolean $i$f$filter = false;
            Iterable iterable = $this$filter$iv;
            Collection destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                Entity it = (Entity)element$iv$iv;
                boolean bl = false;
                boolean bl2 = StringsKt.equals((String)((String)this.fovModeValue.get()), (String)"back", (boolean)true) ? RotationUtils.getRotationBackDifference(it) <= (double)((Number)this.fovValue.get()).floatValue() : RotationUtils.getRotationDifference(it) <= (double)((Number)this.fovValue.get()).floatValue();
                if (!bl2) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            list = (List)destination$iv$iv;
        }
        for (Entity entity : list) {
            if (entity == null || entity.equals(MinecraftInstance.mc.field_71439_g) || !EntityUtils.isSelected(entity, false)) continue;
            int dist = (int)(MinecraftInstance.mc.field_71439_g.func_70032_d(entity) * (float)2);
            if (dist > 255) {
                dist = 255;
            }
            String string = (String)this.colorMode.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            String colorMode = string2;
            Color color = EntityUtils.isFriend(entity) ? new Color(0, 0, 255, 150) : (colorMode.equals("custom") ? new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue(), 150) : (colorMode.equals("distancecolor") ? new Color(255 - dist, dist, 0, 150) : (colorMode.equals("rainbow") ? ColorUtils.rainbow() : new Color(255, 255, 255, 150))));
            this.drawTraces(entity, color, (Boolean)this.directLineValue.get() == false);
        }
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GlStateManager.func_179117_G();
    }

    public final void drawTraces(Entity entity, Color color, boolean drawHeight) {
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        Intrinsics.checkNotNullParameter((Object)color, (String)"color");
        double x = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78725_b;
        double y = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78726_c;
        double z = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78723_d;
        Vec3 eyeVector = new Vec3(0.0, 0.0, 1.0).func_178789_a((float)(-Math.toRadians(MinecraftInstance.mc.field_71439_g.field_70125_A))).func_178785_b((float)(-Math.toRadians(MinecraftInstance.mc.field_71439_g.field_70177_z)));
        RenderUtils.glColor(color);
        GL11.glVertex3d((double)eyeVector.field_72450_a, (double)((double)MinecraftInstance.mc.field_71439_g.func_70047_e() + eyeVector.field_72448_b - (double)2), (double)eyeVector.field_72449_c);
        if (drawHeight) {
            GL11.glVertex3d((double)x, (double)y, (double)z);
            GL11.glVertex3d((double)x, (double)y, (double)z);
            GL11.glVertex3d((double)x, (double)(y + (double)entity.field_70131_O), (double)z);
        } else {
            GL11.glVertex3d((double)x, (double)(y + (double)entity.field_70131_O / 2.0), (double)z);
        }
    }

    public static final /* synthetic */ ListValue access$getFovModeValue$p(Tracers $this) {
        return $this.fovModeValue;
    }
}

