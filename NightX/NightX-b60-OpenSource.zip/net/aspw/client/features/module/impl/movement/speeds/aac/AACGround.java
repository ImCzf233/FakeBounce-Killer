/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;

public class AACGround
extends SpeedMode {
    public AACGround() {
        super("AACGround");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        AACGround.mc.field_71428_T.field_74278_d = ((Float)Client.moduleManager.getModule(Speed.class).aacGroundTimerValue.get()).floatValue();
        mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(AACGround.mc.field_71439_g.field_70165_t, AACGround.mc.field_71439_g.field_70163_u, AACGround.mc.field_71439_g.field_70161_v, true));
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        AACGround.mc.field_71428_T.field_74278_d = 1.0f;
    }
}

