/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;

@ModuleInfo(name="Sprint", description="", category=ModuleCategory.MOVEMENT)
public final class Sprint
extends Module {
    private final BoolValue allDirectionsValue = new BoolValue("Multi", true);
    private final BoolValue noPacketPatchValue = new BoolValue("Silent", false);
    private final BoolValue rot = new BoolValue("Rotations", false);
    private boolean modified;

    public final BoolValue getAllDirectionsValue() {
        return this.allDirectionsValue;
    }

    public final BoolValue getNoPacketPatchValue() {
        return this.noPacketPatchValue;
    }

    public final BoolValue getRot() {
        return this.rot;
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        KillAura killAura;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.rot.get()).booleanValue() && event.getEventState() == EventState.PRE && MovementUtils.isMoving() && ((killAura = Client.INSTANCE.getModuleManager().getModule(KillAura.class)) == null ? null : killAura.getTarget()) == null) {
            event.setYaw(MovementUtils.getPredictionYaw(event.getX(), event.getZ()) - 90.0f);
            RotationUtils.setTargetRotation(new Rotation(event.getYaw(), event.getPitch()));
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (((Boolean)this.noPacketPatchValue.get()).booleanValue() && packet instanceof C0BPacketEntityAction && (((C0BPacketEntityAction)packet).func_180764_b() == C0BPacketEntityAction.Action.STOP_SPRINTING || ((C0BPacketEntityAction)packet).func_180764_b() == C0BPacketEntityAction.Action.START_SPRINTING)) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.allDirectionsValue.get()).booleanValue() && !this.modified && !MinecraftInstance.mc.func_71387_A()) {
            event.cancelEvent();
            float prevYaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
            MinecraftInstance.mc.field_71439_g.field_70177_z = MovementUtils.getRawDirection();
            this.modified = true;
            MinecraftInstance.mc.field_71439_g.func_70664_aZ();
            MinecraftInstance.mc.field_71439_g.field_70177_z = prevYaw;
            this.modified = false;
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        block5: {
            block4: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (!MovementUtils.isMoving() || MinecraftInstance.mc.field_71439_g.func_70093_af()) break block4;
                if (((Boolean)this.allDirectionsValue.get()).booleanValue() || RotationUtils.targetRotation == null) break block5;
                Rotation rotation = new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70125_A);
                if (!(RotationUtils.getRotationDifference(rotation) > 30.0)) break block5;
            }
            MinecraftInstance.mc.field_71439_g.func_70031_b(false);
            return;
        }
        if (((Boolean)this.allDirectionsValue.get()).booleanValue() || MinecraftInstance.mc.field_71439_g.field_71158_b.field_78900_b >= 0.8f) {
            MinecraftInstance.mc.field_71439_g.func_70031_b(true);
        }
    }
}

