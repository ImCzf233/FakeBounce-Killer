/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPMiniJump
extends SpeedMode {
    public NCPMiniJump() {
        super("NCPMiniJump");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        if (NCPMiniJump.mc.field_71439_g.field_70122_E && !NCPMiniJump.mc.field_71439_g.field_71158_b.field_78901_c) {
            NCPMiniJump.mc.field_71439_g.field_70181_x += 0.1;
            double multiplier = 1.8;
            NCPMiniJump.mc.field_71439_g.field_70159_w *= 1.8;
            NCPMiniJump.mc.field_71439_g.field_70179_y *= 1.8;
            double currentSpeed = Math.sqrt(Math.pow(NCPMiniJump.mc.field_71439_g.field_70159_w, 2.0) + Math.pow(NCPMiniJump.mc.field_71439_g.field_70179_y, 2.0));
            double maxSpeed = 0.66;
            if (currentSpeed > 0.66) {
                NCPMiniJump.mc.field_71439_g.field_70159_w = NCPMiniJump.mc.field_71439_g.field_70159_w / currentSpeed * 0.66;
                NCPMiniJump.mc.field_71439_g.field_70179_y = NCPMiniJump.mc.field_71439_g.field_70179_y / currentSpeed * 0.66;
            }
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPMiniJump.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPMiniJump.mc.field_71439_g.field_70159_w = 0.0;
            NCPMiniJump.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

