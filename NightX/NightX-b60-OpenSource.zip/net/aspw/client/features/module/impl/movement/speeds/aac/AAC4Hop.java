/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class AAC4Hop
extends SpeedMode {
    public AAC4Hop() {
        super("AAC4Hop");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        Intrinsics.checkNotNull((Object)SpeedMode.mc.field_71439_g);
        SpeedMode.mc.field_71439_g.field_71102_ce = 0.02f;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            EntityPlayerSP entityPlayerSP2 = SpeedMode.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP2);
            if (entityPlayerSP2.field_70122_E) {
                EntityPlayerSP entityPlayerSP3 = SpeedMode.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP3);
                entityPlayerSP3.func_70664_aZ();
                Intrinsics.checkNotNull((Object)SpeedMode.mc.field_71439_g);
                SpeedMode.mc.field_71439_g.field_71102_ce = 0.0201f;
                SpeedMode.mc.field_71428_T.field_74278_d = 0.94f;
            }
            EntityPlayerSP entityPlayerSP4 = SpeedMode.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP4);
            if ((double)entityPlayerSP4.field_70143_R > 0.7) {
                EntityPlayerSP entityPlayerSP5 = SpeedMode.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP5);
                if ((double)entityPlayerSP5.field_70143_R < 1.3) {
                    Intrinsics.checkNotNull((Object)SpeedMode.mc.field_71439_g);
                    SpeedMode.mc.field_71439_g.field_71102_ce = 0.02f;
                    SpeedMode.mc.field_71428_T.field_74278_d = 1.8f;
                }
            }
            EntityPlayerSP entityPlayerSP6 = SpeedMode.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP6);
            if ((double)entityPlayerSP6.field_70143_R >= 1.3) {
                SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
                Intrinsics.checkNotNull((Object)SpeedMode.mc.field_71439_g);
                SpeedMode.mc.field_71439_g.field_71102_ce = 0.02f;
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
    }
}

