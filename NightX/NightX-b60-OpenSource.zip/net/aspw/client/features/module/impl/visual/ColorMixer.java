/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.lang.reflect.Field;
import kotlin.jvm.JvmField;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.api.ColorElement;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.render.BlendUtils;

@ModuleInfo(name="ColorMixer", description="", category=ModuleCategory.VISUAL, canEnable=false)
public final class ColorMixer
extends Module {
    public static final Companion Companion = new Companion(null);
    @JvmField
    public static Color[] lastColors = new Color[0];
    private static float[] lastFraction = new float[0];

    @JvmStatic
    public static final Color getMixedColor(int index, int seconds) {
        return Companion.getMixedColor(index, seconds);
    }

    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final Color getMixedColor(int index, int seconds) {
            ColorMixer colorMixer = Client.INSTANCE.getModuleManager().getModule(ColorMixer.class);
            if (colorMixer == null) {
                Color color = Color.white;
                Intrinsics.checkNotNullExpressionValue((Object)color, (String)"white");
                return color;
            }
            ColorMixer colMixer = colorMixer;
            if (lastColors.length <= 0 || lastFraction.length <= 0) {
                this.regenerateColors(true);
            }
            Color color = BlendUtils.blendColors(lastFraction, lastColors, (float)((System.currentTimeMillis() + (long)index) % (long)(seconds * 1000)) / (float)(seconds * 1000));
            Intrinsics.checkNotNullExpressionValue((Object)color, (String)"blendColors(\n           \u2026).toFloat()\n            )");
            return color;
        }

        public final void regenerateColors(boolean forceValue) {
            int i;
            int n;
            ColorMixer colorMixer = Client.INSTANCE.getModuleManager().getModule(ColorMixer.class);
            if (colorMixer == null) {
                return;
            }
            ColorMixer colMixer = colorMixer;
            if (forceValue || lastColors.length <= 0 || lastColors.length != 3) {
                Color[] generator = new Color[3];
                n = 1;
                while (n < 3) {
                    i = n++;
                    Color result = Color.white;
                    try {
                        Field red = ColorMixer.class.getField("col" + i + "RedValue");
                        Field green = ColorMixer.class.getField("col" + i + "GreenValue");
                        Field blue = ColorMixer.class.getField("col" + i + "BlueValue");
                        Object object = red.get(colMixer);
                        if (object == null) {
                            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.api.ColorElement");
                        }
                        int r = ((Number)((ColorElement)object).get()).intValue();
                        Object object2 = green.get(colMixer);
                        if (object2 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.api.ColorElement");
                        }
                        int g = ((Number)((ColorElement)object2).get()).intValue();
                        Object object3 = blue.get(colMixer);
                        if (object3 == null) {
                            throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.api.ColorElement");
                        }
                        int b = ((Number)((ColorElement)object3).get()).intValue();
                        result = new Color(Math.max(0, Math.min(r, 255)), Math.max(0, Math.min(g, 255)), Math.max(0, Math.min(b, 255)));
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                    generator[i - 1] = result;
                }
                int h = 2;
                i = 0;
                do {
                    int z = i--;
                    generator[h] = generator[z];
                    int n2 = h;
                    h = n2 + 1;
                } while (0 <= i);
                lastColors = generator;
            }
            if (forceValue || lastFraction.length <= 0 || lastFraction.length != 3) {
                float[] colorFraction = new float[3];
                n = 0;
                do {
                    i = n++;
                    colorFraction[i] = (float)i / 2.0f;
                } while (i != 2);
                lastFraction = colorFraction;
            }
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

