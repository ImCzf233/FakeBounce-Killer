/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class YPort2
extends SpeedMode {
    public YPort2() {
        super("YPort2");
    }

    @Override
    public void onMotion() {
        if (YPort2.mc.field_71439_g.func_70617_f_() || YPort2.mc.field_71439_g.func_70090_H() || YPort2.mc.field_71439_g.func_180799_ab() || YPort2.mc.field_71439_g.field_70134_J || !MovementUtils.isMoving()) {
            return;
        }
        if (YPort2.mc.field_71439_g.field_70122_E) {
            YPort2.mc.field_71439_g.func_70664_aZ();
        } else {
            YPort2.mc.field_71439_g.field_70181_x = -1.0;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!YPort2.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            YPort2.mc.field_71439_g.field_70159_w = 0.0;
            YPort2.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

