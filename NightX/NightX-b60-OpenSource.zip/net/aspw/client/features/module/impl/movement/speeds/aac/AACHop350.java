/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACHop350
extends SpeedMode
implements Listenable {
    public AACHop350() {
        super("AACHop3.5.0");
        Client.eventManager.registerListener(this);
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    @EventTarget
    public void onMotion(MotionEvent event) {
        if (event.getEventState() == EventState.POST && MovementUtils.isMoving() && !AACHop350.mc.field_71439_g.func_70090_H() && !AACHop350.mc.field_71439_g.func_180799_ab()) {
            AACHop350.mc.field_71439_g.field_70747_aH += 0.00208f;
            if (AACHop350.mc.field_71439_g.field_70143_R <= 1.0f) {
                if (AACHop350.mc.field_71439_g.field_70122_E) {
                    AACHop350.mc.field_71439_g.func_70664_aZ();
                    AACHop350.mc.field_71439_g.field_70159_w *= (double)1.0118f;
                    AACHop350.mc.field_71439_g.field_70179_y *= (double)1.0118f;
                } else {
                    AACHop350.mc.field_71439_g.field_70181_x -= (double)0.0147f;
                    AACHop350.mc.field_71439_g.field_70159_w *= (double)1.00138f;
                    AACHop350.mc.field_71439_g.field_70179_y *= (double)1.00138f;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        if (AACHop350.mc.field_71439_g.field_70122_E) {
            AACHop350.mc.field_71439_g.field_70179_y = 0.0;
            AACHop350.mc.field_71439_g.field_70159_w = 0.0;
        }
    }

    @Override
    public void onDisable() {
        AACHop350.mc.field_71439_g.field_70747_aH = 0.02f;
    }

    @Override
    public boolean handleEvents() {
        return this.isActive();
    }
}

