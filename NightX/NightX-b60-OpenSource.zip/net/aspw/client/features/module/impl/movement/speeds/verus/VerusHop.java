/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.potion.Potion
 */
package net.aspw.client.features.module.impl.movement.speeds.verus;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.potion.Potion;

public class VerusHop
extends SpeedMode {
    public VerusHop() {
        super("VerusHop");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!(VerusHop.mc.field_71439_g.field_70134_J || VerusHop.mc.field_71439_g.func_180799_ab() || VerusHop.mc.field_71439_g.func_70090_H() || VerusHop.mc.field_71439_g.func_70617_f_() || VerusHop.mc.field_71439_g.field_70154_o != null || !MovementUtils.isMoving())) {
            VerusHop.mc.field_71474_y.field_74314_A.field_74513_e = false;
            if (VerusHop.mc.field_71439_g.field_70122_E) {
                VerusHop.mc.field_71439_g.func_70664_aZ();
                if (VerusHop.mc.field_71439_g.func_70644_a(Potion.field_76424_c)) {
                    MovementUtils.strafe(0.57f);
                } else {
                    MovementUtils.strafe(0.48f);
                }
            }
            MovementUtils.strafe();
        }
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!VerusHop.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            VerusHop.mc.field_71439_g.field_70159_w = 0.0;
            VerusHop.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

