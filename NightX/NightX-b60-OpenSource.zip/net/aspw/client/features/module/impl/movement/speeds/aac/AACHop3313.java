/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.BlockCarpet
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.Client;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.minecraft.block.BlockCarpet;
import net.minecraft.util.MathHelper;

public class AACHop3313
extends SpeedMode {
    public AACHop3313() {
        super("AACHop3.3.13");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || AACHop3313.mc.field_71439_g.func_70090_H() || AACHop3313.mc.field_71439_g.func_180799_ab() || AACHop3313.mc.field_71439_g.func_70617_f_() || AACHop3313.mc.field_71439_g.func_70115_ae() || AACHop3313.mc.field_71439_g.field_70737_aN > 0) {
            return;
        }
        if (AACHop3313.mc.field_71439_g.field_70122_E && AACHop3313.mc.field_71439_g.field_70124_G) {
            float yawRad = AACHop3313.mc.field_71439_g.field_70177_z * ((float)Math.PI / 180);
            AACHop3313.mc.field_71439_g.field_70159_w -= (double)(MathHelper.func_76126_a((float)yawRad) * 0.202f);
            AACHop3313.mc.field_71439_g.field_70179_y += (double)(MathHelper.func_76134_b((float)yawRad) * 0.202f);
            AACHop3313.mc.field_71439_g.field_70181_x = 0.405f;
            Client.eventManager.callEvent(new JumpEvent(0.405f));
            MovementUtils.strafe();
        } else if (AACHop3313.mc.field_71439_g.field_70143_R < 0.31f) {
            if (BlockUtils.getBlock(AACHop3313.mc.field_71439_g.func_180425_c()) instanceof BlockCarpet) {
                return;
            }
            AACHop3313.mc.field_71439_g.field_70747_aH = AACHop3313.mc.field_71439_g.field_70702_br == 0.0f ? 0.027f : 0.021f;
            AACHop3313.mc.field_71439_g.field_70159_w *= 1.001;
            AACHop3313.mc.field_71439_g.field_70179_y *= 1.001;
            if (!AACHop3313.mc.field_71439_g.field_70123_F) {
                AACHop3313.mc.field_71439_g.field_70181_x -= 0.01499999314546585;
            }
        } else {
            AACHop3313.mc.field_71439_g.field_70747_aH = 0.02f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        AACHop3313.mc.field_71439_g.field_70747_aH = 0.02f;
    }
}

