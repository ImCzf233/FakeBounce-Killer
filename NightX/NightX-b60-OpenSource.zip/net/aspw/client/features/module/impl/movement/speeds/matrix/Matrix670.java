/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S12PacketEntityVelocity
 */
package net.aspw.client.features.module.impl.movement.speeds.matrix;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;

public final class Matrix670
extends SpeedMode {
    private int noVelocityY;

    public Matrix670() {
        super("Matrix6.7.0");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        this.noVelocityY = 0;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.func_70090_H()) {
            return;
        }
        if (this.noVelocityY >= 0) {
            --this.noVelocityY;
        }
        if (!SpeedMode.mc.field_71439_g.field_70122_E && this.noVelocityY <= 0) {
            EntityPlayerSP entityPlayerSP2;
            if (SpeedMode.mc.field_71439_g.field_70181_x > 0.0) {
                entityPlayerSP2 = SpeedMode.mc.field_71439_g;
                entityPlayerSP2.field_70181_x -= 5.0E-4;
            }
            entityPlayerSP2 = SpeedMode.mc.field_71439_g;
            entityPlayerSP2.field_70181_x -= 0.009400114514191982;
        }
        if (!SpeedMode.mc.field_71439_g.field_70122_E) {
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
            if ((double)MovementUtils.getSpeed() < 0.2177 && this.noVelocityY < 8) {
                MovementUtils.strafe(0.2177f);
            }
        }
        SpeedMode.mc.field_71439_g.field_70747_aH = (double)Math.abs(SpeedMode.mc.field_71439_g.field_71158_b.field_78902_a) < 0.1 ? 0.026f : 0.0247f;
        if (SpeedMode.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            SpeedMode.mc.field_71439_g.field_70181_x = 0.4105000114514192;
            if ((double)Math.abs(SpeedMode.mc.field_71439_g.field_71158_b.field_78902_a) < 0.1) {
                MovementUtils.strafe();
            }
        }
        if (!MovementUtils.isMoving()) {
            SpeedMode.mc.field_71439_g.field_70159_w = 0.0;
            SpeedMode.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    public final void onPacket(PacketEvent event) {
        block4: {
            block6: {
                block5: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    Packet<?> packet = event.getPacket();
                    if (!(packet instanceof S12PacketEntityVelocity)) break block4;
                    if (SpeedMode.mc.field_71439_g == null) break block5;
                    WorldClient worldClient = SpeedMode.mc.field_71441_e;
                    Entity entity = worldClient == null ? null : worldClient.func_73045_a(((S12PacketEntityVelocity)packet).func_149412_c());
                    if (entity == null) {
                        return;
                    }
                    if (entity.equals(SpeedMode.mc.field_71439_g)) break block6;
                }
                return;
            }
            this.noVelocityY = 10;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
    }
}

