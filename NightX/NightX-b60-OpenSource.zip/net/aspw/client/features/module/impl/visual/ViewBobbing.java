/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="ViewBobbing", spacedName="View Bobbing", description="", category=ModuleCategory.VISUAL)
public final class ViewBobbing
extends Module {
    private final BoolValue noBob = new BoolValue("NoBob", false);
    private final BoolValue customBobbing = new BoolValue("CustomBobbing", true);
    private final FloatValue bobbingAmount = new FloatValue("BobbingAmount", 0.03f, -0.5f, 0.5f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ ViewBobbing this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)ViewBobbing.access$getCustomBobbing$p(this.this$0).get();
        }
    }));

    @EventTarget
    public final void onMotion(@Nullable MotionEvent event) {
        if (((Boolean)this.customBobbing.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            MinecraftInstance.mc.field_71439_g.field_71109_bG = ((Number)this.bobbingAmount.getValue()).floatValue();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.noBob.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70140_Q = 0.0f;
        }
    }

    public static final /* synthetic */ BoolValue access$getCustomBobbing$p(ViewBobbing $this) {
        return $this.customBobbing;
    }
}

