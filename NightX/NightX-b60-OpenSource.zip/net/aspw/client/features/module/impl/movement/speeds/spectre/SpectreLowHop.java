/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.spectre;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class SpectreLowHop
extends SpeedMode {
    public SpectreLowHop() {
        super("SpectreLowHop");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving() || SpectreLowHop.mc.field_71439_g.field_71158_b.field_78901_c) {
            return;
        }
        if (SpectreLowHop.mc.field_71439_g.field_70122_E) {
            MovementUtils.strafe(1.1f);
            SpectreLowHop.mc.field_71439_g.field_70181_x = 0.15;
            return;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!SpectreLowHop.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            SpectreLowHop.mc.field_71439_g.field_70159_w = 0.0;
            SpectreLowHop.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

