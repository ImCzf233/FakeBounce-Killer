/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.stats.StatList
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MathHelper
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.StepConfirmEvent;
import net.aspw.client.event.StepEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

@ModuleInfo(name="Step", description="", category=ModuleCategory.PLAYER)
public final class Step
extends Module {
    private final ListValue modeValue;
    private final FloatValue heightValue;
    private final FloatValue jumpHeightValue;
    private final IntegerValue delayValue;
    private final BoolValue useTimer;
    private boolean isStep;
    private double stepX;
    private double stepY;
    private double stepZ;
    private int ncpNextStep;
    private boolean spartanSwitch;
    private boolean isAACStep;
    private final MSTimer timer;
    private boolean usedTimer;
    private final Double[] ncp1Values;
    private final Double[] ncp2Values;

    public Step() {
        Object[] objectArray = new String[]{"Vanilla", "Jump", "NewNCP1", "NewNCP2", "NCPPacket", "NCP", "MotionNCP", "OldNCP", "Verus", "Vulcan", "Matrix", "AAC", "LAAC", "AAC3.3.4", "Spartan", "Rewinside"};
        this.modeValue = new ListValue("Mode", (String[])objectArray, "Vanilla");
        this.heightValue = new FloatValue("Height", 1.5f, 0.6f, 10.0f);
        this.jumpHeightValue = new FloatValue("JumpHeight", 0.42f, 0.37f, 0.42f);
        this.delayValue = new IntegerValue("Delay", 150, 150, 500, "ms");
        this.useTimer = new BoolValue("UseTimer", true);
        this.timer = new MSTimer();
        objectArray = new Double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.919};
        this.ncp1Values = objectArray;
        objectArray = new Double[]{0.42, 0.7532, 1.01, 1.093, 1.015};
        this.ncp2Values = objectArray;
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        MinecraftInstance.mc.field_71439_g.field_70138_W = 0.5f;
        MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.usedTimer) {
            MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
            this.usedTimer = false;
        }
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"jump", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70123_F && MinecraftInstance.mc.field_71439_g.field_70122_E && !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d()) {
            this.fakeJump();
            MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.jumpHeightValue.get()).floatValue();
        } else if (StringsKt.equals((String)mode, (String)"laac", (boolean)true)) {
            if (!(!MinecraftInstance.mc.field_71439_g.field_70123_F || MinecraftInstance.mc.field_71439_g.func_70617_f_() || MinecraftInstance.mc.field_71439_g.func_70090_H() || MinecraftInstance.mc.field_71439_g.func_180799_ab() || MinecraftInstance.mc.field_71439_g.field_70134_J)) {
                if (MinecraftInstance.mc.field_71439_g.field_70122_E && this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
                    this.isStep = true;
                    this.fakeJump();
                    EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70181_x += 0.620000001490116;
                    float f = MinecraftInstance.mc.field_71439_g.field_70177_z * ((float)Math.PI / 180);
                    EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP2.field_70159_w -= (double)MathHelper.func_76126_a((float)f) * 0.2;
                    entityPlayerSP2 = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP2.field_70179_y += (double)MathHelper.func_76134_b((float)f) * 0.2;
                    this.timer.reset();
                }
                MinecraftInstance.mc.field_71439_g.field_70122_E = true;
            } else {
                this.isStep = false;
            }
        } else if (StringsKt.equals((String)mode, (String)"aac3.3.4", (boolean)true)) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F && MovementUtils.isMoving()) {
                EntityPlayerSP entityPlayerSP;
                if (MinecraftInstance.mc.field_71439_g.field_70122_E && this.couldStep()) {
                    entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70159_w *= 1.26;
                    entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70179_y *= 1.26;
                    MinecraftInstance.mc.field_71439_g.func_70664_aZ();
                    this.isAACStep = true;
                }
                if (this.isAACStep) {
                    entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                    entityPlayerSP.field_70181_x -= 0.015;
                    if (!MinecraftInstance.mc.field_71439_g.func_71039_bw() && MinecraftInstance.mc.field_71439_g.field_71158_b.field_78902_a == 0.0f) {
                        MinecraftInstance.mc.field_71439_g.field_70747_aH = 0.3f;
                    }
                }
            } else {
                this.isAACStep = false;
            }
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"motionncp", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70123_F && !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d()) {
            if (MinecraftInstance.mc.field_71439_g.field_70122_E && this.couldStep()) {
                this.fakeJump();
                MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                event.setY(0.41999998688698);
                this.ncpNextStep = 1;
            } else if (this.ncpNextStep == 1) {
                event.setY(0.33319999363422);
                this.ncpNextStep = 2;
            } else if (this.ncpNextStep == 2) {
                double yaw = MovementUtils.getDirection();
                event.setY(0.24813599859094704);
                event.setX(-Math.sin(yaw) * 0.7);
                event.setZ(Math.cos(yaw) * 0.7);
                this.ncpNextStep = 0;
            }
        }
    }

    @EventTarget
    public final void onStep(StepEvent event) {
        float height;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        String mode = (String)this.modeValue.get();
        if (!MinecraftInstance.mc.field_71439_g.field_70122_E || !this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue()) || StringsKt.equals((String)mode, (String)"Jump", (boolean)true) || StringsKt.equals((String)mode, (String)"MotionNCP", (boolean)true) || StringsKt.equals((String)mode, (String)"LAAC", (boolean)true) || StringsKt.equals((String)mode, (String)"AAC3.3.4", (boolean)true) || StringsKt.equals((String)mode, (String)"AACv4", (boolean)true)) {
            MinecraftInstance.mc.field_71439_g.field_70138_W = 0.5f;
            event.setStepHeight(0.5f);
            return;
        }
        MinecraftInstance.mc.field_71439_g.field_70138_W = height = ((Number)this.heightValue.get()).floatValue();
        this.usedTimer = true;
        event.setStepHeight(height);
        if (event.getStepHeight() > 0.5f) {
            this.isStep = true;
            this.stepX = MinecraftInstance.mc.field_71439_g.field_70165_t;
            this.stepY = MinecraftInstance.mc.field_71439_g.field_70163_u;
            this.stepZ = MinecraftInstance.mc.field_71439_g.field_70161_v;
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onStepConfirm(StepConfirmEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null || !this.isStep) {
            return;
        }
        if (MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - this.stepY > 0.8) {
            Step step = Client.INSTANCE.getModuleManager().get(Step.class);
            Intrinsics.checkNotNull((Object)step);
            if (step.getState() && ((Boolean)this.useTimer.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.field_70122_E && !((String)this.modeValue.get()).equals("Matrix")) {
                MinecraftInstance.mc.field_71428_T.field_74278_d = 0.7f;
            }
            Step step2 = Client.INSTANCE.getModuleManager().get(Step.class);
            Intrinsics.checkNotNull((Object)step2);
            if (step2.getState() && ((Boolean)this.useTimer.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.field_70122_E && ((String)this.modeValue.get()).equals("Matrix")) {
                MinecraftInstance.mc.field_71428_T.field_74278_d = 0.12f;
            }
        } else {
            MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
        }
        if (MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - this.stepY > 0.8) {
            String mode = (String)this.modeValue.get();
            if (StringsKt.equals((String)mode, (String)"NCPPacket", (boolean)true)) {
                double rHeight = MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - this.stepY;
                if (rHeight > 2.019) {
                    Double[] $this$forEach$iv = this.ncp1Values;
                    boolean $i$f$forEach = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, false));
                    }
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                } else if (rHeight > 1.869) {
                    int $this$forEach$iv = 0;
                    while ($this$forEach$iv < 8) {
                        int i = $this$forEach$iv++;
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + this.ncp1Values[i], this.stepZ, false));
                    }
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                } else if (rHeight > 1.5) {
                    int $this$forEach$iv = 0;
                    while ($this$forEach$iv < 7) {
                        int i = $this$forEach$iv++;
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + this.ncp1Values[i], this.stepZ, false));
                    }
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                } else if (rHeight > 1.015) {
                    Double[] $this$forEach$iv = this.ncp2Values;
                    boolean $i$f$forEach = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, false));
                    }
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                } else if (rHeight > 0.875) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                } else if (rHeight > 0.6) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.39, this.stepZ, false));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.6938, this.stepZ, false));
                    MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                    MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                }
            } else if (StringsKt.equals((String)mode, (String)"NewNCP1", (boolean)true)) {
                this.fakeJump();
                BlockPos pos = MinecraftInstance.mc.field_71439_g.func_180425_c().func_177963_a(0.0, -1.5, 0.0);
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(pos, 1, new ItemStack(Blocks.field_150348_b.func_180665_b((World)MinecraftInstance.mc.field_71441_e, pos)), 0.0f, 0.5f + (float)Math.random() * 0.44f, 0.0f));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 1.0, this.stepZ, true));
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"NCP", (boolean)true) || StringsKt.equals((String)mode, (String)"AAC", (boolean)true)) {
                this.fakeJump();
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"Spartan", (boolean)true)) {
                this.fakeJump();
                if (this.spartanSwitch) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 1.001335979112147, this.stepZ, false));
                } else {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.6, this.stepZ, false));
                }
                this.spartanSwitch = !this.spartanSwitch;
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"Vulcan", (boolean)true)) {
                double superHeight = MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - this.stepY;
                this.fakeJump();
                if (superHeight > 2.0) {
                    Double[] stpPacket;
                    Double[] $i$f$forEach = new Double[]{0.5, 1.0, 1.5, 2.0};
                    Double[] $this$forEach$iv = stpPacket = $i$f$forEach;
                    boolean $i$f$forEach2 = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, true));
                    }
                } else if (superHeight <= 2.0 && superHeight > 1.5) {
                    Double[] stpPacket;
                    Double[] $this$forEach$iv = new Double[]{0.5, 1.0, 1.5};
                    $this$forEach$iv = stpPacket = $this$forEach$iv;
                    boolean $i$f$forEach = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, true));
                    }
                } else if (superHeight <= 1.5 && superHeight > 1.0) {
                    Double[] stpPacket;
                    Double[] $this$forEach$iv = new Double[]{0.5, 1.0};
                    $this$forEach$iv = stpPacket = $this$forEach$iv;
                    boolean $i$f$forEach = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, true));
                    }
                } else if (superHeight <= 1.0 && superHeight > 0.6) {
                    Double[] stpPacket;
                    Double[] $this$forEach$iv = new Double[]{0.5};
                    $this$forEach$iv = stpPacket = $this$forEach$iv;
                    boolean $i$f$forEach = false;
                    for (Double element$iv : $this$forEach$iv) {
                        double it = ((Number)element$iv).doubleValue();
                        boolean bl = false;
                        MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + it, this.stepZ, true));
                    }
                }
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"Verus", (boolean)true)) {
                double superHeight = MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - this.stepY;
                MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f / (float)Math.ceil(superHeight * 2.0);
                double superHighest = 0.0;
                this.fakeJump();
                int n = (int)(Math.ceil(superHeight * 2.0) - 1.0);
                int n2 = 0;
                while (n2 < n) {
                    int n3;
                    int it = n3 = n2++;
                    boolean bl = false;
                    MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + (superHighest += 0.5), this.stepZ, true));
                }
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"NewNCP2", (boolean)true)) {
                this.fakeJump();
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 1.0, this.stepZ, true));
            } else if (StringsKt.equals((String)mode, (String)"Matrix", (boolean)true)) {
                this.fakeJump();
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 1.001335979112147, this.stepZ, false));
                this.timer.reset();
            } else if (StringsKt.equals((String)mode, (String)"Rewinside", (boolean)true)) {
                this.fakeJump();
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.41999998688698, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 0.7531999805212, this.stepZ, false));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(this.stepX, this.stepY + 1.001335979112147, this.stepZ, false));
                this.timer.reset();
            }
        }
        this.isStep = false;
        this.stepX = 0.0;
        this.stepY = 0.0;
        this.stepZ = 0.0;
    }

    @EventTarget(ignoreCondition=true)
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer && this.isStep && StringsKt.equals((String)((String)this.modeValue.get()), (String)"OldNCP", (boolean)true)) {
            ((C03PacketPlayer)packet).field_149477_b += 0.07;
            this.isStep = false;
        }
    }

    private final void fakeJump() {
        MinecraftInstance.mc.field_71439_g.field_70160_al = true;
        MinecraftInstance.mc.field_71439_g.func_71029_a(StatList.field_75953_u);
    }

    private final boolean couldStep() {
        double yaw = MovementUtils.getDirection();
        double x = -Math.sin(yaw) * 0.4;
        double z = Math.cos(yaw) * 0.4;
        return MinecraftInstance.mc.field_71441_e.func_147461_a(MinecraftInstance.mc.field_71439_g.func_174813_aQ().func_72317_d(x, 1.001335979112147, z)).isEmpty();
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

