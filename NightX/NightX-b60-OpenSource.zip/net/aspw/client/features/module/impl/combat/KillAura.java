/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.internal.ProgressionUtilKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.item.EntityArmorStand
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.potion.Potion
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.internal.ProgressionUtilKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EntityMovementEvent;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.BackTrack;
import net.aspw.client.features.module.impl.exploit.Disabler;
import net.aspw.client.features.module.impl.other.FreeLook;
import net.aspw.client.features.module.impl.player.Freecam;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.features.module.impl.targets.AntiBots;
import net.aspw.client.features.module.impl.targets.AntiTeams;
import net.aspw.client.features.module.impl.visual.Tracers;
import net.aspw.client.util.CooldownHelper;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.RaycastUtils;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.VecRotation;
import net.aspw.client.util.extensions.PlayerExtensionKt;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.opengl.GL11;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="KillAura", spacedName="Kill Aura", description="", category=ModuleCategory.COMBAT)
public final class KillAura
extends Module {
    private final BoolValue coolDownCheck = new BoolValue("Cooldown-Check", false);
    private final BoolValue clickOnly = new BoolValue("Click-Only", false);
    private final IntegerValue maxCPS;
    private final IntegerValue minCPS;
    private final FloatValue prevRangeValue;
    private final FloatValue rangeValue;
    private final ListValue rotations;
    private final FloatValue maxTurnSpeed;
    private final FloatValue minTurnSpeed;
    private final IntegerValue angleTick;
    private final BoolValue animationValue;
    private final BoolValue noInventoryAttackValue;
    private final BoolValue randomValue;
    private final BoolValue movementFix;
    private final BoolValue multiCombo;
    private final IntegerValue amountValue;
    private final BoolValue noHitCheck;
    private final ListValue priorityValue;
    private final ListValue targetModeValue;
    private final ListValue swingValue;
    private final ListValue autoBlockModeValue;
    private final BoolValue interactAutoBlockValue;
    private final BoolValue verusAutoBlockValue;
    private final BoolValue silentRotationValue;
    private final BoolValue toggleFreeLook;
    private final FloatValue fovValue;
    private final FloatValue failRateValue;
    private final IntegerValue limitedMultiTargetsValue;
    private final BoolValue tracerESPValue;
    private final BoolValue simpleESPValue;
    private final BoolValue espValue;
    private final BoolValue circleValue;
    private EntityLivingBase target;
    private EntityLivingBase currentTarget;
    private boolean hitable;
    private final List<Integer> prevTargetEntities;
    private EntityLivingBase markEntity;
    private final MSTimer attackTimer;
    private final TickTimer endTimer;
    private boolean failedHit;
    private long attackDelay;
    private int clicks;
    private long containerOpen;
    private boolean blockingStatus;
    private boolean verusBlocking;
    private boolean fakeBlock;
    private float spinYaw;

    public KillAura() {
        String[] stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.maxCPS = new IntegerValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MaxCPS", 12, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)KillAura.access$getMinCPS$p(this.this$0).get()).intValue();
                if (i > newValue) {
                    this.set(i);
                }
                KillAura.access$setAttackDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)KillAura.access$getMinCPS$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getCoolDownCheck$p(this.this$0).get() == false;
            }
        };
        this.minCPS = new IntegerValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MinCPS", 10, 1, 20, (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)KillAura.access$getMaxCPS$p(this.this$0).get()).intValue();
                if (i < newValue) {
                    this.set(i);
                }
                KillAura.access$setAttackDelay$p(this.this$0, TimeUtils.randomClickDelay(((Number)this.get()).intValue(), ((Number)KillAura.access$getMaxCPS$p(this.this$0).get()).intValue()));
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getNoHitCheck$p(this.this$0).get() == false;
            }
        };
        this.prevRangeValue = new FloatValue(stringArray){};
        this.rangeValue = new FloatValue(){};
        stringArray = new String[]{"Undetectable", "HvH", "Zero", "None"};
        this.rotations = new ListValue("RotationMode", stringArray, "Undetectable");
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"zero", (boolean)true);
            }
        };
        this.maxTurnSpeed = new FloatValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MaxTurnSpeed", 120.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)KillAura.access$getMinTurnSpeed$p(this.this$0).get()).floatValue();
                if (v > newValue) {
                    this.set(Float.valueOf(v));
                }
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"zero", (boolean)true);
            }
        };
        this.minTurnSpeed = new FloatValue(this, stringArray){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super("MinTurnSpeed", 100.0f, 0.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(float oldValue, float newValue) {
                float v = ((Number)KillAura.access$getMaxTurnSpeed$p(this.this$0).get()).floatValue();
                if (v < newValue) {
                    this.set(Float.valueOf(v));
                }
            }
        };
        this.angleTick = new IntegerValue("Angle-Tick", 1, 1, 100, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.animationValue = new BoolValue("Animation", true);
        this.noInventoryAttackValue = new BoolValue("NoInvAttack", false);
        this.randomValue = new BoolValue("Random", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"undetectable", (boolean)true);
            }
        }));
        this.movementFix = new BoolValue("MovementFix", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.multiCombo = new BoolValue("MultiCombo", false);
        this.amountValue = new IntegerValue("Multi-Packet", 5, 0, 20, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)KillAura.access$getMultiCombo$p(this.this$0).get();
            }
        }));
        this.noHitCheck = new BoolValue("NoHitCheck", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        stringArray = new String[]{"Health", "Distance", "Direction", "LivingTime", "Armor", "HurtResistance", "HurtTime", "HealthAbsorption", "RegenAmplifier"};
        this.priorityValue = new ListValue("Priority", stringArray, "Distance");
        stringArray = new String[]{"Single", "Switch", "Multi"};
        this.targetModeValue = new ListValue("TargetMode", stringArray, "Single");
        stringArray = new String[]{"Full", "Smart", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Full");
        stringArray = new String[]{"Packet", "AfterTick", "NCP", "HurtTime", "Click", "OldHypixel", "OldIntave", "Fake", "None"};
        this.autoBlockModeValue = new ListValue("AutoBlock", stringArray, "Fake");
        this.interactAutoBlockValue = new BoolValue("InteractAutoBlock", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"Fake", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"None", (boolean)true);
            }
        }));
        this.verusAutoBlockValue = new BoolValue("UnBlock-Exploit", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"Fake", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getAutoBlockModeValue().get()), (String)"None", (boolean)true);
            }
        }));
        this.silentRotationValue = new BoolValue("SilentRotation", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true);
            }
        }));
        this.toggleFreeLook = new BoolValue("ToggleFreeLook", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotations().get()), (String)"none", (boolean)true) && (Boolean)this.this$0.getSilentRotationValue().get() == false;
            }
        }));
        this.fovValue = new FloatValue("FOV", 180.0f, 0.0f, 180.0f);
        this.failRateValue = new FloatValue("FailRate", 0.0f, 0.0f, 100.0f);
        this.limitedMultiTargetsValue = new IntegerValue("LimitedMultiTargets", 6, 1, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ KillAura this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)KillAura.access$getTargetModeValue$p(this.this$0).get()), (String)"multi", (boolean)true);
            }
        }));
        this.tracerESPValue = new BoolValue("Tracer-ESP", true);
        this.simpleESPValue = new BoolValue("Simple-ESP", false);
        this.espValue = new BoolValue("CSGO-ESP", false);
        this.circleValue = new BoolValue("Circle", false);
        this.prevTargetEntities = new ArrayList();
        this.attackTimer = new MSTimer();
        this.endTimer = new TickTimer();
        this.containerOpen = -1L;
    }

    public final ListValue getRotations() {
        return this.rotations;
    }

    public final BoolValue getMovementFix() {
        return this.movementFix;
    }

    public final ListValue getAutoBlockModeValue() {
        return this.autoBlockModeValue;
    }

    public final BoolValue getSilentRotationValue() {
        return this.silentRotationValue;
    }

    public final EntityLivingBase getTarget() {
        return this.target;
    }

    public final void setTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.target = entityLivingBase;
    }

    public final EntityLivingBase getCurrentTarget() {
        return this.currentTarget;
    }

    public final void setCurrentTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.currentTarget = entityLivingBase;
    }

    public final boolean getHitable() {
        return this.hitable;
    }

    public final void setHitable(boolean bl) {
        this.hitable = bl;
    }

    public final boolean getBlockingStatus() {
        return this.blockingStatus;
    }

    public final void setBlockingStatus(boolean bl) {
        this.blockingStatus = bl;
    }

    public final boolean getVerusBlocking() {
        return this.verusBlocking;
    }

    public final void setVerusBlocking(boolean bl) {
        this.verusBlocking = bl;
    }

    public final boolean getFakeBlock() {
        return this.fakeBlock;
    }

    public final void setFakeBlock(boolean bl) {
        this.fakeBlock = bl;
    }

    public final float getSpinYaw() {
        return this.spinYaw;
    }

    public final void setSpinYaw(float f) {
        this.spinYaw = f;
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        if (MinecraftInstance.mc.field_71441_e == null) {
            return;
        }
        this.updateTarget();
        this.verusBlocking = false;
    }

    @Override
    public void onDisable() {
        this.target = null;
        this.currentTarget = null;
        this.hitable = false;
        this.prevTargetEntities.clear();
        this.attackTimer.reset();
        this.clicks = 0;
        if (((Boolean)this.toggleFreeLook.get()).booleanValue() && this.target != null) {
            FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
            Intrinsics.checkNotNull((Object)freeLook);
            freeLook.setState(false);
        }
        this.stopBlocking();
        if (this.verusBlocking && !this.blockingStatus && !MinecraftInstance.mc.field_71439_g.func_70632_aY()) {
            this.verusBlocking = false;
            if (((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN)));
            }
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() == EventState.POST) {
            if (this.target == null) {
                return;
            }
            if (this.currentTarget == null) {
                return;
            }
            this.updateHitable();
            if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"AfterTick", (boolean)true) && this.getCanBlock()) {
                EntityLivingBase entityLivingBase = this.currentTarget;
                Intrinsics.checkNotNull((Object)entityLivingBase);
                this.startBlocking((Entity)entityLivingBase, this.hitable);
            }
        }
        if (((Boolean)this.toggleFreeLook.get()).booleanValue() && !((Boolean)this.silentRotationValue.get()).booleanValue() && this.target != null && !StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
            Intrinsics.checkNotNull((Object)freeLook);
            freeLook.setState(true);
        }
    }

    public final void update() {
        if (this.getCancelRun() || ((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.field_71462_r instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            return;
        }
        this.updateTarget();
        if (this.target == null) {
            this.stopBlocking();
            return;
        }
        this.currentTarget = this.target;
        if (!StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Switch", (boolean)true) && this.isEnemy((Entity)this.currentTarget)) {
            this.target = this.currentTarget;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (this.verusBlocking && (packet instanceof C07PacketPlayerDigging && ((C07PacketPlayerDigging)packet).func_180762_c() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM || packet instanceof C08PacketPlayerBlockPlacement) && ((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
            event.cancelEvent();
        }
        if (packet instanceof C09PacketHeldItemChange) {
            this.verusBlocking = false;
        }
    }

    @EventTarget
    public final void onStrafe(StrafeEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.update();
        if (this.target != null) {
            EntityLivingBase entityLivingBase = this.target;
            Integer n = entityLivingBase == null ? null : Integer.valueOf(entityLivingBase.field_70737_aN);
            Intrinsics.checkNotNull((Object)n);
            if ((double)n.intValue() > 7.8 && ((Boolean)this.animationValue.get()).booleanValue()) {
                MinecraftInstance.mc.func_175597_ag().func_78445_c();
            }
            EntityLivingBase entityLivingBase2 = this.target;
            Integer n2 = entityLivingBase2 == null ? null : Integer.valueOf(entityLivingBase2.field_70737_aN);
            Intrinsics.checkNotNull((Object)n2);
            if (n2 > 9) {
                MinecraftInstance.mc.field_71452_i.func_178926_a((Entity)this.target, EnumParticleTypes.CRIT_MAGIC);
                MinecraftInstance.mc.field_71452_i.func_178926_a((Entity)this.target, EnumParticleTypes.CRIT);
            }
        }
        if (((Boolean)this.movementFix.get()).booleanValue() && this.currentTarget != null && RotationUtils.targetRotation != null) {
            Rotation rotation = RotationUtils.targetRotation;
            if (rotation == null) {
                return;
            }
            float yaw = rotation.component1();
            float strafe = event.getStrafe();
            float forward = event.getForward();
            float friction = event.getFriction();
            float f = strafe * strafe + forward * forward;
            if (f >= 1.0E-4f) {
                if ((f = MathHelper.func_76129_c((float)f)) < 1.0f) {
                    f = 1.0f;
                }
                f = friction / f;
                float yawSin = MathHelper.func_76126_a((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                float yawCos = MathHelper.func_76134_b((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70159_w += (double)((strafe *= f) * yawCos - (forward *= f) * yawSin);
                entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70179_y += (double)(forward * yawCos + strafe * yawSin);
            }
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.updateKA();
        if (MinecraftInstance.mc.field_71439_g.func_70632_aY() || this.blockingStatus || this.target != null) {
            this.verusBlocking = true;
        } else if (this.verusBlocking) {
            this.verusBlocking = false;
            if (((Boolean)this.verusAutoBlockValue.get()).booleanValue()) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN)));
            }
        }
    }

    private final void updateKA() {
        if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.field_71474_y.field_74312_F.func_151470_d() || MinecraftInstance.mc.field_71439_g.func_70115_ae()) {
            return;
        }
        if (this.getCancelRun()) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            this.stopBlocking();
            return;
        }
        if (((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.field_71462_r instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            if (MinecraftInstance.mc.field_71462_r instanceof GuiContainer) {
                this.containerOpen = System.currentTimeMillis();
            }
            return;
        }
        if (((Boolean)this.coolDownCheck.get()).booleanValue() && CooldownHelper.INSTANCE.getAttackCooldownProgress() < 1.0) {
            return;
        }
        if (this.target != null && this.currentTarget != null) {
            this.endTimer.update();
            while (this.clicks > 0) {
                this.runAttack();
                int n = this.clicks;
                this.clicks = n + -1;
            }
        }
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        int i;
        int n;
        int n2;
        int n3;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.circleValue.get()).booleanValue()) {
            GL11.glPushMatrix();
            GL11.glTranslated((double)(MinecraftInstance.mc.field_71439_g.field_70142_S + (MinecraftInstance.mc.field_71439_g.field_70165_t - MinecraftInstance.mc.field_71439_g.field_70142_S) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78725_b), (double)(MinecraftInstance.mc.field_71439_g.field_70137_T + (MinecraftInstance.mc.field_71439_g.field_70163_u - MinecraftInstance.mc.field_71439_g.field_70137_T) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78726_c), (double)(MinecraftInstance.mc.field_71439_g.field_70136_U + (MinecraftInstance.mc.field_71439_g.field_70161_v - MinecraftInstance.mc.field_71439_g.field_70136_U) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78723_d));
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glLineWidth((float)1.0f);
            GL11.glColor4f((float)0.0f, (float)1.0f, (float)1.0f, (float)0.78431374f);
            GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glBegin((int)3);
            n3 = 20;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * ((Number)this.rangeValue.get()).floatValue() - 0.3f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * ((Number)this.rangeValue.get()).floatValue() - 0.3f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glPopMatrix();
        }
        if (this.getCancelRun()) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            this.stopBlocking();
            return;
        }
        if (((Boolean)this.noInventoryAttackValue.get()).booleanValue() && (MinecraftInstance.mc.field_71462_r instanceof GuiContainer || System.currentTimeMillis() - this.containerOpen < 200L)) {
            this.target = null;
            this.currentTarget = null;
            this.hitable = false;
            if (MinecraftInstance.mc.field_71462_r instanceof GuiContainer) {
                this.containerOpen = System.currentTimeMillis();
            }
            return;
        }
        if (this.target == null) {
            return;
        }
        if (((Boolean)this.simpleESPValue.get()).booleanValue()) {
            EntityLivingBase entityLivingBase = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            int n4 = (int)entityLivingBase.field_70165_t;
            EntityLivingBase entityLivingBase2 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase2);
            int n5 = (int)entityLivingBase2.field_70163_u + 2;
            EntityLivingBase entityLivingBase3 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase3);
            RenderUtils.drawBlockBox(new BlockPos(n4, n5, (int)entityLivingBase3.field_70161_v), Color.WHITE, false);
        }
        if (((Boolean)this.tracerESPValue.get()).booleanValue()) {
            Tracers tracers = Client.INSTANCE.getModuleManager().getModule(Tracers.class);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glLineWidth((float)0.5f);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            GL11.glDepthMask((boolean)false);
            GL11.glBegin((int)1);
            int dist = (int)(MinecraftInstance.mc.field_71439_g.func_70032_d((Entity)this.currentTarget) * (float)2);
            if (dist > 255) {
                dist = 255;
            }
            EntityLivingBase entityLivingBase = this.currentTarget;
            if (entityLivingBase != null) {
                EntityLivingBase it = entityLivingBase;
                boolean bl = false;
                Tracers tracers2 = tracers;
                if (tracers2 != null) {
                    Entity entity = (Entity)it;
                    Color color = Color.WHITE;
                    Intrinsics.checkNotNullExpressionValue((Object)color, (String)"WHITE");
                    tracers2.drawTraces(entity, color, false);
                }
            }
            GL11.glEnd();
            GL11.glEnable((int)3553);
            GL11.glDisable((int)2848);
            GL11.glEnable((int)2929);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3042);
            GlStateManager.func_179117_G();
        }
        if (((Boolean)this.espValue.get()).booleanValue()) {
            if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.field_71474_y.field_74312_F.func_151470_d() || MinecraftInstance.mc.field_71439_g.func_70115_ae()) {
                return;
            }
            GL11.glPushMatrix();
            EntityLivingBase entityLivingBase = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            double d = entityLivingBase.field_70142_S;
            EntityLivingBase entityLivingBase4 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase4);
            double d2 = entityLivingBase4.field_70165_t;
            EntityLivingBase entityLivingBase5 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase5);
            double d3 = d + (d2 - entityLivingBase5.field_70142_S) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78725_b;
            EntityLivingBase entityLivingBase6 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase6);
            double d4 = entityLivingBase6.field_70137_T;
            EntityLivingBase entityLivingBase7 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase7);
            double d5 = entityLivingBase7.field_70163_u;
            EntityLivingBase entityLivingBase8 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase8);
            double d6 = d4 + (d5 - entityLivingBase8.field_70137_T) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78726_c;
            EntityLivingBase entityLivingBase9 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase9);
            double d7 = entityLivingBase9.field_70136_U;
            EntityLivingBase entityLivingBase10 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase10);
            double d8 = entityLivingBase10.field_70161_v;
            EntityLivingBase entityLivingBase11 = this.target;
            Intrinsics.checkNotNull((Object)entityLivingBase11);
            GL11.glTranslated((double)d3, (double)d6, (double)(d7 + (d8 - entityLivingBase11.field_70136_U) * (double)MinecraftInstance.mc.field_71428_T.field_74281_c - MinecraftInstance.mc.func_175598_ae().field_78723_d));
            GL11.glEnable((int)3042);
            GL11.glEnable((int)2848);
            GL11.glDisable((int)3553);
            GL11.glDisable((int)2929);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glRotatef((float)90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            GL11.glLineWidth((float)4.25f);
            GL11.glColor3f((float)0.0f, (float)0.0f, (float)0.0f);
            GL11.glBegin((int)2);
            n3 = 40;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * 0.8f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * 0.8f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glLineWidth((float)3.0f);
            GL11.glBegin((int)2);
            n3 = 40;
            n2 = 0;
            n = ProgressionUtilKt.getProgressionLastElement((int)0, (int)360, (int)n3);
            if (n2 <= n) {
                do {
                    i = n2;
                    n2 += n3;
                    GL11.glColor3f((float)1.0f, (float)1.0f, (float)0.0f);
                    GL11.glVertex2f((float)((float)Math.cos((double)i * Math.PI / 180.0) * 0.8f), (float)((float)Math.sin((double)i * Math.PI / 180.0) * 0.8f));
                } while (i != n);
            }
            GL11.glEnd();
            GL11.glDisable((int)3042);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)2848);
            GL11.glPopMatrix();
            GlStateManager.func_179117_G();
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        }
        if (this.currentTarget != null && this.attackTimer.hasTimePassed(this.attackDelay)) {
            EntityLivingBase entityLivingBase = this.currentTarget;
            Intrinsics.checkNotNull((Object)entityLivingBase);
            if (entityLivingBase.field_70737_aN <= 10) {
                n3 = this.clicks;
                this.clicks = n3 + 1;
                this.attackTimer.reset();
                this.attackDelay = (Boolean)this.coolDownCheck.get() != false ? TimeUtils.randomClickDelay(20, 20) : TimeUtils.randomClickDelay(((Number)this.minCPS.get()).intValue(), ((Number)this.maxCPS.get()).intValue());
            }
        }
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.multiCombo.get()).booleanValue()) {
            if (event.getTargetEntity() == null) {
                return;
            }
            int n = ((Number)this.amountValue.get()).intValue();
            int n2 = 0;
            while (n2 < n) {
                int n3;
                int it = n3 = n2++;
                boolean bl = false;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0APacketAnimation()));
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C02PacketUseEntity(event.getTargetEntity(), C02PacketUseEntity.Action.ATTACK)));
            }
        }
    }

    @EventTarget
    public final void onEntityMove(EntityMovementEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Entity movedEntity = event.getMovedEntity();
        if (this.target == null || !movedEntity.equals(this.currentTarget)) {
            return;
        }
        this.updateHitable();
    }

    /*
     * Unable to fully structure code
     */
    private final void runAttack() {
        if (this.target == null) {
            return;
        }
        if (this.currentTarget == null) {
            return;
        }
        failRate = ((Number)this.failRateValue.get()).floatValue();
        multi = StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Multi", (boolean)true);
        if (!(failRate > 0.0f)) ** GOTO lbl-1000
        v0 = new Random();
        if ((float)v0.nextInt(100) <= failRate) {
            v1 = true;
        } else lbl-1000:
        // 2 sources

        {
            v1 = failHit = false;
        }
        if (!this.hitable || failHit) {
            if (failHit) {
                this.failedHit = true;
            }
        } else {
            if (!multi) {
                v2 = this.currentTarget;
                Intrinsics.checkNotNull((Object)v2);
                this.attackEntity(v2);
            } else {
                targets = 0;
                for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
                    var9_8 = MinecraftInstance.mc.field_71439_g;
                    Intrinsics.checkNotNullExpressionValue((Object)var9_8, (String)"mc.thePlayer");
                    v3 = (Entity)var9_8;
                    Intrinsics.checkNotNullExpressionValue((Object)entity, (String)"entity");
                    distance = PlayerExtensionKt.getDistanceToEntityBox(v3, entity);
                    if (!(entity instanceof EntityLivingBase) || !this.isEnemy(entity) || !(distance <= (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f))) continue;
                    this.attackEntity((EntityLivingBase)entity);
                    if (((Number)this.limitedMultiTargetsValue.get()).intValue() == 0 || ((Number)this.limitedMultiTargetsValue.get()).intValue() > ++targets) continue;
                }
            }
            v4 = this.currentTarget;
            Intrinsics.checkNotNull((Object)v4);
            this.prevTargetEntities.add(v4.func_145782_y());
            if (this.target.equals(this.currentTarget)) {
                this.target = null;
            }
        }
    }

    private final void updateTarget() {
        Object searchTarget = null;
        int hurtTime = 10;
        float fov = ((Number)this.fovValue.get()).floatValue();
        boolean switchMode = StringsKt.equals((String)((String)this.targetModeValue.get()), (String)"Switch", (boolean)true);
        List targets = new ArrayList();
        for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityLivingBase) || !this.isEnemy(entity) || switchMode && this.prevTargetEntities.contains(((EntityLivingBase)entity).func_145782_y())) continue;
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
            double distance = PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity);
            double entityFov = RotationUtils.getRotationDifference(entity);
            if (!(distance <= (double)this.getMaxRange()) || !(fov == 180.0f) && !(entityFov <= (double)fov) || ((EntityLivingBase)entity).field_70737_aN > hurtTime) continue;
            targets.add(entity);
        }
        String string = (String)this.priorityValue.get();
        Locale distance = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)distance, (String)"getDefault()");
        String string2 = string.toLowerCase(distance);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "distance": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
                        Comparable comparable = Double.valueOf(PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, (Entity)it));
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Double.valueOf(PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, (Entity)it)));
                    }
                });
                break;
            }
            case "health": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(it.func_110143_aJ());
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.func_110143_aJ()));
                    }
                });
                break;
            }
            case "direction": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Double.valueOf(RotationUtils.getRotationDifference((Entity)it));
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Double.valueOf(RotationUtils.getRotationDifference((Entity)it)));
                    }
                });
                break;
            }
            case "livingtime": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(-it.field_70173_aa);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(-it.field_70173_aa));
                    }
                });
                break;
            }
            case "hurtresistance": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(it.field_70172_ad);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.field_70172_ad));
                    }
                });
                break;
            }
            case "hurttime": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(it.field_70737_aN);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.field_70737_aN));
                    }
                });
                break;
            }
            case "healthabsorption": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        Comparable comparable = Float.valueOf(it.func_110143_aJ() + it.func_110139_bj());
                        it = (EntityLivingBase)b;
                        Comparable comparable2 = comparable;
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.func_110143_aJ() + it.func_110139_bj()));
                    }
                });
                break;
            }
            case "regenamplifier": {
                List $this$sortBy$iv = targets;
                boolean $i$f$sortBy = false;
                if ($this$sortBy$iv.size() <= 1) break;
                CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                    public final int compare(T a, T b) {
                        EntityLivingBase it = (EntityLivingBase)a;
                        boolean bl = false;
                        int n = it.func_70644_a(Potion.field_76428_l) ? it.func_70660_b(Potion.field_76428_l).func_76458_c() : -1;
                        it = (EntityLivingBase)b;
                        Comparable comparable = Integer.valueOf(n);
                        bl = false;
                        return ComparisonsKt.compareValues((Comparable)comparable, (Comparable)Integer.valueOf(it.func_70644_a(Potion.field_76428_l) ? it.func_70660_b(Potion.field_76428_l).func_76458_c() : -1));
                    }
                });
            }
        }
        boolean found = false;
        for (EntityLivingBase entity : targets) {
            if (!this.updateRotations((Entity)entity)) continue;
            BackTrack backTrack = Client.INSTANCE.getModuleManager().getModule(BackTrack.class);
            if (backTrack != null) {
                backTrack.loopThroughBacktrackData((Entity)entity, (Function0<Boolean>)((Function0)new Function0<Boolean>(this, entity){
                    final /* synthetic */ KillAura this$0;
                    final /* synthetic */ EntityLivingBase $entity;
                    {
                        this.this$0 = $receiver;
                        this.$entity = $entity;
                        super(0);
                    }

                    public final Boolean invoke() {
                        if (KillAura.access$updateRotations(this.this$0, (Entity)this.$entity)) {
                            return true;
                        }
                        return false;
                    }
                }));
            }
            this.target = entity;
            found = true;
            break;
        }
        if (found) {
            return;
        }
        this.target = null;
        if (!((Collection)this.prevTargetEntities).isEmpty()) {
            this.prevTargetEntities.clear();
            this.updateTarget();
        }
    }

    private final boolean isEnemy(Entity entity) {
        if (entity instanceof EntityLivingBase && (EntityUtils.targetDead || this.isAlive((EntityLivingBase)entity)) && !entity.equals(MinecraftInstance.mc.field_71439_g)) {
            if (!EntityUtils.targetInvisible && ((EntityLivingBase)entity).func_82150_aj()) {
                return false;
            }
            if (EntityUtils.targetPlayer && entity instanceof EntityPlayer) {
                if (((EntityPlayer)entity).func_175149_v() || AntiBots.Companion.isBot((EntityLivingBase)entity)) {
                    return false;
                }
                if (EntityUtils.isFriend(entity)) {
                    return false;
                }
                AntiTeams antiTeams = Client.INSTANCE.getModuleManager().get(AntiTeams.class);
                if (antiTeams == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.targets.AntiTeams");
                }
                AntiTeams antiTeams2 = antiTeams;
                return !antiTeams2.getState() || !antiTeams2.isInYourTeam((EntityLivingBase)entity);
            }
            return EntityUtils.targetMobs && EntityUtils.isMob(entity) || EntityUtils.targetAnimals && EntityUtils.isAnimal(entity);
        }
        return false;
    }

    private final void attackEntity(EntityLivingBase entity) {
        Client.INSTANCE.getEventManager().callEvent(new AttackEvent((Entity)entity));
        this.markEntity = entity;
        String string = (String)this.swingValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "full": {
                MinecraftInstance.mc.field_71439_g.func_71038_i();
                break;
            }
            case "smart": {
                MinecraftInstance.mc.field_71439_g.field_82175_bq = true;
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
                break;
            }
            case "packet": {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
            }
        }
        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C02PacketUseEntity((Entity)entity, C02PacketUseEntity.Action.ATTACK));
        if (!StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"AfterTick", (boolean)true) && (MinecraftInstance.mc.field_71439_g.func_70632_aY() || this.getCanBlock())) {
            this.startBlocking((Entity)entity, (Boolean)this.interactAutoBlockValue.get());
        }
    }

    private final boolean updateRotations(Entity entity) {
        if (((Boolean)this.clickOnly.get()).booleanValue() && !MinecraftInstance.mc.field_71474_y.field_74312_F.func_151470_d() || MinecraftInstance.mc.field_71439_g.func_70115_ae()) {
            return false;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            return true;
        }
        Disabler disabler = Client.INSTANCE.getModuleManager().getModule(Disabler.class);
        Intrinsics.checkNotNull((Object)disabler);
        Disabler disabler2 = disabler;
        boolean modify = disabler2.getCanModifyRotation();
        if (modify) {
            return true;
        }
        Rotation rotation = this.getTargetRotation(entity);
        if (rotation == null) {
            return false;
        }
        Rotation defRotation = rotation;
        if (!((Object)defRotation).equals(RotationUtils.serverRotation)) {
            defRotation.setYaw(RotationUtils.roundRotation(defRotation.getYaw(), ((Number)this.angleTick.get()).intValue()));
        }
        if (((Boolean)this.silentRotationValue.get()).booleanValue()) {
            RotationUtils.setTargetRotation(defRotation, 0);
        } else {
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            defRotation.toPlayer((EntityPlayer)entityPlayerSP);
        }
        return true;
    }

    private final Rotation getTargetRotation(Entity entity) {
        AxisAlignedBB boundingBox = null;
        boundingBox = entity.func_174813_aQ();
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"HvH", (boolean)true)) {
            Rotation rotation;
            Rotation rotation2 = RotationUtils.serverRotation;
            if (rotation2 == null) {
                rotation = null;
            } else {
                Rotation it = rotation2;
                boolean bl = false;
                Vec3 vec3 = RotationUtils.getCenter(entity.func_174813_aQ());
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP);
                rotation = RotationUtils.limitAngleChange(it, RotationUtils.OtherRotation(boundingBox, vec3, false, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity) < (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f), this.getMaxRange()), (float)(Math.random() * (double)(((Number)this.maxTurnSpeed.get()).floatValue() - ((Number)this.minTurnSpeed.get()).floatValue()) + ((Number)this.minTurnSpeed.get()).doubleValue()));
            }
            Rotation limitedRotation = rotation;
            return limitedRotation;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"Undetectable", (boolean)true)) {
            if (((Number)this.maxTurnSpeed.get()).floatValue() <= 0.0f) {
                return RotationUtils.serverRotation;
            }
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            VecRotation vecRotation = RotationUtils.searchCenter(boundingBox, false, true, false, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, entity) < (double)(((Number)this.rangeValue.get()).floatValue() - 0.3f), this.getMaxRange(), (Boolean)this.randomValue.get() != false ? RandomUtils.nextFloat(14.0f, 18.0f) : RandomUtils.nextFloat(0.0f, 0.0f), false);
            if (vecRotation == null) {
                return null;
            }
            Rotation rotation = vecRotation.component2();
            Rotation rotation3 = RotationUtils.limitAngleChange(RotationUtils.serverRotation, rotation, (float)(Math.random() * (double)(((Number)this.maxTurnSpeed.get()).floatValue() - ((Number)this.minTurnSpeed.get()).floatValue()) + ((Number)this.minTurnSpeed.get()).doubleValue()));
            Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026).toFloat()\n            )");
            Rotation limitedRotation = rotation3;
            return limitedRotation;
        }
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"Zero", (boolean)true)) {
            Vec3 vec3 = MinecraftInstance.mc.field_71439_g.func_174824_e(1.0f);
            Intrinsics.checkNotNullExpressionValue((Object)vec3, (String)"mc.thePlayer.getPositionEyes(1F)");
            Vec3 vec32 = vec3;
            vec3 = boundingBox;
            Intrinsics.checkNotNullExpressionValue((Object)vec3, (String)"boundingBox");
            return RotationUtils.calculate(PlayerExtensionKt.getNearestPointBB(vec32, (AxisAlignedBB)vec3));
        }
        return RotationUtils.serverRotation;
    }

    private final void updateHitable() {
        if (StringsKt.equals((String)((String)this.rotations.get()), (String)"none", (boolean)true)) {
            this.hitable = true;
            return;
        }
        Disabler disabler = Client.INSTANCE.getModuleManager().getModule(Disabler.class);
        Intrinsics.checkNotNull((Object)disabler);
        Disabler disabler2 = disabler;
        if (((Number)this.maxTurnSpeed.get()).floatValue() <= 0.0f || ((Boolean)this.noHitCheck.get()).booleanValue() || disabler2.getCanModifyRotation()) {
            this.hitable = true;
            return;
        }
        double d = this.getAttackRange();
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
        Entity entity = (Entity)entityPlayerSP;
        EntityLivingBase entityLivingBase = this.target;
        Intrinsics.checkNotNull((Object)entityLivingBase);
        Entity raycastedEntity = RaycastUtils.raycastEntity(Math.min(d, PlayerExtensionKt.getDistanceToEntityBox(entity, (Entity)entityLivingBase)) + 1.0, arg_0 -> KillAura.updateHitable$lambda-11(this, arg_0));
        if (raycastedEntity instanceof EntityLivingBase && !EntityUtils.isFriend(raycastedEntity)) {
            this.currentTarget = (EntityLivingBase)raycastedEntity;
        }
        this.hitable = ((Number)this.maxTurnSpeed.get()).floatValue() > 0.0f ? this.currentTarget.equals(raycastedEntity) : true;
    }

    private final void startBlocking(Entity interactEntity, boolean interact) {
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"none", (boolean)true)) {
            this.fakeBlock = false;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"fake", (boolean)true)) {
            this.fakeBlock = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"ncp", (boolean)true)) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, null, 0.0f, 0.0f, 0.0f)));
            this.blockingStatus = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"click", (boolean)true)) {
            KeyBinding.func_74510_a((int)MinecraftInstance.mc.field_71474_y.field_74313_G.func_151463_i(), (boolean)true);
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldintave", (boolean)true)) {
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange((MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c + 1) % 9));
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"hurttime", (boolean)true)) {
            if (MinecraftInstance.mc.field_71439_g.field_70737_aN > 1) {
                if (!MinecraftInstance.mc.field_71439_g.field_70122_E) {
                    KeyBinding.func_74510_a((int)MinecraftInstance.mc.field_71474_y.field_74313_G.func_151463_i(), (boolean)true);
                }
            } else {
                KeyBinding.func_74510_a((int)MinecraftInstance.mc.field_71474_y.field_74313_G.func_151463_i(), (boolean)false);
            }
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"packet", (boolean)true)) {
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g()));
            this.blockingStatus = true;
        }
        if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldhypixel", (boolean)true)) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g(), 0.0f, 0.0f, 0.0f)));
            this.blockingStatus = true;
        }
        if (interact) {
            Entity entity = MinecraftInstance.mc.func_175606_aa();
            Vec3 positionEye = entity == null ? null : entity.func_174824_e(1.0f);
            double expandSize = interactEntity.func_70111_Y();
            AxisAlignedBB boundingBox = interactEntity.func_174813_aQ().func_72314_b(expandSize, expandSize, expandSize);
            Rotation rotation = RotationUtils.targetRotation;
            if (rotation == null) {
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP);
                float f = entityPlayerSP.field_70177_z;
                EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP2);
                rotation = new Rotation(f, entityPlayerSP2.field_70125_A);
            }
            Rotation rotation2 = rotation;
            float yaw = rotation2.component1();
            float pitch = rotation2.component2();
            float yawCos = (float)Math.cos(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
            float yawSin = (float)Math.sin(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
            float pitchCos = -((float)Math.cos(-pitch * ((float)Math.PI / 180)));
            float pitchSin = (float)Math.sin(-pitch * ((float)Math.PI / 180));
            double d = this.getMaxRange();
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP);
            double range2 = Math.min(d, PlayerExtensionKt.getDistanceToEntityBox((Entity)entityPlayerSP, interactEntity)) + 1.0;
            Vec3 vec3 = positionEye;
            Intrinsics.checkNotNull((Object)vec3);
            Vec3 lookAt = vec3.func_72441_c((double)(yawSin * pitchCos) * range2, (double)pitchSin * range2, (double)(yawCos * pitchCos) * range2);
            MovingObjectPosition movingObjectPosition = boundingBox.func_72327_a(positionEye, lookAt);
            if (movingObjectPosition == null) {
                return;
            }
            MovingObjectPosition movingObject = movingObjectPosition;
            Vec3 hitVec = movingObject.field_72307_f;
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C02PacketUseEntity(interactEntity, new Vec3(hitVec.field_72450_a - interactEntity.field_70165_t, hitVec.field_72448_b - interactEntity.field_70163_u, hitVec.field_72449_c - interactEntity.field_70161_v)));
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C02PacketUseEntity(interactEntity, C02PacketUseEntity.Action.INTERACT));
        }
    }

    private final void stopBlocking() {
        this.fakeBlock = false;
        this.blockingStatus = false;
        if (this.endTimer.hasTimePassed(2)) {
            if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"click", (boolean)true) || StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"hurttime", (boolean)true)) {
                KeyBinding.func_74510_a((int)MinecraftInstance.mc.field_71474_y.field_74313_G.func_151463_i(), (boolean)false);
            }
            if (StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"oldhypixel", (boolean)true)) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(1.0, 1.0, 1.0), EnumFacing.DOWN)));
            }
            if (!StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"fake", (boolean)true) && !StringsKt.equals((String)((String)this.autoBlockModeValue.get()), (String)"none", (boolean)true)) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN)));
            }
            if (((Boolean)this.toggleFreeLook.get()).booleanValue()) {
                FreeLook freeLook = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
                Boolean bl = freeLook == null ? null : Boolean.valueOf(freeLook.getState());
                Intrinsics.checkNotNull((Object)bl);
                if (bl.booleanValue()) {
                    FreeLook freeLook2 = Client.INSTANCE.getModuleManager().getModule(FreeLook.class);
                    Intrinsics.checkNotNull((Object)freeLook2);
                    freeLook2.setState(false);
                }
            }
            this.endTimer.reset();
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private final boolean getCancelRun() {
        if (MinecraftInstance.mc.field_71439_g.func_175149_v()) return true;
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
        Intrinsics.checkNotNullExpressionValue((Object)entityPlayerSP, (String)"mc.thePlayer");
        if (!this.isAlive((EntityLivingBase)entityPlayerSP)) return true;
        Freecam freecam = Client.INSTANCE.getModuleManager().get(Freecam.class);
        Intrinsics.checkNotNull((Object)freecam);
        if (freecam.getState()) return true;
        Scaffold scaffold = Client.INSTANCE.getModuleManager().get(Scaffold.class);
        Intrinsics.checkNotNull((Object)scaffold);
        if (!scaffold.getState()) return false;
        return true;
    }

    private final boolean isAlive(EntityLivingBase entity) {
        return entity.func_70089_S() && entity.func_110143_aJ() > 0.0f;
    }

    private final boolean getCanBlock() {
        return MinecraftInstance.mc.field_71439_g.func_70694_bm() != null && MinecraftInstance.mc.field_71439_g.func_70694_bm().func_77973_b() instanceof ItemSword;
    }

    private final float getMaxRange() {
        return !((Boolean)this.noHitCheck.get()).booleanValue() ? Math.max(((Number)this.rangeValue.get()).floatValue() - 0.3f + ((Number)this.prevRangeValue.get()).floatValue() + 1.2f, ((Number)this.rangeValue.get()).floatValue() - 0.3f + ((Number)this.prevRangeValue.get()).floatValue() + 1.2f) : Math.max(((Number)this.rangeValue.get()).floatValue() - 0.3f, ((Number)this.rangeValue.get()).floatValue() - 0.3f);
    }

    private final float getAttackRange() {
        return Math.max(((Number)this.rangeValue.get()).floatValue() - 0.3f, ((Number)this.rangeValue.get()).floatValue() - 0.3f);
    }

    @Override
    public String getTag() {
        return (String)this.targetModeValue.get();
    }

    private static final boolean updateHitable$lambda-11(KillAura this$0, Entity it) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        return it instanceof EntityLivingBase && !(it instanceof EntityArmorStand) && this$0.isEnemy(it);
    }

    public static final /* synthetic */ boolean access$updateRotations(KillAura $this, Entity entity) {
        return $this.updateRotations(entity);
    }

    public static final /* synthetic */ IntegerValue access$getMinCPS$p(KillAura $this) {
        return $this.minCPS;
    }

    public static final /* synthetic */ void access$setAttackDelay$p(KillAura $this, long l) {
        $this.attackDelay = l;
    }

    public static final /* synthetic */ BoolValue access$getCoolDownCheck$p(KillAura $this) {
        return $this.coolDownCheck;
    }

    public static final /* synthetic */ IntegerValue access$getMaxCPS$p(KillAura $this) {
        return $this.maxCPS;
    }

    public static final /* synthetic */ BoolValue access$getNoHitCheck$p(KillAura $this) {
        return $this.noHitCheck;
    }

    public static final /* synthetic */ FloatValue access$getMinTurnSpeed$p(KillAura $this) {
        return $this.minTurnSpeed;
    }

    public static final /* synthetic */ FloatValue access$getMaxTurnSpeed$p(KillAura $this) {
        return $this.maxTurnSpeed;
    }

    public static final /* synthetic */ BoolValue access$getMultiCombo$p(KillAura $this) {
        return $this.multiCombo;
    }

    public static final /* synthetic */ ListValue access$getTargetModeValue$p(KillAura $this) {
        return $this.targetModeValue;
    }
}

