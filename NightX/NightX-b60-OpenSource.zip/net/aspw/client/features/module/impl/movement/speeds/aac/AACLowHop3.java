/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACLowHop3
extends SpeedMode {
    private boolean firstJump;
    private boolean waitForGround;

    public AACLowHop3() {
        super("AACLowHop3");
    }

    @Override
    public void onEnable() {
        this.firstJump = true;
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving()) {
            if (AACLowHop3.mc.field_71439_g.field_70737_aN <= 0) {
                if (AACLowHop3.mc.field_71439_g.field_70122_E) {
                    this.waitForGround = false;
                    if (!this.firstJump) {
                        this.firstJump = true;
                    }
                    AACLowHop3.mc.field_71439_g.func_70664_aZ();
                    AACLowHop3.mc.field_71439_g.field_70181_x = 0.41;
                } else {
                    if (this.waitForGround) {
                        return;
                    }
                    if (AACLowHop3.mc.field_71439_g.field_70123_F) {
                        return;
                    }
                    this.firstJump = false;
                    AACLowHop3.mc.field_71439_g.field_70181_x -= 0.0149;
                }
                if (!AACLowHop3.mc.field_71439_g.field_70123_F) {
                    MovementUtils.forward(this.firstJump ? 0.0016 : 0.001799);
                }
            } else {
                this.firstJump = true;
                this.waitForGround = true;
            }
        }
        double speed2 = MovementUtils.getSpeed();
        AACLowHop3.mc.field_71439_g.field_70159_w = -(Math.sin(MovementUtils.getDirection()) * speed2);
        AACLowHop3.mc.field_71439_g.field_70179_y = Math.cos(MovementUtils.getDirection()) * speed2;
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

