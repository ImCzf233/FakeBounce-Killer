/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.other;

import net.aspw.client.event.ClientShutdownEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="PotionSpoof", spacedName="Potion Spoof", description="", category=ModuleCategory.OTHER)
public final class PotionSpoof
extends Module {
    private final BoolValue speedValue = new BoolValue("Speed", false);
    private final BoolValue moveSlowDownValue = new BoolValue("Slowness", false);
    private final BoolValue hasteValue = new BoolValue("Haste", false);
    private final BoolValue digSlowDownValue = new BoolValue("MiningFatigue", false);
    private final BoolValue blindnessValue = new BoolValue("Blindness", false);
    private final BoolValue strengthValue = new BoolValue("Strength", false);
    private final BoolValue jumpBoostValue = new BoolValue("JumpBoost", false);
    private final BoolValue weaknessValue = new BoolValue("Weakness", false);
    private final BoolValue regenerationValue = new BoolValue("Regeneration", false);
    private final BoolValue witherValue = new BoolValue("Wither", false);
    private final BoolValue resistanceValue = new BoolValue("Resistance", false);
    private final BoolValue fireResistanceValue = new BoolValue("FireResistance", false);
    private final BoolValue absorptionValue = new BoolValue("Absorption", false);
    private final BoolValue healthBoostValue = new BoolValue("HealthBoost", false);
    private final BoolValue poisonValue = new BoolValue("Poison", false);
    private final BoolValue saturationValue = new BoolValue("Saturation", false);
    private final BoolValue waterBreathingValue = new BoolValue("WaterBreathing", false);

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g != null) {
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76424_c.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76422_e.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76421_d.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76440_q.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76420_g.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76430_j.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76437_t.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76428_l.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76426_n.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_82731_v.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76429_m.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76444_x.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_180152_w.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76419_f.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76436_u.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76443_y.field_76415_H);
            MinecraftInstance.mc.field_71439_g.func_70618_n(Potion.field_76427_o.field_76415_H);
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (this.getState() && ((Boolean)this.speedValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76424_c.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.hasteValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76422_e.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.moveSlowDownValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76421_d.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.blindnessValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76440_q.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.strengthValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76420_g.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.jumpBoostValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76430_j.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.weaknessValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76437_t.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.regenerationValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76428_l.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.fireResistanceValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76426_n.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.witherValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_82731_v.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.resistanceValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76429_m.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.absorptionValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76444_x.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.healthBoostValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_180152_w.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.digSlowDownValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76419_f.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.poisonValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76436_u.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.saturationValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76443_y.field_76415_H, 1337, 1));
        }
        if (this.getState() && ((Boolean)this.waterBreathingValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.func_70690_d(new PotionEffect(Potion.field_76427_o.field_76415_H, 1337, 1));
        }
    }

    @EventTarget(ignoreCondition=true)
    public final void onShutdown(@Nullable ClientShutdownEvent event) {
        this.onDisable();
    }
}

