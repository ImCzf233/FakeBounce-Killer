/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.Vec3
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.player;

import java.awt.Color;
import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.player.AutoTool;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.VecRotation;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.extensions.BlockExtensionKt;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

@ModuleInfo(name="BedBreaker", spacedName="Bed Breaker", description="", category=ModuleCategory.PLAYER)
public final class BedBreaker
extends Module {
    private final ListValue throughWallsValue;
    private final FloatValue rangeValue;
    private final ListValue actionValue;
    private final BoolValue instantValue;
    private final ListValue swingValue;
    private final BoolValue rotationsValue;
    private final BoolValue surroundingsValue;
    private final BoolValue hypixelValue;
    private BlockPos pos;
    private BlockPos oldPos;
    private int blockHitDelay;
    private float currentDamage;
    private boolean breaking;

    public BedBreaker() {
        String[] stringArray = new String[]{"None", "Raycast", "Around"};
        this.throughWallsValue = new ListValue("ThroughWalls", stringArray, "Around");
        this.rangeValue = new FloatValue("Range", 5.0f, 1.0f, 7.0f, "m");
        stringArray = new String[]{"Destroy", "Use"};
        this.actionValue = new ListValue("Action", stringArray, "Destroy");
        this.instantValue = new BoolValue("Instant", false);
        stringArray = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Packet");
        this.rotationsValue = new BoolValue("Rotations", true);
        this.surroundingsValue = new BoolValue("Surroundings", false);
        this.hypixelValue = new BoolValue("Hypixel", false);
    }

    public final boolean getBreaking() {
        return this.breaking;
    }

    public final void setBreaking(boolean bl) {
        this.breaking = bl;
    }

    @Override
    public String getTag() {
        return (Boolean)this.hypixelValue.get() != false ? "Watchdog" : "Normal";
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        boolean b;
        Vec3 eyes;
        BlockPos blockPos;
        int targetId;
        block42: {
            block41: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                targetId = 26;
                if (this.pos == null || Block.func_149682_b((Block)BlockUtils.getBlock(this.pos)) != targetId) break block41;
                BlockPos blockPos2 = this.pos;
                Intrinsics.checkNotNull((Object)blockPos2);
                if (!(BlockUtils.getCenterDistance(blockPos2) > (double)((Number)this.rangeValue.get()).floatValue())) break block42;
            }
            this.pos = this.find(targetId);
        }
        if (this.pos == null) {
            this.currentDamage = 0.0f;
            return;
        }
        BlockPos blockPos3 = this.pos;
        if (blockPos3 == null) {
            return;
        }
        BlockPos currentPos = blockPos3;
        VecRotation vecRotation = RotationUtils.faceBlock(currentPos);
        if (vecRotation == null) {
            return;
        }
        VecRotation rotations = vecRotation;
        boolean surroundings = false;
        if (((Boolean)this.surroundingsValue.get()).booleanValue() && (blockPos = MinecraftInstance.mc.field_71441_e.func_147447_a(eyes = MinecraftInstance.mc.field_71439_g.func_174824_e(1.0f), rotations.getVec(), false, false, true).func_178782_a()) != null && !(BlockExtensionKt.getBlock(blockPos) instanceof BlockAir)) {
            if (currentPos.func_177958_n() != blockPos.func_177958_n() || currentPos.func_177956_o() != blockPos.func_177956_o() || currentPos.func_177952_p() != blockPos.func_177952_p()) {
                surroundings = true;
            }
            BlockPos blockPos4 = this.pos = blockPos;
            if (blockPos4 == null) {
                return;
            }
            currentPos = blockPos4;
            VecRotation vecRotation2 = RotationUtils.faceBlock(currentPos);
            if (vecRotation2 == null) {
                return;
            }
            rotations = vecRotation2;
        }
        boolean bl = b = Block.func_149682_b((Block)BlockUtils.getBlock(currentPos)) == targetId;
        if (((Boolean)this.hypixelValue.get()).booleanValue() && b && !(BlockUtils.getBlock(blockPos = currentPos.func_177984_a()) instanceof BlockAir)) {
            if (currentPos.func_177958_n() != blockPos.func_177958_n() || currentPos.func_177956_o() != blockPos.func_177956_o() || currentPos.func_177952_p() != blockPos.func_177952_p()) {
                surroundings = true;
            }
            BlockPos blockPos5 = this.pos = blockPos;
            if (blockPos5 == null) {
                return;
            }
            currentPos = blockPos5;
            VecRotation vecRotation3 = RotationUtils.faceBlock(currentPos);
            if (vecRotation3 == null) {
                return;
            }
            rotations = vecRotation3;
        }
        if (this.oldPos != null && !this.oldPos.equals(currentPos)) {
            this.currentDamage = 0.0f;
        }
        this.oldPos = currentPos;
        if (this.blockHitDelay < 1) {
            this.breaking = true;
        }
        if (this.blockHitDelay > 0) {
            int blockPos6 = this.blockHitDelay;
            this.blockHitDelay = blockPos6 + -1;
            return;
        }
        if (((Boolean)this.rotationsValue.get()).booleanValue()) {
            RotationUtils.setTargetRotation(rotations.getRotation());
        }
        if (StringsKt.equals((String)((String)this.actionValue.get()), (String)"destroy", (boolean)true) || surroundings) {
            AutoTool autoTool = Client.INSTANCE.getModuleManager().get(AutoTool.class);
            if (autoTool == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.features.module.impl.player.AutoTool");
            }
            AutoTool autoTool2 = autoTool;
            if (autoTool2.getState()) {
                autoTool2.switchSlot(currentPos);
            }
            if (((Boolean)this.instantValue.get()).booleanValue()) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, currentPos, EnumFacing.DOWN));
                String string = (String)this.swingValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                String string3 = string2;
                if (string3.equals("normal")) {
                    MinecraftInstance.mc.field_71439_g.func_71038_i();
                } else if (string3.equals("packet")) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
                }
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, currentPos, EnumFacing.DOWN));
                this.currentDamage = 0.0f;
                return;
            }
            Block block = BlockExtensionKt.getBlock(currentPos);
            if (block == null) {
                return;
            }
            Block block2 = block;
            if (this.currentDamage == 0.0f) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, currentPos, EnumFacing.DOWN));
                if (MinecraftInstance.mc.field_71439_g.field_71075_bZ.field_75098_d || block2.func_180647_a((EntityPlayer)MinecraftInstance.mc.field_71439_g, (World)MinecraftInstance.mc.field_71441_e, this.pos) >= 1.0f) {
                    String string = (String)this.swingValue.get();
                    Locale locale = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                    String string4 = string.toLowerCase(locale);
                    Intrinsics.checkNotNullExpressionValue((Object)string4, (String)"this as java.lang.String).toLowerCase(locale)");
                    String string5 = string4;
                    if (string5.equals("normal")) {
                        MinecraftInstance.mc.field_71439_g.func_71038_i();
                    } else if (string5.equals("packet")) {
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
                    }
                    MinecraftInstance.mc.field_71442_b.func_178888_a(this.pos, EnumFacing.DOWN);
                    this.currentDamage = 0.0f;
                    this.pos = null;
                    return;
                }
            }
            String string = (String)this.swingValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string6 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string6, (String)"this as java.lang.String).toLowerCase(locale)");
            String string7 = string6;
            if (string7.equals("normal")) {
                MinecraftInstance.mc.field_71439_g.func_71038_i();
            } else if (string7.equals("packet")) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
            }
            this.currentDamage += block2.func_180647_a((EntityPlayer)MinecraftInstance.mc.field_71439_g, (World)MinecraftInstance.mc.field_71441_e, currentPos);
            MinecraftInstance.mc.field_71441_e.func_175715_c(MinecraftInstance.mc.field_71439_g.func_145782_y(), currentPos, (int)(this.currentDamage * 10.0f) - 1);
            if (this.currentDamage >= 1.0f) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, currentPos, EnumFacing.DOWN));
                MinecraftInstance.mc.field_71442_b.func_178888_a(currentPos, EnumFacing.DOWN);
                this.blockHitDelay = 4;
                this.currentDamage = 0.0f;
                this.pos = null;
            }
        } else if (StringsKt.equals((String)((String)this.actionValue.get()), (String)"use", (boolean)true) && MinecraftInstance.mc.field_71442_b.func_178890_a(MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71441_e, MinecraftInstance.mc.field_71439_g.func_70694_bm(), this.pos, EnumFacing.DOWN, new Vec3((double)currentPos.func_177958_n(), (double)currentPos.func_177956_o(), (double)currentPos.func_177952_p()))) {
            String string = (String)this.swingValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string8 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string8, (String)"this as java.lang.String).toLowerCase(locale)");
            String string9 = string8;
            if (string9.equals("normal")) {
                MinecraftInstance.mc.field_71439_g.func_71038_i();
            } else if (string9.equals("packet")) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
            }
            this.blockHitDelay = 4;
            this.currentDamage = 0.0f;
            this.pos = null;
        }
    }

    @Override
    public void onEnable() {
        this.breaking = false;
    }

    @Override
    public void onDisable() {
        this.breaking = false;
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        BlockPos blockPos = this.pos;
        if (blockPos == null) {
            return;
        }
        RenderUtils.drawBlockBox(blockPos, Color.WHITE, true);
    }

    private final BlockPos find(int targetID) {
        this.breaking = false;
        int radius = (int)((Number)this.rangeValue.get()).floatValue() + 1;
        double nearestBlockDistance = Double.MAX_VALUE;
        BlockPos nearestBlock = null;
        int n = -radius + 1;
        int n2 = radius;
        if (n <= n2) {
            int x;
            do {
                int y;
                x = n2--;
                int n3 = -radius + 1;
                int n4 = radius;
                if (n3 > n4) continue;
                do {
                    int z;
                    y = n4--;
                    int n5 = -radius + 1;
                    int n6 = radius;
                    if (n5 > n6) continue;
                    do {
                        double distance;
                        Block block;
                        BlockPos blockPos;
                        if (BlockUtils.getBlock(blockPos = new BlockPos((int)MinecraftInstance.mc.field_71439_g.field_70165_t + x, (int)MinecraftInstance.mc.field_71439_g.field_70163_u + y, (int)MinecraftInstance.mc.field_71439_g.field_70161_v + (z = n6--))) == null || Block.func_149682_b((Block)block) != targetID || (distance = BlockUtils.getCenterDistance(blockPos)) > (double)((Number)this.rangeValue.get()).floatValue() || nearestBlockDistance < distance || !this.isHitable(blockPos) && !((Boolean)this.surroundingsValue.get()).booleanValue()) continue;
                        nearestBlockDistance = distance;
                        nearestBlock = blockPos;
                    } while (z != n5);
                } while (y != n3);
            } while (x != n);
        }
        return nearestBlock;
    }

    private final boolean isHitable(BlockPos blockPos) {
        Vec3 eyesPos;
        MovingObjectPosition movingObjectPosition;
        this.breaking = true;
        String string = (String)this.throughWallsValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        String string3 = string2;
        return string3.equals("raycast") ? (movingObjectPosition = MinecraftInstance.mc.field_71441_e.func_147447_a(eyesPos = new Vec3(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b + (double)MinecraftInstance.mc.field_71439_g.func_70047_e(), MinecraftInstance.mc.field_71439_g.field_70161_v), new Vec3((double)blockPos.func_177958_n() + 0.5, (double)blockPos.func_177956_o() + 0.5, (double)blockPos.func_177952_p() + 0.5), false, true, false)) != null && movingObjectPosition.func_178782_a().equals(blockPos) : (string3.equals("around") ? !(BlockUtils.isFullBlock(blockPos.func_177977_b()) && BlockUtils.isFullBlock(blockPos.func_177984_a()) && BlockUtils.isFullBlock(blockPos.func_177978_c()) && BlockUtils.isFullBlock(blockPos.func_177974_f()) && BlockUtils.isFullBlock(blockPos.func_177968_d()) && BlockUtils.isFullBlock(blockPos.func_177976_e())) : true);
    }
}

