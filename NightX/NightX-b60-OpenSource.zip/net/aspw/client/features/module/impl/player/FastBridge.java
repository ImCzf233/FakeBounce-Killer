/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.BlockPos
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.value.IntegerValue;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;

@ModuleInfo(name="FastBridge", spacedName="Fast Bridge", description="", category=ModuleCategory.PLAYER)
public final class FastBridge
extends Module {
    private final IntegerValue speedValue = new IntegerValue("Place-Speed", 0, 0, 20);
    private final TickTimer tickTimer = new TickTimer();

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        boolean shouldEagle;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.tickTimer.update();
        MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = shouldEagle = MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() == Blocks.field_150350_a;
        if (this.tickTimer.hasTimePassed(0 + ((Number)this.speedValue.get()).intValue()) && MinecraftInstance.mc.field_71474_y.field_74313_G.func_151470_d() && shouldEagle || MinecraftInstance.mc.field_71474_y.field_74313_G.func_151470_d() && !MinecraftInstance.mc.field_71439_g.field_70122_E) {
            KeyBinding.func_74507_a((int)MinecraftInstance.mc.field_71474_y.field_74313_G.func_151463_i());
            this.tickTimer.reset();
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E)) {
            MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
        }
    }
}

