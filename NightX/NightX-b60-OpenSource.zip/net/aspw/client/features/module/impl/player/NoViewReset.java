/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

@ModuleInfo(name="NoViewReset", spacedName="No View Reset", description="", category=ModuleCategory.PLAYER)
public final class NoViewReset
extends Module {
    private final BoolValue confirmValue = new BoolValue("Confirm", true);
    private final BoolValue illegalRotationValue = new BoolValue("ConfirmIllegalRotation", true);
    private final BoolValue noZeroValue = new BoolValue("NoZero", false);

    @EventTarget
    public final void onPacket(PacketEvent event) {
        block6: {
            block8: {
                Packet<?> packet;
                block7: {
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    packet = event.getPacket();
                    if (MinecraftInstance.mc.field_71439_g == null) {
                        return;
                    }
                    if (!(packet instanceof S08PacketPlayerPosLook)) break block6;
                    if (((Boolean)this.noZeroValue.get()).booleanValue() && ((S08PacketPlayerPosLook)packet).func_148931_f() == 0.0f && ((S08PacketPlayerPosLook)packet).func_148930_g() == 0.0f) {
                        return;
                    }
                    if (((Boolean)this.illegalRotationValue.get()).booleanValue()) break block7;
                    if (!(((S08PacketPlayerPosLook)packet).func_148930_g() <= 90.0f) || !(((S08PacketPlayerPosLook)packet).func_148930_g() >= -90.0f) || RotationUtils.serverRotation == null) break block8;
                    float f = ((S08PacketPlayerPosLook)packet).func_148931_f();
                    Rotation rotation = RotationUtils.serverRotation;
                    Intrinsics.checkNotNull((Object)rotation);
                    if (f == rotation.getYaw()) break block8;
                    float f2 = ((S08PacketPlayerPosLook)packet).func_148930_g();
                    Rotation rotation2 = RotationUtils.serverRotation;
                    Intrinsics.checkNotNull((Object)rotation2);
                    if (f2 == rotation2.getPitch()) break block8;
                }
                if (((Boolean)this.confirmValue.get()).booleanValue()) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C05PacketPlayerLook(((S08PacketPlayerPosLook)packet).func_148931_f(), ((S08PacketPlayerPosLook)packet).func_148930_g(), MinecraftInstance.mc.field_71439_g.field_70122_E));
                }
            }
            ((S08PacketPlayerPosLook)packet).field_148936_d = MinecraftInstance.mc.field_71439_g.field_70177_z;
            ((S08PacketPlayerPosLook)packet).field_148937_e = MinecraftInstance.mc.field_71439_g.field_70125_A;
        }
    }
}

