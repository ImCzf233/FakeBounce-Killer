/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.world.World
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Freecam", description="", category=ModuleCategory.PLAYER, keyBind=66)
public final class Freecam
extends Module {
    private final FloatValue speedValue = new FloatValue("Speed", 1.0f, 0.1f, 2.0f, "m");
    private final BoolValue noClipValue = new BoolValue("NoClip", true);
    private EntityOtherPlayerMP fakePlayer;
    private double oldX;
    private double oldY;
    private double oldZ;

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        this.oldX = MinecraftInstance.mc.field_71439_g.field_70165_t;
        this.oldY = MinecraftInstance.mc.field_71439_g.field_70163_u;
        this.oldZ = MinecraftInstance.mc.field_71439_g.field_70161_v;
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer = new EntityOtherPlayerMP((World)MinecraftInstance.mc.field_71441_e, MinecraftInstance.mc.field_71439_g.func_146103_bH());
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        entityOtherPlayerMP.func_71049_a((EntityPlayer)MinecraftInstance.mc.field_71439_g, true);
        Intrinsics.checkNotNull((Object)this.fakePlayer);
        this.fakePlayer.field_70759_as = MinecraftInstance.mc.field_71439_g.field_70759_as;
        EntityOtherPlayerMP entityOtherPlayerMP2 = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP2);
        entityOtherPlayerMP2.func_82149_j((Entity)MinecraftInstance.mc.field_71439_g);
        MinecraftInstance.mc.field_71441_e.func_73027_a(-1000, (Entity)this.fakePlayer);
        if (((Boolean)this.noClipValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70145_X = true;
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g == null || this.fakePlayer == null) {
            return;
        }
        MinecraftInstance.mc.field_71439_g.func_70080_a(this.oldX, this.oldY, this.oldZ, MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70125_A);
        WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        worldClient.func_73028_b(entityOtherPlayerMP.func_145782_y());
        this.fakePlayer = null;
        MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
        MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
        MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        EntityPlayerSP entityPlayerSP;
        if (((Boolean)this.noClipValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70145_X = true;
        }
        MinecraftInstance.mc.field_71439_g.field_70143_R = 0.0f;
        float value = ((Number)this.speedValue.get()).floatValue();
        MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
        MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
        MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
        if (MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d()) {
            entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            entityPlayerSP.field_70181_x += (double)value;
        }
        if (GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E)) {
            entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            entityPlayerSP.field_70181_x -= (double)value;
            MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
        }
        MovementUtils.strafe(value);
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        MinecraftInstance.mc.field_71439_g.field_70726_aT = 0.0f;
        MinecraftInstance.mc.field_71439_g.field_71109_bG = 0.0f;
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer || packet instanceof C0BPacketEntityAction) {
            event.cancelEvent();
        }
    }
}

