/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiIngameMenu
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.TickEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.InvMove;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC2BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC3BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC4BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC4Hop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC4SlowHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC5BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC6BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AAC7BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACBHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACGround;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACGround2;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACHop3313;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACHop350;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACHop438;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACLowHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACLowHop2;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACLowHop3;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACPort;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACYPort;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACYPort2;
import net.aspw.client.features.module.impl.movement.speeds.aac.AACv4BHop;
import net.aspw.client.features.module.impl.movement.speeds.aac.OldAACBHop;
import net.aspw.client.features.module.impl.movement.speeds.intave.IntaveHop;
import net.aspw.client.features.module.impl.movement.speeds.kauri.KauriLowHop;
import net.aspw.client.features.module.impl.movement.speeds.matrix.Matrix670;
import net.aspw.client.features.module.impl.movement.speeds.matrix.Matrix692;
import net.aspw.client.features.module.impl.movement.speeds.matrix.MatrixHop;
import net.aspw.client.features.module.impl.movement.speeds.matrix.MatrixYPort;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPBHop;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPBoost;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPFHop;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPFrame;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPHop;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPMiniJump;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPOnGround;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPSemiStrafe;
import net.aspw.client.features.module.impl.movement.speeds.ncp.NCPYPort;
import net.aspw.client.features.module.impl.movement.speeds.ncp.SNCPBHop;
import net.aspw.client.features.module.impl.movement.speeds.other.AEMine;
import net.aspw.client.features.module.impl.movement.speeds.other.Custom;
import net.aspw.client.features.module.impl.movement.speeds.other.GWEN;
import net.aspw.client.features.module.impl.movement.speeds.other.HiveHop;
import net.aspw.client.features.module.impl.movement.speeds.other.Jump;
import net.aspw.client.features.module.impl.movement.speeds.other.MineplexGround;
import net.aspw.client.features.module.impl.movement.speeds.other.RedeskyHop;
import net.aspw.client.features.module.impl.movement.speeds.other.SlowHop;
import net.aspw.client.features.module.impl.movement.speeds.other.TeleportCubeCraft;
import net.aspw.client.features.module.impl.movement.speeds.other.YPort;
import net.aspw.client.features.module.impl.movement.speeds.other.YPort2;
import net.aspw.client.features.module.impl.movement.speeds.spartan.SpartanYPort;
import net.aspw.client.features.module.impl.movement.speeds.spectre.SpectreBHop;
import net.aspw.client.features.module.impl.movement.speeds.spectre.SpectreLowHop;
import net.aspw.client.features.module.impl.movement.speeds.spectre.SpectreOnGround;
import net.aspw.client.features.module.impl.movement.speeds.vanillabhop.VanillaBhop;
import net.aspw.client.features.module.impl.movement.speeds.verus.VerusFloat;
import net.aspw.client.features.module.impl.movement.speeds.verus.VerusHop;
import net.aspw.client.features.module.impl.movement.speeds.verus.VerusLowHop;
import net.aspw.client.features.module.impl.movement.speeds.vulcan.VulcanGround;
import net.aspw.client.features.module.impl.movement.speeds.vulcan.VulcanHop1;
import net.aspw.client.features.module.impl.movement.speeds.vulcan.VulcanHop2;
import net.aspw.client.features.module.impl.movement.speeds.vulcan.VulcanYPort;
import net.aspw.client.features.module.impl.movement.speeds.watchdog.WatchdogBoost;
import net.aspw.client.features.module.impl.movement.speeds.watchdog.WatchdogCustom;
import net.aspw.client.features.module.impl.movement.speeds.watchdog.WatchdogOnGround;
import net.aspw.client.features.module.impl.movement.speeds.watchdog.WatchdogStable;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Speed", description="", category=ModuleCategory.MOVEMENT)
public final class Speed
extends Module {
    private boolean wasDown;
    private final SpeedMode[] speedModes;
    private final ListValue typeValue;
    private double y;
    private final ListValue ncpModeValue;
    private final ListValue aacModeValue;
    private final ListValue hypixelModeValue;
    private final ListValue kauriModeValue;
    private final ListValue intaveModeValue;
    private final ListValue spectreModeValue;
    private final ListValue otherModeValue;
    private final ListValue verusModeValue;
    private final ListValue vulcanModeValue;
    private final ListValue matrixModeValue;
    private final BoolValue timerValue;
    private final BoolValue smoothStrafe;
    private final FloatValue customSpeedValue;
    private final FloatValue motionYValue;
    @JvmField
    public final BoolValue boostSpeedValue;
    @JvmField
    public final IntegerValue boostDelayValue;
    @JvmField
    public final FloatValue speedValue;
    @JvmField
    public final FloatValue launchSpeedValue;
    @JvmField
    public final FloatValue addYMotionValue;
    @JvmField
    public final FloatValue yValue;
    @JvmField
    public final FloatValue upTimerValue;
    @JvmField
    public final FloatValue downTimerValue;
    @JvmField
    public final ListValue strafeValue;
    @JvmField
    public final IntegerValue groundStay;
    @JvmField
    public final BoolValue groundResetXZValue;
    @JvmField
    public final BoolValue resetXZValue;
    @JvmField
    public final BoolValue resetYValue;
    @JvmField
    public final BoolValue doLaunchSpeedValue;
    @JvmField
    public final BoolValue jumpStrafe;
    @JvmField
    public final BoolValue sendJumpValue;
    @JvmField
    public final BoolValue recalcValue;
    @JvmField
    public final FloatValue glideStrengthValue;
    @JvmField
    public final FloatValue moveSpeedValue;
    @JvmField
    public final FloatValue jumpYValue;
    @JvmField
    public final FloatValue baseStrengthValue;
    @JvmField
    public final FloatValue baseTimerValue;
    @JvmField
    public final FloatValue baseMTimerValue;
    @JvmField
    public final FloatValue portMax;
    @JvmField
    public final FloatValue aacGroundTimerValue;
    @JvmField
    public final FloatValue vanillaBhopSpeed;
    @JvmField
    public final FloatValue cubecraftPortLengthValue;
    @JvmField
    public final FloatValue mineplexGroundSpeedValue;
    @JvmField
    public final BoolValue noBob;
    private final BoolValue fakeYValue;

    public Speed() {
        Object[] objectArray = new SpeedMode[]{new NCPBHop(), new NCPFHop(), new SNCPBHop(), new NCPHop(), new NCPYPort(), new AAC4Hop(), new AAC4SlowHop(), new AACv4BHop(), new AACBHop(), new AAC2BHop(), new AAC3BHop(), new AAC4BHop(), new AAC5BHop(), new AAC6BHop(), new AAC7BHop(), new OldAACBHop(), new AACPort(), new AACLowHop(), new AACLowHop2(), new AACLowHop3(), new AACGround(), new AACGround2(), new AACHop350(), new AACHop3313(), new AACHop438(), new AACYPort(), new AACYPort2(), new WatchdogOnGround(), new WatchdogBoost(), new WatchdogStable(), new WatchdogCustom(), new VanillaBhop(), new SpartanYPort(), new SpectreBHop(), new SpectreLowHop(), new SpectreOnGround(), new SlowHop(), new Custom(), new Jump(), new AEMine(), new NCPSemiStrafe(), new GWEN(), new NCPBoost(), new NCPFrame(), new NCPMiniJump(), new NCPOnGround(), new YPort(), new YPort2(), new HiveHop(), new MineplexGround(), new RedeskyHop(), new TeleportCubeCraft(), new VerusHop(), new VerusLowHop(), new VerusFloat(), new VulcanHop1(), new VulcanHop2(), new VulcanYPort(), new VulcanGround(), new MatrixHop(), new MatrixYPort(), new Matrix670(), new Matrix692(), new KauriLowHop(), new IntaveHop()};
        this.speedModes = objectArray;
        Object object = new String[]{"NCP", "AAC", "Spartan", "Spectre", "Watchdog", "Verus", "Vulcan", "Matrix", "Kauri", "Intave", "Custom", "VanillaBhop", "Other"};
        objectArray = object;
        this.typeValue = new ListValue(this, (String[])objectArray){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Type", $super_call_param$1, "VanillaBhop");
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"BHop", "FHop", "SBHop", "Hop", "SemiStrafe", "YPort", "Boost", "Frame", "MiniJump", "OnGround"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"ncp", (boolean)true);
            }
        };
        this.ncpModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("NCP-Mode", $super_call_param$1, "BHop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"4Hop", "4SlowHop", "v4BHop", "BHop", "2BHop", "3BHop", "4BHop", "5BHop", "6BHop", "7BHop", "OldBHop", "Port", "LowHop", "LowHop2", "LowHop3", "Ground", "Ground2", "Hop3.5.0", "Hop3.3.13", "Hop4.3.8", "YPort", "YPort2"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"aac", (boolean)true);
            }
        };
        this.aacModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("AAC-Mode", $super_call_param$1, "4Hop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"OnGround", "Boost", "Stable", "Custom"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true);
            }
        };
        this.hypixelModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Watchdog-Mode", $super_call_param$1, "OnGround", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"LowHop"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"kauri", (boolean)true);
            }
        };
        this.kauriModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Kauri-Mode", $super_call_param$1, "LowHop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"Hop"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"intave", (boolean)true);
            }
        };
        this.intaveModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Intave-Mode", $super_call_param$1, "Hop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"BHop", "LowHop", "OnGround"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"spectre", (boolean)true);
            }
        };
        this.spectreModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Spectre-Mode", $super_call_param$1, "BHop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"YPort", "YPort2", "SlowHop", "Jump", "AEMine", "GWEN", "HiveHop", "MineplexGround", "RedeskyHop", "TeleportCubeCraft"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"other", (boolean)true);
            }
        };
        this.otherModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Other-Mode", $super_call_param$1, "YPort", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"Hop", "LowHop", "Float"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"verus", (boolean)true);
            }
        };
        this.verusModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Verus-Mode", $super_call_param$1, "Hop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"Hop1", "Hop2", "YPort", "Ground"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"vulcan", (boolean)true);
            }
        };
        this.vulcanModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Vulcan-Mode", $super_call_param$1, "YPort", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        object = new String[]{"Hop", "YPort", "6.7.0", "6.9.2"};
        objectArray = object;
        object = new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"matrix", (boolean)true);
            }
        };
        this.matrixModeValue = new ListValue(this, (String[])objectArray, (Object)object){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super("Matrix-Mode", $super_call_param$1, "Hop", (Function0<Boolean>)((Function0)$super_call_param$2));
            }

            protected void onChange(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onDisable();
                }
            }

            protected void onChanged(String oldValue, String newValue) {
                Intrinsics.checkNotNullParameter((Object)oldValue, (String)"oldValue");
                Intrinsics.checkNotNullParameter((Object)newValue, (String)"newValue");
                if (this.this$0.getState()) {
                    this.this$0.onEnable();
                }
            }
        };
        this.timerValue = new BoolValue("UseTimer", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true);
            }
        }));
        this.smoothStrafe = new BoolValue("SmoothStrafe", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true);
            }
        }));
        this.customSpeedValue = new FloatValue("StrSpeed", 0.42f, 0.2f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true);
            }
        }));
        this.motionYValue = new FloatValue("MotionY", 0.42f, 0.0f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true);
            }
        }));
        this.boostSpeedValue = new BoolValue("Ground-Boost", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"vulcanground", (boolean)true);
            }
        }));
        this.boostDelayValue = new IntegerValue("Boost-Delay", 8, 2, 15, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"vulcanground", (boolean)true);
            }
        }));
        this.speedValue = new FloatValue("CustomSpeed", 1.0f, 0.2f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.launchSpeedValue = new FloatValue("CustomLaunchSpeed", 1.6f, 0.2f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.addYMotionValue = new FloatValue("CustomAddYMotion", 0.0f, 0.0f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.yValue = new FloatValue("CustomY", 0.42f, 0.0f, 4.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.upTimerValue = new FloatValue("CustomUpTimer", 1.0f, 0.1f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.downTimerValue = new FloatValue("CustomDownTimer", 1.0f, 0.1f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        objectArray = new String[]{"Strafe", "Boost", "Plus", "PlusOnlyUp", "Non-Strafe"};
        this.strafeValue = new ListValue("CustomStrafe", (String[])objectArray, "Strafe", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.groundStay = new IntegerValue("CustomGroundStay", 0, 0, 10, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.groundResetXZValue = new BoolValue("CustomGroundResetXZ", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.resetXZValue = new BoolValue("CustomResetXZ", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.resetYValue = new BoolValue("CustomResetY", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.doLaunchSpeedValue = new BoolValue("CustomDoLaunchSpeed", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.jumpStrafe = new BoolValue("JumpStrafe", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"other", (boolean)true);
            }
        }));
        this.sendJumpValue = new BoolValue("SendJump", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true);
            }
        }));
        this.recalcValue = new BoolValue("ReCalculate", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && (Boolean)this.this$0.sendJumpValue.get() != false && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true);
            }
        }));
        this.glideStrengthValue = new FloatValue("GlideStrength", 0.0f, 0.0f, 0.05f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true);
            }
        }));
        this.moveSpeedValue = new FloatValue("MoveSpeed", 1.7f, 1.0f, 1.7f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true);
            }
        }));
        this.jumpYValue = new FloatValue("JumpY", 0.42f, 0.0f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true);
            }
        }));
        this.baseStrengthValue = new FloatValue("BaseMultiplier", 1.0f, 0.5f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"watchdog", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdognew", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogcustom", (boolean)true) && !StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogonground", (boolean)true);
            }
        }));
        this.baseTimerValue = new FloatValue("BaseTimer", 1.5f, 1.0f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogboost", (boolean)true);
            }
        }));
        this.baseMTimerValue = new FloatValue("BaseMultiplierTimer", 1.0f, 0.0f, 3.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"watchdogboost", (boolean)true);
            }
        }));
        this.portMax = new FloatValue("AAC-PortLength", 1.0f, 1.0f, 20.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"aac", (boolean)true);
            }
        }));
        this.aacGroundTimerValue = new FloatValue("AACGround-Timer", 3.0f, 1.1f, 10.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"aac", (boolean)true);
            }
        }));
        this.vanillaBhopSpeed = new FloatValue("Hop-Speed", 0.9f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getTypeValue().get()), (String)"vanillabhop", (boolean)true);
            }
        }));
        this.cubecraftPortLengthValue = new FloatValue("CubeCraft-PortLength", 1.0f, 0.1f, 2.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"teleportcubecraft", (boolean)true);
            }
        }));
        this.mineplexGroundSpeedValue = new FloatValue("MineplexGround-Speed", 0.6f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Speed this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)this.this$0.getModeName(), (String)"mineplexground", (boolean)true);
            }
        }));
        this.noBob = new BoolValue("NoBob", false);
        this.fakeYValue = new BoolValue("FakeY", false);
    }

    public final SpeedMode[] getSpeedModes() {
        return this.speedModes;
    }

    public final ListValue getTypeValue() {
        return this.typeValue;
    }

    public final double getY() {
        return this.y;
    }

    public final void setY(double d) {
        this.y = d;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        SpeedMode speedMode;
        if (MinecraftInstance.mc.field_71439_g.func_70093_af()) {
            return;
        }
        SpeedMode speedMode2 = speedMode = this.getMode();
        if (speedMode2 != null) {
            speedMode2.onUpdate();
        }
    }

    public final ListValue getNcpModeValue() {
        return this.ncpModeValue;
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.noBob.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70726_aT = 0.0f;
            MinecraftInstance.mc.field_71439_g.field_71109_bG = 0.0f;
        }
        if (((Boolean)this.fakeYValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70726_aT = 0.0f;
        }
        if (MinecraftInstance.mc.field_71439_g.func_70093_af() || event.getEventState() != EventState.PRE) {
            return;
        }
        SpeedMode speedMode = this.getMode();
        if (speedMode != null) {
            speedMode.onMotion(event);
            speedMode.onMotion();
        }
    }

    @EventTarget
    public final void onMove(@Nullable MoveEvent event) {
        SpeedMode speedMode;
        if (MinecraftInstance.mc.field_71439_g.func_70093_af()) {
            return;
        }
        SpeedMode speedMode2 = speedMode = this.getMode();
        if (speedMode2 != null) {
            speedMode2.onMove(event);
        }
    }

    public final ListValue getAacModeValue() {
        return this.aacModeValue;
    }

    @EventTarget
    public final void onTick(@Nullable TickEvent event) {
        SpeedMode speedMode;
        if (MinecraftInstance.mc.field_71439_g.func_70093_af()) {
            return;
        }
        SpeedMode speedMode2 = speedMode = this.getMode();
        if (speedMode2 != null) {
            speedMode2.onTick();
        }
    }

    @EventTarget
    public final void onJump(@Nullable JumpEvent event) {
        SpeedMode speedMode;
        SpeedMode speedMode2 = speedMode = this.getMode();
        if (speedMode2 != null) {
            speedMode2.onJump(event);
        }
    }

    public final ListValue getHypixelModeValue() {
        return this.hypixelModeValue;
    }

    public final ListValue getKauriModeValue() {
        return this.kauriModeValue;
    }

    public final ListValue getIntaveModeValue() {
        return this.intaveModeValue;
    }

    @Override
    public void onEnable() {
        SpeedMode speedMode;
        this.wasDown = false;
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
        this.y = MinecraftInstance.mc.field_71439_g.field_70163_u;
        SpeedMode speedMode2 = speedMode = this.getMode();
        if (speedMode2 != null) {
            speedMode2.onEnable();
        }
    }

    /*
     * Unable to fully structure code
     */
    @Override
    public void onDisable() {
        block4: {
            MinecraftInstance.mc.field_71439_g.eyeHeight = MinecraftInstance.mc.field_71439_g.getDefaultEyeHeight();
            if (MinecraftInstance.mc.field_71439_g == null) {
                return;
            }
            MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
            v0 = MinecraftInstance.mc.field_71474_y.field_74314_A;
            if (MinecraftInstance.mc.field_71439_g == null) ** GOTO lbl-1000
            if (MinecraftInstance.mc.field_71415_G) break block4;
            v1 = Client.INSTANCE.getModuleManager().getModule(InvMove.class);
            Intrinsics.checkNotNull((Object)v1);
            if (!v1.getState()) ** GOTO lbl-1000
        }
        if (!(MinecraftInstance.mc.field_71462_r instanceof GuiIngameMenu) && !(MinecraftInstance.mc.field_71462_r instanceof GuiChat) && GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A)) {
            v2 = true;
        } else lbl-1000:
        // 3 sources

        {
            v2 = false;
        }
        v0.field_74513_e = v2;
        v3 = speedMode = this.getMode();
        if (v3 != null) {
            v3.onDisable();
        }
    }

    public final ListValue getSpectreModeValue() {
        return this.spectreModeValue;
    }

    @Override
    public String getTag() {
        return (String)this.typeValue.get();
    }

    public final ListValue getOtherModeValue() {
        return this.otherModeValue;
    }

    public final String getModeName() {
        String mode = "";
        switch ((String)this.typeValue.get()) {
            case "NCP": {
                mode = StringsKt.equals((String)((String)this.ncpModeValue.get()), (String)"SBHop", (boolean)true) ? "SNCPBHop" : Intrinsics.stringPlus((String)"NCP", this.ncpModeValue.get());
                break;
            }
            case "AAC": {
                mode = StringsKt.equals((String)((String)this.aacModeValue.get()), (String)"oldbhop", (boolean)true) ? "OldAACBHop" : Intrinsics.stringPlus((String)"AAC", this.aacModeValue.get());
                break;
            }
            case "Spartan": {
                mode = "SpartanYPort";
                break;
            }
            case "Spectre": {
                mode = Intrinsics.stringPlus((String)"Spectre", this.spectreModeValue.get());
                break;
            }
            case "Watchdog": {
                mode = Intrinsics.stringPlus((String)"Watchdog", this.hypixelModeValue.get());
                break;
            }
            case "Verus": {
                mode = Intrinsics.stringPlus((String)"Verus", this.verusModeValue.get());
                break;
            }
            case "Vulcan": {
                mode = Intrinsics.stringPlus((String)"Vulcan", this.vulcanModeValue.get());
                break;
            }
            case "Matrix": {
                mode = Intrinsics.stringPlus((String)"Matrix", this.matrixModeValue.get());
                break;
            }
            case "Kauri": {
                mode = Intrinsics.stringPlus((String)"Kauri", this.kauriModeValue.get());
                break;
            }
            case "Intave": {
                mode = Intrinsics.stringPlus((String)"Intave", this.intaveModeValue.get());
                break;
            }
            case "VanillaBhop": {
                mode = "VanillaBhop";
                break;
            }
            case "Custom": {
                mode = "Custom";
                break;
            }
            case "Other": {
                mode = (String)this.otherModeValue.get();
            }
        }
        return mode;
    }

    public final SpeedMode getMode() {
        for (SpeedMode speedMode : this.speedModes) {
            if (!StringsKt.equals((String)speedMode.modeName, (String)this.getModeName(), (boolean)true)) continue;
            return speedMode;
        }
        return null;
    }

    public final ListValue getVerusModeValue() {
        return this.verusModeValue;
    }

    public final ListValue getVulcanModeValue() {
        return this.vulcanModeValue;
    }

    public final ListValue getMatrixModeValue() {
        return this.matrixModeValue;
    }

    public final BoolValue getTimerValue() {
        return this.timerValue;
    }

    public final BoolValue getSmoothStrafe() {
        return this.smoothStrafe;
    }

    public final FloatValue getCustomSpeedValue() {
        return this.customSpeedValue;
    }

    public final FloatValue getMotionYValue() {
        return this.motionYValue;
    }

    public final BoolValue getFakeYValue() {
        return this.fakeYValue;
    }
}

