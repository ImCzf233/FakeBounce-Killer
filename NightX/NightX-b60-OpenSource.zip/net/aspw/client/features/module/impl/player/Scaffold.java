/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.RangesKt
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.multiplayer.PlayerControllerMP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 *  net.minecraft.potion.Potion
 *  net.minecraft.stats.StatList
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.MathHelper
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.util.MovingObjectPosition$MovingObjectType
 *  net.minecraft.util.Vec3
 *  net.minecraft.util.Vec3i
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import java.util.Locale;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.PlaceRotation;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.block.PlaceInfo;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TickTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.font.Fonts;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.potion.Potion;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Scaffold", description="", category=ModuleCategory.PLAYER)
public final class Scaffold
extends Module {
    private final BoolValue allowTower = new BoolValue("EnableTower", true);
    private final BoolValue towerMove = new BoolValue("TowerMove", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ Scaffold this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get();
        }
    }));
    private final ListValue towerModeValue;
    private final FloatValue towerTimerValue;
    private final FloatValue jumpMotionValue;
    private final IntegerValue jumpDelayValue;
    private final FloatValue stableMotionValue;
    private final BoolValue stableFakeJumpValue;
    private final BoolValue stableStopValue;
    private final IntegerValue stableStopDelayValue;
    private final FloatValue constantMotionValue;
    private final FloatValue constantMotionJumpGroundValue;
    private final FloatValue teleportHeightValue;
    private final IntegerValue teleportDelayValue;
    private final BoolValue teleportGroundValue;
    private final BoolValue teleportNoMotionValue;
    private final ListValue modeValue;
    @JvmField
    public final ListValue sprintModeValue;
    private final ListValue autoBlockMode;
    private final ListValue placeConditionValue;
    private final ListValue rotationModeValue;
    private final ListValue rotationLookupValue;
    private final FloatValue staticPitchValue;
    private final FloatValue customYawValue;
    private final FloatValue customPitchValue;
    private final FloatValue speenSpeedValue;
    private final FloatValue speenPitchValue;
    private final BoolValue keepRotOnJumpValue;
    private final ListValue preRotationValue;
    private final ListValue swingValue;
    private final BoolValue placeableDelay;
    private final IntegerValue maxDelayValue;
    private final IntegerValue minDelayValue;
    private final FloatValue timerValue;
    private final BoolValue placeSlowDownValue;
    private final FloatValue speedModifierValue;
    private final BoolValue slowDownValue;
    private final FloatValue xzMultiplier;
    private final BoolValue noSpeedPotValue;
    private final FloatValue speedSlowDown;
    private final BoolValue customSpeedValue;
    private final FloatValue customMoveSpeedValue;
    private final BoolValue animationValue;
    private final BoolValue downValue;
    private final BoolValue noHitCheckValue;
    private final BoolValue sameYValue;
    private final BoolValue autoJumpValue;
    private final BoolValue smartSpeedValue;
    private final BoolValue safeWalkValue;
    private final BoolValue airSafeValue;
    private final BoolValue autoDisableSpeedValue;
    private final BoolValue keepRotationValue;
    private final IntegerValue keepLengthValue;
    private final BoolValue rotationStrafeValue;
    private final FloatValue maxTurnSpeed;
    private final FloatValue minTurnSpeed;
    private final BoolValue eagleValue;
    private final BoolValue eagleSilentValue;
    private final IntegerValue blocksToEagleValue;
    private final FloatValue eagleEdgeDistanceValue;
    private final BoolValue omniDirectionalExpand;
    private final IntegerValue expandLengthValue;
    private final BoolValue zitterValue;
    private final ListValue zitterModeValue;
    private final FloatValue zitterSpeed;
    private final FloatValue zitterStrength;
    private final IntegerValue zitterDelay;
    private final MSTimer delayTimer;
    private final MSTimer towerDelayTimer;
    private final MSTimer zitterTimer;
    private final TickTimer timer;
    private PlaceInfo targetPlace;
    private PlaceInfo towerPlace;
    private int launchY;
    private boolean faceBlock;
    private Rotation lockRotation;
    private Rotation lookupRotation;
    private Rotation speenRotation;
    private int slot;
    private int lastSlot;
    private boolean zitterDirection;
    private long delay;
    private int offGroundTicks;
    private int placedBlocksWithoutEagle;
    private boolean eagleSneaking;
    private boolean shouldGoDown;
    private boolean canTower;
    private float firstPitch;
    private float firstRotate;
    private float progress;
    private float spinYaw;
    private long lastMS;
    private double jumpGround;
    private int verusState;
    private int prevSlot;

    public Scaffold() {
        String[] stringArray = new String[]{"Jump", "Motion", "StableMotion", "ConstantMotion", "MotionTP", "Teleport", "AAC3.3.9", "AAC3.6.4"};
        this.towerModeValue = new ListValue("TowerMode", stringArray, "ConstantMotion", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get();
            }
        }));
        this.towerTimerValue = new FloatValue("TowerTimer", 1.0f, 0.1f, 1.4f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get();
            }
        }));
        this.jumpMotionValue = new FloatValue("JumpMotion", 0.42f, 0.3681289f, 0.79f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Jump", (boolean)true);
            }
        }));
        this.jumpDelayValue = new IntegerValue("JumpDelay", 0, 0, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Jump", (boolean)true);
            }
        }));
        this.stableMotionValue = new FloatValue("StableMotion", 0.41982f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"StableMotion", (boolean)true);
            }
        }));
        this.stableFakeJumpValue = new BoolValue("StableFakeJump", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"StableMotion", (boolean)true);
            }
        }));
        this.stableStopValue = new BoolValue("StableStop", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"StableMotion", (boolean)true);
            }
        }));
        this.stableStopDelayValue = new IntegerValue("StableStopDelay", 1500, 0, 5000, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"StableMotion", (boolean)true) && (Boolean)Scaffold.access$getStableStopValue$p(this.this$0).get() != false;
            }
        }));
        this.constantMotionValue = new FloatValue("ConstantMotion", 0.42f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"ConstantMotion", (boolean)true);
            }
        }));
        this.constantMotionJumpGroundValue = new FloatValue("ConstantMotionJumpGround", 0.79f, 0.76f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"ConstantMotion", (boolean)true);
            }
        }));
        this.teleportHeightValue = new FloatValue("TeleportHeight", 1.15f, 0.1f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Teleport", (boolean)true);
            }
        }));
        this.teleportDelayValue = new IntegerValue("TeleportDelay", 0, 0, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Teleport", (boolean)true);
            }
        }));
        this.teleportGroundValue = new BoolValue("TeleportGround", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Teleport", (boolean)true);
            }
        }));
        this.teleportNoMotionValue = new BoolValue("TeleportNoMotion", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getAllowTower$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getTowerModeValue$p(this.this$0).get()), (String)"Teleport", (boolean)true);
            }
        }));
        stringArray = new String[]{"Normal", "Rewinside", "Expand"};
        this.modeValue = new ListValue("Mode", stringArray, "Normal");
        stringArray = new String[]{"Same", "Silent", "Ground", "Air", "Off"};
        this.sprintModeValue = new ListValue("SprintMode", stringArray, "Same");
        stringArray = new String[]{"Fake", "Spoof", "Switch", "Off"};
        this.autoBlockMode = new ListValue("AutoBlock", stringArray, "Fake");
        stringArray = new String[]{"Air", "FallDown", "NegativeMotion", "Always"};
        this.placeConditionValue = new ListValue("Place-Condition", stringArray, "Always");
        stringArray = new String[]{"Normal", "AAC", "Watchdog", "Static", "Static2", "Static3", "Spin", "Custom"};
        this.rotationModeValue = new ListValue("RotationMode", stringArray, "Normal");
        stringArray = new String[]{"Normal", "AAC", "Same"};
        this.rotationLookupValue = new ListValue("RotationLookup", stringArray, "Normal");
        this.staticPitchValue = new FloatValue("Static-Pitch", 86.0f, 80.0f, 90.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                String string = (String)this.this$0.getRotationModeValue().get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                return StringsKt.startsWith$default((String)string2, (String)"static", (boolean)false, (int)2, null);
            }
        }));
        this.customYawValue = new FloatValue("Custom-Yaw", 135.0f, -180.0f, 180.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.customPitchValue = new FloatValue("Custom-Pitch", 86.0f, -90.0f, 90.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"custom", (boolean)true);
            }
        }));
        this.speenSpeedValue = new FloatValue("Spin-Speed", 5.0f, -90.0f, 90.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"spin", (boolean)true);
            }
        }));
        this.speenPitchValue = new FloatValue("Spin-Pitch", 90.0f, -90.0f, 90.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"spin", (boolean)true);
            }
        }));
        this.keepRotOnJumpValue = new BoolValue("KeepRotation-OnJump", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"normal", (boolean)true) && !StringsKt.equals((String)((String)this.this$0.getRotationModeValue().get()), (String)"aac", (boolean)true);
            }
        }));
        stringArray = new String[]{"Lock", "Normal", "None"};
        this.preRotationValue = new ListValue("PreRotationMode", stringArray, "Lock");
        stringArray = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Packet");
        this.placeableDelay = new BoolValue("PlaceableDelay", false);
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getPlaceableDelay$p(this.this$0).get();
            }
        };
        this.maxDelayValue = new IntegerValue(this, stringArray){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super("MaxDelay", 50, 0, 1000, "ms", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)Scaffold.access$getMinDelayValue$p(this.this$0).get()).intValue();
                if (i > newValue) {
                    this.set(i);
                }
            }
        };
        stringArray = new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getPlaceableDelay$p(this.this$0).get();
            }
        };
        this.minDelayValue = new IntegerValue(this, stringArray){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super("MinDelay", 50, 0, 1000, "ms", (Function0<Boolean>)((Function0)$super_call_param$1));
            }

            protected void onChanged(int oldValue, int newValue) {
                int i = ((Number)Scaffold.access$getMaxDelayValue$p(this.this$0).get()).intValue();
                if (i < newValue) {
                    this.set(i);
                }
            }
        };
        this.timerValue = new FloatValue("Timer", 1.0f, 0.1f, 1.4f);
        this.placeSlowDownValue = new BoolValue("Place-SlowDown", false);
        this.speedModifierValue = new FloatValue("Speed-Multiplier", 0.8f, 0.0f, 1.4f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getPlaceSlowDownValue$p(this.this$0).get();
            }
        }));
        this.slowDownValue = new BoolValue("SlowDown", false);
        this.xzMultiplier = new FloatValue("XZ-Multiplier", 0.6f, 0.0f, 1.1f, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getSlowDownValue$p(this.this$0).get();
            }
        }));
        this.noSpeedPotValue = new BoolValue("NoSpeedPot", false);
        this.speedSlowDown = new FloatValue("SpeedPot-SlowDown", 0.8f, 0.0f, 0.9f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getNoSpeedPotValue$p(this.this$0).get();
            }
        }));
        this.customSpeedValue = new BoolValue("CustomSpeed", false);
        this.customMoveSpeedValue = new FloatValue("CustomMoveSpeed", 0.2f, 0.0f, 5.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getCustomSpeedValue$p(this.this$0).get();
            }
        }));
        this.animationValue = new BoolValue("Animation", false);
        this.downValue = new BoolValue("Down", true);
        this.noHitCheckValue = new BoolValue("NoHitCheck", false);
        this.sameYValue = new BoolValue("KeepY", false);
        this.autoJumpValue = new BoolValue("AutoJump", false);
        this.smartSpeedValue = new BoolValue("SpeedKeepY", true);
        this.safeWalkValue = new BoolValue("SafeWalk", false);
        this.airSafeValue = new BoolValue("AirSafe", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getSafeWalkValue$p(this.this$0).get();
            }
        }));
        this.autoDisableSpeedValue = new BoolValue("AutoDisable-Speed", false);
        this.keepRotationValue = new BoolValue("KeepRotation", true);
        this.keepLengthValue = new IntegerValue("KeepRotation-Length", 0, 0, 20, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getKeepRotationValue$p(this.this$0).get() == false;
            }
        }));
        this.rotationStrafeValue = new BoolValue("RotationStrafe", false);
        this.maxTurnSpeed = new FloatValue(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super("MaxTurnSpeed", 120.0f, 0.0f, 180.0f, "\u00b0");
            }

            protected void onChanged(float oldValue, float newValue) {
                float i = ((Number)Scaffold.access$getMinTurnSpeed$p(this.this$0).get()).floatValue();
                if (i > newValue) {
                    this.set(Float.valueOf(i));
                }
            }
        };
        this.minTurnSpeed = new FloatValue(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super("MinTurnSpeed", 80.0f, 0.0f, 180.0f, "\u00b0");
            }

            protected void onChanged(float oldValue, float newValue) {
                float i = ((Number)Scaffold.access$getMaxTurnSpeed$p(this.this$0).get()).floatValue();
                if (i < newValue) {
                    this.set(Float.valueOf(i));
                }
            }
        };
        this.eagleValue = new BoolValue("Eagle", false);
        this.eagleSilentValue = new BoolValue("EagleSilent", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getEagleValue$p(this.this$0).get();
            }
        }));
        this.blocksToEagleValue = new IntegerValue("BlocksToEagle", 0, 0, 10, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getEagleValue$p(this.this$0).get();
            }
        }));
        this.eagleEdgeDistanceValue = new FloatValue("EagleEdgeDistance", 0.2f, 0.0f, 0.5f, "m", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)Scaffold.access$getEagleValue$p(this.this$0).get();
            }
        }));
        this.omniDirectionalExpand = new BoolValue("OmniDirectionalExpand", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getModeValue().get()), (String)"expand", (boolean)true);
            }
        }));
        this.expandLengthValue = new IntegerValue("ExpandLength", 3, 1, 6, " blocks", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getModeValue().get()), (String)"expand", (boolean)true);
            }
        }));
        this.zitterValue = new BoolValue("Zitter", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !Scaffold.access$isTowerOnly(this.this$0);
            }
        }));
        stringArray = new String[]{"Teleport", "Smooth"};
        this.zitterModeValue = new ListValue("ZitterMode", stringArray, "Smooth", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !Scaffold.access$isTowerOnly(this.this$0) && (Boolean)Scaffold.access$getZitterValue$p(this.this$0).get() != false;
            }
        }));
        this.zitterSpeed = new FloatValue("ZitterSpeed", 0.13f, 0.1f, 0.3f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !Scaffold.access$isTowerOnly(this.this$0) && (Boolean)Scaffold.access$getZitterValue$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getZitterModeValue$p(this.this$0).get()), (String)"teleport", (boolean)true);
            }
        }));
        this.zitterStrength = new FloatValue("ZitterStrength", 0.072f, 0.05f, 0.2f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !Scaffold.access$isTowerOnly(this.this$0) && (Boolean)Scaffold.access$getZitterValue$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getZitterModeValue$p(this.this$0).get()), (String)"teleport", (boolean)true);
            }
        }));
        this.zitterDelay = new IntegerValue("ZitterDelay", 100, 0, 500, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Scaffold this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return !Scaffold.access$isTowerOnly(this.this$0) && (Boolean)Scaffold.access$getZitterValue$p(this.this$0).get() != false && StringsKt.equals((String)((String)Scaffold.access$getZitterModeValue$p(this.this$0).get()), (String)"smooth", (boolean)true);
            }
        }));
        this.delayTimer = new MSTimer();
        this.towerDelayTimer = new MSTimer();
        this.zitterTimer = new MSTimer();
        this.timer = new TickTimer();
        this.prevSlot = -1;
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    public final ListValue getRotationModeValue() {
        return this.rotationModeValue;
    }

    public final ListValue getRotationLookupValue() {
        return this.rotationLookupValue;
    }

    public final boolean getCanTower() {
        return this.canTower;
    }

    public final void setCanTower(boolean bl) {
        this.canTower = bl;
    }

    public final float getFirstPitch() {
        return this.firstPitch;
    }

    public final void setFirstPitch(float f) {
        this.firstPitch = f;
    }

    public final float getFirstRotate() {
        return this.firstRotate;
    }

    public final void setFirstRotate(float f) {
        this.firstRotate = f;
    }

    private final boolean isTowerOnly() {
        return (Boolean)this.allowTower.get();
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        this.progress = 0.0f;
        this.spinYaw = 0.0f;
        this.firstPitch = MinecraftInstance.mc.field_71439_g.field_70125_A;
        this.firstRotate = MinecraftInstance.mc.field_71439_g.field_70177_z;
        this.launchY = (int)MinecraftInstance.mc.field_71439_g.field_70163_u;
        this.lastSlot = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c;
        this.slot = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c;
        this.canTower = false;
        this.lastMS = System.currentTimeMillis();
    }

    private final void fakeJump() {
        MinecraftInstance.mc.field_71439_g.field_70160_al = true;
        MinecraftInstance.mc.field_71439_g.func_71029_a(StatList.field_75953_u);
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        block70: {
            block69: {
                block68: {
                    String string;
                    if (this.faceBlock) {
                        this.place();
                    }
                    if (!(!((Boolean)this.allowTower.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d() || GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E) || this.getBlocksAmount() <= 0 || MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.8, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 0.5, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t + 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.8, MinecraftInstance.mc.field_71439_g.field_70161_v + 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t - 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.8, MinecraftInstance.mc.field_71439_g.field_70161_v + 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t + 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.8, MinecraftInstance.mc.field_71439_g.field_70161_v - 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t - 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.8, MinecraftInstance.mc.field_71439_g.field_70161_v - 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t + 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v + 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t - 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v + 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t + 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v - 0.5)).func_177230_c() instanceof BlockAir && MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t - 0.5, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v - 0.5)).func_177230_c() instanceof BlockAir || (MovementUtils.isMoving() || ((Boolean)this.towerMove.get()).booleanValue()) && !((Boolean)this.towerMove.get()).booleanValue())) {
                        this.canTower = true;
                        String string2 = (String)this.towerModeValue.get();
                        Locale locale = Locale.getDefault();
                        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                        string = string2.toLowerCase(locale);
                        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
                        switch (string) {
                            case "jump": {
                                if (!MinecraftInstance.mc.field_71439_g.field_70122_E || !this.timer.hasTimePassed(((Number)this.jumpDelayValue.get()).intValue())) break;
                                this.fakeJump();
                                MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.jumpMotionValue.get()).floatValue();
                                this.timer.reset();
                                break;
                            }
                            case "motion": {
                                if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                                    this.fakeJump();
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.41999998688698;
                                    break;
                                }
                                if (!(MinecraftInstance.mc.field_71439_g.field_70181_x < 0.1)) break;
                                MinecraftInstance.mc.field_71439_g.field_70181_x = -0.3;
                                break;
                            }
                            case "motiontp": {
                                if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                                    this.fakeJump();
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.41999998688698;
                                    break;
                                }
                                if (!(MinecraftInstance.mc.field_71439_g.field_70181_x < 0.23)) break;
                                MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t, (double)((int)MinecraftInstance.mc.field_71439_g.field_70163_u), MinecraftInstance.mc.field_71439_g.field_70161_v);
                                break;
                            }
                            case "teleport": {
                                if (((Boolean)this.teleportNoMotionValue.get()).booleanValue()) {
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                                }
                                if (!MinecraftInstance.mc.field_71439_g.field_70122_E && ((Boolean)this.teleportGroundValue.get()).booleanValue() || !this.timer.hasTimePassed(((Number)this.teleportDelayValue.get()).intValue())) break;
                                this.fakeJump();
                                MinecraftInstance.mc.field_71439_g.func_70634_a(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u + ((Number)this.teleportHeightValue.get()).doubleValue(), MinecraftInstance.mc.field_71439_g.field_70161_v);
                                this.timer.reset();
                                break;
                            }
                            case "stablemotion": {
                                if (((Boolean)this.stableFakeJumpValue.get()).booleanValue()) {
                                    this.fakeJump();
                                }
                                MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.stableMotionValue.get()).floatValue();
                                if (!((Boolean)this.stableStopValue.get()).booleanValue() || !this.towerDelayTimer.hasTimePassed(((Number)this.stableStopDelayValue.get()).intValue())) break;
                                MinecraftInstance.mc.field_71439_g.field_70181_x = -0.28;
                                this.towerDelayTimer.reset();
                                break;
                            }
                            case "constantmotion": {
                                if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                                    this.fakeJump();
                                    this.jumpGround = MinecraftInstance.mc.field_71439_g.field_70163_u;
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.constantMotionValue.get()).floatValue();
                                }
                                if (!(MinecraftInstance.mc.field_71439_g.field_70163_u > this.jumpGround + ((Number)this.constantMotionJumpGroundValue.get()).doubleValue())) break;
                                this.fakeJump();
                                MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t, (double)((int)MinecraftInstance.mc.field_71439_g.field_70163_u), MinecraftInstance.mc.field_71439_g.field_70161_v);
                                MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.constantMotionValue.get()).floatValue();
                                this.jumpGround = MinecraftInstance.mc.field_71439_g.field_70163_u;
                                break;
                            }
                            case "aac3.3.9": {
                                if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                                    this.fakeJump();
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.4001;
                                }
                                MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
                                if (!(MinecraftInstance.mc.field_71439_g.field_70181_x < 0.0)) break;
                                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                                entityPlayerSP.field_70181_x -= 9.45E-6;
                                MinecraftInstance.mc.field_71428_T.field_74278_d = 1.6f;
                                break;
                            }
                            case "aac3.6.4": {
                                if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 4 == 1) {
                                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.4195464;
                                    MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t - 0.035, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v);
                                    break;
                                }
                                if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 4 != 0) break;
                                MinecraftInstance.mc.field_71439_g.field_70181_x = -0.5;
                                MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t + 0.035, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v);
                            }
                        }
                    } else {
                        this.canTower = false;
                    }
                    if (((Boolean)this.autoDisableSpeedValue.get()).booleanValue()) {
                        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
                        Intrinsics.checkNotNull((Object)speed2);
                        if (speed2.getState()) {
                            Speed speed3 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
                            Intrinsics.checkNotNull((Object)speed3);
                            speed3.setState(false);
                            Client.INSTANCE.getHud().addNotification(new Notification("Speed was disabled!", Notification.Type.WARNING));
                        }
                    }
                    if (this.canTower) {
                        this.shouldGoDown = false;
                        MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
                    }
                    MinecraftInstance.mc.field_71428_T.field_74278_d = ((Number)this.timerValue.get()).floatValue();
                    boolean bl = this.shouldGoDown = (Boolean)this.downValue.get() != false && GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E) && this.getBlocksAmount() >= 1;
                    if (this.shouldGoDown) {
                        MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
                    }
                    if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                        this.offGroundTicks = 0;
                    } else {
                        int n = this.offGroundTicks;
                        this.offGroundTicks = n + 1;
                    }
                    if (((Boolean)this.customSpeedValue.get()).booleanValue()) {
                        MovementUtils.strafe(((Number)this.customMoveSpeedValue.get()).floatValue());
                    }
                    if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                        String mode = (String)this.modeValue.get();
                        if (StringsKt.equals((String)mode, (String)"Rewinside", (boolean)true)) {
                            MovementUtils.strafe(0.2f);
                            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                        }
                        if (((Boolean)this.zitterValue.get()).booleanValue() && StringsKt.equals((String)((String)this.zitterModeValue.get()), (String)"smooth", (boolean)true)) {
                            if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74366_z)) {
                                MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = false;
                            }
                            if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74370_x)) {
                                MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = false;
                            }
                            if (this.zitterTimer.hasTimePassed(((Number)this.zitterDelay.get()).intValue())) {
                                this.zitterDirection = !this.zitterDirection;
                                this.zitterTimer.reset();
                            }
                            if (this.zitterDirection) {
                                MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = true;
                                MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = false;
                            } else {
                                MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = false;
                                MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = true;
                            }
                        }
                        if (((Boolean)this.eagleValue.get()).booleanValue() && !this.shouldGoDown) {
                            double dif = 0.5;
                            if (((Number)this.eagleEdgeDistanceValue.get()).floatValue() > 0.0f) {
                                int n = 0;
                                while (n < 4) {
                                    int n2;
                                    int n3;
                                    int i = n++;
                                    double d = MinecraftInstance.mc.field_71439_g.field_70165_t;
                                    switch (i) {
                                        case 0: {
                                            n3 = -1;
                                            break;
                                        }
                                        case 1: {
                                            n3 = 1;
                                            break;
                                        }
                                        default: {
                                            n3 = 0;
                                        }
                                    }
                                    double d2 = d + (double)n3;
                                    double d3 = MinecraftInstance.mc.field_71439_g.field_70163_u - (MinecraftInstance.mc.field_71439_g.field_70163_u == (double)((int)MinecraftInstance.mc.field_71439_g.field_70163_u) + 0.5 ? 0.0 : 1.0);
                                    double d4 = MinecraftInstance.mc.field_71439_g.field_70161_v;
                                    switch (i) {
                                        case 2: {
                                            n2 = -1;
                                            break;
                                        }
                                        case 3: {
                                            n2 = 1;
                                            break;
                                        }
                                        default: {
                                            n2 = 0;
                                        }
                                    }
                                    BlockPos blockPos = new BlockPos(d2, d3, d4 + (double)n2);
                                    PlaceInfo placeInfo = PlaceInfo.Companion.get(blockPos);
                                    if (!BlockUtils.isReplaceable(blockPos) || placeInfo == null) continue;
                                    double calcDif = i > 1 ? MinecraftInstance.mc.field_71439_g.field_70161_v - (double)blockPos.func_177952_p() : MinecraftInstance.mc.field_71439_g.field_70165_t - (double)blockPos.func_177958_n();
                                    if ((calcDif -= 0.5) < 0.0) {
                                        calcDif *= -1.0;
                                    }
                                    if (!((calcDif -= 0.5) < dif)) continue;
                                    dif = calcDif;
                                }
                            }
                            if (this.placedBlocksWithoutEagle >= ((Number)this.blocksToEagleValue.get()).intValue()) {
                                boolean shouldEagle;
                                boolean bl2 = shouldEagle = MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() == Blocks.field_150350_a || dif < (double)((Number)this.eagleEdgeDistanceValue.get()).floatValue();
                                if (((Boolean)this.eagleSilentValue.get()).booleanValue()) {
                                    if (this.eagleSneaking != shouldEagle) {
                                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, shouldEagle ? C0BPacketEntityAction.Action.START_SNEAKING : C0BPacketEntityAction.Action.STOP_SNEAKING));
                                    }
                                    this.eagleSneaking = shouldEagle;
                                } else {
                                    MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = shouldEagle;
                                }
                                this.placedBlocksWithoutEagle = 0;
                            } else {
                                int n = this.placedBlocksWithoutEagle;
                                this.placedBlocksWithoutEagle = n + 1;
                            }
                        }
                        if (((Boolean)this.zitterValue.get()).booleanValue() && StringsKt.equals((String)((String)this.zitterModeValue.get()), (String)"teleport", (boolean)true)) {
                            MovementUtils.strafe(((Number)this.zitterSpeed.get()).floatValue());
                            double yaw = Math.toRadians((double)MinecraftInstance.mc.field_71439_g.field_70177_z + (this.zitterDirection ? 90.0 : -90.0));
                            string = MinecraftInstance.mc.field_71439_g;
                            ((EntityPlayerSP)string).field_70159_w -= Math.sin(yaw) * ((Number)this.zitterStrength.get()).doubleValue();
                            string = MinecraftInstance.mc.field_71439_g;
                            ((EntityPlayerSP)string).field_70179_y += Math.cos(yaw) * ((Number)this.zitterStrength.get()).doubleValue();
                            boolean bl3 = this.zitterDirection = !this.zitterDirection;
                        }
                    }
                    if (StringsKt.equals((String)((String)this.sprintModeValue.get()), (String)"off", (boolean)true) || StringsKt.equals((String)((String)this.sprintModeValue.get()), (String)"ground", (boolean)true) && !MinecraftInstance.mc.field_71439_g.field_70122_E || StringsKt.equals((String)((String)this.sprintModeValue.get()), (String)"air", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70122_E) {
                        MinecraftInstance.mc.field_71439_g.func_70031_b(false);
                    }
                    if (this.shouldGoDown) {
                        this.launchY = (int)MinecraftInstance.mc.field_71439_g.field_70163_u - 1;
                        return;
                    }
                    if ((Boolean)this.sameYValue.get() != false) return;
                    if (((Boolean)this.autoJumpValue.get()).booleanValue()) break block68;
                    if (!((Boolean)this.smartSpeedValue.get()).booleanValue()) break block69;
                    Speed speed4 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
                    Intrinsics.checkNotNull((Object)speed4);
                    if (!speed4.getState()) break block69;
                }
                if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A) && !(MinecraftInstance.mc.field_71439_g.field_70163_u < (double)this.launchY)) break block70;
            }
            this.launchY = (int)MinecraftInstance.mc.field_71439_g.field_70163_u;
        }
        if ((Boolean)this.autoJumpValue.get() == false) return;
        Speed speed5 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        Intrinsics.checkNotNull((Object)speed5);
        if (speed5.getState()) return;
        if (!MovementUtils.isMoving()) return;
        if (!MinecraftInstance.mc.field_71439_g.field_70122_E) return;
        MinecraftInstance.mc.field_71439_g.func_70664_aZ();
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (!MinecraftInstance.mc.func_71356_B() && packet instanceof C09PacketHeldItemChange) {
            if (((C09PacketHeldItemChange)packet).func_149614_c() == this.prevSlot) {
                event.cancelEvent();
            } else {
                this.prevSlot = ((C09PacketHeldItemChange)packet).func_149614_c();
            }
        }
        if (packet instanceof C08PacketPlayerBlockPlacement) {
            ((C08PacketPlayerBlockPlacement)packet).field_149577_f = RangesKt.coerceIn((float)((C08PacketPlayerBlockPlacement)packet).field_149577_f, (float)-1.0f, (float)1.0f);
            ((C08PacketPlayerBlockPlacement)packet).field_149578_g = RangesKt.coerceIn((float)((C08PacketPlayerBlockPlacement)packet).field_149578_g, (float)-1.0f, (float)1.0f);
            ((C08PacketPlayerBlockPlacement)packet).field_149584_h = RangesKt.coerceIn((float)((C08PacketPlayerBlockPlacement)packet).field_149584_h, (float)-1.0f, (float)1.0f);
        }
        if (StringsKt.equals((String)((String)this.sprintModeValue.get()), (String)"silent", (boolean)true) && packet instanceof C0BPacketEntityAction && (((C0BPacketEntityAction)packet).func_180764_b() == C0BPacketEntityAction.Action.STOP_SPRINTING || ((C0BPacketEntityAction)packet).func_180764_b() == C0BPacketEntityAction.Action.START_SPRINTING)) {
            event.cancelEvent();
        }
        if (packet instanceof C09PacketHeldItemChange) {
            this.slot = ((C09PacketHeldItemChange)packet).func_149614_c();
        }
    }

    @EventTarget
    public final void onStrafe(StrafeEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.lookupRotation != null && ((Boolean)this.rotationStrafeValue.get()).booleanValue()) {
            float f;
            float f2 = MinecraftInstance.mc.field_71439_g.field_70177_z;
            Rotation rotation = this.lookupRotation;
            Intrinsics.checkNotNull((Object)rotation);
            int dif = (int)((MathHelper.func_76142_g((float)(f2 - rotation.getYaw() - 23.5f - (float)135)) + (float)180) / (float)45);
            Rotation rotation2 = this.lookupRotation;
            Intrinsics.checkNotNull((Object)rotation2);
            float yaw = rotation2.getYaw();
            float strafe = event.getStrafe();
            float forward = event.getForward();
            float friction = event.getFriction();
            float calcForward = 0.0f;
            float calcStrafe = 0.0f;
            switch (dif) {
                case 0: {
                    calcForward = forward;
                    calcStrafe = strafe;
                    break;
                }
                case 1: {
                    calcForward += forward;
                    calcStrafe -= forward;
                    calcForward += strafe;
                    calcStrafe += strafe;
                    break;
                }
                case 2: {
                    calcForward = strafe;
                    calcStrafe = -forward;
                    break;
                }
                case 3: {
                    calcForward -= forward;
                    calcStrafe -= forward;
                    calcForward += strafe;
                    calcStrafe -= strafe;
                    break;
                }
                case 4: {
                    calcForward = -forward;
                    calcStrafe = -strafe;
                    break;
                }
                case 5: {
                    calcForward -= forward;
                    calcStrafe += forward;
                    calcForward -= strafe;
                    calcStrafe -= strafe;
                    break;
                }
                case 6: {
                    calcForward = -strafe;
                    calcStrafe = forward;
                    break;
                }
                case 7: {
                    calcForward += forward;
                    calcStrafe += forward;
                    calcForward -= strafe;
                    calcStrafe += strafe;
                }
            }
            if (calcForward > 1.0f || calcForward < 0.9f && calcForward > 0.3f || calcForward < -1.0f || calcForward > -0.9f && calcForward < -0.3f) {
                calcForward *= 0.5f;
            }
            if (calcStrafe > 1.0f || calcStrafe < 0.9f && calcStrafe > 0.3f || calcStrafe < -1.0f || calcStrafe > -0.9f && calcStrafe < -0.3f) {
                calcStrafe *= 0.5f;
            }
            if ((f = calcStrafe * calcStrafe + calcForward * calcForward) >= 1.0E-4f) {
                if ((f = MathHelper.func_76129_c((float)f)) < 1.0f) {
                    f = 1.0f;
                }
                f = friction / f;
                float yawSin = MathHelper.func_76126_a((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                float yawCos = MathHelper.func_76134_b((float)((float)((double)yaw * Math.PI / (double)180.0f)));
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70159_w += (double)((calcStrafe *= f) * yawCos - (calcForward *= f) * yawSin);
                entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70179_y += (double)(calcForward * yawCos + calcStrafe * yawSin);
            }
            event.cancelEvent();
        }
    }

    private final boolean shouldPlace() {
        boolean placeWhenAir = StringsKt.equals((String)((String)this.placeConditionValue.get()), (String)"air", (boolean)true);
        boolean placeWhenFall = StringsKt.equals((String)((String)this.placeConditionValue.get()), (String)"falldown", (boolean)true);
        boolean placeWhenNegativeMotion = StringsKt.equals((String)((String)this.placeConditionValue.get()), (String)"negativemotion", (boolean)true);
        boolean alwaysPlace = StringsKt.equals((String)((String)this.placeConditionValue.get()), (String)"always", (boolean)true);
        return alwaysPlace || placeWhenAir && !MinecraftInstance.mc.field_71439_g.field_70122_E || placeWhenFall && MinecraftInstance.mc.field_71439_g.field_70143_R > 0.0f || placeWhenNegativeMotion && MinecraftInstance.mc.field_71439_g.field_70181_x < 0.0;
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        block39: {
            String mode;
            block41: {
                block40: {
                    float pitch;
                    Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                    if (this.canTower && event.getEventState() == EventState.POST && !((Boolean)this.towerMove.get()).booleanValue()) {
                        MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                        MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                    }
                    if (((Boolean)this.noSpeedPotValue.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.func_70644_a(Potion.field_76424_c) && !this.canTower && MinecraftInstance.mc.field_71439_g.field_70122_E) {
                        MinecraftInstance.mc.field_71439_g.field_70159_w *= ((Number)this.speedSlowDown.get()).doubleValue();
                        MinecraftInstance.mc.field_71439_g.field_70179_y *= ((Number)this.speedSlowDown.get()).doubleValue();
                    }
                    if (MinecraftInstance.mc.field_71439_g.field_70122_E && ((Boolean)this.slowDownValue.get()).booleanValue()) {
                        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                        entityPlayerSP.field_70159_w *= (double)((Number)this.xzMultiplier.get()).floatValue();
                        entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                        entityPlayerSP.field_70179_y *= (double)((Number)this.xzMultiplier.get()).floatValue();
                    }
                    if (this.lockRotation != null) {
                        if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"spin", (boolean)true)) {
                            this.spinYaw += ((Number)this.speenSpeedValue.get()).floatValue();
                            this.spinYaw = MathHelper.func_76142_g((float)this.spinYaw);
                            Rotation rotation = this.speenRotation = new Rotation(this.spinYaw, ((Number)this.speenPitchValue.get()).floatValue());
                            Intrinsics.checkNotNull((Object)rotation);
                            RotationUtils.setTargetRotation(rotation);
                        } else if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"watchdog", (boolean)true)) {
                            float yaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
                            pitch = 84.0f;
                            Rotation rotation = RotationUtils.serverRotation;
                            Intrinsics.checkNotNull((Object)rotation);
                            RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation, new Rotation(yaw - (float)180, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation2 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation2);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation2, new Rotation(yaw, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation3 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation3);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation3, new Rotation(yaw - (float)135, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation4 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation4);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation4, new Rotation(yaw - (float)90, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation5 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation5);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation5, new Rotation(yaw - (float)45, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation6 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation6);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation6, new Rotation(yaw - (float)225, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation7 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation7);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation7, new Rotation(yaw - (float)270, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                Rotation rotation8 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation8);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation8, new Rotation(yaw - (float)315, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                            if (((Boolean)this.noHitCheckValue.get()).booleanValue()) {
                                this.faceBlock = true;
                            }
                        } else if (this.lockRotation != null) {
                            if (((Boolean)this.noHitCheckValue.get()).booleanValue()) {
                                this.faceBlock = true;
                            }
                            if (((Boolean)this.keepRotationValue.get()).booleanValue()) {
                                Rotation rotation = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation);
                                Rotation rotation9 = this.lockRotation;
                                Intrinsics.checkNotNull((Object)rotation9);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation, rotation9, RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                            }
                        }
                    } else {
                        this.faceBlock = false;
                        if (((Boolean)this.keepRotationValue.get()).booleanValue()) {
                            String string = ((String)this.preRotationValue.get()).toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
                            String yaw = string;
                            if (yaw.equals("lock")) {
                                RotationUtils.setTargetRotation(new Rotation(this.firstRotate, this.firstPitch));
                            } else if (yaw.equals("normal")) {
                                pitch = 84.0f;
                                Rotation rotation = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation);
                                RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)180, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation10 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation10);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation10, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation11 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation11);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation11, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)135, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation12 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation12);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation12, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)90, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation13 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation13);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation13, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)45, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation14 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation14);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation14, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)225, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation15 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation15);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation15, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)270, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation16 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation16);
                                    RotationUtils.setTargetRotation(RotationUtils.limitAngleChange(rotation16, new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z - (float)315, pitch), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue())));
                                }
                            }
                        }
                    }
                    mode = (String)this.modeValue.get();
                    EventState eventState = event.getEventState();
                    int n = 0;
                    while (n < 8) {
                        int i;
                        if (MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a[i = n++] == null || MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a[i].field_77994_a > 0) continue;
                        MinecraftInstance.mc.field_71439_g.field_71071_by.field_70462_a[i] = null;
                    }
                    if (eventState != EventState.PRE) break block39;
                    if (!this.shouldPlace()) break block40;
                    boolean bl = !StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Off", (boolean)true) ? InventoryUtils.findAutoBlockBlock() == -1 : MinecraftInstance.mc.field_71439_g.func_70694_bm() == null || !(MinecraftInstance.mc.field_71439_g.func_70694_bm().func_77973_b() instanceof ItemBlock);
                    if (!bl) break block41;
                }
                return;
            }
            this.findBlock(StringsKt.equals((String)mode, (String)"expand", (boolean)true) && !this.canTower);
        }
        if (this.targetPlace == null && ((Boolean)this.placeableDelay.get()).booleanValue()) {
            this.delayTimer.reset();
        }
        if (this.canTower) {
            this.verusState = 0;
            MinecraftInstance.mc.field_71428_T.field_74278_d = ((Number)this.towerTimerValue.get()).floatValue();
        }
    }

    /*
     * Unable to fully structure code
     */
    private final void findBlock(boolean expand) {
        block14: {
            block15: {
                block11: {
                    block12: {
                        block13: {
                            block10: {
                                if (!this.shouldGoDown) break block10;
                                v0 = MinecraftInstance.mc.field_71439_g.field_70163_u == (double)((int)MinecraftInstance.mc.field_71439_g.field_70163_u) + 0.5 ? new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 0.6, MinecraftInstance.mc.field_71439_g.field_70161_v) : new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 0.6, MinecraftInstance.mc.field_71439_g.field_70161_v).func_177977_b();
                                break block11;
                            }
                            if (this.canTower) ** GOTO lbl-1000
                            if (((Boolean)this.sameYValue.get()).booleanValue()) break block12;
                            if (((Boolean)this.autoJumpValue.get()).booleanValue()) break block13;
                            if (!((Boolean)this.smartSpeedValue.get()).booleanValue()) ** GOTO lbl-1000
                            v1 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
                            Intrinsics.checkNotNull((Object)v1);
                            if (!v1.getState()) ** GOTO lbl-1000
                        }
                        if (GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A)) ** GOTO lbl-1000
                    }
                    if ((double)this.launchY <= MinecraftInstance.mc.field_71439_g.field_70163_u) {
                        v0 = new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, (double)(this.launchY - 1), MinecraftInstance.mc.field_71439_g.field_70161_v);
                    } else lbl-1000:
                    // 5 sources

                    {
                        v0 = blockPosition = MinecraftInstance.mc.field_71439_g.field_70163_u == (double)((int)MinecraftInstance.mc.field_71439_g.field_70163_u) + 0.5 != false ? new BlockPos((Entity)MinecraftInstance.mc.field_71439_g) : new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v).func_177977_b();
                    }
                }
                if (expand) break block14;
                if (!BlockUtils.isReplaceable(blockPosition)) break block15;
                Intrinsics.checkNotNullExpressionValue((Object)blockPosition, (String)"blockPosition");
                if (!this.search(blockPosition, this.shouldGoDown == false, false)) break block14;
            }
            return;
        }
        if (expand) {
            yaw = Math.toRadians(MinecraftInstance.mc.field_71439_g.field_70177_z);
            x = (Boolean)this.omniDirectionalExpand.get() != false ? (int)Math.round(-Math.sin(yaw)) : MinecraftInstance.mc.field_71439_g.func_174811_aO().func_176730_m().func_177958_n();
            z = (Boolean)this.omniDirectionalExpand.get() != false ? (int)Math.round(Math.cos(yaw)) : MinecraftInstance.mc.field_71439_g.func_174811_aO().func_176730_m().func_177952_p();
            var7_9 = 0;
            var8_11 = ((Number)this.expandLengthValue.get()).intValue();
            while (var7_9 < var8_11) {
                i = var7_9++;
                var10_13 = blockPosition.func_177982_a(x * i, 0, z * i);
                Intrinsics.checkNotNullExpressionValue((Object)var10_13, (String)"blockPosition.add(x * i, 0, z * i)");
                if (!this.search(var10_13, false, false)) continue;
                return;
            }
        } else {
            var3_4 = -1;
            while (var3_4 < 2) {
                x = var3_4++;
                var5_6 = -1;
                while (var5_6 < 2) {
                    z = var5_6++;
                    var7_10 = blockPosition.func_177982_a(x, 0, z);
                    Intrinsics.checkNotNullExpressionValue((Object)var7_10, (String)"blockPosition.add(x, 0, z)");
                    if (!this.search(var7_10, this.shouldGoDown == false, false)) continue;
                    return;
                }
            }
        }
    }

    private final void place() {
        block21: {
            block22: {
                block23: {
                    block24: {
                        if (this.targetPlace == null) {
                            if (((Boolean)this.placeableDelay.get()).booleanValue()) {
                                this.delayTimer.reset();
                            }
                            return;
                        }
                        if (this.canTower) break block21;
                        if (!this.delayTimer.hasTimePassed(this.delay)) break block22;
                        if (((Boolean)this.sameYValue.get()).booleanValue()) break block23;
                        if (((Boolean)this.autoJumpValue.get()).booleanValue()) break block24;
                        if (!((Boolean)this.smartSpeedValue.get()).booleanValue()) break block21;
                        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
                        Intrinsics.checkNotNull((Object)speed2);
                        if (!speed2.getState()) break block21;
                    }
                    if (GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A)) break block21;
                }
                PlaceInfo placeInfo = this.targetPlace;
                Intrinsics.checkNotNull((Object)placeInfo);
                if (this.launchY - 1 == (int)placeInfo.getVec3().field_72448_b) break block21;
            }
            return;
        }
        int blockSlot = -1;
        ItemStack itemStack = MinecraftInstance.mc.field_71439_g.func_70694_bm();
        if (MinecraftInstance.mc.field_71439_g.func_70694_bm() == null || !(MinecraftInstance.mc.field_71439_g.func_70694_bm().func_77973_b() instanceof ItemBlock)) {
            if (StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Off", (boolean)true)) {
                return;
            }
            blockSlot = InventoryUtils.findAutoBlockBlock();
            if (blockSlot == -1) {
                return;
            }
            if (StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Switch", (boolean)true)) {
                MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = blockSlot - 36;
                MinecraftInstance.mc.field_71442_b.func_78765_e();
            }
            if (StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Spoof", (boolean)true)) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(blockSlot - 36));
                itemStack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(blockSlot).func_75211_c();
            }
            if (StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Fake", (boolean)true)) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(blockSlot - 36));
                itemStack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(blockSlot).func_75211_c();
            }
        }
        if (itemStack != null && itemStack.func_77973_b() != null && itemStack.func_77973_b() instanceof ItemBlock) {
            Item item = itemStack.func_77973_b();
            if (item == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemBlock");
            }
            Block block = ((ItemBlock)item).func_179223_d();
            if (InventoryUtils.BLOCK_BLACKLIST.contains(block) || !block.func_149686_d() || itemStack.field_77994_a <= 0) {
                return;
            }
        }
        PlayerControllerMP playerControllerMP = MinecraftInstance.mc.field_71442_b;
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
        WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
        PlaceInfo placeInfo = this.targetPlace;
        Intrinsics.checkNotNull((Object)placeInfo);
        BlockPos blockPos = placeInfo.getBlockPos();
        PlaceInfo placeInfo2 = this.targetPlace;
        Intrinsics.checkNotNull((Object)placeInfo2);
        EnumFacing enumFacing = placeInfo2.getEnumFacing();
        PlaceInfo placeInfo3 = this.targetPlace;
        Intrinsics.checkNotNull((Object)placeInfo3);
        if (playerControllerMP.func_178890_a(entityPlayerSP, worldClient, itemStack, blockPos, enumFacing, placeInfo3.getVec3())) {
            this.delayTimer.reset();
            if (((Boolean)this.animationValue.get()).booleanValue()) {
                MinecraftInstance.mc.func_175597_ag().func_78445_c();
            }
            long l = this.delay = (Boolean)this.placeableDelay.get() == false ? 0L : TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
            if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                float modifier = ((Number)this.speedModifierValue.get()).floatValue();
                EntityPlayerSP entityPlayerSP2 = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP2.field_70159_w *= (double)modifier;
                entityPlayerSP2 = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP2.field_70179_y *= (double)modifier;
            }
            String string = (String)this.swingValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            String string3 = string2;
            if (string3.equals("normal")) {
                MinecraftInstance.mc.field_71439_g.func_71038_i();
            } else if (string3.equals("packet")) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
            }
        }
        this.targetPlace = null;
        if (blockSlot >= 0 && StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"Spoof", (boolean)true)) {
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        this.faceBlock = false;
        this.firstPitch = 0.0f;
        this.firstRotate = 0.0f;
        this.canTower = false;
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E)) {
            MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
            if (this.eagleSneaking) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, C0BPacketEntityAction.Action.STOP_SNEAKING));
            }
        } else {
            MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = true;
        }
        if (StringsKt.equals((String)((String)this.sprintModeValue.get()), (String)"silent", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70051_ag()) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, C0BPacketEntityAction.Action.STOP_SPRINTING)));
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, C0BPacketEntityAction.Action.START_SPRINTING)));
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74366_z)) {
            MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74370_x)) {
            MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = false;
        }
        this.lockRotation = null;
        this.lookupRotation = null;
        MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
        this.shouldGoDown = false;
        this.faceBlock = false;
        if (this.lastSlot != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c && StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"switch", (boolean)true)) {
            MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = this.lastSlot;
            MinecraftInstance.mc.field_71442_b.func_78765_e();
        }
        if (this.slot != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c && (StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"spoof", (boolean)true) || StringsKt.equals((String)((String)this.autoBlockMode.get()), (String)"fake", (boolean)true)) || this.slot != MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!((Boolean)this.safeWalkValue.get()).booleanValue() || this.shouldGoDown) {
            return;
        }
        if (((Boolean)this.airSafeValue.get()).booleanValue() || MinecraftInstance.mc.field_71439_g.field_70122_E) {
            event.setSafeWalk(true);
        }
    }

    @EventTarget
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.canTower) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onRender2D(@Nullable Render2DEvent event) {
        this.progress = (float)(System.currentTimeMillis() - this.lastMS) / 100.0f;
        if (this.progress >= 1.0f) {
            this.progress = 1.0f;
        }
        ScaledResolution scaledResolution = new ScaledResolution(MinecraftInstance.mc);
        int infoWidth2 = Fonts.minecraftFont.func_78256_a(this.getBlocksAmount() + " Blocks");
        Fonts.minecraftFont.func_175065_a(this.faceBlock ? "\u00a7b" + this.getBlocksAmount() + " Blocks" : "\u00a77" + this.getBlocksAmount() + " Blocks", (float)(scaledResolution.func_78326_a() / 2 - infoWidth2 + 60), (float)(scaledResolution.func_78328_b() / 2 + 25), -17895697, true);
    }

    private final boolean search(BlockPos blockPosition, boolean checks, boolean towerActive) {
        this.faceBlock = false;
        if (!BlockUtils.isReplaceable(blockPosition)) {
            return false;
        }
        boolean staticYawMode = StringsKt.equals((String)((String)this.rotationLookupValue.get()), (String)"AAC", (boolean)true) || StringsKt.equals((String)((String)this.rotationLookupValue.get()), (String)"same", (boolean)true) && (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"AAC", (boolean)true) || ((String)this.rotationModeValue.get()).equals("Static") && !StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"static3", (boolean)true));
        Vec3 eyesPos = new Vec3(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b + (double)MinecraftInstance.mc.field_71439_g.func_70047_e(), MinecraftInstance.mc.field_71439_g.field_70161_v);
        PlaceRotation placeRotation = null;
        EnumFacing[] enumFacingArray = EnumFacing.values();
        int n = 0;
        int n2 = enumFacingArray.length;
        while (n < n2) {
            EnumFacing side = enumFacingArray[n];
            ++n;
            BlockPos neighbor = blockPosition.func_177972_a(side);
            if (!BlockUtils.canBeClicked(neighbor)) continue;
            Vec3 dirVec = new Vec3(side.func_176730_m());
            for (double xSearch = 0.1; xSearch < 0.9; xSearch += 0.1) {
                for (double ySearch = 0.1; ySearch < 0.9; ySearch += 0.1) {
                    double zSearch = 0.1;
                    while (zSearch < 0.9) {
                        int n3;
                        Vec3 posVec = new Vec3((Vec3i)blockPosition).func_72441_c(xSearch, ySearch, zSearch);
                        double distanceSqPosVec = eyesPos.func_72436_e(posVec);
                        Vec3 hitVec = posVec.func_178787_e(new Vec3(dirVec.field_72450_a * 0.5, dirVec.field_72448_b * 0.5, dirVec.field_72449_c * 0.5));
                        if (checks && (eyesPos.func_72436_e(hitVec) > 18.0 || distanceSqPosVec > eyesPos.func_72436_e(posVec.func_178787_e(dirVec)) || MinecraftInstance.mc.field_71441_e.func_147447_a(eyesPos, hitVec, false, true, false) != null)) {
                            zSearch += 0.1;
                            continue;
                        }
                        int n4 = 0;
                        int n5 = n3 = staticYawMode ? 2 : 1;
                        while (n4 < n3) {
                            Vec3 rotationVector;
                            Vec3 vec3;
                            Rotation pitch2;
                            Rotation rotation;
                            int i = n4++;
                            double diffX = staticYawMode && i == 0 ? 0.0 : hitVec.field_72450_a - eyesPos.field_72450_a;
                            double diffY = hitVec.field_72448_b - eyesPos.field_72448_b;
                            double diffZ = staticYawMode && i == 1 ? 0.0 : hitVec.field_72449_c - eyesPos.field_72449_c;
                            double diffXZ = MathHelper.func_76133_a((double)(diffX * diffX + diffZ * diffZ));
                            this.lookupRotation = rotation = new Rotation(MathHelper.func_76142_g((float)((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f)), MathHelper.func_76142_g((float)(-((float)Math.toDegrees(Math.atan2(diffY, diffXZ))))));
                            if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"static", (boolean)true) && (((Boolean)this.keepRotOnJumpValue.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d())) {
                                rotation = new Rotation(MovementUtils.getScaffoldRotation(MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70702_br), ((Number)this.staticPitchValue.get()).floatValue());
                            }
                            if ((StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"static2", (boolean)true) || StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"static3", (boolean)true)) && (((Boolean)this.keepRotOnJumpValue.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d())) {
                                rotation = new Rotation(rotation.getYaw(), ((Number)this.staticPitchValue.get()).floatValue());
                            }
                            if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"custom", (boolean)true) && (((Boolean)this.keepRotOnJumpValue.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d())) {
                                rotation = new Rotation(MinecraftInstance.mc.field_71439_g.field_70177_z + ((Number)this.customYawValue.get()).floatValue(), ((Number)this.customPitchValue.get()).floatValue());
                            }
                            if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"watchdog", (boolean)true) && (((Boolean)this.keepRotOnJumpValue.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d())) {
                                float yaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
                                float pitch2 = 84.0f;
                                Rotation rotation2 = RotationUtils.serverRotation;
                                Intrinsics.checkNotNull((Object)rotation2);
                                Rotation rotation3 = RotationUtils.limitAngleChange(rotation2, new Rotation(yaw - (float)180, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                rotation = rotation3;
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation4 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation4);
                                    rotation3 = RotationUtils.limitAngleChange(rotation4, new Rotation(yaw, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation5 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation5);
                                    rotation3 = RotationUtils.limitAngleChange(rotation5, new Rotation(yaw - (float)135, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation6 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation6);
                                    rotation3 = RotationUtils.limitAngleChange(rotation6, new Rotation(yaw - (float)90, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation7 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation7);
                                    rotation3 = RotationUtils.limitAngleChange(rotation7, new Rotation(yaw - (float)45, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation8 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation8);
                                    rotation3 = RotationUtils.limitAngleChange(rotation8, new Rotation(yaw - (float)225, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation9 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation9);
                                    rotation3 = RotationUtils.limitAngleChange(rotation9, new Rotation(yaw - (float)270, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                                if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74366_z.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74370_x.func_151470_d() && MinecraftInstance.mc.field_71474_y.field_74368_y.func_151470_d()) {
                                    Rotation rotation10 = RotationUtils.serverRotation;
                                    Intrinsics.checkNotNull((Object)rotation10);
                                    rotation3 = RotationUtils.limitAngleChange(rotation10, new Rotation(yaw - (float)315, pitch2), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
                                    Intrinsics.checkNotNullExpressionValue((Object)rotation3, (String)"limitAngleChange(\n      \u2026                        )");
                                    rotation = rotation3;
                                }
                            }
                            if (StringsKt.equals((String)((String)this.rotationModeValue.get()), (String)"spin", (boolean)true) && this.speenRotation != null && (((Boolean)this.keepRotOnJumpValue.get()).booleanValue() || !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d())) {
                                Rotation rotation11 = this.speenRotation;
                                if (rotation11 == null) {
                                    throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.util.Rotation");
                                }
                                rotation = rotation11;
                            }
                            Rotation rotation12 = pitch2 = StringsKt.equals((String)((String)this.rotationLookupValue.get()), (String)"same", (boolean)true) ? rotation : this.lookupRotation;
                            if (pitch2 == null) {
                                vec3 = null;
                            } else {
                                Rotation it = pitch2;
                                boolean bl = false;
                                vec3 = RotationUtils.getVectorForRotation(it);
                            }
                            Vec3 vec32 = rotationVector = vec3;
                            Double d = vec32 == null ? null : Double.valueOf(vec32.field_72450_a);
                            Intrinsics.checkNotNull((Object)d);
                            Vec3 vector = eyesPos.func_72441_c(d * (double)4, rotationVector.field_72448_b * (double)4, rotationVector.field_72449_c * (double)4);
                            MovingObjectPosition obj = MinecraftInstance.mc.field_71441_e.func_147447_a(eyesPos, vector, false, false, true);
                            if (obj.field_72313_a != MovingObjectPosition.MovingObjectType.BLOCK || !obj.func_178782_a().equals(neighbor) || placeRotation != null && !(RotationUtils.getRotationDifference(rotation) < RotationUtils.getRotationDifference(placeRotation.getRotation()))) continue;
                            Intrinsics.checkNotNullExpressionValue((Object)neighbor, (String)"neighbor");
                            EnumFacing enumFacing = side.func_176734_d();
                            Intrinsics.checkNotNullExpressionValue((Object)enumFacing, (String)"side.opposite");
                            Intrinsics.checkNotNullExpressionValue((Object)hitVec, (String)"hitVec");
                            placeRotation = new PlaceRotation(new PlaceInfo(neighbor, enumFacing, hitVec), rotation);
                        }
                        zSearch += 0.1;
                    }
                }
            }
        }
        if (placeRotation == null) {
            return false;
        }
        if (((Number)this.minTurnSpeed.get()).floatValue() < 180.0f) {
            Rotation rotation = RotationUtils.serverRotation;
            Intrinsics.checkNotNull((Object)rotation);
            Rotation rotation13 = RotationUtils.limitAngleChange(rotation, placeRotation.getRotation(), RandomUtils.nextFloat(((Number)this.minTurnSpeed.get()).floatValue(), ((Number)this.maxTurnSpeed.get()).floatValue()));
            Intrinsics.checkNotNullExpressionValue((Object)rotation13, (String)"limitAngleChange(\n      \u2026peed.get())\n            )");
            Rotation limitedRotation = rotation13;
            if ((int)((float)10 * MathHelper.func_76142_g((float)limitedRotation.getYaw())) == (int)((float)10 * MathHelper.func_76142_g((float)placeRotation.getRotation().getYaw())) && (int)((float)10 * MathHelper.func_76142_g((float)limitedRotation.getPitch())) == (int)((float)10 * MathHelper.func_76142_g((float)placeRotation.getRotation().getPitch()))) {
                RotationUtils.setTargetRotation(placeRotation.getRotation(), ((Number)this.keepLengthValue.get()).intValue());
                this.lockRotation = placeRotation.getRotation();
                this.faceBlock = true;
            } else {
                RotationUtils.setTargetRotation(limitedRotation, ((Number)this.keepLengthValue.get()).intValue());
                this.lockRotation = limitedRotation;
                this.faceBlock = false;
            }
        } else {
            RotationUtils.setTargetRotation(placeRotation.getRotation(), ((Number)this.keepLengthValue.get()).intValue());
            this.lockRotation = placeRotation.getRotation();
            this.faceBlock = true;
        }
        if (StringsKt.equals((String)((String)this.rotationLookupValue.get()), (String)"same", (boolean)true)) {
            this.lookupRotation = this.lockRotation;
        }
        if (towerActive) {
            this.towerPlace = placeRotation.getPlaceInfo();
        } else {
            this.targetPlace = placeRotation.getPlaceInfo();
        }
        return true;
    }

    private final int getBlocksAmount() {
        int amount = 0;
        int n = 36;
        while (n < 45) {
            int i;
            ItemStack itemStack;
            if ((itemStack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(i = n++).func_75211_c()) == null || !(itemStack.func_77973_b() instanceof ItemBlock)) continue;
            Item item = itemStack.func_77973_b();
            if (item == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemBlock");
            }
            Block block = ((ItemBlock)item).func_179223_d();
            if (InventoryUtils.BLOCK_BLACKLIST.contains(block) || !block.func_149686_d()) continue;
            amount += itemStack.field_77994_a;
        }
        return amount;
    }

    public static final /* synthetic */ BoolValue access$getAllowTower$p(Scaffold $this) {
        return $this.allowTower;
    }

    public static final /* synthetic */ ListValue access$getTowerModeValue$p(Scaffold $this) {
        return $this.towerModeValue;
    }

    public static final /* synthetic */ BoolValue access$getStableStopValue$p(Scaffold $this) {
        return $this.stableStopValue;
    }

    public static final /* synthetic */ IntegerValue access$getMinDelayValue$p(Scaffold $this) {
        return $this.minDelayValue;
    }

    public static final /* synthetic */ BoolValue access$getPlaceableDelay$p(Scaffold $this) {
        return $this.placeableDelay;
    }

    public static final /* synthetic */ IntegerValue access$getMaxDelayValue$p(Scaffold $this) {
        return $this.maxDelayValue;
    }

    public static final /* synthetic */ BoolValue access$getPlaceSlowDownValue$p(Scaffold $this) {
        return $this.placeSlowDownValue;
    }

    public static final /* synthetic */ BoolValue access$getSlowDownValue$p(Scaffold $this) {
        return $this.slowDownValue;
    }

    public static final /* synthetic */ BoolValue access$getNoSpeedPotValue$p(Scaffold $this) {
        return $this.noSpeedPotValue;
    }

    public static final /* synthetic */ BoolValue access$getCustomSpeedValue$p(Scaffold $this) {
        return $this.customSpeedValue;
    }

    public static final /* synthetic */ BoolValue access$getSafeWalkValue$p(Scaffold $this) {
        return $this.safeWalkValue;
    }

    public static final /* synthetic */ BoolValue access$getKeepRotationValue$p(Scaffold $this) {
        return $this.keepRotationValue;
    }

    public static final /* synthetic */ FloatValue access$getMinTurnSpeed$p(Scaffold $this) {
        return $this.minTurnSpeed;
    }

    public static final /* synthetic */ FloatValue access$getMaxTurnSpeed$p(Scaffold $this) {
        return $this.maxTurnSpeed;
    }

    public static final /* synthetic */ BoolValue access$getEagleValue$p(Scaffold $this) {
        return $this.eagleValue;
    }

    public static final /* synthetic */ boolean access$isTowerOnly(Scaffold $this) {
        return $this.isTowerOnly();
    }

    public static final /* synthetic */ BoolValue access$getZitterValue$p(Scaffold $this) {
        return $this.zitterValue;
    }

    public static final /* synthetic */ ListValue access$getZitterModeValue$p(Scaffold $this) {
        return $this.zitterModeValue;
    }
}

