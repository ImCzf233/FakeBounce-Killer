/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.kauri;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class KauriLowHop
extends SpeedMode {
    private int ticks;

    public KauriLowHop() {
        super("KauriLowHop");
    }

    @Override
    public void onUpdate() {
        int n = this.ticks;
        this.ticks = n + 1;
        if (!SpeedMode.mc.field_71439_g.field_70122_E && this.ticks == 3) {
            SpeedMode.mc.field_71439_g.field_70181_x = 0.0;
        }
        SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
        if (SpeedMode.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            SpeedMode.mc.field_71439_g.field_70181_x = 0.300114514191981;
            if ((double)MovementUtils.getSpeed() < 0.22) {
                MovementUtils.strafe(0.22f);
            } else {
                MovementUtils.strafe(0.48f);
            }
        }
        if (!MovementUtils.isMoving()) {
            SpeedMode.mc.field_71439_g.field_70159_w = 0.0;
            SpeedMode.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onDisable() {
        this.ticks = 0;
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        super.onEnable();
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

