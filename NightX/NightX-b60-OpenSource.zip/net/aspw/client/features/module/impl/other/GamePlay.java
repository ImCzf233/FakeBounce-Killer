/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.event.ClickEvent
 *  net.minecraft.event.ClickEvent$Action
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.client.C0EPacketClickWindow
 *  net.minecraft.network.play.server.S02PacketChat
 *  net.minecraft.network.play.server.S2DPacketOpenWindow
 *  net.minecraft.network.play.server.S2FPacketSetSlot
 *  net.minecraft.util.IChatComponent
 */
package net.aspw.client.features.module.impl.other;

import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.other.GamePlay;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.event.ClickEvent;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S2DPacketOpenWindow;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.util.IChatComponent;

@ModuleInfo(name="GamePlay", spacedName="Game Play", description="", category=ModuleCategory.OTHER)
public final class GamePlay
extends Module {
    private int clickState;
    private final ListValue modeValue;
    private final IntegerValue delayValue;
    private boolean clicking;
    private boolean queued;
    private boolean waitForLobby;

    public GamePlay() {
        String[] stringArray = new String[]{"RedeSky", "BlocksMC", "Minemora", "Hypixel", "Jartex"};
        this.modeValue = new ListValue("Server", stringArray, "Hypixel");
        this.delayValue = new IntegerValue("JoinDelay", 3, 0, 7, " seconds");
    }

    @Override
    public void onEnable() {
        this.clickState = 0;
        this.clicking = false;
        this.queued = false;
        this.waitForLobby = false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @EventTarget
    public final void onPacket(PacketEvent event) {
        Object itemName2;
        Locale locale;
        Packet<?> packet;
        block40: {
            Intrinsics.checkNotNullParameter((Object)event, (String)"event");
            packet = event.getPacket();
            String string = (String)this.modeValue.get();
            locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            String string3 = string2;
            if (string3.equals("redesky")) {
                if (this.clicking && (packet instanceof C0EPacketClickWindow || packet instanceof C07PacketPlayerDigging)) {
                    event.cancelEvent();
                    return;
                }
                if (this.clickState == 2 && packet instanceof S2DPacketOpenWindow) {
                    event.cancelEvent();
                }
            } else if (string3.equals("hypixel") && this.clickState == 1 && packet instanceof S2DPacketOpenWindow) {
                event.cancelEvent();
            }
            if (!(packet instanceof S2FPacketSetSlot)) break block40;
            ItemStack itemStack = ((S2FPacketSetSlot)packet).func_149174_e();
            if (itemStack == null) {
                return;
            }
            ItemStack item = itemStack;
            int windowId = ((S2FPacketSetSlot)packet).func_149175_c();
            int slot = ((S2FPacketSetSlot)packet).func_149173_d();
            itemName2 = item.func_77977_a();
            String displayName = item.func_82833_r();
            String string4 = (String)this.modeValue.get();
            Locale locale2 = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale2, (String)"getDefault()");
            String string5 = string4.toLowerCase(locale2);
            Intrinsics.checkNotNullExpressionValue((Object)string5, (String)"this as java.lang.String).toLowerCase(locale)");
            switch (string5) {
                case "redesky": {
                    if (this.clickState == 0 && windowId == 0 && slot == 42) {
                        Intrinsics.checkNotNullExpressionValue((Object)itemName2, (String)"itemName");
                        if (StringsKt.contains((CharSequence)((CharSequence)itemName2), (CharSequence)"paper", (boolean)true)) {
                            Intrinsics.checkNotNullExpressionValue((Object)displayName, (String)"displayName");
                            if (StringsKt.contains((CharSequence)displayName, (CharSequence)"Jogar novamente", (boolean)true)) {
                                this.clickState = 1;
                                this.clicking = true;
                                GamePlay.queueAutoPlay$default(this, 0L, (Function0)new Function0<Unit>(item, this){
                                    final /* synthetic */ ItemStack $item;
                                    final /* synthetic */ GamePlay this$0;
                                    {
                                        this.$item = $item;
                                        this.this$0 = $receiver;
                                        super(0);
                                    }

                                    public final void invoke() {
                                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(6));
                                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(this.$item));
                                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
                                        GamePlay.access$setClickState$p(this.this$0, 2);
                                    }
                                }, 1, null);
                                return;
                            }
                        }
                    }
                    if (this.clickState != 2 || windowId == 0 || slot != 11) return;
                    Intrinsics.checkNotNullExpressionValue((Object)itemName2, (String)"itemName");
                    if (!StringsKt.contains((CharSequence)((CharSequence)itemName2), (CharSequence)"enderPearl", (boolean)true)) return;
                    Timer timer = new Timer();
                    long l = 500L;
                    TimerTask timerTask = new TimerTask(this, windowId, slot, item){
                        final /* synthetic */ GamePlay this$0;
                        final /* synthetic */ int $windowId$inlined;
                        final /* synthetic */ int $slot$inlined;
                        final /* synthetic */ ItemStack $item$inlined;
                        {
                            this.this$0 = gamePlay;
                            this.$windowId$inlined = n;
                            this.$slot$inlined = n2;
                            this.$item$inlined = itemStack;
                        }

                        public void run() {
                            TimerTask $this$onPacket_u24lambda_u2d0 = this;
                            boolean bl = false;
                            GamePlay.access$setClicking$p(this.this$0, false);
                            GamePlay.access$setClickState$p(this.this$0, 0);
                            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0EPacketClickWindow(this.$windowId$inlined, this.$slot$inlined, 0, 0, this.$item$inlined, 1919));
                        }
                    };
                    timer.schedule(timerTask, l);
                    return;
                }
                case "hypixel": 
                case "blocksmc": {
                    if (this.clickState == 0 && windowId == 0 && slot == 43) {
                        Intrinsics.checkNotNullExpressionValue((Object)itemName2, (String)"itemName");
                        if (StringsKt.contains((CharSequence)((CharSequence)itemName2), (CharSequence)"paper", (boolean)true)) {
                            GamePlay.queueAutoPlay$default(this, 0L, (Function0)new Function0<Unit>(item){
                                final /* synthetic */ ItemStack $item;
                                {
                                    this.$item = $item;
                                    super(0);
                                }

                                public final void invoke() {
                                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(7));
                                    int n = 2;
                                    ItemStack itemStack = this.$item;
                                    int n2 = 0;
                                    while (n2 < n) {
                                        int n3;
                                        int it = n3 = n2++;
                                        boolean bl = false;
                                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(itemStack));
                                    }
                                }
                            }, 1, null);
                            this.clickState = 1;
                        }
                    }
                    if (!this.modeValue.equals("hypixel") || this.clickState != 1 || windowId == 0 || !StringsKt.equals((String)itemName2, (String)"item.fireworks", (boolean)true)) return;
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0EPacketClickWindow(windowId, slot, 0, 0, item, 1919));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0DPacketCloseWindow(windowId));
                }
                default: {
                    return;
                }
            }
        }
        if (!(packet instanceof S02PacketChat)) return;
        String text = ((S02PacketChat)packet).func_148915_c().func_150260_c();
        String string = (String)this.modeValue.get();
        itemName2 = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)itemName2, (String)"getDefault()");
        String displayName = string.toLowerCase((Locale)itemName2);
        Intrinsics.checkNotNullExpressionValue((Object)displayName, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (displayName) {
            case "minemora": {
                Intrinsics.checkNotNullExpressionValue((Object)text, (String)"text");
                if (!StringsKt.contains((CharSequence)text, (CharSequence)"Has click en alguna de las siguientes opciones", (boolean)true)) return;
                GamePlay.queueAutoPlay$default(this, 0L, onPacket.4.INSTANCE, 1, null);
                return;
            }
            case "blocksmc": {
                if (this.clickState != 1) return;
                Intrinsics.checkNotNullExpressionValue((Object)text, (String)"text");
                if (!StringsKt.contains((CharSequence)text, (CharSequence)"Only VIP players can join full servers!", (boolean)true)) return;
                Client.INSTANCE.getHud().addNotification(new Notification("Join failed! trying again...", Notification.Type.WARNING, 3000L));
                Timer slot = new Timer();
                long itemName2 = 1500L;
                TimerTask timerTask = new TimerTask(){

                    public void run() {
                        TimerTask $this$onPacket_u24lambda_u2d2 = this;
                        boolean bl = false;
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(7));
                        int n = 2;
                        int n2 = 0;
                        while (n2 < n) {
                            int n3;
                            int it = n3 = n2++;
                            boolean bl2 = false;
                            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g()));
                        }
                    }
                };
                slot.schedule(timerTask, itemName2);
                return;
            }
            case "jartex": {
                IChatComponent component = ((S02PacketChat)packet).func_148915_c();
                Intrinsics.checkNotNullExpressionValue((Object)text, (String)"text");
                if (!StringsKt.contains((CharSequence)text, (CharSequence)"Click here to play again", (boolean)true)) return;
                itemName2 = component.func_150253_a();
                Intrinsics.checkNotNullExpressionValue((Object)itemName2, (String)"component.siblings");
                Iterable $this$forEach$iv = (Iterable)itemName2;
                boolean $i$f$forEach = false;
                for (Object element$iv : $this$forEach$iv) {
                    IChatComponent sib = (IChatComponent)element$iv;
                    boolean bl = false;
                    ClickEvent clickEvent = sib.func_150256_b().func_150235_h();
                    if (clickEvent == null || clickEvent.func_150669_a() != ClickEvent.Action.RUN_COMMAND) continue;
                    String string6 = clickEvent.func_150668_b();
                    Intrinsics.checkNotNullExpressionValue((Object)string6, (String)"clickEvent.value");
                    if (!StringsKt.startsWith$default((String)string6, (String)"/", (boolean)false, (int)2, null)) continue;
                    GamePlay.queueAutoPlay$default(this, 0L, (Function0)new Function0<Unit>(clickEvent){
                        final /* synthetic */ ClickEvent $clickEvent;
                        {
                            this.$clickEvent = $clickEvent;
                            super(0);
                        }

                        public final void invoke() {
                            MinecraftInstance.mc.field_71439_g.func_71165_d(this.$clickEvent.func_150668_b());
                        }
                    }, 1, null);
                }
                return;
            }
            case "hypixel": {
                locale = ((S02PacketChat)packet).func_148915_c();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"packet.chatComponent");
                GamePlay.onPacket$process(this, (IChatComponent)locale);
            }
        }
    }

    private final void queueAutoPlay(long delay, Function0<Unit> runnable) {
        if (this.queued) {
            return;
        }
        this.queued = true;
        if (this.getState()) {
            Timer timer = new Timer();
            TimerTask timerTask = new TimerTask(this, runnable){
                final /* synthetic */ GamePlay this$0;
                final /* synthetic */ Function0 $runnable$inlined;
                {
                    this.this$0 = gamePlay;
                    this.$runnable$inlined = function0;
                }

                public void run() {
                    TimerTask $this$queueAutoPlay_u24lambda_u2d5 = this;
                    boolean bl = false;
                    GamePlay.access$setQueued$p(this.this$0, false);
                    if (this.this$0.getState()) {
                        this.$runnable$inlined.invoke();
                    }
                }
            };
            timer.schedule(timerTask, delay);
            Client.INSTANCE.getHud().addNotification(new Notification("Sending you to next game in " + ((Number)this.delayValue.get()).intValue() + "s...", Notification.Type.INFO, (long)((Number)this.delayValue.get()).intValue() * 1000L));
        }
    }

    static /* synthetic */ void queueAutoPlay$default(GamePlay gamePlay, long l, Function0 function0, int n, Object object) {
        if ((n & 1) != 0) {
            l = (long)((Number)gamePlay.delayValue.get()).intValue() * (long)1000;
        }
        gamePlay.queueAutoPlay(l, (Function0<Unit>)function0);
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.clicking = false;
        this.clickState = 0;
        this.queued = false;
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    private static final void onPacket$process(GamePlay this$0, IChatComponent component) {
        String value;
        ClickEvent clickEvent = component.func_150256_b().func_150235_h();
        String string = value = clickEvent == null ? null : clickEvent.func_150668_b();
        if (value != null && StringsKt.startsWith((String)value, (String)"/play", (boolean)true)) {
            GamePlay.queueAutoPlay$default(this$0, 0L, (Function0)new Function0<Unit>(value){
                final /* synthetic */ String $value;
                {
                    this.$value = $value;
                    super(0);
                }

                public final void invoke() {
                    MinecraftInstance.mc.field_71439_g.func_71165_d(this.$value);
                }
            }, 1, null);
        }
        List list = component.func_150253_a();
        Intrinsics.checkNotNullExpressionValue((Object)list, (String)"component.siblings");
        Iterable $this$forEach$iv = list;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            IChatComponent it = (IChatComponent)element$iv;
            boolean bl = false;
            Intrinsics.checkNotNullExpressionValue((Object)it, (String)"it");
            GamePlay.onPacket$process(this$0, it);
        }
    }

    public static final /* synthetic */ void access$setClickState$p(GamePlay $this, int n) {
        $this.clickState = n;
    }

    public static final /* synthetic */ void access$setClicking$p(GamePlay $this, boolean bl) {
        $this.clicking = bl;
    }

    public static final /* synthetic */ void access$setQueued$p(GamePlay $this, boolean bl) {
        $this.queued = bl;
    }
}

