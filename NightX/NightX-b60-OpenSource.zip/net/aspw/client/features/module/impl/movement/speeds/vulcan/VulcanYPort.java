/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.vulcan;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class VulcanYPort
extends SpeedMode {
    private boolean wasTimer;
    private int ticks;

    public VulcanYPort() {
        super("VulcanYPort");
    }

    @Override
    public void onUpdate() {
        int n = this.ticks;
        this.ticks = n + 1;
        if (this.wasTimer) {
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
            this.wasTimer = false;
        }
        SpeedMode.mc.field_71439_g.field_70747_aH = 0.0245f;
        if (!SpeedMode.mc.field_71439_g.field_70122_E && this.ticks > 3 && SpeedMode.mc.field_71439_g.field_70181_x > 0.0) {
            SpeedMode.mc.field_71439_g.field_70181_x = -0.27;
        }
        SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
        if (MovementUtils.getSpeed() < 0.215f && !SpeedMode.mc.field_71439_g.field_70122_E) {
            MovementUtils.strafe(0.215f);
        }
        if (SpeedMode.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            this.ticks = 0;
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            if (!SpeedMode.mc.field_71439_g.field_70160_al) {
                return;
            }
            SpeedMode.mc.field_71428_T.field_74278_d = 1.2f;
            this.wasTimer = true;
            if (MovementUtils.getSpeed() < 0.48f) {
                MovementUtils.strafe(0.48f);
            } else {
                MovementUtils.strafe((float)((double)MovementUtils.getSpeed() * 0.985));
            }
        } else if (!MovementUtils.isMoving()) {
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
        Scaffold scaffoldModule = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        if (!SpeedMode.mc.field_71439_g.func_70093_af()) {
            Scaffold scaffold = scaffoldModule;
            Intrinsics.checkNotNull((Object)scaffold);
            if (!scaffold.getState()) {
                MovementUtils.strafe(0.2f);
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

