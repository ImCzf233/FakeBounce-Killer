/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Unit
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.BlockAir
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.util.BlockPos
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Locale;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Flight;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.misc.NewFallingPlayer;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.pathfinder.Vec3;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.BlockAir;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="AntiVoid", spacedName="Anti Void", description="", category=ModuleCategory.MOVEMENT)
public final class AntiVoid
extends Module {
    private final ListValue voidDetectionAlgorithm;
    private final ListValue setBackModeValue;
    private final IntegerValue maxFallDistSimulateValue;
    private final IntegerValue maxFindRangeValue;
    private final IntegerValue illegalDupeValue;
    private final FloatValue setBackFallDistValue;
    private final BoolValue scaffoldValue;
    private final LinkedList<double[]> positions;
    private BlockPos detectedLocation;
    private double lastX;
    private double lastY;
    private double lastZ;
    private double lastFound;
    private boolean shouldRender;
    private boolean shouldStopMotion;
    private boolean shouldEdit;

    public AntiVoid() {
        String[] stringArray = new String[]{"Collision", "Predict"};
        this.voidDetectionAlgorithm = new ListValue("Detect-Method", stringArray, "Collision");
        stringArray = new String[]{"Teleport", "FlyFlag", "IllegalPacket", "IllegalTeleport", "StopMotion", "Position", "Edit", "SpoofBack"};
        this.setBackModeValue = new ListValue("SetBack-Mode", stringArray, "FlyFlag");
        this.maxFallDistSimulateValue = new IntegerValue("Predict-CheckFallDistance", 255, 0, 255, "m", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVoid this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVoid.access$getVoidDetectionAlgorithm$p(this.this$0).get()), (String)"predict", (boolean)true);
            }
        }));
        this.maxFindRangeValue = new IntegerValue("Predict-MaxFindRange", 60, 0, 255, "m", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVoid this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)AntiVoid.access$getVoidDetectionAlgorithm$p(this.this$0).get()), (String)"predict", (boolean)true);
            }
        }));
        this.illegalDupeValue = new IntegerValue("Illegal-Dupe", 1, 1, 5, "x", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiVoid this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                String string = (String)AntiVoid.access$getSetBackModeValue$p(this.this$0).get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                return string2.equals("illegal");
            }
        }));
        this.setBackFallDistValue = new FloatValue("Max-FallDistance", 5.0f, 0.0f, 255.0f, "m");
        this.scaffoldValue = new BoolValue("AutoScaffold", false);
        this.positions = new LinkedList();
        this.detectedLocation = BlockPos.field_177992_a;
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        Object object;
        block62: {
            block61: {
                Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
                Intrinsics.checkNotNull((Object)flight);
                if (flight.getState()) {
                    return;
                }
                this.detectedLocation = null;
                if (!StringsKt.equals((String)((String)this.voidDetectionAlgorithm.get()), (String)"collision", (boolean)true)) break block61;
                if (MinecraftInstance.mc.field_71439_g.field_70122_E && !(BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)) instanceof BlockAir)) {
                    this.lastX = MinecraftInstance.mc.field_71439_g.field_70169_q;
                    this.lastY = MinecraftInstance.mc.field_71439_g.field_70167_r;
                    this.lastZ = MinecraftInstance.mc.field_71439_g.field_70166_s;
                }
                this.shouldStopMotion = false;
                this.shouldEdit = false;
                if (MovementUtils.isBlockUnder() || !(MinecraftInstance.mc.field_71439_g.field_70143_R >= ((Number)this.setBackFallDistValue.get()).floatValue())) break block62;
                this.shouldStopMotion = true;
                switch ((String)this.setBackModeValue.get()) {
                    case "IllegalTeleport": {
                        int n;
                        MinecraftInstance.mc.field_71439_g.func_70634_a(this.lastX, this.lastY, this.lastZ);
                        int i = 0;
                        while (i < ((Number)this.illegalDupeValue.get()).intValue()) {
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0E159, MinecraftInstance.mc.field_71439_g.field_70161_v, false)));
                            n = i;
                            i = n + 1;
                        }
                        break;
                    }
                    case "IllegalPacket": {
                        int n;
                        int i = 0;
                        while (i < ((Number)this.illegalDupeValue.get()).intValue()) {
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0E159, MinecraftInstance.mc.field_71439_g.field_70161_v, false)));
                            n = i;
                            i = n + 1;
                        }
                        break;
                    }
                    case "Teleport": {
                        new Thread(() -> AntiVoid.onUpdate$lambda-0(this)).start();
                        break;
                    }
                    case "FlyFlag": {
                        MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                        break;
                    }
                    case "StopMotion": {
                        float oldFallDist22 = MinecraftInstance.mc.field_71439_g.field_70143_R;
                        MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                        MinecraftInstance.mc.field_71439_g.field_70143_R = oldFallDist22;
                        break;
                    }
                    case "Position": {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u + RandomUtils.nextDouble(6.0, 10.0), MinecraftInstance.mc.field_71439_g.field_70161_v, MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70125_A, false)));
                        break;
                    }
                    case "Edit": 
                    case "SpoofBack": {
                        this.shouldEdit = true;
                        break;
                    }
                }
                if (!StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"StopMotion", (boolean)true)) {
                    MinecraftInstance.mc.field_71439_g.field_70143_R = 0.0f;
                }
                if (((Boolean)this.scaffoldValue.get()).booleanValue()) {
                    Scaffold scaffold = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
                    Intrinsics.checkNotNull((Object)scaffold);
                    if (!scaffold.getState()) {
                        Scaffold scaffold2 = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
                        Intrinsics.checkNotNull((Object)scaffold2);
                        scaffold2.setState(true);
                    }
                }
                break block62;
            }
            if (MinecraftInstance.mc.field_71439_g.field_70122_E && !(BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)) instanceof BlockAir)) {
                this.lastX = MinecraftInstance.mc.field_71439_g.field_70169_q;
                this.lastY = MinecraftInstance.mc.field_71439_g.field_70167_r;
                this.lastZ = MinecraftInstance.mc.field_71439_g.field_70166_s;
            }
            this.shouldStopMotion = false;
            this.shouldEdit = false;
            this.shouldRender = false;
            if (!(MinecraftInstance.mc.field_71439_g.field_70122_E || MinecraftInstance.mc.field_71439_g.func_70617_f_() || MinecraftInstance.mc.field_71439_g.func_70090_H())) {
                Object oldFallDist22 = MinecraftInstance.mc.field_71439_g;
                Intrinsics.checkNotNullExpressionValue((Object)oldFallDist22, (String)"mc.thePlayer");
                NewFallingPlayer NewFallingPlayer2 = new NewFallingPlayer((EntityPlayer)oldFallDist22);
                try {
                    this.detectedLocation = NewFallingPlayer2.findCollision(((Number)this.maxFindRangeValue.get()).intValue());
                }
                catch (Exception oldFallDist22) {
                    // empty catch block
                }
                if (this.detectedLocation != null && Math.abs(MinecraftInstance.mc.field_71439_g.field_70163_u - (double)this.detectedLocation.func_177956_o()) + (double)MinecraftInstance.mc.field_71439_g.field_70143_R <= (double)((Number)this.maxFallDistSimulateValue.get()).intValue()) {
                    this.lastFound = MinecraftInstance.mc.field_71439_g.field_70143_R;
                }
                if ((double)MinecraftInstance.mc.field_71439_g.field_70143_R - this.lastFound > (double)((Number)this.setBackFallDistValue.get()).floatValue()) {
                    this.shouldStopMotion = true;
                    switch ((String)this.setBackModeValue.get()) {
                        case "IllegalTeleport": {
                            MinecraftInstance.mc.field_71439_g.func_70634_a(this.lastX, this.lastY, this.lastZ);
                            int i = 0;
                            while (i < ((Number)this.illegalDupeValue.get()).intValue()) {
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0E159, MinecraftInstance.mc.field_71439_g.field_70161_v, false)));
                                int n = i;
                                i = n + 1;
                            }
                            break;
                        }
                        case "IllegalPacket": {
                            int i = 0;
                            while (i < ((Number)this.illegalDupeValue.get()).intValue()) {
                                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0E159, MinecraftInstance.mc.field_71439_g.field_70161_v, false)));
                                int n = i;
                                i = n + 1;
                            }
                            break;
                        }
                        case "Teleport": {
                            new Thread(() -> AntiVoid.onUpdate$lambda-1(this)).start();
                            break;
                        }
                        case "FlyFlag": {
                            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                            break;
                        }
                        case "StopMotion": {
                            float oldFallDist = MinecraftInstance.mc.field_71439_g.field_70143_R;
                            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                            MinecraftInstance.mc.field_71439_g.field_70143_R = oldFallDist;
                            break;
                        }
                        case "Position": {
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C06PacketPlayerPosLook(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u + RandomUtils.nextDouble(6.0, 10.0), MinecraftInstance.mc.field_71439_g.field_70161_v, MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70125_A, false)));
                            break;
                        }
                        case "Edit": 
                        case "SpoofBack": {
                            this.shouldEdit = true;
                            break;
                        }
                    }
                    if (!StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"StopMotion", (boolean)true)) {
                        MinecraftInstance.mc.field_71439_g.field_70143_R = 0.0f;
                    }
                    if (((Boolean)this.scaffoldValue.get()).booleanValue()) {
                        Scaffold scaffold = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
                        Intrinsics.checkNotNull((Object)scaffold);
                        if (!scaffold.getState()) {
                            Scaffold scaffold3 = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
                            Intrinsics.checkNotNull((Object)scaffold3);
                            scaffold3.setState(true);
                        }
                    }
                }
            }
        }
        if (this.shouldRender) {
            object = this.positions;
            synchronized (object) {
                boolean bl = false;
                double[] dArray = new double[]{MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b, MinecraftInstance.mc.field_71439_g.field_70161_v};
                bl = this.positions.add(dArray);
                return;
            }
        }
        object = this.positions;
        synchronized (object) {
            boolean bl = false;
            this.positions.clear();
            Unit unit = Unit.INSTANCE;
            return;
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
        Intrinsics.checkNotNull((Object)flight);
        if (flight.getState()) {
            return;
        }
        if (StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"StopMotion", (boolean)true) && event.getPacket() instanceof S08PacketPlayerPosLook) {
            MinecraftInstance.mc.field_71439_g.field_70143_R = 0.0f;
        }
        if (StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"Edit", (boolean)true) && this.shouldEdit && event.getPacket() instanceof C03PacketPlayer) {
            Packet<?> packet = event.getPacket();
            ((C03PacketPlayer)packet).field_149477_b += 100.0;
            this.shouldEdit = false;
        }
        if (StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"SpoofBack", (boolean)true) && this.shouldEdit && event.getPacket() instanceof C03PacketPlayer) {
            Packet<?> packetPlayer = event.getPacket();
            ((C03PacketPlayer)packetPlayer).field_149479_a = this.lastX;
            ((C03PacketPlayer)packetPlayer).field_149477_b = this.lastY;
            ((C03PacketPlayer)packetPlayer).field_149478_c = this.lastZ;
            ((C03PacketPlayer)packetPlayer).func_149469_a(false);
            this.shouldEdit = false;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Flight flight = Client.INSTANCE.getModuleManager().getModule(Flight.class);
        Intrinsics.checkNotNull((Object)flight);
        if (flight.getState()) {
            return;
        }
        if (StringsKt.equals((String)((String)this.setBackModeValue.get()), (String)"StopMotion", (boolean)true) && this.shouldStopMotion) {
            event.zero();
        }
    }

    @Override
    public void onDisable() {
        this.reset();
        super.onDisable();
    }

    @Override
    public void onEnable() {
        this.reset();
        super.onEnable();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private final void reset() {
        this.detectedLocation = null;
        this.lastX = this.lastY = (this.lastZ = (this.lastFound = 0.0));
        this.shouldStopMotion = this.shouldRender = false;
        LinkedList<double[]> linkedList = this.positions;
        synchronized (linkedList) {
            boolean bl = false;
            this.positions.clear();
            Unit unit = Unit.INSTANCE;
        }
    }

    private static final void onUpdate$lambda-0(AntiVoid this$0) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        ArrayList<Vec3> arrayList = MainPathFinder.computePath(new Vec3(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v), new Vec3(this$0.lastX, this$0.lastY, this$0.lastZ));
        Intrinsics.checkNotNullExpressionValue(arrayList, (String)"computePath(\n           \u2026                        )");
        ArrayList<Vec3> path = arrayList;
        for (Vec3 point : path) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true)));
        }
        MinecraftInstance.mc.field_71439_g.func_70107_b(this$0.lastX, this$0.lastY, this$0.lastZ);
    }

    private static final void onUpdate$lambda-1(AntiVoid this$0) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        ArrayList<Vec3> arrayList = MainPathFinder.computePath(new Vec3(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v), new Vec3(this$0.lastX, this$0.lastY, this$0.lastZ));
        Intrinsics.checkNotNullExpressionValue(arrayList, (String)"computePath(\n           \u2026                        )");
        ArrayList<Vec3> path = arrayList;
        for (Vec3 point : path) {
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(point.getX(), point.getY(), point.getZ(), true)));
        }
        MinecraftInstance.mc.field_71439_g.func_70107_b(this$0.lastX, this$0.lastY, this$0.lastZ);
    }

    public static final /* synthetic */ ListValue access$getVoidDetectionAlgorithm$p(AntiVoid $this) {
        return $this.voidDetectionAlgorithm;
    }

    public static final /* synthetic */ ListValue access$getSetBackModeValue$p(AntiVoid $this) {
        return $this.setBackModeValue;
    }
}

