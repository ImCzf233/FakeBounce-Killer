/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.network.NetworkPlayerInfo
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S0BPacketAnimation
 *  net.minecraft.network.play.server.S14PacketEntity
 *  net.minecraft.network.play.server.S38PacketPlayerListItem
 *  net.minecraft.network.play.server.S38PacketPlayerListItem$AddPlayerData
 *  net.minecraft.network.play.server.S41PacketServerDifficulty
 *  net.minecraft.world.World
 *  net.minecraft.world.WorldSettings$GameType
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.targets;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S38PacketPlayerListItem;
import net.minecraft.network.play.server.S41PacketServerDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="AntiBots", spacedName="Anti Bots", description="", category=ModuleCategory.TARGETS, array=false)
public final class AntiBots
extends Module {
    public static final Companion Companion = new Companion(null);
    private final BoolValue czechHekValue = new BoolValue("CzechMatrix", false);
    private final BoolValue czechHekPingCheckValue = new BoolValue("PingCheck", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AntiBots this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AntiBots.access$getCzechHekValue$p(this.this$0).get();
        }
    }));
    private final BoolValue czechHekGMCheckValue = new BoolValue("GamemodeCheck", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AntiBots this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AntiBots.access$getCzechHekValue$p(this.this$0).get();
        }
    }));
    private final BoolValue tabValue = new BoolValue("Tab", true);
    private final ListValue tabModeValue;
    private final BoolValue entityIDValue;
    private final BoolValue colorValue;
    private final BoolValue livingTimeValue;
    private final IntegerValue livingTimeTicksValue;
    private final BoolValue groundValue;
    private final BoolValue airValue;
    private final BoolValue invalidGroundValue;
    private final BoolValue swingValue;
    private final BoolValue healthValue;
    private final BoolValue invalidHealthValue;
    private final FloatValue minHealthValue;
    private final FloatValue maxHealthValue;
    private final BoolValue derpValue;
    private final BoolValue wasInvisibleValue;
    private final BoolValue armorValue;
    private final BoolValue pingValue;
    private final BoolValue needHitValue;
    private final BoolValue duplicateInWorldValue;
    private final BoolValue drvcValue;
    private final BoolValue duplicateInTabValue;
    private final BoolValue experimentalNPCDetection;
    private final BoolValue illegalName;
    private final BoolValue removeFromWorld;
    private final IntegerValue removeIntervalValue;
    private final BoolValue alwaysInRadiusValue;
    private final FloatValue alwaysRadiusValue;
    private final BoolValue alwaysInRadiusRemoveValue;
    private final BoolValue alwaysInRadiusWithTicksCheckValue;
    private final BoolValue debugValue;
    private final List<Integer> ground;
    private final List<Integer> air;
    private final Map<Integer, Integer> invalidGround;
    private final List<Integer> swing;
    private final List<Integer> notAlwaysInRadius;
    private final List<Integer> invisible;
    private final List<Integer> hitted;
    private boolean wasAdded;

    public AntiBots() {
        String[] stringArray = new String[]{"Equals", "Contains"};
        this.tabModeValue = new ListValue("TabMode", stringArray, "Contains");
        this.entityIDValue = new BoolValue("EntityID", false);
        this.colorValue = new BoolValue("Color", false);
        this.livingTimeValue = new BoolValue("LivingTime", false);
        this.livingTimeTicksValue = new IntegerValue("LivingTimeTicks", 40, 1, 200);
        this.groundValue = new BoolValue("Ground", false);
        this.airValue = new BoolValue("Air", false);
        this.invalidGroundValue = new BoolValue("InvalidGround", false);
        this.swingValue = new BoolValue("Swing", false);
        this.healthValue = new BoolValue("Health", false);
        this.invalidHealthValue = new BoolValue("InvalidHealth", false);
        this.minHealthValue = new FloatValue("MinHealth", 0.0f, 0.0f, 100.0f);
        this.maxHealthValue = new FloatValue("MaxHealth", 20.0f, 0.0f, 100.0f);
        this.derpValue = new BoolValue("Derp", false);
        this.wasInvisibleValue = new BoolValue("WasInvisible", false);
        this.armorValue = new BoolValue("Armor", false);
        this.pingValue = new BoolValue("Ping", false);
        this.needHitValue = new BoolValue("NeedHit", false);
        this.duplicateInWorldValue = new BoolValue("DuplicateInWorld", false);
        this.drvcValue = new BoolValue("ReverseCheck", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiBots this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiBots.access$getDuplicateInWorldValue$p(this.this$0).get();
            }
        }));
        this.duplicateInTabValue = new BoolValue("DuplicateInTab", false);
        this.experimentalNPCDetection = new BoolValue("ExperimentalNPCDetection", false);
        this.illegalName = new BoolValue("IllegalName", false);
        this.removeFromWorld = new BoolValue("RemoveFromWorld", false);
        this.removeIntervalValue = new IntegerValue("Remove-Interval", 20, 1, 100, " tick");
        this.alwaysInRadiusValue = new BoolValue("AlwaysInRadius", false);
        this.alwaysRadiusValue = new FloatValue("AlwaysInRadiusBlocks", 20.0f, 5.0f, 30.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiBots this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiBots.access$getAlwaysInRadiusValue$p(this.this$0).get();
            }
        }));
        this.alwaysInRadiusRemoveValue = new BoolValue("AlwaysInRadiusRemove", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiBots this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiBots.access$getAlwaysInRadiusValue$p(this.this$0).get();
            }
        }));
        this.alwaysInRadiusWithTicksCheckValue = new BoolValue("AlwaysInRadiusWithTicksCheck", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AntiBots this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AntiBots.access$getAlwaysInRadiusValue$p(this.this$0).get() != false && (Boolean)AntiBots.access$getLivingTimeValue$p(this.this$0).get() != false;
            }
        }));
        this.debugValue = new BoolValue("Debug", false);
        this.ground = new ArrayList();
        this.air = new ArrayList();
        this.invalidGround = new HashMap();
        this.swing = new ArrayList();
        this.notAlwaysInRadius = new ArrayList();
        this.invisible = new ArrayList();
        this.hitted = new ArrayList();
        this.wasAdded = MinecraftInstance.mc.field_71439_g != null;
    }

    @Override
    public void onDisable() {
        this.clearAll();
        super.onDisable();
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71441_e == null) {
            return;
        }
        if (((Boolean)this.removeFromWorld.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.field_70173_aa > 0 && MinecraftInstance.mc.field_71439_g.field_70173_aa % ((Number)this.removeIntervalValue.get()).intValue() == 0) {
            List ent = new ArrayList();
            for (EntityPlayer entity : MinecraftInstance.mc.field_71441_e.field_73010_i) {
                if (entity == MinecraftInstance.mc.field_71439_g) continue;
                Intrinsics.checkNotNullExpressionValue((Object)entity, (String)"entity");
                if (!Companion.isBot((EntityLivingBase)entity)) continue;
                ent.add(entity);
            }
            if (ent.isEmpty()) {
                return;
            }
            for (EntityPlayer e : ent) {
                MinecraftInstance.mc.field_71441_e.func_72900_e((Entity)e);
                if (!((Boolean)this.debugValue.get()).booleanValue()) continue;
                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7fRemoved \u00a7r" + e.func_70005_c_() + " \u00a7fdue to it being a bot.");
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        S14PacketEntity packetEntity;
        Entity entity;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71441_e == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (((Boolean)this.czechHekValue.get()).booleanValue()) {
            S38PacketPlayerListItem packetListItem;
            S38PacketPlayerListItem.AddPlayerData data;
            if (packet instanceof S41PacketServerDifficulty) {
                this.wasAdded = false;
            }
            if (packet instanceof S38PacketPlayerListItem && (data = (S38PacketPlayerListItem.AddPlayerData)(packetListItem = (S38PacketPlayerListItem)event.getPacket()).func_179767_a().get(0)).func_179962_a() != null && data.func_179962_a().getName() != null) {
                if (!this.wasAdded) {
                    this.wasAdded = data.func_179962_a().getName().equals(MinecraftInstance.mc.field_71439_g.func_70005_c_());
                } else if (!(MinecraftInstance.mc.field_71439_g.func_175149_v() || MinecraftInstance.mc.field_71439_g.field_71075_bZ.field_75101_c || ((Boolean)this.czechHekPingCheckValue.get()).booleanValue() && data.func_179963_b() == 0 || ((Boolean)this.czechHekGMCheckValue.get()).booleanValue() && data.func_179960_c() == WorldSettings.GameType.NOT_SET)) {
                    event.cancelEvent();
                    if (((Boolean)this.debugValue.get()).booleanValue()) {
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7fPrevented \u00a7r" + data.func_179962_a().getName() + " \u00a7ffrom spawning.");
                    }
                }
            }
        }
        if (packet instanceof S14PacketEntity && (entity = (packetEntity = (S14PacketEntity)event.getPacket()).func_149065_a((World)MinecraftInstance.mc.field_71441_e)) instanceof EntityPlayer) {
            if (packetEntity.func_179742_g() && !this.ground.contains(entity.func_145782_y())) {
                this.ground.add(entity.func_145782_y());
            }
            if (!packetEntity.func_179742_g() && !this.air.contains(entity.func_145782_y())) {
                this.air.add(entity.func_145782_y());
            }
            if (packetEntity.func_179742_g()) {
                if (!(entity.field_70167_r == entity.field_70163_u)) {
                    Map<Integer, Integer> map = this.invalidGround;
                    Integer n = entity.func_145782_y();
                    Integer n2 = ((Number)this.invalidGround.getOrDefault(entity.func_145782_y(), 0)).intValue() + 1;
                    map.put(n, n2);
                }
            } else {
                int currentVL = ((Number)this.invalidGround.getOrDefault(entity.func_145782_y(), 0)).intValue() / 2;
                if (currentVL <= 0) {
                    this.invalidGround.remove(entity.func_145782_y());
                } else {
                    Map<Integer, Integer> map = this.invalidGround;
                    Integer n = entity.func_145782_y();
                    Integer n3 = currentVL;
                    map.put(n, n3);
                }
            }
            if (entity.func_82150_aj() && !this.invisible.contains(entity.func_145782_y())) {
                this.invisible.add(entity.func_145782_y());
            }
        }
        if (packet instanceof S0BPacketAnimation) {
            S0BPacketAnimation packetAnimation = (S0BPacketAnimation)event.getPacket();
            entity = MinecraftInstance.mc.field_71441_e.func_73045_a(packetAnimation.func_148978_c());
            if (entity instanceof EntityLivingBase && packetAnimation.func_148977_d() == 0 && !this.swing.contains(entity.func_145782_y())) {
                this.swing.add(entity.func_145782_y());
            }
            if (!(!(entity instanceof EntityPlayer) || ((Boolean)this.livingTimeValue.get()).booleanValue() && entity.field_70173_aa <= ((Number)this.livingTimeTicksValue.get()).intValue() && ((Boolean)this.alwaysInRadiusWithTicksCheckValue.get()).booleanValue() || this.notAlwaysInRadius.contains(((EntityPlayer)entity).func_145782_y()) || !(MinecraftInstance.mc.field_71439_g.func_70032_d(entity) > ((Number)this.alwaysRadiusValue.get()).floatValue()))) {
                this.notAlwaysInRadius.add(((EntityPlayer)entity).func_145782_y());
            }
        }
    }

    @EventTarget
    public final void onAttack(AttackEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        Entity entity = e.getTargetEntity();
        if (entity instanceof EntityLivingBase && !this.hitted.contains(((EntityLivingBase)entity).func_145782_y())) {
            this.hitted.add(((EntityLivingBase)entity).func_145782_y());
        }
    }

    @EventTarget
    public final void onWorld(@Nullable WorldEvent event) {
        this.clearAll();
    }

    private final void clearAll() {
        this.hitted.clear();
        this.swing.clear();
        this.ground.clear();
        this.invalidGround.clear();
        this.invisible.clear();
    }

    @JvmStatic
    public static final boolean isBot(EntityLivingBase entity) {
        return Companion.isBot(entity);
    }

    public static final /* synthetic */ BoolValue access$getCzechHekValue$p(AntiBots $this) {
        return $this.czechHekValue;
    }

    /*
     * Illegal identifiers - consider using --renameillegalidents true
     */
    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final boolean isBot(EntityLivingBase entity) {
            EntityLivingBase player;
            String string;
            AntiBots antiBots;
            block37: {
                block38: {
                    block35: {
                        block36: {
                            Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
                            if (!(entity instanceof EntityPlayer) || entity == MinecraftInstance.mc.field_71439_g) {
                                return false;
                            }
                            antiBots = Client.INSTANCE.getModuleManager().getModule(AntiBots.class);
                            if (antiBots == null || !antiBots.getState()) {
                                return false;
                            }
                            if (!((Boolean)antiBots.experimentalNPCDetection.get()).booleanValue()) break block35;
                            string = entity.func_145748_c_().func_150260_c();
                            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.getDisplayName().unformattedText");
                            Locale locale = Locale.getDefault();
                            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                            Object object = string.toLowerCase(locale);
                            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
                            if (((String)object).equals("npc")) break block36;
                            string = entity.func_145748_c_().func_150260_c();
                            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.getDisplayName().unformattedText");
                            locale = Locale.getDefault();
                            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                            object = string.toLowerCase(locale);
                            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
                            if (!((String)object).equals("cit-")) break block35;
                        }
                        return true;
                    }
                    if (!((Boolean)antiBots.illegalName.get()).booleanValue()) break block37;
                    string = entity.func_70005_c_();
                    Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.getName()");
                    if (string.equals(" ")) break block38;
                    string = entity.func_145748_c_().func_150260_c();
                    Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.getDisplayName().unformattedText");
                    if (!string.equals(" ")) break block37;
                }
                return true;
            }
            if (((Boolean)antiBots.colorValue.get()).booleanValue()) {
                string = entity.func_145748_c_().func_150254_d();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"entity.getDisplayName().formattedText");
                if (!StringsKt.replace$default((String)string, (String)"\u00a7r", (String)"", (boolean)false, (int)4, null).equals("\u00a7")) {
                    return true;
                }
            }
            if (((Boolean)antiBots.livingTimeValue.get()).booleanValue() && entity.field_70173_aa < ((Number)antiBots.livingTimeTicksValue.get()).intValue()) {
                return true;
            }
            if (((Boolean)antiBots.groundValue.get()).booleanValue() && !antiBots.ground.contains(entity.func_145782_y())) {
                return true;
            }
            if (((Boolean)antiBots.airValue.get()).booleanValue() && !antiBots.air.contains(entity.func_145782_y())) {
                return true;
            }
            if (((Boolean)antiBots.swingValue.get()).booleanValue() && !antiBots.swing.contains(entity.func_145782_y())) {
                return true;
            }
            if (((Boolean)antiBots.invalidHealthValue.get()).booleanValue() && entity.func_110143_aJ() == Float.NaN) {
                return true;
            }
            if (((Boolean)antiBots.healthValue.get()).booleanValue() && (entity.func_110143_aJ() > ((Number)antiBots.maxHealthValue.get()).floatValue() || entity.func_110143_aJ() < ((Number)antiBots.minHealthValue.get()).floatValue())) {
                return true;
            }
            if (((Boolean)antiBots.entityIDValue.get()).booleanValue() && (entity.func_145782_y() >= 1000000000 || entity.func_145782_y() <= -1)) {
                return true;
            }
            if (((Boolean)antiBots.derpValue.get()).booleanValue() && (entity.field_70125_A > 90.0f || entity.field_70125_A < -90.0f)) {
                return true;
            }
            if (((Boolean)antiBots.wasInvisibleValue.get()).booleanValue() && antiBots.invisible.contains(entity.func_145782_y())) {
                return true;
            }
            if (((Boolean)antiBots.armorValue.get()).booleanValue()) {
                player = entity;
                if (((EntityPlayer)player).field_71071_by.field_70460_b[0] == null && ((EntityPlayer)player).field_71071_by.field_70460_b[1] == null && ((EntityPlayer)player).field_71071_by.field_70460_b[2] == null && ((EntityPlayer)player).field_71071_by.field_70460_b[3] == null) {
                    return true;
                }
            }
            if (((Boolean)antiBots.alwaysInRadiusValue.get()).booleanValue() && !antiBots.notAlwaysInRadius.contains(((EntityPlayer)entity).func_145782_y())) {
                if (((Boolean)antiBots.alwaysInRadiusRemoveValue.get()).booleanValue()) {
                    MinecraftInstance.mc.field_71441_e.func_72900_e((Entity)entity);
                }
                return true;
            }
            if (((Boolean)antiBots.pingValue.get()).booleanValue()) {
                player = entity;
                if (MinecraftInstance.mc.func_147114_u().func_175102_a(((EntityPlayer)player).func_110124_au()) != null && MinecraftInstance.mc.func_147114_u().func_175102_a(((EntityPlayer)player).func_110124_au()).func_178853_c() == 0) {
                    return true;
                }
            }
            if (((Boolean)antiBots.needHitValue.get()).booleanValue() && !antiBots.hitted.contains(entity.func_145782_y())) {
                return true;
            }
            if (((Boolean)antiBots.invalidGroundValue.get()).booleanValue() && ((Number)antiBots.invalidGround.getOrDefault(entity.func_145782_y(), 0)).intValue() >= 10) {
                return true;
            }
            if (((Boolean)antiBots.tabValue.get()).booleanValue()) {
                boolean equals = StringsKt.equals((String)((String)antiBots.tabModeValue.get()), (String)"Equals", (boolean)true);
                String targetName = ColorUtils.stripColor(entity.func_145748_c_().func_150254_d());
                if (targetName != null) {
                    for (NetworkPlayerInfo networkPlayerInfo : MinecraftInstance.mc.func_147114_u().func_175106_d()) {
                        String networkName;
                        if (ColorUtils.stripColor(EntityUtils.getName(networkPlayerInfo)) == null || !(equals ? targetName.equals(networkName) : targetName.equals(networkName))) continue;
                        return false;
                    }
                    return true;
                }
            }
            if (((Boolean)antiBots.duplicateInWorldValue.get()).booleanValue()) {
                if (((Boolean)antiBots.drvcValue.get()).booleanValue()) {
                    Stream stream = MinecraftInstance.mc.field_71441_e.field_72996_f.stream();
                    Intrinsics.checkNotNullExpressionValue(stream, (String)"mc.theWorld.loadedEntityList.stream()");
                    if (this.reverse(stream).filter(Companion::isBot$lambda-0).count() > 1L) {
                        return true;
                    }
                }
                if (MinecraftInstance.mc.field_71441_e.field_72996_f.stream().filter(Companion::isBot$lambda-1).count() > 1L) {
                    return true;
                }
            }
            if (((Boolean)antiBots.duplicateInTabValue.get()).booleanValue() && MinecraftInstance.mc.func_147114_u().func_175106_d().stream().filter(arg_0 -> Companion.isBot$lambda-2(entity, arg_0)).count() > 1L) {
                return true;
            }
            String string2 = entity.func_70005_c_();
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"entity.getName()");
            return ((CharSequence)string2).length() == 0 || entity.func_70005_c_().equals(MinecraftInstance.mc.field_71439_g.func_70005_c_());
        }

        private final <T> Stream<T> reverse(Stream<T> stream) {
            LinkedList stack = new LinkedList();
            stream.forEach(arg_0 -> Companion.reverse$lambda-3(stack, arg_0));
            Stream stream2 = stack.stream();
            Intrinsics.checkNotNullExpressionValue(stream2, (String)"stack.stream()");
            return stream2;
        }

        private static final boolean isBot$lambda-0(Entity currEntity) {
            return currEntity instanceof EntityPlayer && ((EntityPlayer)currEntity).getDisplayNameString().equals(((EntityPlayer)currEntity).getDisplayNameString());
        }

        private static final boolean isBot$lambda-1(Entity currEntity) {
            return currEntity instanceof EntityPlayer && ((EntityPlayer)currEntity).getDisplayNameString().equals(((EntityPlayer)currEntity).getDisplayNameString());
        }

        private static final boolean isBot$lambda-2(EntityLivingBase $entity, NetworkPlayerInfo networkPlayer) {
            Intrinsics.checkNotNullParameter((Object)$entity, (String)"$entity");
            return $entity.func_70005_c_().equals(ColorUtils.stripColor(EntityUtils.getName(networkPlayer)));
        }

        private static final void reverse$lambda-3(LinkedList $stack, Object e) {
            Intrinsics.checkNotNullParameter((Object)$stack, (String)"$stack");
            $stack.push(e);
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

