/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtilsFix;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;

@ModuleInfo(name="EntityFlight", spacedName="Entity Flight", description="", category=ModuleCategory.MOVEMENT)
public final class EntityFlight
extends Module {
    private final ListValue modeValue;
    private final FloatValue speedValue;

    public EntityFlight() {
        String[] stringArray = new String[]{"Motion", "Clip", "Velocity"};
        this.modeValue = new ListValue("Mode", stringArray, "Motion");
        this.speedValue = new FloatValue("Speed", 0.3f, 0.0f, 1.0f);
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.field_71439_g.func_70115_ae()) {
            return;
        }
        Entity vehicle = MinecraftInstance.mc.field_71439_g.field_70154_o;
        double x = -Math.sin(MovementUtilsFix.INSTANCE.getDirection()) * ((Number)this.speedValue.get()).doubleValue();
        double z = Math.cos(MovementUtilsFix.INSTANCE.getDirection()) * ((Number)this.speedValue.get()).doubleValue();
        String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
        switch (string) {
            case "motion": {
                vehicle.field_70159_w = x;
                vehicle.field_70181_x = ((Number)(MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e ? this.speedValue.get() : Integer.valueOf(0))).doubleValue();
                vehicle.field_70179_y = z;
                break;
            }
            case "clip": {
                vehicle.func_70107_b(vehicle.field_70165_t + x, vehicle.field_70163_u + ((Number)(MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e ? this.speedValue.get() : Integer.valueOf(0))).doubleValue(), vehicle.field_70161_v + z);
                break;
            }
            case "velocity": {
                vehicle.func_70024_g(x, MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e ? (double)((Number)this.speedValue.get()).floatValue() : 0.0, z);
            }
        }
    }
}

