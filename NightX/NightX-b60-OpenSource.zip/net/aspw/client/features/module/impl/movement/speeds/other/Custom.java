/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class Custom
extends SpeedMode {
    private int groundTick = 0;

    public Custom() {
        super("Custom");
    }

    @Override
    public void onMotion(MotionEvent eventMotion) {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null || eventMotion.getEventState() != EventState.PRE) {
            return;
        }
        if (MovementUtils.isMoving()) {
            float f = Custom.mc.field_71428_T.field_74278_d = Custom.mc.field_71439_g.field_70181_x > 0.0 ? ((Float)speed2.upTimerValue.get()).floatValue() : ((Float)speed2.downTimerValue.get()).floatValue();
            if (Custom.mc.field_71439_g.field_70122_E) {
                if (this.groundTick >= (Integer)speed2.groundStay.get()) {
                    if (((Boolean)speed2.doLaunchSpeedValue.get()).booleanValue()) {
                        MovementUtils.strafe(((Float)speed2.launchSpeedValue.get()).floatValue());
                    }
                    if (((Float)speed2.yValue.get()).floatValue() != 0.0f) {
                        Custom.mc.field_71439_g.field_70181_x = ((Float)speed2.yValue.get()).floatValue();
                    }
                } else if (((Boolean)speed2.groundResetXZValue.get()).booleanValue()) {
                    Custom.mc.field_71439_g.field_70159_w = 0.0;
                    Custom.mc.field_71439_g.field_70179_y = 0.0;
                }
                ++this.groundTick;
            } else {
                this.groundTick = 0;
                switch (((String)speed2.strafeValue.get()).toLowerCase()) {
                    case "strafe": {
                        MovementUtils.strafe(((Float)speed2.speedValue.get()).floatValue());
                        break;
                    }
                    case "boost": {
                        MovementUtils.strafe();
                        break;
                    }
                    case "plus": {
                        MovementUtils.accelerate(((Float)speed2.speedValue.get()).floatValue() * 0.1f);
                        break;
                    }
                    case "plusonlyup": {
                        if (Custom.mc.field_71439_g.field_70181_x > 0.0) {
                            MovementUtils.accelerate(((Float)speed2.speedValue.get()).floatValue() * 0.1f);
                            break;
                        }
                        MovementUtils.strafe();
                    }
                }
                Custom.mc.field_71439_g.field_70181_x += (double)((Float)speed2.addYMotionValue.get()).floatValue() * 0.03;
            }
        } else if (((Boolean)speed2.resetXZValue.get()).booleanValue()) {
            Custom.mc.field_71439_g.field_70159_w = 0.0;
            Custom.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        if (((Boolean)speed2.resetXZValue.get()).booleanValue()) {
            Custom.mc.field_71439_g.field_70179_y = 0.0;
            Custom.mc.field_71439_g.field_70159_w = 0.0;
        }
        if (((Boolean)speed2.resetYValue.get()).booleanValue()) {
            Custom.mc.field_71439_g.field_70181_x = 0.0;
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        Custom.mc.field_71428_T.field_74278_d = 1.0f;
        super.onDisable();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

