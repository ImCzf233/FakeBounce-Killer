/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.util.MathHelper;

public class NCPYPort
extends SpeedMode {
    private int jumps;

    public NCPYPort() {
        super("NCPYPort");
    }

    @Override
    public void onMotion() {
        if (NCPYPort.mc.field_71439_g.func_70617_f_() || NCPYPort.mc.field_71439_g.func_70090_H() || NCPYPort.mc.field_71439_g.func_180799_ab() || NCPYPort.mc.field_71439_g.field_70134_J || !MovementUtils.isMoving() || NCPYPort.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (this.jumps >= 4 && NCPYPort.mc.field_71439_g.field_70122_E) {
            this.jumps = 0;
        }
        if (NCPYPort.mc.field_71439_g.field_70122_E) {
            NCPYPort.mc.field_71439_g.field_70181_x = this.jumps <= 1 ? (double)0.42f : (double)0.4f;
            float f = NCPYPort.mc.field_71439_g.field_70177_z * ((float)Math.PI / 180);
            NCPYPort.mc.field_71439_g.field_70159_w -= (double)(MathHelper.func_76126_a((float)f) * 0.2f);
            NCPYPort.mc.field_71439_g.field_70179_y += (double)(MathHelper.func_76134_b((float)f) * 0.2f);
            ++this.jumps;
        } else if (this.jumps <= 1) {
            NCPYPort.mc.field_71439_g.field_70181_x = -5.0;
        }
        MovementUtils.strafe();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPYPort.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPYPort.mc.field_71439_g.field_70159_w = 0.0;
            NCPYPort.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

