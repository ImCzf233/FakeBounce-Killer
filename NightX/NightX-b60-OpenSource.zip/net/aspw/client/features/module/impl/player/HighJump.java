/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="HighJump", spacedName="High Jump", description="", category=ModuleCategory.PLAYER)
public final class HighJump
extends Module {
    private final FloatValue heightValue = new FloatValue("Height", 5.0f, 1.0f, 10.0f, "m");
    private final ListValue modeValue;
    private int tick;

    public HighJump() {
        String[] stringArray = new String[]{"Vanilla", "Damage", "AACv3", "DAC", "Mineplex"};
        this.modeValue = new ListValue("Mode", stringArray, "Vanilla");
    }

    public final int getTick() {
        return this.tick;
    }

    public final void setTick(int n) {
        this.tick = n;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "damage": {
                if (MinecraftInstance.mc.field_71439_g.field_70737_aN <= 0 || !MinecraftInstance.mc.field_71439_g.field_70122_E) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += (double)(0.42f * ((Number)this.heightValue.get()).floatValue());
                break;
            }
            case "aacv3": {
                if (MinecraftInstance.mc.field_71439_g.field_70122_E) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += 0.059;
                break;
            }
            case "dac": {
                if (MinecraftInstance.mc.field_71439_g.field_70122_E) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += 0.049999;
                break;
            }
            case "mineplex": {
                if (MinecraftInstance.mc.field_71439_g.field_70122_E) break;
                MovementUtils.strafe(0.35f);
            }
        }
    }

    @EventTarget
    public final void onMove(@Nullable MoveEvent event) {
        if (!MinecraftInstance.mc.field_71439_g.field_70122_E && StringsKt.equals((String)"mineplex", (String)((String)this.modeValue.get()), (boolean)true)) {
            EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
            entityPlayerSP.field_70181_x = entityPlayerSP.field_70181_x + (MinecraftInstance.mc.field_71439_g.field_70143_R == 0.0f ? 0.0499 : 0.05);
        }
    }

    @EventTarget
    public final void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        String string3 = string2;
        if (string3.equals("vanilla")) {
            event.setMotion(event.getMotion() * ((Number)this.heightValue.get()).floatValue());
        } else if (string3.equals("mineplex")) {
            event.setMotion(0.47f);
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

