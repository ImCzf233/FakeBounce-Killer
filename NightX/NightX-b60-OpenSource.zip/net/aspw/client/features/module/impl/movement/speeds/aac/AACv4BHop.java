/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;

public class AACv4BHop
extends SpeedMode {
    public AACv4BHop() {
        super("AACv4BHop");
    }

    @Override
    public void onMotion() {
        if (AACv4BHop.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (AACv4BHop.mc.field_71439_g.field_70701_bs > 0.0f) {
            if (AACv4BHop.mc.field_71439_g.field_70122_E) {
                AACv4BHop.mc.field_71439_g.func_70664_aZ();
                AACv4BHop.mc.field_71428_T.field_74278_d = 1.6105f;
                AACv4BHop.mc.field_71439_g.field_70159_w *= 1.0708;
                AACv4BHop.mc.field_71439_g.field_70179_y *= 1.0708;
            } else if (AACv4BHop.mc.field_71439_g.field_70143_R > 0.0f) {
                AACv4BHop.mc.field_71428_T.field_74278_d = 0.6f;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

