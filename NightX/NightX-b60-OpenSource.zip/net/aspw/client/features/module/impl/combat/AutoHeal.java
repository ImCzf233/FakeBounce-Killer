/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.gui.inventory.GuiInventory
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0DPacketCloseWindow
 *  net.minecraft.network.play.client.C16PacketClientStatus
 *  net.minecraft.network.play.client.C16PacketClientStatus$EnumState
 *  net.minecraft.potion.Potion
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.combat;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.InventoryHelper;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="AutoHeal", spacedName="Auto Heal", description="", category=ModuleCategory.COMBAT)
public final class AutoHeal
extends Module {
    private final BoolValue autoPotValue = new BoolValue("AutoPot", true);
    private final FloatValue healthValue = new FloatValue("Health-Pot", 15.0f, 0.0f, 100.0f, "%", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final IntegerValue delayValue = new IntegerValue("Delay-Pot", 300, 0, 5000, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final BoolValue regenValue = new BoolValue("Heal-Pot", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final BoolValue utilityValue = new BoolValue("Utility-Pot", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final BoolValue smartValue = new BoolValue("Smart-Pot", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final IntegerValue smartTimeoutValue = new IntegerValue("SmartTimeout-Pot", 500, 500, 5000, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getSmartValue$p(this.this$0).get() != false && (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get() != false;
        }
    }));
    private final BoolValue spoofInvValue = new BoolValue("InvSpoof-Pot", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final IntegerValue spoofDelayValue = new IntegerValue("InvDelay-Pot", 500, 500, 5000, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getSpoofInvValue$p(this.this$0).get() != false && (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get() != false;
        }
    }));
    private final BoolValue noCombatValue = new BoolValue("NoCombat-Pot", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final BoolValue customPitchValue = new BoolValue("Custom-Pitch-Pot", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final FloatValue customPitchAngle = new FloatValue("Angle-Pot", 90.0f, -90.0f, 90.0f, "\u00b0", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getCustomPitchValue$p(this.this$0).get() != false && (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get() != false;
        }
    }));
    private final BoolValue debugValue = new BoolValue("Debug-Pot", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoPotValue$p(this.this$0).get();
        }
    }));
    private final BoolValue autoSoupValue = new BoolValue("AutoSoup", false);
    private final FloatValue healthValueA = new FloatValue("Health-Soup", 15.0f, 0.0f, 20.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoSoupValue$p(this.this$0).get();
        }
    }));
    private final IntegerValue delayValueA = new IntegerValue("Delay-Soup", 150, 0, 500, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoSoupValue$p(this.this$0).get();
        }
    }));
    private final BoolValue openInventoryValue = new BoolValue("OpenInv-Soup", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoSoupValue$p(this.this$0).get();
        }
    }));
    private final BoolValue simulateInventoryValue = new BoolValue("SimulateInventory-Soup", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AutoHeal this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AutoHeal.access$getAutoSoupValue$p(this.this$0).get();
        }
    }));
    private final ListValue bowlValue;
    private boolean isRotating;
    private boolean throwing;
    private boolean rotated;
    private int prevSlot;
    private int potIndex;
    private MSTimer throwTimer;
    private MSTimer resetTimer;
    private MSTimer invTimer;
    private MSTimer timeoutTimer;
    private final MSTimer timer;
    private final ArrayList<Integer> throwQueue;
    private final KillAura killAura;
    private final Scaffold scaffold;

    public AutoHeal() {
        String[] stringArray = new String[]{"Drop", "Move", "Stay"};
        this.bowlValue = new ListValue("Bowl-Soup", stringArray, "Drop", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ AutoHeal this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return (Boolean)AutoHeal.access$getAutoSoupValue$p(this.this$0).get();
            }
        }));
        this.prevSlot = -1;
        this.potIndex = -1;
        this.throwTimer = new MSTimer();
        this.resetTimer = new MSTimer();
        this.invTimer = new MSTimer();
        this.timeoutTimer = new MSTimer();
        this.timer = new MSTimer();
        this.throwQueue = new ArrayList();
        this.killAura = Client.INSTANCE.getModuleManager().getModule(KillAura.class);
        this.scaffold = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
    }

    public final boolean isRotating() {
        return this.isRotating;
    }

    public final void setRotating(boolean bl) {
        this.isRotating = bl;
    }

    public final boolean getThrowing() {
        return this.throwing;
    }

    public final void setThrowing(boolean bl) {
        this.throwing = bl;
    }

    public final KillAura getKillAura() {
        return this.killAura;
    }

    public final Scaffold getScaffold() {
        return this.scaffold;
    }

    @Override
    public String getTag() {
        return "" + ((Number)this.healthValue.get()).floatValue() + '%';
    }

    private final void resetAll() {
        this.throwing = false;
        this.rotated = false;
        this.throwTimer.reset();
        this.resetTimer.reset();
        this.timeoutTimer.reset();
        this.invTimer.reset();
        this.throwQueue.clear();
    }

    @Override
    public void onDisable() {
        this.isRotating = false;
    }

    @Override
    public void onEnable() {
        if (((Boolean)this.autoPotValue.get()).booleanValue()) {
            this.resetAll();
        }
    }

    @EventTarget
    public final void onWorld(WorldEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.autoPotValue.get()).booleanValue()) {
            this.resetAll();
        }
    }

    private final void debug(String s) {
        if (((Boolean)this.debugValue.get()).booleanValue()) {
            ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a73", (Object)s));
        }
    }

    @EventTarget(priority=2)
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.autoPotValue.get()).booleanValue() && event.getEventState() == EventState.PRE) {
            int potion;
            int n;
            if (((Boolean)this.smartValue.get()).booleanValue() && !this.throwQueue.isEmpty()) {
                boolean foundPot = false;
                n = this.throwQueue.size() + -1;
                if (0 <= n) {
                    do {
                        int k = n--;
                        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                        Integer n2 = this.throwQueue.get(k);
                        Intrinsics.checkNotNullExpressionValue((Object)n2, (String)"throwQueue[k]");
                        if (!entityPlayerSP.func_82165_m(((Number)n2).intValue())) continue;
                        this.throwQueue.remove(k);
                        this.timeoutTimer.reset();
                        foundPot = true;
                    } while (0 <= n);
                }
                if (!foundPot && this.timeoutTimer.hasTimePassed(((Number)this.smartTimeoutValue.get()).intValue())) {
                    this.debug("reached timeout, clearing queue");
                    this.throwQueue.clear();
                    this.timeoutTimer.reset();
                }
            } else {
                this.timeoutTimer.reset();
            }
            if (((Boolean)this.spoofInvValue.get()).booleanValue() && !(MinecraftInstance.mc.field_71462_r instanceof GuiContainer) && !this.throwing) {
                int invPotion;
                if (this.invTimer.hasTimePassed(((Number)this.spoofDelayValue.get()).intValue()) && (invPotion = this.findPotion(9, 36)) != -1) {
                    if (InventoryUtils.hasSpaceHotbar()) {
                        InventoryHelper.INSTANCE.openPacket();
                        MinecraftInstance.mc.field_71442_b.func_78753_a(0, invPotion, 0, 1, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                        InventoryHelper.INSTANCE.closePacket();
                    } else {
                        n = 36;
                        while (n < 45) {
                            int i;
                            ItemStack stack;
                            if ((stack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(i = n++).func_75211_c()) == null || !(stack.func_77973_b() instanceof ItemPotion) || !ItemPotion.func_77831_g((int)stack.func_77952_i())) continue;
                            InventoryHelper.INSTANCE.openPacket();
                            MinecraftInstance.mc.field_71442_b.func_78753_a(0, invPotion, 0, 0, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                            MinecraftInstance.mc.field_71442_b.func_78753_a(0, i, 0, 0, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                            InventoryHelper.INSTANCE.closePacket();
                            break;
                        }
                    }
                    this.invTimer.reset();
                    this.debug("moved pot");
                    return;
                }
            } else {
                this.invTimer.reset();
            }
            if (!(MinecraftInstance.mc.field_71462_r instanceof GuiContainer) && !this.throwing && this.throwTimer.hasTimePassed(((Number)this.delayValue.get()).intValue()) && (potion = this.findPotion(36, 45)) != -1) {
                this.potIndex = potion;
                this.throwing = true;
                this.debug("found pot, queueing");
            }
            if (this.throwing && !(MinecraftInstance.mc.field_71462_r instanceof GuiContainer)) {
                KillAura killAura = this.killAura;
                Boolean bl = killAura == null ? null : Boolean.valueOf(killAura.getState());
                Intrinsics.checkNotNull((Object)bl);
                if (!bl.booleanValue() || this.killAura.getTarget() == null) {
                    Scaffold scaffold = this.scaffold;
                    Boolean bl2 = scaffold == null ? null : Boolean.valueOf(scaffold.getState());
                    Intrinsics.checkNotNull((Object)bl2);
                    if (!bl2.booleanValue()) {
                        if (MinecraftInstance.mc.field_71439_g.field_70122_E) {
                            MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                            MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                            MinecraftInstance.mc.field_71439_g.func_70664_aZ();
                            this.debug("jumped");
                        }
                        RotationUtils.reset();
                        event.setPitch((Boolean)this.customPitchValue.get() != false ? ((Number)this.customPitchAngle.get()).floatValue() : 90.0f);
                        this.debug("silent rotation");
                        this.isRotating = true;
                    }
                }
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (((Boolean)this.autoPotValue.get()).booleanValue() && this.throwing && !MinecraftInstance.mc.func_71356_B() && packet instanceof C09PacketHeldItemChange) {
            if (((C09PacketHeldItemChange)packet).func_149614_c() == this.prevSlot) {
                event.cancelEvent();
            } else {
                this.prevSlot = ((C09PacketHeldItemChange)packet).func_149614_c();
            }
        }
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (((Boolean)this.autoSoupValue.get()).booleanValue()) {
            int soupInInventory;
            boolean openInventory;
            if (!this.timer.hasTimePassed(((Number)this.delayValueA.get()).intValue())) {
                return;
            }
            int soupInHotbar = InventoryUtils.findItem(36, 45, Items.field_151009_A);
            if (MinecraftInstance.mc.field_71439_g.func_110143_aJ() <= ((Number)this.healthValueA.get()).floatValue() && soupInHotbar != -1) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(soupInHotbar - 36));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(soupInHotbar).func_75211_c()));
                if (StringsKt.equals((String)((String)this.bowlValue.get()), (String)"Drop", (boolean)true)) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.DROP_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN));
                }
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
                this.timer.reset();
                return;
            }
            int bowlInHotbar = InventoryUtils.findItem(36, 45, Items.field_151054_z);
            if (StringsKt.equals((String)((String)this.bowlValue.get()), (String)"Move", (boolean)true) && bowlInHotbar != -1) {
                if (((Boolean)this.openInventoryValue.get()).booleanValue() && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory)) {
                    return;
                }
                boolean bowlMovable = false;
                int n = 9;
                while (n < 37) {
                    int i;
                    ItemStack itemStack;
                    if ((itemStack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(i = n++).func_75211_c()) == null) {
                        bowlMovable = true;
                        break;
                    }
                    if (!itemStack.func_77973_b().equals(Items.field_151054_z) || itemStack.field_77994_a >= 64) continue;
                    bowlMovable = true;
                    break;
                }
                if (bowlMovable) {
                    boolean bl = openInventory = !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && (Boolean)this.simulateInventoryValue.get() != false;
                    if (openInventory) {
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
                    }
                    MinecraftInstance.mc.field_71442_b.func_78753_a(0, bowlInHotbar, 0, 1, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                }
            }
            if ((soupInInventory = InventoryUtils.findItem(9, 36, Items.field_151009_A)) != -1 && InventoryUtils.hasSpaceHotbar()) {
                if (((Boolean)this.openInventoryValue.get()).booleanValue() && !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory)) {
                    return;
                }
                boolean bl = openInventory = !(MinecraftInstance.mc.field_71462_r instanceof GuiInventory) && (Boolean)this.simulateInventoryValue.get() != false;
                if (openInventory) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
                }
                MinecraftInstance.mc.field_71442_b.func_78753_a(0, soupInInventory, 0, 1, (EntityPlayer)MinecraftInstance.mc.field_71439_g);
                if (openInventory) {
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0DPacketCloseWindow());
                }
                this.timer.reset();
            }
        }
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget(priority=-1)
    public final void onMotionPost(MotionEvent event) {
        block10: {
            block11: {
                Intrinsics.checkNotNullParameter((Object)event, (String)"event");
                if (!((Boolean)this.autoPotValue.get()).booleanValue() || event.getEventState() != EventState.POST || !this.throwing || MinecraftInstance.mc.field_71462_r instanceof GuiContainer || MinecraftInstance.mc.field_71439_g.field_70122_E) break block10;
                if (!((Boolean)this.noCombatValue.get()).booleanValue()) break block11;
                KillAura killAura = this.killAura;
                Boolean bl = killAura == null ? null : Boolean.valueOf(killAura.getState());
                Intrinsics.checkNotNull((Object)bl);
                if (bl.booleanValue() && this.killAura.getTarget() != null) break block10;
            }
            Scaffold scaffold = this.scaffold;
            Boolean bl = scaffold == null ? null : Boolean.valueOf(scaffold.getState());
            Intrinsics.checkNotNull((Object)bl);
            if (!bl.booleanValue()) {
                List<PotionEffect> potionEffects = this.getPotionFromSlot(this.potIndex);
                if (potionEffects != null) {
                    Iterable $this$mapTo$iv$iv;
                    Iterable $this$map$iv = potionEffects;
                    boolean $i$f$map = false;
                    Iterable iterable = $this$map$iv;
                    Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv, (int)10));
                    boolean $i$f$mapTo = false;
                    for (Object item$iv$iv : $this$mapTo$iv$iv) {
                        void it;
                        PotionEffect potionEffect = (PotionEffect)item$iv$iv;
                        Collection collection = destination$iv$iv;
                        boolean bl2 = false;
                        collection.add(it.func_76456_a());
                    }
                    List potionIds = (List)destination$iv$iv;
                    if (((Boolean)this.smartValue.get()).booleanValue()) {
                        void $this$forEach$iv;
                        void $this$filterTo$iv$iv;
                        Iterable $this$filter$iv = potionIds;
                        boolean $i$f$filter = false;
                        $this$mapTo$iv$iv = $this$filter$iv;
                        destination$iv$iv = new ArrayList();
                        boolean $i$f$filterTo = false;
                        for (Object element$iv$iv : $this$filterTo$iv$iv) {
                            int it = ((Number)element$iv$iv).intValue();
                            boolean bl3 = false;
                            if (!(!this.throwQueue.contains(it))) continue;
                            destination$iv$iv.add(element$iv$iv);
                        }
                        $this$filter$iv = (List)destination$iv$iv;
                        boolean $i$f$forEach = false;
                        for (Object element$iv : $this$forEach$iv) {
                            int it = ((Number)element$iv).intValue();
                            boolean bl4 = false;
                            this.throwQueue.add(it);
                        }
                    }
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(this.potIndex - 36));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.func_70694_bm()));
                    MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
                    MinecraftInstance.mc.func_175597_ag().func_78445_c();
                    this.potIndex = -1;
                    this.throwing = false;
                    this.throwTimer.reset();
                    this.isRotating = false;
                    this.debug("thrown");
                } else {
                    this.potIndex = -1;
                    this.throwing = false;
                    this.debug("failed to retrieve potion info, retrying...");
                }
            }
        }
    }

    private final int findPotion(int startSlot, int endSlot) {
        int n = startSlot;
        while (n < endSlot) {
            int i;
            if (!this.findSinglePotion(i = n++)) continue;
            return i;
        }
        return -1;
    }

    private final List<PotionEffect> getPotionFromSlot(int slot) {
        ItemStack stack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(slot).func_75211_c();
        if (stack == null || !(stack.func_77973_b() instanceof ItemPotion) || !ItemPotion.func_77831_g((int)stack.func_77952_i())) {
            return null;
        }
        Item item = stack.func_77973_b();
        if (item == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemPotion");
        }
        ItemPotion itemPotion = (ItemPotion)item;
        return itemPotion.func_77832_l(stack);
    }

    private final boolean findSinglePotion(int slot) {
        block7: {
            ItemPotion itemPotion;
            ItemStack stack;
            block6: {
                stack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(slot).func_75211_c();
                if (stack == null || !(stack.func_77973_b() instanceof ItemPotion) || !ItemPotion.func_77831_g((int)stack.func_77952_i())) {
                    return false;
                }
                Item item = stack.func_77973_b();
                if (item == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.ItemPotion");
                }
                itemPotion = (ItemPotion)item;
                if (!(MinecraftInstance.mc.field_71439_g.func_110143_aJ() / MinecraftInstance.mc.field_71439_g.func_110138_aP() * 100.0f < ((Number)this.healthValue.get()).floatValue()) || !((Boolean)this.regenValue.get()).booleanValue()) break block6;
                for (PotionEffect potionEffect : itemPotion.func_77832_l(stack)) {
                    if (potionEffect.func_76456_a() != Potion.field_76432_h.field_76415_H) continue;
                    return true;
                }
                if (MinecraftInstance.mc.field_71439_g.func_70644_a(Potion.field_76428_l) || ((Boolean)this.smartValue.get()).booleanValue() && this.throwQueue.contains(Potion.field_76428_l.field_76415_H)) break block7;
                for (PotionEffect potionEffect : itemPotion.func_77832_l(stack)) {
                    if (potionEffect.func_76456_a() != Potion.field_76428_l.field_76415_H) continue;
                    return true;
                }
                break block7;
            }
            if (((Boolean)this.utilityValue.get()).booleanValue()) {
                for (PotionEffect potionEffect : itemPotion.func_77832_l(stack)) {
                    if (!this.isUsefulPotion(potionEffect.func_76456_a())) continue;
                    return true;
                }
            }
        }
        return false;
    }

    private final boolean isUsefulPotion(int id) {
        if (id == Potion.field_76428_l.field_76415_H || id == Potion.field_76432_h.field_76415_H || id == Potion.field_76436_u.field_76415_H || id == Potion.field_76440_q.field_76415_H || id == Potion.field_76433_i.field_76415_H || id == Potion.field_82731_v.field_76415_H || id == Potion.field_76419_f.field_76415_H || id == Potion.field_76421_d.field_76415_H || id == Potion.field_76437_t.field_76415_H) {
            return false;
        }
        return !MinecraftInstance.mc.field_71439_g.func_82165_m(id) && ((Boolean)this.smartValue.get() == false || !this.throwQueue.contains(id));
    }

    public static final /* synthetic */ BoolValue access$getAutoPotValue$p(AutoHeal $this) {
        return $this.autoPotValue;
    }

    public static final /* synthetic */ BoolValue access$getSmartValue$p(AutoHeal $this) {
        return $this.smartValue;
    }

    public static final /* synthetic */ BoolValue access$getSpoofInvValue$p(AutoHeal $this) {
        return $this.spoofInvValue;
    }

    public static final /* synthetic */ BoolValue access$getCustomPitchValue$p(AutoHeal $this) {
        return $this.customPitchValue;
    }

    public static final /* synthetic */ BoolValue access$getAutoSoupValue$p(AutoHeal $this) {
        return $this.autoSoupValue;
    }
}

