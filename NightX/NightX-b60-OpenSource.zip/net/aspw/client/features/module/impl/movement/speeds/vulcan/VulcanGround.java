/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 */
package net.aspw.client.features.module.impl.movement.speeds.vulcan;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;

public final class VulcanGround
extends SpeedMode {
    private boolean jumped;
    private int jumpCount;
    private double yMotion;

    public VulcanGround() {
        super("VulcanGround");
    }

    @Override
    public void onUpdate() {
        if (this.jumped) {
            SpeedMode.mc.field_71439_g.field_70181_x = -0.1;
            SpeedMode.mc.field_71439_g.field_70122_E = false;
            this.jumped = false;
            this.yMotion = 0.0;
        }
        SpeedMode.mc.field_71439_g.field_70747_aH = 0.025f;
        if (SpeedMode.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            if (SpeedMode.mc.field_71439_g.field_70123_F || SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e) {
                if (!SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e) {
                    SpeedMode.mc.field_71439_g.func_70664_aZ();
                }
                return;
            }
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            SpeedMode.mc.field_71439_g.field_70181_x = 0.0;
            this.yMotion = 0.1 + Math.random() * 0.03;
            MovementUtils.strafe(0.48f + (float)this.jumpCount * 0.001f);
            int n = this.jumpCount;
            this.jumpCount = n + 1;
            this.jumped = true;
        } else if (MovementUtils.isMoving()) {
            MovementUtils.strafe(0.27f + (float)this.jumpCount * 0.0018f);
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onEnable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }

    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            ((C03PacketPlayer)packet).field_149477_b += this.yMotion;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        Intrinsics.checkNotNull((Object)speed2);
        if (this.jumpCount >= ((Number)speed2.boostDelayValue.get()).intValue()) {
            Speed speed3 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
            Intrinsics.checkNotNull((Object)speed3);
            if (((Boolean)speed3.boostSpeedValue.get()).booleanValue()) {
                event.setX(event.getX() * 1.718114514191981);
                event.setZ(event.getZ() * 1.718114514191981);
                this.jumpCount = 0;
                return;
            }
        }
        Speed speed4 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        Intrinsics.checkNotNull((Object)speed4);
        if ((Boolean)speed4.boostSpeedValue.get() != false) return;
        this.jumpCount = 4;
    }
}

