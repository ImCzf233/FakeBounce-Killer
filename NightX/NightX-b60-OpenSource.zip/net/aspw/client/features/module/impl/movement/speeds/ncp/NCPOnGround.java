/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;

public class NCPOnGround
extends SpeedMode {
    public NCPOnGround() {
        super("NCPOnGround");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving()) {
            return;
        }
        if ((double)NCPOnGround.mc.field_71439_g.field_70143_R > 3.994) {
            return;
        }
        if (NCPOnGround.mc.field_71439_g.func_70090_H() || NCPOnGround.mc.field_71439_g.func_70617_f_() || NCPOnGround.mc.field_71439_g.field_70123_F) {
            return;
        }
        NCPOnGround.mc.field_71439_g.field_70163_u -= (double)0.3993f;
        NCPOnGround.mc.field_71439_g.field_70181_x = -1000.0;
        NCPOnGround.mc.field_71439_g.field_70140_Q = 44.0f;
        NCPOnGround.mc.field_71428_T.field_74278_d = 1.0f;
        if (NCPOnGround.mc.field_71439_g.field_70122_E) {
            NCPOnGround.mc.field_71439_g.field_70163_u += (double)0.3993f;
            NCPOnGround.mc.field_71439_g.field_70181_x = 0.3993f;
            NCPOnGround.mc.field_71439_g.field_82151_R = 44.0f;
            NCPOnGround.mc.field_71439_g.field_70159_w *= (double)1.59f;
            NCPOnGround.mc.field_71439_g.field_70179_y *= (double)1.59f;
            NCPOnGround.mc.field_71428_T.field_74278_d = 1.199f;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onDisable() {
        Scaffold scaffold = Client.moduleManager.getModule(Scaffold.class);
        if (!NCPOnGround.mc.field_71439_g.func_70093_af() && !scaffold.getState()) {
            NCPOnGround.mc.field_71439_g.field_70159_w = 0.0;
            NCPOnGround.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

