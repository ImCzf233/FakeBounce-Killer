/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

@ModuleInfo(name="FakePlayer", spacedName="Fake Player", description="", category=ModuleCategory.OTHER)
public final class FakePlayer
extends Module {
    private EntityOtherPlayerMP fakePlayer;

    @Override
    public void onEnable() {
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer = new EntityOtherPlayerMP((World)MinecraftInstance.mc.field_71441_e, MinecraftInstance.mc.field_71439_g.func_146103_bH());
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        entityOtherPlayerMP.func_71049_a((EntityPlayer)MinecraftInstance.mc.field_71439_g, true);
        Intrinsics.checkNotNull((Object)this.fakePlayer);
        this.fakePlayer.field_70759_as = MinecraftInstance.mc.field_71439_g.field_70759_as;
        EntityOtherPlayerMP entityOtherPlayerMP2 = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP2);
        entityOtherPlayerMP2.func_82149_j((Entity)MinecraftInstance.mc.field_71439_g);
        MinecraftInstance.mc.field_71441_e.func_73027_a(-1000, (Entity)this.fakePlayer);
    }

    @Override
    public void onDisable() {
        WorldClient worldClient = MinecraftInstance.mc.field_71441_e;
        EntityOtherPlayerMP entityOtherPlayerMP = this.fakePlayer;
        Intrinsics.checkNotNull((Object)entityOtherPlayerMP);
        worldClient.func_73028_b(entityOtherPlayerMP.func_145782_y());
        this.fakePlayer = null;
    }
}

