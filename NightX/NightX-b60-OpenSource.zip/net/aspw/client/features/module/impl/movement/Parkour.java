/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.minecraft.entity.Entity;

@ModuleInfo(name="Parkour", description="", category=ModuleCategory.MOVEMENT)
public final class Parkour
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MovementUtils.isMoving() && MinecraftInstance.mc.field_71439_g.field_70122_E && !MinecraftInstance.mc.field_71439_g.func_70093_af() && !MinecraftInstance.mc.field_71474_y.field_74311_E.func_151470_d() && !MinecraftInstance.mc.field_71474_y.field_74314_A.func_151470_d() && MinecraftInstance.mc.field_71441_e.func_72945_a((Entity)MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, -0.5, 0.0).func_72314_b(-0.001, 0.0, -0.001)).isEmpty()) {
            MinecraftInstance.mc.field_71439_g.func_70664_aZ();
        }
    }
}

