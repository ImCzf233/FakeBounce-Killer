/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class HiveHop
extends SpeedMode {
    public HiveHop() {
        super("HiveHop");
    }

    @Override
    public void onEnable() {
        HiveHop.mc.field_71439_g.field_71102_ce = 0.0425f;
        HiveHop.mc.field_71428_T.field_74278_d = 1.04f;
    }

    @Override
    public void onDisable() {
        HiveHop.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        if (MovementUtils.isMoving()) {
            if (HiveHop.mc.field_71439_g.field_70122_E) {
                HiveHop.mc.field_71439_g.field_70181_x = 0.3;
            }
            HiveHop.mc.field_71439_g.field_71102_ce = 0.0425f;
            HiveHop.mc.field_71428_T.field_74278_d = 1.04f;
            MovementUtils.strafe();
        } else {
            HiveHop.mc.field_71439_g.field_70179_y = 0.0;
            HiveHop.mc.field_71439_g.field_70159_w = 0.0;
            HiveHop.mc.field_71439_g.field_71102_ce = 0.02f;
            HiveHop.mc.field_71428_T.field_74278_d = 1.0f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

