/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemBow
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.IntegerValue;
import net.minecraft.item.ItemBow;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="FastBow", spacedName="Fast Bow", description="", category=ModuleCategory.COMBAT)
public final class FastBow
extends Module {
    private final IntegerValue packetsValue = new IntegerValue("Packets", 20, 3, 20);
    private final IntegerValue delay = new IntegerValue("Delay", 0, 0, 500, "ms");
    private final MSTimer timer = new MSTimer();

    public final MSTimer getTimer() {
        return this.timer;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.field_71439_g.func_71039_bw()) {
            return;
        }
        if (MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g() != null && MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow) {
            float f;
            float yaw;
            float f2;
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(BlockPos.field_177992_a, 255, MinecraftInstance.mc.field_71439_g.func_71045_bC(), 0.0f, 0.0f, 0.0f));
            if (RotationUtils.targetRotation != null) {
                Rotation rotation = RotationUtils.targetRotation;
                Intrinsics.checkNotNull((Object)rotation);
                f2 = rotation.getYaw();
            } else {
                f2 = yaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
            }
            if (RotationUtils.targetRotation != null) {
                Rotation rotation = RotationUtils.targetRotation;
                Intrinsics.checkNotNull((Object)rotation);
                f = rotation.getPitch();
            } else {
                f = MinecraftInstance.mc.field_71439_g.field_70125_A;
            }
            float pitch = f;
            int n = 0;
            int n2 = ((Number)this.packetsValue.get()).intValue();
            while (n < n2) {
                int i = n++;
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C05PacketPlayerLook(yaw, pitch, true));
            }
            if (this.timer.hasTimePassed(((Number)this.delay.get()).intValue())) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN));
                this.timer.reset();
            }
            MinecraftInstance.mc.field_71439_g.field_71072_f = MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g().func_77988_m() - 1;
        }
    }
}

