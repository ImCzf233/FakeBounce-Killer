/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.other;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.Rotation;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.ListValue;

@ModuleInfo(name="Annoy", description="", category=ModuleCategory.OTHER)
public final class Annoy
extends Module {
    private final ListValue yawModeValue;
    private final ListValue pitchModeValue;
    private final BoolValue rotateValue;
    private float yaw;
    private float pitch;

    public Annoy() {
        String[] stringArray = new String[]{"None", "Jitter", "Spin", "Back"};
        this.yawModeValue = new ListValue("YawMove", stringArray, "Spin");
        stringArray = new String[]{"None", "Down", "Up", "Jitter"};
        this.pitchModeValue = new ListValue("PitchMode", stringArray, "Down");
        this.rotateValue = new BoolValue("SilentRotate", true);
    }

    public final BoolValue getRotateValue() {
        return this.rotateValue;
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = ((String)this.yawModeValue.get()).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
        switch (string) {
            case "none": {
                this.yaw = MinecraftInstance.mc.field_71439_g.field_70177_z;
                break;
            }
            case "spin": {
                this.yaw += 20.0f;
                if (this.yaw > 175.0f) {
                    this.yaw = -180.0f;
                    break;
                }
                if (!(this.yaw < -175.0f)) break;
                this.yaw = 180.0f;
                break;
            }
            case "jitter": {
                this.yaw = MinecraftInstance.mc.field_71439_g.field_70177_z + (MinecraftInstance.mc.field_71439_g.field_70173_aa % 2 == 0 ? 90.0f : -90.0f);
                break;
            }
            case "back": {
                this.yaw = MinecraftInstance.mc.field_71439_g.field_70177_z + 180.0f;
            }
        }
        string = ((String)this.pitchModeValue.get()).toLowerCase(Locale.ROOT);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
        switch (string) {
            case "none": {
                this.pitch = MinecraftInstance.mc.field_71439_g.field_70125_A;
                break;
            }
            case "up": {
                this.pitch = -90.0f;
                break;
            }
            case "down": {
                this.pitch = 90.0f;
                break;
            }
            case "jitter": {
                this.pitch += 30.0f;
                if (this.pitch > 90.0f) {
                    this.pitch = -90.0f;
                    break;
                }
                if (!(this.pitch < -90.0f)) break;
                this.pitch = 90.0f;
            }
        }
        if (((Boolean)this.rotateValue.get()).booleanValue()) {
            RotationUtils.setTargetRotation(new Rotation(this.yaw, this.pitch));
        } else {
            MinecraftInstance.mc.field_71439_g.field_70177_z = this.yaw;
            MinecraftInstance.mc.field_71439_g.field_70125_A = this.pitch;
        }
    }
}

