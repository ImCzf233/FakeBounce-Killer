/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.player;

import java.awt.Color;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.font.Fonts;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.Items;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="BowLongJump", spacedName="Bow Long Jump", description="", category=ModuleCategory.PLAYER)
public final class BowLongJump
extends Module {
    private final FloatValue boostValue = new FloatValue("Boost", 0.96f, 0.0f, 10.0f, "x");
    private final FloatValue heightValue = new FloatValue("Height", 0.58f, 0.0f, 10.0f, "m");
    private final FloatValue timerValue = new FloatValue("Timer", 1.0f, 0.1f, 10.0f, "x");
    private final IntegerValue delayBeforeLaunch = new IntegerValue("DelayBeforeArrowLaunch", 1, 1, 20, " tick");
    private final BoolValue autoDisable = new BoolValue("AutoDisable", true);
    private final BoolValue fakeYValue = new BoolValue("FakeY", false);
    private final BoolValue viewBobbingValue = new BoolValue("ViewBobbing", false);
    private final FloatValue bobbingAmountValue = new FloatValue("BobbingAmount", 0.1f, 0.0f, 0.1f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ BowLongJump this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)BowLongJump.access$getViewBobbingValue$p(this.this$0).get();
        }
    }));
    private final BoolValue renderValue = new BoolValue("RenderStatus", false);
    private int bowState;
    private double y;
    private long lastPlayerTick;
    private int lastSlot = -1;

    public final BoolValue getFakeYValue() {
        return this.fakeYValue;
    }

    public final double getY() {
        return this.y;
    }

    public final void setY(double d) {
        this.y = d;
    }

    @Override
    public void onEnable() {
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        this.y = MinecraftInstance.mc.field_71439_g.field_70163_u;
        this.bowState = 0;
        this.lastPlayerTick = -1L;
        this.lastSlot = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c;
        MovementUtils.strafe(0.0f);
    }

    @EventTarget
    public final void onMotion(@Nullable MotionEvent event) {
        if (MovementUtils.isMoving() && ((Boolean)this.viewBobbingValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_71109_bG = ((Number)this.bobbingAmountValue.get()).floatValue();
        }
        if (((Boolean)this.fakeYValue.get()).booleanValue()) {
            MinecraftInstance.mc.field_71439_g.field_70726_aT = 0.0f;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g.field_70122_E && this.bowState < 3) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof C09PacketHeldItemChange) {
            this.lastSlot = ((C09PacketHeldItemChange)event.getPacket()).func_149614_c();
            event.cancelEvent();
        }
        if (event.getPacket() instanceof C03PacketPlayer && this.bowState < 3) {
            ((C03PacketPlayer)event.getPacket()).func_149469_a(false);
        }
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
        boolean forceDisable = false;
        switch (this.bowState) {
            case 0: {
                int slot = this.getBowSlot();
                if (slot < 0 || !MinecraftInstance.mc.field_71439_g.field_71071_by.func_146028_b(Items.field_151032_g)) {
                    Client.INSTANCE.getHud().addNotification(new Notification("No arrows or bow found in your inventory!", Notification.Type.ERROR));
                    forceDisable = true;
                    this.bowState = 5;
                    break;
                }
                if (this.lastPlayerTick != -1L) break;
                ItemStack stack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(slot + 36).func_75211_c();
                if (this.lastSlot != slot) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(slot)));
                }
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(slot + 36).func_75211_c(), 0.0f, 0.0f, 0.0f)));
                this.lastPlayerTick = MinecraftInstance.mc.field_71439_g.field_70173_aa;
                this.bowState = 1;
                break;
            }
            case 1: {
                int reSlot = this.getBowSlot();
                if ((long)MinecraftInstance.mc.field_71439_g.field_70173_aa - this.lastPlayerTick <= (long)((Number)this.delayBeforeLaunch.get()).intValue()) break;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C05PacketPlayerLook(MinecraftInstance.mc.field_71439_g.field_70177_z, -90.0f, MinecraftInstance.mc.field_71439_g.field_70122_E)));
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN)));
                if (this.lastSlot != reSlot) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(this.lastSlot)));
                }
                this.bowState = 2;
                break;
            }
            case 2: {
                if (MinecraftInstance.mc.field_71439_g.field_70737_aN <= 0) break;
                this.bowState = 3;
                break;
            }
            case 3: {
                MovementUtils.strafe(((Number)this.boostValue.get()).floatValue());
                MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.heightValue.get()).floatValue();
                this.bowState = 4;
                this.lastPlayerTick = MinecraftInstance.mc.field_71439_g.field_70173_aa;
                break;
            }
            case 4: {
                MinecraftInstance.mc.field_71428_T.field_74278_d = ((Number)this.timerValue.get()).floatValue();
                if (!MinecraftInstance.mc.field_71439_g.field_70122_E || (long)MinecraftInstance.mc.field_71439_g.field_70173_aa - this.lastPlayerTick < 1L) break;
                this.bowState = 5;
            }
        }
        if (this.bowState < 3) {
            MinecraftInstance.mc.field_71439_g.field_71158_b.field_78900_b = 0.0f;
            MinecraftInstance.mc.field_71439_g.field_71158_b.field_78902_a = 0.0f;
        }
        if (this.bowState == 5 && (((Boolean)this.autoDisable.get()).booleanValue() || forceDisable)) {
            this.setState(false);
        }
    }

    @EventTarget
    public final void onWorld(@Nullable WorldEvent event) {
        this.setState(false);
    }

    @Override
    public void onDisable() {
        MinecraftInstance.mc.field_71439_g.eyeHeight = MinecraftInstance.mc.field_71439_g.getDefaultEyeHeight();
        MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
        if (!MinecraftInstance.mc.field_71439_g.func_70093_af()) {
            MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
            MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    private final int getBowSlot() {
        int n = 36;
        while (n < 45) {
            int i;
            ItemStack stack;
            if ((stack = MinecraftInstance.mc.field_71439_g.field_71069_bz.func_75139_a(i = n++).func_75211_c()) == null || !(stack.func_77973_b() instanceof ItemBow)) continue;
            return i - 36;
        }
        return -1;
    }

    @EventTarget
    public final void onRender2D(@Nullable Render2DEvent event) {
        if (!((Boolean)this.renderValue.get()).booleanValue()) {
            return;
        }
        ScaledResolution scaledRes = new ScaledResolution(MinecraftInstance.mc);
        float width = (float)this.bowState / 5.0f * 60.0f;
        Fonts.fontSFUI40.drawCenteredString(this.getBowStatus(), (float)scaledRes.func_78326_a() / 2.0f, (float)scaledRes.func_78328_b() / 2.0f + 14.0f, -1, true);
        RenderUtils.drawRect((float)scaledRes.func_78326_a() / 2.0f - 31.0f, (float)scaledRes.func_78328_b() / 2.0f + 25.0f, (float)scaledRes.func_78326_a() / 2.0f + 31.0f, (float)scaledRes.func_78328_b() / 2.0f + 29.0f, -1610612736);
        RenderUtils.drawRect((float)scaledRes.func_78326_a() / 2.0f - 30.0f, (float)scaledRes.func_78328_b() / 2.0f + 26.0f, (float)scaledRes.func_78326_a() / 2.0f - 30.0f + width, (float)scaledRes.func_78328_b() / 2.0f + 28.0f, this.getStatusColor());
    }

    public final String getBowStatus() {
        String string;
        switch (this.bowState) {
            case 0: {
                string = "Idle...";
                break;
            }
            case 1: {
                string = "Preparing...";
                break;
            }
            case 2: {
                string = "Waiting...";
                break;
            }
            case 3: 
            case 4: {
                string = "Successfully!";
                break;
            }
            default: {
                string = "Task completed.";
            }
        }
        return string;
    }

    public final Color getStatusColor() {
        Color color;
        switch (this.bowState) {
            case 0: {
                color = new Color(21, 21, 21);
                break;
            }
            case 1: {
                color = new Color(48, 48, 48);
                break;
            }
            case 2: {
                Color color2 = Color.yellow;
                Intrinsics.checkNotNullExpressionValue((Object)color2, (String)"yellow");
                color = color2;
                break;
            }
            case 3: 
            case 4: {
                Color color3 = Color.green;
                Intrinsics.checkNotNullExpressionValue((Object)color3, (String)"green");
                color = color3;
                break;
            }
            default: {
                color = new Color(0, 111, 255);
            }
        }
        return color;
    }

    public static final /* synthetic */ BoolValue access$getViewBobbingValue$p(BowLongJump $this) {
        return $this.viewBobbingValue;
    }
}

