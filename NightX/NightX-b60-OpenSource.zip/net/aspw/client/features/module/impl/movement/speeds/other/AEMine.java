/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AEMine
extends SpeedMode {
    public AEMine() {
        super("AEMine");
    }

    @Override
    public void onDisable() {
        AEMine.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onMotion() {
        if (AEMine.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            AEMine.mc.field_71439_g.func_70664_aZ();
            AEMine.mc.field_71428_T.field_74278_d = 1.0f;
        } else {
            AEMine.mc.field_71428_T.field_74278_d = 1.3091955f;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

