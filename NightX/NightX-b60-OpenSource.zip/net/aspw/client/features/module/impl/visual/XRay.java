/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 */
package net.aspw.client.features.module.impl.visual;

import java.util.List;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

@ModuleInfo(name="XRay", description="", category=ModuleCategory.VISUAL, keyBind=65)
public final class XRay
extends Module {
    private final List<Block> xrayBlocks;

    public XRay() {
        Object[] objectArray = new Block[34];
        Block block = Blocks.field_150365_q;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"coal_ore");
        objectArray[0] = block;
        block = Blocks.field_150366_p;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"iron_ore");
        objectArray[1] = block;
        block = Blocks.field_150352_o;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"gold_ore");
        objectArray[2] = block;
        block = Blocks.field_150450_ax;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"redstone_ore");
        objectArray[3] = block;
        block = Blocks.field_150369_x;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lapis_ore");
        objectArray[4] = block;
        block = Blocks.field_150482_ag;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"diamond_ore");
        objectArray[5] = block;
        block = Blocks.field_150412_bA;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"emerald_ore");
        objectArray[6] = block;
        block = Blocks.field_150449_bY;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"quartz_ore");
        objectArray[7] = block;
        block = Blocks.field_150435_aG;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"clay");
        objectArray[8] = block;
        block = Blocks.field_150426_aN;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"glowstone");
        objectArray[9] = block;
        block = Blocks.field_150462_ai;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"crafting_table");
        objectArray[10] = block;
        block = Blocks.field_150478_aa;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"torch");
        objectArray[11] = block;
        block = Blocks.field_150468_ap;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"ladder");
        objectArray[12] = block;
        block = Blocks.field_150335_W;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"tnt");
        objectArray[13] = block;
        block = Blocks.field_150402_ci;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"coal_block");
        objectArray[14] = block;
        block = Blocks.field_150339_S;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"iron_block");
        objectArray[15] = block;
        block = Blocks.field_150340_R;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"gold_block");
        objectArray[16] = block;
        block = Blocks.field_150484_ah;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"diamond_block");
        objectArray[17] = block;
        block = Blocks.field_150475_bE;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"emerald_block");
        objectArray[18] = block;
        block = Blocks.field_150451_bX;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"redstone_block");
        objectArray[19] = block;
        block = Blocks.field_150368_y;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lapis_block");
        objectArray[20] = block;
        block = Blocks.field_150480_ab;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"fire");
        objectArray[21] = block;
        block = Blocks.field_150341_Y;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"mossy_cobblestone");
        objectArray[22] = block;
        block = Blocks.field_150474_ac;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"mob_spawner");
        objectArray[23] = block;
        block = Blocks.field_150378_br;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"end_portal_frame");
        objectArray[24] = block;
        block = Blocks.field_150381_bn;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"enchanting_table");
        objectArray[25] = block;
        block = Blocks.field_150342_X;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"bookshelf");
        objectArray[26] = block;
        block = Blocks.field_150483_bI;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"command_block");
        objectArray[27] = block;
        block = Blocks.field_150353_l;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lava");
        objectArray[28] = block;
        block = Blocks.field_150356_k;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"flowing_lava");
        objectArray[29] = block;
        block = Blocks.field_150355_j;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"water");
        objectArray[30] = block;
        block = Blocks.field_150358_i;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"flowing_water");
        objectArray[31] = block;
        block = Blocks.field_150460_al;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"furnace");
        objectArray[32] = block;
        block = Blocks.field_150470_am;
        Intrinsics.checkNotNullExpressionValue((Object)block, (String)"lit_furnace");
        objectArray[33] = block;
        this.xrayBlocks = CollectionsKt.mutableListOf((Object[])objectArray);
    }

    public final List<Block> getXrayBlocks() {
        return this.xrayBlocks;
    }

    @Override
    public void onToggle(boolean state) {
        MinecraftInstance.mc.field_71438_f.func_72712_a();
    }
}

