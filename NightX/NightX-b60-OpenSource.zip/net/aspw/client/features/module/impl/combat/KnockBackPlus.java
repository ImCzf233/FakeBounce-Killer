/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;

@ModuleInfo(name="KnockBack+", spacedName="Knock Back+", description="", category=ModuleCategory.COMBAT)
public final class KnockBackPlus
extends Module {
    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g.func_70051_ag()) {
            MinecraftInstance.mc.field_71439_g.func_70031_b(false);
        }
        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0BPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, C0BPacketEntityAction.Action.START_SPRINTING));
        MinecraftInstance.mc.field_71439_g.field_175171_bO = true;
    }
}

