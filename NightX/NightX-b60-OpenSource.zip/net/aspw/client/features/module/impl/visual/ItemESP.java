/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.projectile.EntityArrow
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.util.render.shader.shaders.OutlineShader;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.projectile.EntityArrow;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="ItemESP", spacedName="Item ESP", description="", category=ModuleCategory.VISUAL)
public final class ItemESP
extends Module {
    private final ListValue modeValue;
    private final IntegerValue colorRedValue;
    private final IntegerValue colorGreenValue;
    private final IntegerValue colorBlueValue;
    private final BoolValue colorRainbow;

    public ItemESP() {
        String[] stringArray = new String[]{"Box", "ShaderOutline"};
        this.modeValue = new ListValue("Mode", stringArray, "Box");
        this.colorRedValue = new IntegerValue("R", 255, 0, 255);
        this.colorGreenValue = new IntegerValue("G", 255, 0, 255);
        this.colorBlueValue = new IntegerValue("B", 255, 0, 255);
        this.colorRainbow = new BoolValue("Rainbow", false);
    }

    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"Box", (boolean)true)) {
            Color color = (Boolean)this.colorRainbow.get() != false ? ColorUtils.rainbow() : new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue());
            for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityItem) && !(entity instanceof EntityArrow)) continue;
                RenderUtils.drawEntityBox(entity, color, true);
            }
        }
    }

    @EventTarget
    public final void onRender2D(Render2DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"ShaderOutline", (boolean)true)) {
            OutlineShader.OUTLINE_SHADER.startDraw(event.getPartialTicks());
            try {
                for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
                    if (!(entity instanceof EntityItem) && !(entity instanceof EntityArrow)) continue;
                    MinecraftInstance.mc.func_175598_ae().func_147936_a(entity, event.getPartialTicks(), true);
                }
            }
            catch (Exception ex) {
                ClientUtils.getLogger().error("An error occurred while rendering all item entities for shader esp", (Throwable)ex);
            }
            OutlineShader.OUTLINE_SHADER.stopDraw((Boolean)this.colorRainbow.get() != false ? ColorUtils.rainbow() : new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue()), 1.0f, 1.0f);
        }
    }
}

