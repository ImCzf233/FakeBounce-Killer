/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.functions.Function0;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;

@ModuleInfo(name="PlayerEdit", spacedName="Player Edit", description="", category=ModuleCategory.OTHER)
public class PlayerEdit
extends Module {
    public static BoolValue editPlayerSizeValue = new BoolValue("PlayerSize", true);
    public static FloatValue playerSizeValue = new FloatValue("PlayerSize", 1.5f, 0.5f, 2.5f, "m", (Function0<Boolean>)((Function0)() -> (Boolean)editPlayerSizeValue.get()));
    public static BoolValue rotatePlayer = new BoolValue("PlayerRotate", true);
    public static FloatValue xRot = new FloatValue("X-Rotation", 0.0f, -180.0f, 180.0f, (Function0<Boolean>)((Function0)() -> (Boolean)rotatePlayer.get()));
    public static FloatValue yPos = new FloatValue("Y-Position", 0.0f, -5.0f, 5.0f, (Function0<Boolean>)((Function0)() -> (Boolean)rotatePlayer.get()));

    @EventTarget
    public void onMotion(MotionEvent event) {
        PlayerEdit.mc.field_71439_g.eyeHeight = (Boolean)editPlayerSizeValue.get() != false ? ((Float)playerSizeValue.get()).floatValue() + 0.62f : PlayerEdit.mc.field_71439_g.getDefaultEyeHeight();
    }

    @Override
    public void onDisable() {
        PlayerEdit.mc.field_71439_g.eyeHeight = PlayerEdit.mc.field_71439_g.getDefaultEyeHeight();
    }
}

