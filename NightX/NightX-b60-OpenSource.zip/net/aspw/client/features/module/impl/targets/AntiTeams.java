/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemArmor
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.module.impl.targets;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

@ModuleInfo(name="AntiTeams", spacedName="Anti Teams", description="", category=ModuleCategory.TARGETS, array=false)
public final class AntiTeams
extends Module {
    private final BoolValue scoreboardValue = new BoolValue("ScoreboardTeam", true);
    private final BoolValue colorValue = new BoolValue("Color", false);
    private final BoolValue gommeSWValue = new BoolValue("GommeSW", false);
    private final BoolValue armorColorValue = new BoolValue("ArmorColor", false);
    private final IntegerValue armorIndexValue = new IntegerValue("ArmorIndex", 3, 0, 3, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
        final /* synthetic */ AntiTeams this$0;
        {
            this.this$0 = $receiver;
            super(0);
        }

        public final Boolean invoke() {
            return (Boolean)AntiTeams.access$getArmorColorValue$p(this.this$0).get();
        }
    }));

    public final boolean isInYourTeam(EntityLivingBase entity) {
        String clientName;
        String string;
        String targetName;
        String myHead;
        Intrinsics.checkNotNullParameter((Object)entity, (String)"entity");
        if (MinecraftInstance.mc.field_71439_g == null) {
            return false;
        }
        if (((Boolean)this.scoreboardValue.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.func_96124_cp() != null && entity.func_96124_cp() != null && MinecraftInstance.mc.field_71439_g.func_96124_cp().func_142054_a(entity.func_96124_cp())) {
            return true;
        }
        if (((Boolean)this.armorColorValue.get()).booleanValue()) {
            EntityPlayer entityPlayer = (EntityPlayer)entity;
            if (MinecraftInstance.mc.field_71439_g.field_71071_by.field_70460_b[((Number)this.armorIndexValue.get()).intValue()] != null && entityPlayer.field_71071_by.field_70460_b[((Number)this.armorIndexValue.get()).intValue()] != null) {
                String string2 = myHead = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70460_b[((Number)this.armorIndexValue.get()).intValue()];
                Intrinsics.checkNotNull((Object)string2);
                Item item = string2.func_77973_b();
                Intrinsics.checkNotNull((Object)item);
                ItemArmor myItemArmor = (ItemArmor)item;
                ItemStack entityHead = entityPlayer.field_71071_by.field_70460_b[((Number)this.armorIndexValue.get()).intValue()];
                Item item2 = myHead.func_77973_b();
                Intrinsics.checkNotNull((Object)item2);
                ItemArmor entityItemArmor = (ItemArmor)item2;
                int n = myItemArmor.func_82814_b((ItemStack)myHead);
                ItemStack itemStack = entityHead;
                Intrinsics.checkNotNull((Object)itemStack);
                if (n == entityItemArmor.func_82814_b(itemStack)) {
                    return true;
                }
            }
        }
        if (((Boolean)this.gommeSWValue.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.func_145748_c_() != null && entity.func_145748_c_() != null) {
            myHead = entity.func_145748_c_().func_150254_d();
            Intrinsics.checkNotNullExpressionValue((Object)myHead, (String)"entity.displayName.formattedText");
            targetName = StringsKt.replace$default((String)myHead, (String)"\u00a7r", (String)"", (boolean)false, (int)4, null);
            string = MinecraftInstance.mc.field_71439_g.func_145748_c_().func_150254_d();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"mc.thePlayer.displayName.formattedText");
            clientName = StringsKt.replace$default((String)string, (String)"\u00a7r", (String)"", (boolean)false, (int)4, null);
            if (StringsKt.startsWith$default((String)targetName, (String)"T", (boolean)false, (int)2, null) && StringsKt.startsWith$default((String)clientName, (String)"T", (boolean)false, (int)2, null) && Character.isDigit(targetName.charAt(1)) && Character.isDigit(clientName.charAt(1))) {
                return targetName.charAt(1) == clientName.charAt(1);
            }
        }
        if (((Boolean)this.colorValue.get()).booleanValue() && MinecraftInstance.mc.field_71439_g.func_145748_c_() != null && entity.func_145748_c_() != null) {
            clientName = entity.func_145748_c_().func_150254_d();
            Intrinsics.checkNotNullExpressionValue((Object)clientName, (String)"entity.displayName.formattedText");
            targetName = StringsKt.replace$default((String)clientName, (String)"\u00a7r", (String)"", (boolean)false, (int)4, null);
            string = MinecraftInstance.mc.field_71439_g.func_145748_c_().func_150254_d();
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"mc.thePlayer.displayName.formattedText");
            clientName = StringsKt.replace$default((String)string, (String)"\u00a7r", (String)"", (boolean)false, (int)4, null);
            return StringsKt.startsWith$default((String)targetName, (String)Intrinsics.stringPlus((String)"\u00a7", (Object)Character.valueOf(clientName.charAt(1))), (boolean)false, (int)2, null);
        }
        return false;
    }

    public static final /* synthetic */ BoolValue access$getArmorColorValue$p(AntiTeams $this) {
        return $this.armorColorValue;
    }
}

