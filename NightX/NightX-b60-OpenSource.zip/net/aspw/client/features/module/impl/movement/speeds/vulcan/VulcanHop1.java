/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.vulcan;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class VulcanHop1
extends SpeedMode {
    private boolean wasTimer;

    public VulcanHop1() {
        super("VulcanHop1");
    }

    @Override
    public void onUpdate() {
        if (this.wasTimer) {
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
            this.wasTimer = false;
        }
        SpeedMode.mc.field_71439_g.field_70747_aH = Math.abs(SpeedMode.mc.field_71439_g.field_71158_b.field_78902_a) < 0.1f ? 0.026499f : 0.0244f;
        SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
        if (MovementUtils.getSpeed() < 0.215f && !SpeedMode.mc.field_71439_g.field_70122_E) {
            MovementUtils.strafe(0.215f);
        }
        if (SpeedMode.mc.field_71439_g.field_70122_E && MovementUtils.isMoving()) {
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            if (!SpeedMode.mc.field_71439_g.field_70160_al) {
                return;
            }
            SpeedMode.mc.field_71428_T.field_74278_d = 1.25f;
            this.wasTimer = true;
            MovementUtils.strafe();
            if (MovementUtils.getSpeed() < 0.5f) {
                MovementUtils.strafe(0.4849f);
            }
        } else if (!MovementUtils.isMoving()) {
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        }
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
        Scaffold scaffoldModule = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        if (!SpeedMode.mc.field_71439_g.func_70093_af()) {
            Scaffold scaffold = scaffoldModule;
            Intrinsics.checkNotNull((Object)scaffold);
            if (!scaffold.getState()) {
                MovementUtils.strafe(0.2f);
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

