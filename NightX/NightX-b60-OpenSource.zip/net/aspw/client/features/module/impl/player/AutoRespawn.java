/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiGameOver
 *  net.minecraft.client.gui.GuiScreen
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiScreen;

@ModuleInfo(name="AutoRespawn", spacedName="Auto Respawn", description="", category=ModuleCategory.PLAYER)
public final class AutoRespawn
extends Module {
    private final BoolValue instantValue = new BoolValue("Instant", true);

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        boolean bl;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.instantValue.get()).booleanValue()) {
            if (!(MinecraftInstance.mc.field_71439_g.func_110143_aJ() == 0.0f)) {
                if (!MinecraftInstance.mc.field_71439_g.field_70128_L) return;
            }
            bl = true;
        } else {
            if (!(MinecraftInstance.mc.field_71462_r instanceof GuiGameOver)) return;
            GuiScreen guiScreen = MinecraftInstance.mc.field_71462_r;
            if (guiScreen == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.client.gui.GuiGameOver");
            }
            if (((GuiGameOver)guiScreen).field_146347_a < 20) return;
            bl = true;
        }
        if (!bl) return;
        MinecraftInstance.mc.field_71439_g.func_71004_bE();
        MinecraftInstance.mc.func_147108_a(null);
    }
}

