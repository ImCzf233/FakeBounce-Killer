/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.watchdog;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.features.module.impl.player.Scaffold;
import net.aspw.client.features.module.impl.player.Timer;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class WatchdogCustom
extends SpeedMode {
    public WatchdogCustom() {
        super("WatchdogCustom");
    }

    @Override
    public void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (SpeedMode.mc.field_71439_g != null && MovementUtils.isMoving()) {
            event.cancelEvent();
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        Intrinsics.checkNotNull((Object)speed2);
        Speed speedModule = speed2;
        Scaffold scaffoldModule = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        Timer timer = Client.INSTANCE.getModuleManager().getModule(Timer.class);
        if (MovementUtils.isMoving()) {
            if (thePlayer.field_70122_E && thePlayer.field_70124_G) {
                Scaffold scaffold = scaffoldModule;
                Intrinsics.checkNotNull((Object)scaffold);
                thePlayer.field_70181_x = MovementUtils.getJumpBoostModifier(scaffold.getState() ? 0.41999 : (double)((Number)speedModule.getMotionYValue().get()).floatValue(), true);
                if (scaffoldModule.getState()) {
                    MovementUtils.strafe(0.37f);
                } else {
                    MovementUtils.strafe((float)Math.max(((Number)speedModule.getCustomSpeedValue().get()).doubleValue() + (double)MovementUtils.getSpeedEffect() * 0.1, MovementUtils.getBaseMoveSpeed(0.2873)));
                }
            } else {
                Timer timer2 = timer;
                Intrinsics.checkNotNull((Object)timer2);
                if (!timer2.getState() && ((Boolean)speedModule.getTimerValue().get()).booleanValue()) {
                    SpeedMode.mc.field_71428_T.field_74278_d = 1.07f;
                }
                MovementUtils.setMotion(MovementUtils.getSpeed(), (Boolean)speedModule.getSmoothStrafe().get());
            }
        }
    }

    @Override
    public void onDisable() {
        Scaffold scaffoldModule = Client.INSTANCE.getModuleManager().getModule(Scaffold.class);
        if (!SpeedMode.mc.field_71439_g.func_70093_af()) {
            Scaffold scaffold = scaffoldModule;
            Intrinsics.checkNotNull((Object)scaffold);
            if (!scaffold.getState()) {
                MovementUtils.strafe(0.2f);
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        Intrinsics.checkNotNull((Object)speed2);
        Speed speedModule = speed2;
        if (MovementUtils.isMoving()) {
            if (thePlayer.field_70123_F) {
                MovementUtils.setMotion(event, MovementUtils.getBaseMoveSpeed(0.258), 1.0, (Boolean)speedModule.getSmoothStrafe().get());
            }
        }
    }
}

