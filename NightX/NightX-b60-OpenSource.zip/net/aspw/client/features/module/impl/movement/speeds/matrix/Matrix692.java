/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 */
package net.aspw.client.features.module.impl.movement.speeds.matrix;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;

public final class Matrix692
extends SpeedMode {
    private boolean wasTimer;

    public Matrix692() {
        super("Matrix6.9.2");
    }

    @Override
    public void onDisable() {
        this.wasTimer = false;
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.func_70090_H()) {
            return;
        }
        if (this.wasTimer) {
            this.wasTimer = false;
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        }
        EntityPlayerSP entityPlayerSP2 = SpeedMode.mc.field_71439_g;
        entityPlayerSP2.field_70181_x -= 0.00348;
        SpeedMode.mc.field_71439_g.field_70747_aH = 0.026f;
        SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)SpeedMode.mc.field_71474_y.field_74314_A);
        if (MovementUtils.isMoving() && SpeedMode.mc.field_71439_g.field_70122_E) {
            SpeedMode.mc.field_71474_y.field_74314_A.field_74513_e = false;
            SpeedMode.mc.field_71428_T.field_74278_d = 1.35f;
            this.wasTimer = true;
            SpeedMode.mc.field_71439_g.func_70664_aZ();
            MovementUtils.strafe();
        } else if ((double)MovementUtils.getSpeed() < 0.215) {
            MovementUtils.strafe(0.215f);
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
    }
}

