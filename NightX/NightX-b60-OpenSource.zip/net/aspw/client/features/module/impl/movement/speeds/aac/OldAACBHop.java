/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class OldAACBHop
extends SpeedMode {
    public OldAACBHop() {
        super("OldAACBHop");
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving()) {
            if (OldAACBHop.mc.field_71439_g.field_70122_E) {
                MovementUtils.strafe(0.56f);
                OldAACBHop.mc.field_71439_g.field_70181_x = 0.42f;
            } else {
                MovementUtils.strafe(MovementUtils.getSpeed() * (OldAACBHop.mc.field_71439_g.field_70143_R > 0.4f ? 1.0f : 1.01f));
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

