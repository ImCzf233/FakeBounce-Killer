/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.matrix;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class MatrixYPort
extends SpeedMode {
    public MatrixYPort() {
        super("MatrixYPort");
    }

    @Override
    public void onDisable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        Intrinsics.checkNotNull((Object)entityPlayerSP);
        if (entityPlayerSP.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            EntityPlayerSP entityPlayerSP2 = SpeedMode.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)entityPlayerSP2);
            if (entityPlayerSP2.field_70122_E) {
                EntityPlayerSP entityPlayerSP3 = SpeedMode.mc.field_71439_g;
                Intrinsics.checkNotNull((Object)entityPlayerSP3);
                entityPlayerSP3.func_70664_aZ();
            }
            SpeedMode.mc.field_71428_T.field_74278_d = 10.0f;
        } else {
            SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
    }
}

