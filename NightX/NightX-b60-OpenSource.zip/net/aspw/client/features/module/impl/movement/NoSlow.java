/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBow
 *  net.minecraft.item.ItemBucketMilk
 *  net.minecraft.item.ItemFood
 *  net.minecraft.item.ItemPotion
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C03PacketPlayer$C05PacketPlayerLook
 *  net.minecraft.network.play.client.C03PacketPlayer$C06PacketPlayerPosLook
 *  net.minecraft.network.play.client.C07PacketPlayerDigging
 *  net.minecraft.network.play.client.C07PacketPlayerDigging$Action
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.server.S30PacketWindowItems
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.movement;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.SlowDownEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.combat.KillAura;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemBucketMilk;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="NoSlow", spacedName="No Slow", description="", category=ModuleCategory.MOVEMENT)
public final class NoSlow
extends Module {
    private final MSTimer msTimer = new MSTimer();
    private final ListValue modeValue;
    private final FloatValue blockForwardMultiplier;
    private final FloatValue blockStrafeMultiplier;
    private final FloatValue consumeForwardMultiplier;
    private final FloatValue consumeStrafeMultiplier;
    private final FloatValue bowForwardMultiplier;
    private final FloatValue bowStrafeMultiplier;
    private final FloatValue sneakForwardMultiplier;
    private final FloatValue sneakStrafeMultiplier;
    private final BoolValue customRelease;
    private final BoolValue customPlace;
    private final BoolValue customOnGround;
    private final IntegerValue customDelayValue;
    private final BoolValue testValue;
    private final BoolValue ciucValue;
    private final ListValue packetTriggerValue;
    private final BoolValue debugValue;
    private final BoolValue soulsandValue;
    private final BoolValue liquidPushValue;
    private final List<Packet<INetHandlerPlayServer>> blinkPackets;
    private double lastX;
    private double lastY;
    private double lastZ;
    private boolean lastOnGround;
    private boolean fasterDelay;
    private long placeDelay;
    private final MSTimer timer;

    public NoSlow() {
        String[] stringArray = new String[]{"Vanilla", "Watchdog", "OldHypixel", "Blink", "Experimental", "ValidSpoof", "NCP", "NewNCP", "AAC", "AAC5", "Custom"};
        this.modeValue = new ListValue("Mode", stringArray, "NCP");
        this.blockForwardMultiplier = new FloatValue("BlockForwardMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.blockStrafeMultiplier = new FloatValue("BlockStrafeMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.consumeForwardMultiplier = new FloatValue("ConsumeForwardMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.consumeStrafeMultiplier = new FloatValue("ConsumeStrafeMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.bowForwardMultiplier = new FloatValue("BowForwardMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.bowStrafeMultiplier = new FloatValue("BowStrafeMultiplier", 1.0f, 0.2f, 1.0f, "x");
        this.sneakForwardMultiplier = new FloatValue("SneakForwardMultiplier", 0.3f, 0.3f, 1.0f, "x");
        this.sneakStrafeMultiplier = new FloatValue("SneakStrafeMultiplier", 0.3f, 0.3f, 1.0f, "x");
        this.customRelease = new BoolValue("CustomReleasePacket", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"custom", (boolean)true);
            }
        }));
        this.customPlace = new BoolValue("CustomPlacePacket", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"custom", (boolean)true);
            }
        }));
        this.customOnGround = new BoolValue("CustomOnGround", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"custom", (boolean)true);
            }
        }));
        this.customDelayValue = new IntegerValue("CustomDelay", 60, 0, 1000, "ms", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"custom", (boolean)true);
            }
        }));
        this.testValue = new BoolValue("SendPacket", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"watchdog", (boolean)true);
            }
        }));
        this.ciucValue = new BoolValue("CheckInUseCount", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"blink", (boolean)true);
            }
        }));
        stringArray = new String[]{"PreRelease", "PostRelease"};
        this.packetTriggerValue = new ListValue("PacketTrigger", stringArray, "PostRelease", (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"blink", (boolean)true);
            }
        }));
        this.debugValue = new BoolValue("Debug", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ NoSlow this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"watchdog", (boolean)true) || StringsKt.equals((String)((String)NoSlow.access$getModeValue$p(this.this$0).get()), (String)"blink", (boolean)true);
            }
        }));
        this.soulsandValue = new BoolValue("Soulsand", true);
        this.liquidPushValue = new BoolValue("LiquidPush", true);
        this.blinkPackets = new ArrayList();
        this.timer = new MSTimer();
    }

    public final FloatValue getSneakForwardMultiplier() {
        return this.sneakForwardMultiplier;
    }

    public final FloatValue getSneakStrafeMultiplier() {
        return this.sneakStrafeMultiplier;
    }

    public final BoolValue getSoulsandValue() {
        return this.soulsandValue;
    }

    public final BoolValue getLiquidPushValue() {
        return this.liquidPushValue;
    }

    @Override
    public void onEnable() {
        this.blinkPackets.clear();
        this.msTimer.reset();
    }

    @Override
    public void onDisable() {
        Iterable $this$forEach$iv = this.blinkPackets;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Packet it = (Packet)element$iv;
            boolean bl = false;
            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)it);
        }
        this.blinkPackets.clear();
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    private final void sendPacket(MotionEvent event, boolean sendC07, boolean sendC08, boolean delay, long delayValue2, boolean onGround, boolean watchDog) {
        C07PacketPlayerDigging digging = new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), EnumFacing.DOWN);
        C08PacketPlayerBlockPlacement blockPlace = new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g());
        C08PacketPlayerBlockPlacement blockMent = new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g(), 0.0f, 0.0f, 0.0f);
        if (onGround && !MinecraftInstance.mc.field_71439_g.field_70122_E) {
            return;
        }
        if (sendC07 && event.getEventState() == EventState.PRE) {
            if (delay && this.msTimer.hasTimePassed(delayValue2)) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)digging);
            } else if (!delay) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)digging);
            }
        }
        if (sendC08 && event.getEventState() == EventState.POST) {
            if (delay && this.msTimer.hasTimePassed(delayValue2) && !watchDog) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)blockPlace);
                this.msTimer.reset();
            } else if (!delay && !watchDog) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)blockPlace);
            } else if (watchDog) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)blockMent);
            }
        }
    }

    static /* synthetic */ void sendPacket$default(NoSlow noSlow, MotionEvent motionEvent, boolean bl, boolean bl2, boolean bl3, long l, boolean bl4, boolean bl5, int n, Object object) {
        if ((n & 0x40) != 0) {
            bl5 = false;
        }
        noSlow.sendPacket(motionEvent, bl, bl2, bl3, l, bl4, bl5);
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        KillAura killAura = Client.INSTANCE.getModuleManager().get(KillAura.class);
        Intrinsics.checkNotNull((Object)killAura);
        KillAura killAura2 = killAura;
        if (StringsKt.equals((String)((String)this.modeValue.get()), (String)"watchdog", (boolean)true) && packet instanceof S30PacketWindowItems && MinecraftInstance.mc.field_71439_g.func_71039_bw()) {
            event.cancelEvent();
            if (((Boolean)this.debugValue.get()).booleanValue()) {
                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7rdetected reset item packet");
            }
        }
        if (!(!StringsKt.equals((String)((String)this.modeValue.get()), (String)"blink", (boolean)true) || killAura2.getState() && killAura2.getBlockingStatus() || MinecraftInstance.mc.field_71439_g.func_71011_bu() == null || MinecraftInstance.mc.field_71439_g.func_71011_bu().func_77973_b() == null)) {
            Item item = MinecraftInstance.mc.field_71439_g.func_71011_bu().func_77973_b();
            if (MinecraftInstance.mc.field_71439_g.func_71039_bw() && (item instanceof ItemFood || item instanceof ItemBucketMilk || item instanceof ItemPotion) && (!((Boolean)this.ciucValue.get()).booleanValue() || MinecraftInstance.mc.field_71439_g.field_71072_f >= 1)) {
                if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
                    if (MinecraftInstance.mc.field_71439_g.field_175168_bP >= 20 && StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"postrelease", (boolean)true)) {
                        ((C03PacketPlayer)packet).field_149479_a = this.lastX;
                        ((C03PacketPlayer)packet).field_149477_b = this.lastY;
                        ((C03PacketPlayer)packet).field_149478_c = this.lastZ;
                        ((C03PacketPlayer)packet).field_149474_g = this.lastOnGround;
                        if (((Boolean)this.debugValue.get()).booleanValue()) {
                            ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7rpos update reached 20");
                        }
                    } else {
                        event.cancelEvent();
                        if (StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"postrelease", (boolean)true)) {
                            PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer(this.lastOnGround)));
                        }
                        this.blinkPackets.add(packet);
                        if (((Boolean)this.debugValue.get()).booleanValue()) {
                            ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7rpacket player (movement) added at ", (Object)(this.blinkPackets.size() - 1)));
                        }
                    }
                } else if (packet instanceof C03PacketPlayer.C05PacketPlayerLook) {
                    event.cancelEvent();
                    if (StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"postrelease", (boolean)true)) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer(this.lastOnGround)));
                    }
                    this.blinkPackets.add(packet);
                    if (((Boolean)this.debugValue.get()).booleanValue()) {
                        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7rpacket player (rotation) added at ", (Object)(this.blinkPackets.size() - 1)));
                    }
                } else if (packet instanceof C03PacketPlayer && (StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"prerelease", (boolean)true) || ((C03PacketPlayer)packet).field_149474_g != this.lastOnGround)) {
                    event.cancelEvent();
                    this.blinkPackets.add(packet);
                    if (((Boolean)this.debugValue.get()).booleanValue()) {
                        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7rpacket player (idle) added at ", (Object)(this.blinkPackets.size() - 1)));
                    }
                }
                if (packet instanceof C0BPacketEntityAction) {
                    event.cancelEvent();
                    this.blinkPackets.add(packet);
                    if (((Boolean)this.debugValue.get()).booleanValue()) {
                        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7rpacket action added at ", (Object)(this.blinkPackets.size() - 1)));
                    }
                }
                if (packet instanceof C07PacketPlayerDigging && StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"prerelease", (boolean)true) && this.blinkPackets.size() > 0) {
                    Iterable $this$forEach$iv = this.blinkPackets;
                    boolean $i$f$forEach = false;
                    for (Object element$iv : $this$forEach$iv) {
                        Packet it = (Packet)element$iv;
                        boolean bl = false;
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)it);
                    }
                    if (((Boolean)this.debugValue.get()).booleanValue()) {
                        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7rsent " + this.blinkPackets.size() + " packets.");
                    }
                    this.blinkPackets.clear();
                }
            }
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MovementUtils.isMoving() && !StringsKt.equals((String)((String)this.modeValue.get()), (String)"blink", (boolean)true)) {
            return;
        }
        KillAura killAura = Client.INSTANCE.getModuleManager().get(KillAura.class);
        Intrinsics.checkNotNull((Object)killAura);
        KillAura killAura2 = killAura;
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        Iterator iterator = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"this as java.lang.String).toLowerCase(locale)");
        block7 : switch (iterator) {
            case "validspoof": {
                if (!MinecraftInstance.mc.field_71439_g.func_71039_bw()) {
                    return;
                }
                if (event.getEventState() == EventState.PRE) {
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c % 8 + 1)));
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c)));
                }
                if (event.getEventState() != EventState.POST) break;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.func_70694_bm())));
                break;
            }
            case "aac5": {
                if (event.getEventState() != EventState.POST || !MinecraftInstance.mc.field_71439_g.func_71039_bw() && !MinecraftInstance.mc.field_71439_g.func_70632_aY() && !killAura2.getBlockingStatus()) break;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, MinecraftInstance.mc.field_71439_g.field_71071_by.func_70448_g(), 0.0f, 0.0f, 0.0f)));
                break;
            }
            case "watchdog": {
                if (!((Boolean)this.testValue.get()).booleanValue() || killAura2.getState() && killAura2.getBlockingStatus() || event.getEventState() != EventState.PRE || MinecraftInstance.mc.field_71439_g.func_71011_bu() == null || MinecraftInstance.mc.field_71439_g.func_71011_bu().func_77973_b() == null) break;
                Item item = MinecraftInstance.mc.field_71439_g.func_71011_bu().func_77973_b();
                if (!MinecraftInstance.mc.field_71439_g.func_71039_bw() || !(item instanceof ItemFood) && !(item instanceof ItemBucketMilk) && !(item instanceof ItemPotion) || MinecraftInstance.mc.field_71439_g.func_71052_bv() < 1) break;
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c)));
                break;
            }
            case "blink": {
                if (event.getEventState() != EventState.PRE || MinecraftInstance.mc.field_71439_g.func_71039_bw() || MinecraftInstance.mc.field_71439_g.func_70632_aY()) break;
                this.lastX = event.getX();
                this.lastY = event.getY();
                this.lastZ = event.getZ();
                this.lastOnGround = event.getOnGround();
                if (this.blinkPackets.size() <= 0 || !StringsKt.equals((String)((String)this.packetTriggerValue.get()), (String)"postrelease", (boolean)true)) break;
                Iterable $this$forEach$iv = this.blinkPackets;
                boolean $i$f$forEach = false;
                for (Object element$iv : $this$forEach$iv) {
                    Packet it = (Packet)element$iv;
                    boolean bl = false;
                    PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)it);
                }
                if (((Boolean)this.debugValue.get()).booleanValue()) {
                    ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7rsent " + this.blinkPackets.size() + " packets.");
                }
                this.blinkPackets.clear();
                break;
            }
            case "experimental": {
                if (!MinecraftInstance.mc.field_71439_g.func_71039_bw() && !MinecraftInstance.mc.field_71439_g.func_70632_aY() || !this.timer.hasTimePassed(this.placeDelay)) break;
                MinecraftInstance.mc.field_71442_b.func_78750_j();
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.field_177992_a, EnumFacing.DOWN));
                if (event.getEventState() != EventState.POST) break;
                this.placeDelay = 200L;
                if (this.fasterDelay) {
                    this.placeDelay = 100L;
                    this.fasterDelay = false;
                } else {
                    this.fasterDelay = true;
                }
                this.timer.reset();
                break;
            }
            default: {
                if (!MinecraftInstance.mc.field_71439_g.func_70632_aY() && !killAura2.getBlockingStatus()) {
                    return;
                }
                String string2 = (String)this.modeValue.get();
                iterator = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)iterator, (String)"getDefault()");
                String string3 = string2.toLowerCase((Locale)((Object)iterator));
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toLowerCase(locale)");
                switch (string3) {
                    case "aac": {
                        if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 3 == 0) {
                            NoSlow.sendPacket$default(this, event, true, false, false, 0L, false, false, 64, null);
                            break block7;
                        }
                        NoSlow.sendPacket$default(this, event, false, true, false, 0L, false, false, 64, null);
                        break block7;
                    }
                    case "ncp": {
                        NoSlow.sendPacket$default(this, event, true, true, false, 0L, false, false, 64, null);
                        break block7;
                    }
                    case "newncp": {
                        if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 2 == 0) {
                            NoSlow.sendPacket$default(this, event, true, false, false, 50L, true, false, 64, null);
                            break block7;
                        }
                        this.sendPacket(event, false, true, false, 0L, true, true);
                        break block7;
                    }
                    case "oldhypixel": {
                        if (event.getEventState() == EventState.PRE) {
                            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), EnumFacing.DOWN));
                            break block7;
                        }
                        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, null, 0.0f, 0.0f, 0.0f));
                        break block7;
                    }
                    case "custom": {
                        NoSlow.sendPacket$default(this, event, (Boolean)this.customRelease.get(), (Boolean)this.customPlace.get(), ((Number)this.customDelayValue.get()).intValue() > 0, ((Number)this.customDelayValue.get()).intValue(), (Boolean)this.customOnGround.get(), false, 64, null);
                    }
                }
            }
        }
    }

    @EventTarget
    public final void onSlowDown(SlowDownEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        ItemStack itemStack = MinecraftInstance.mc.field_71439_g.func_70694_bm();
        Item heldItem = itemStack == null ? null : itemStack.func_77973_b();
        event.setForward(this.getMultiplier(heldItem, true));
        event.setStrafe(this.getMultiplier(heldItem, false));
    }

    private final float getMultiplier(Item item, boolean isForward) {
        Item item2 = item;
        return ((item2 instanceof ItemFood ? true : item2 instanceof ItemPotion) ? true : item2 instanceof ItemBucketMilk) ? (isForward ? ((Number)this.consumeForwardMultiplier.get()).floatValue() : ((Number)this.consumeStrafeMultiplier.get()).floatValue()) : (item2 instanceof ItemSword ? (isForward ? ((Number)this.blockForwardMultiplier.get()).floatValue() : ((Number)this.blockStrafeMultiplier.get()).floatValue()) : (item2 instanceof ItemBow ? (isForward ? ((Number)this.bowForwardMultiplier.get()).floatValue() : ((Number)this.bowStrafeMultiplier.get()).floatValue()) : 0.2f));
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(NoSlow $this) {
        return $this.modeValue;
    }
}

