/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.combat;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.InventoryUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="AutoGapple", spacedName="Auto Gapple", description="", category=ModuleCategory.COMBAT)
public final class AutoGapple
extends Module {
    private final ListValue modeValue;
    private final FloatValue healthValue;
    private final IntegerValue delayValue;
    private final BoolValue noAbsorption;
    private final MSTimer timer;

    public AutoGapple() {
        String[] stringArray = new String[]{"Auto", "Once", "Head"};
        this.modeValue = new ListValue("Mode", stringArray, "Auto");
        this.healthValue = new FloatValue("Health", 10.0f, 1.0f, 20.0f);
        this.delayValue = new IntegerValue("Delay", 150, 0, 1000, "ms");
        this.noAbsorption = new BoolValue("NoAbsorption", true);
        this.timer = new MSTimer();
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "once": {
                this.doEat(true);
                this.setState(false);
                break;
            }
            case "auto": {
                if (!this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
                    return;
                }
                if (!(MinecraftInstance.mc.field_71439_g.func_110143_aJ() <= ((Number)this.healthValue.get()).floatValue())) break;
                this.doEat(false);
                this.timer.reset();
                break;
            }
            case "head": {
                int headInHotbar;
                if (!this.timer.hasTimePassed(((Number)this.delayValue.get()).intValue())) {
                    return;
                }
                if (!(MinecraftInstance.mc.field_71439_g.func_110143_aJ() <= ((Number)this.healthValue.get()).floatValue()) || (headInHotbar = InventoryUtils.findItem(36, 45, Items.field_151144_bL)) == -1) break;
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(headInHotbar - 36));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.func_70694_bm()));
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
                this.timer.reset();
            }
        }
    }

    private final void doEat(boolean warn) {
        float abAmount;
        if (((Boolean)this.noAbsorption.get()).booleanValue() && !warn && (abAmount = MinecraftInstance.mc.field_71439_g.func_110139_bj()) > 0.0f) {
            return;
        }
        int gappleInHotbar = InventoryUtils.findItem(36, 45, Items.field_151153_ao);
        if (gappleInHotbar != -1) {
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(gappleInHotbar - 36));
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C08PacketPlayerBlockPlacement(MinecraftInstance.mc.field_71439_g.func_70694_bm()));
            int n = 35;
            int n2 = 0;
            while (n2 < n) {
                int n3;
                int it = n3 = n2++;
                boolean bl = false;
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer(MinecraftInstance.mc.field_71439_g.field_70122_E));
            }
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
        } else if (warn) {
            Client.INSTANCE.getHud().addNotification(new Notification("No Gapple were found in hotbar.", Notification.Type.ERROR));
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

