/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.material.Material
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.movement;

import java.util.Locale;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.Jesus;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Jesus", spacedName="Jesus", description="", category=ModuleCategory.MOVEMENT)
public final class Jesus
extends Module {
    @JvmField
    public final ListValue modeValue;
    private final FloatValue aacFlyValue;
    private boolean nextTick;

    public Jesus() {
        String[] stringArray = new String[]{"Vanilla", "NCP", "Bounce", "AAC", "AACFly", "AAC3.3.11", "AAC4.2.1", "Horizon1.4.6", "Twillight", "MatrixFast", "MatrixDolphin", "Dolphin", "Swim"};
        this.modeValue = new ListValue("Mode", stringArray, "NCP");
        this.aacFlyValue = new FloatValue("Motion", 0.5f, 0.1f, 1.0f, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ Jesus this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return ((String)this.this$0.modeValue.get()).equals("AACFly");
            }
        }));
    }

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71439_g.func_70093_af()) {
            return;
        }
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "ncp": 
            case "vanilla": {
                AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.field_71439_g.func_174813_aQ();
                Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBoundingBox");
                if (!BlockUtils.collideBlock(axisAlignedBB, (Function1<? super Block, Boolean>)((Function1)onUpdate.1.INSTANCE)) || !MinecraftInstance.mc.field_71439_g.func_70055_a(Material.field_151579_a) || MinecraftInstance.mc.field_71439_g.func_70093_af()) break;
                MinecraftInstance.mc.field_71439_g.field_70181_x = 0.08;
                break;
            }
            case "bounce": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += 0.7;
                break;
            }
            case "aac": {
                BlockPos blockPos = MinecraftInstance.mc.field_71439_g.func_180425_c().func_177977_b();
                if (!MinecraftInstance.mc.field_71439_g.field_70122_E && BlockUtils.getBlock(blockPos) == Blocks.field_150355_j || MinecraftInstance.mc.field_71439_g.func_70090_H()) {
                    if (!MinecraftInstance.mc.field_71439_g.func_70051_ag()) {
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70159_w *= 0.99999;
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70181_x *= 0.0;
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70179_y *= 0.99999;
                        if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                            MinecraftInstance.mc.field_71439_g.field_70181_x = (float)((int)(MinecraftInstance.mc.field_71439_g.field_70163_u - (double)((int)(MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0)))) / 8.0f;
                        }
                    } else {
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70159_w *= 0.99999;
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70181_x *= 0.0;
                        locale = MinecraftInstance.mc.field_71439_g;
                        ((EntityPlayerSP)locale).field_70179_y *= 0.99999;
                        if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                            MinecraftInstance.mc.field_71439_g.field_70181_x = (float)((int)(MinecraftInstance.mc.field_71439_g.field_70163_u - (double)((int)(MinecraftInstance.mc.field_71439_g.field_70163_u - 1.0)))) / 8.0f;
                        }
                    }
                    if (MinecraftInstance.mc.field_71439_g.field_70143_R >= 4.0f) {
                        MinecraftInstance.mc.field_71439_g.field_70181_x = -0.004;
                    } else if (MinecraftInstance.mc.field_71439_g.func_70090_H()) {
                        MinecraftInstance.mc.field_71439_g.field_70181_x = 0.09;
                    }
                }
                if (MinecraftInstance.mc.field_71439_g.field_70737_aN == 0) break;
                MinecraftInstance.mc.field_71439_g.field_70122_E = false;
                break;
            }
            case "matrixfast": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                MovementUtils.strafe(0.6f);
                break;
            }
            case "matrixdolphin": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                MinecraftInstance.mc.field_71439_g.field_70181_x = 0.6;
                break;
            }
            case "aac3.3.11": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70159_w *= 1.17;
                entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70179_y *= 1.17;
                if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                    MinecraftInstance.mc.field_71439_g.field_70181_x = 0.24;
                    break;
                }
                if (MinecraftInstance.mc.field_71441_e.func_180495_p(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u + 1.0, MinecraftInstance.mc.field_71439_g.field_70161_v)).func_177230_c() == Blocks.field_150350_a) break;
                entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += 0.04;
                break;
            }
            case "dolphin": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += (double)0.04f;
                break;
            }
            case "aac4.2.1": {
                if ((MinecraftInstance.mc.field_71439_g.field_70122_E || BlockUtils.getBlock(MinecraftInstance.mc.field_71439_g.func_180425_c().func_177977_b()) != Blocks.field_150355_j) && !MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x *= 0.0;
                MinecraftInstance.mc.field_71439_g.field_70747_aH = 0.08f;
                if (MinecraftInstance.mc.field_71439_g.field_70143_R > 0.0f) {
                    return;
                }
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e = true;
                break;
            }
            case "horizon1.4.6": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                MovementUtils.strafe();
                MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e = true;
                if (!MovementUtils.isMoving() || MinecraftInstance.mc.field_71439_g.field_70122_E) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70181_x += 0.13;
                break;
            }
            case "twillight": {
                if (!MinecraftInstance.mc.field_71439_g.func_70090_H()) break;
                EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70159_w *= 1.04;
                entityPlayerSP = MinecraftInstance.mc.field_71439_g;
                entityPlayerSP.field_70179_y *= 1.04;
                MovementUtils.strafe();
            }
        }
    }

    @Override
    public void onDisable() {
        if (MinecraftInstance.mc.field_71439_g.func_70090_H()) {
            MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
            MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        if ("aacfly".equals(string2) && MinecraftInstance.mc.field_71439_g.func_70090_H()) {
            event.setY(((Number)this.aacFlyValue.get()).floatValue());
            MinecraftInstance.mc.field_71439_g.field_70181_x = ((Number)this.aacFlyValue.get()).floatValue();
        }
        if (StringsKt.equals((String)"twillight", (String)((String)this.modeValue.get()), (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70090_H()) {
            event.setY(0.01);
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.01;
        }
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71439_g.func_174813_aQ() == null) {
            return;
        }
        if (event.getBlock() instanceof BlockLiquid) {
            Object object = MinecraftInstance.mc.field_71439_g.func_174813_aQ();
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"mc.thePlayer.entityBoundingBox");
            if (!BlockUtils.collideBlock((AxisAlignedBB)object, (Function1<? super Block, Boolean>)((Function1)onBlockBB.1.INSTANCE)) && !MinecraftInstance.mc.field_71439_g.func_70093_af()) {
                String string = (String)this.modeValue.get();
                Locale locale = Locale.getDefault();
                Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                String string2 = string.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
                object = string2;
                if (object.equals("ncp") ? true : object.equals("vanilla")) {
                    event.setBoundingBox(AxisAlignedBB.func_178781_a((double)event.getX(), (double)event.getY(), (double)event.getZ(), (double)(event.getX() + 1), (double)(event.getY() + 1), (double)(event.getZ() + 1)));
                }
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null || !StringsKt.equals((String)((String)this.modeValue.get()), (String)"NCP", (boolean)true)) {
            return;
        }
        if (event.getPacket() instanceof C03PacketPlayer && BlockUtils.collideBlock(new AxisAlignedBB(MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72336_d, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72337_e, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72334_f, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72340_a, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b - 0.01, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72339_c), (Function1<? super Block, Boolean>)((Function1)onPacket.1.INSTANCE))) {
            boolean bl = this.nextTick = !this.nextTick;
            if (this.nextTick) {
                Packet<?> packet = event.getPacket();
                ((C03PacketPlayer)packet).field_149477_b -= 0.001;
            }
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }
}

