/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.CollectionsKt
 *  kotlin.comparisons.ComparisonsKt
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 *  net.minecraft.network.play.client.C0APacketAnimation
 *  net.minecraft.network.play.server.S08PacketPlayerPosLook
 *  net.minecraft.util.Vec3
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import kotlin.collections.CollectionsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.RotationUtils;
import net.aspw.client.util.pathfinder.MainPathFinder;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.Vec3;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
@ModuleInfo(name="TPAura", spacedName="TP Aura", description="", category=ModuleCategory.COMBAT)
public final class TPAura
extends Module {
    private final IntegerValue apsValue = new IntegerValue("CPS", 6, 1, 10);
    private final IntegerValue maxTargetsValue = new IntegerValue("MaxTarget", 1, 1, 8);
    private final IntegerValue rangeValue = new IntegerValue("Range", 30, 10, 70, "m");
    private final FloatValue fovValue = new FloatValue("FOV", 180.0f, 0.0f, 180.0f, "\u00b0");
    private final ListValue swingValue;
    private final BoolValue autoBlock;
    private final MSTimer clickTimer;
    private ArrayList<Vec3> tpVectors;
    private Thread thread;
    private boolean isBlocking;
    private EntityLivingBase lastTarget;

    public TPAura() {
        String[] stringArray = new String[]{"Normal", "Packet", "None"};
        this.swingValue = new ListValue("Swing", stringArray, "Normal");
        this.autoBlock = new BoolValue("AutoBlock", true);
        this.clickTimer = new MSTimer();
        this.tpVectors = new ArrayList();
    }

    public final boolean isBlocking() {
        return this.isBlocking;
    }

    public final void setBlocking(boolean bl) {
        this.isBlocking = bl;
    }

    public final EntityLivingBase getLastTarget() {
        return this.lastTarget;
    }

    public final void setLastTarget(@Nullable EntityLivingBase entityLivingBase) {
        this.lastTarget = entityLivingBase;
    }

    private final long getAttackDelay() {
        return 1000L / (long)((Number)this.apsValue.get()).intValue();
    }

    @Override
    public void onEnable() {
        this.clickTimer.reset();
        this.tpVectors.clear();
        this.lastTarget = null;
    }

    @Override
    public void onDisable() {
        this.isBlocking = false;
        this.clickTimer.reset();
        this.tpVectors.clear();
        this.lastTarget = null;
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!this.clickTimer.hasTimePassed(this.getAttackDelay())) {
            return;
        }
        if (this.thread != null) {
            Thread thread = this.thread;
            Intrinsics.checkNotNull((Object)thread);
            if (thread.isAlive()) {
                this.clickTimer.reset();
                return;
            }
        }
        this.tpVectors.clear();
        this.clickTimer.reset();
        Thread thread = this.thread = new Thread(() -> TPAura.onUpdate$lambda-0(this));
        Intrinsics.checkNotNull((Object)thread);
        thread.start();
    }

    private final void runAttack() {
        if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71441_e == null) {
            return;
        }
        ArrayList<Entity> targets = new ArrayList<Entity>();
        int entityCount = 0;
        for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
            if (!(entity instanceof EntityLivingBase) || !EntityUtils.isSelected(entity, true) || !(MinecraftInstance.mc.field_71439_g.func_70032_d(entity) <= (float)((Number)this.rangeValue.get()).intValue()) || ((Number)this.fovValue.get()).floatValue() < 180.0f && RotationUtils.getRotationDifference(entity) > (double)((Number)this.fovValue.get()).floatValue()) continue;
            if (entityCount >= ((Number)this.maxTargetsValue.get()).intValue()) break;
            if (((Boolean)this.autoBlock.get()).booleanValue()) {
                this.isBlocking = true;
            }
            targets.add(entity);
            int n = entityCount;
            entityCount = n + 1;
        }
        if (targets.isEmpty()) {
            this.lastTarget = null;
            this.isBlocking = false;
            return;
        }
        List $this$sortBy$iv = targets;
        boolean $i$f$sortBy = false;
        if ($this$sortBy$iv.size() > 1) {
            CollectionsKt.sortWith((List)$this$sortBy$iv, (Comparator)new Comparator(){

                public final int compare(T a, T b) {
                    EntityLivingBase it = (EntityLivingBase)a;
                    boolean bl = false;
                    Comparable comparable = Float.valueOf(it.func_110143_aJ());
                    it = (EntityLivingBase)b;
                    Comparable comparable2 = comparable;
                    bl = false;
                    return ComparisonsKt.compareValues((Comparable)comparable2, (Comparable)Float.valueOf(it.func_110143_aJ()));
                }
            });
        }
        Iterable $this$forEach$iv = targets;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            EntityLivingBase it = (EntityLivingBase)element$iv;
            boolean bl = false;
            if (MinecraftInstance.mc.field_71439_g == null || MinecraftInstance.mc.field_71441_e == null) {
                return;
            }
            ArrayList<net.aspw.client.util.pathfinder.Vec3> path = MainPathFinder.computePath(new net.aspw.client.util.pathfinder.Vec3(MinecraftInstance.mc.field_71439_g.field_70165_t, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v), new net.aspw.client.util.pathfinder.Vec3(it.field_70165_t, it.field_70163_u, it.field_70161_v));
            for (net.aspw.client.util.pathfinder.Vec3 vec : path) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(vec.getX(), vec.getY(), vec.getZ(), false)));
            }
            this.setLastTarget(it);
            String string = (String)this.swingValue.get();
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string2 = string.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
            Iterator<net.aspw.client.util.pathfinder.Vec3> iterator = string2;
            if (iterator.equals("normal")) {
                MinecraftInstance.mc.field_71439_g.func_71038_i();
            } else if (iterator.equals("packet")) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C0APacketAnimation());
            }
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C02PacketUseEntity((Entity)it, C02PacketUseEntity.Action.ATTACK));
            Intrinsics.checkNotNullExpressionValue(path, (String)"path");
            CollectionsKt.reverse((List)path);
            for (net.aspw.client.util.pathfinder.Vec3 vec : path) {
                PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)((Packet)new C03PacketPlayer.C04PacketPlayerPosition(vec.getX(), vec.getY(), vec.getZ(), false)));
            }
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S08PacketPlayerPosLook) {
            this.clickTimer.reset();
        }
    }

    private static final void onUpdate$lambda-0(TPAura this$0) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        this$0.runAttack();
    }
}

