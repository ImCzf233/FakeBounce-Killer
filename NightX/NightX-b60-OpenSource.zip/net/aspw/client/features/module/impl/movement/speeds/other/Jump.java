/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class Jump
extends SpeedMode {
    public Jump() {
        super("Jump");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        if (MovementUtils.isMoving() && Jump.mc.field_71439_g.field_70122_E && !Jump.mc.field_71474_y.field_74314_A.func_151470_d() && !Jump.mc.field_71439_g.func_70090_H() && !Jump.mc.field_71439_g.func_180799_ab() && Jump.mc.field_71439_g.field_70773_bE == 0) {
            Jump.mc.field_71439_g.func_70664_aZ();
            Jump.mc.field_71439_g.field_70773_bE = 10;
        }
        if (((Boolean)speed2.jumpStrafe.get()).booleanValue() && MovementUtils.isMoving() && !Jump.mc.field_71439_g.field_70122_E && !Jump.mc.field_71439_g.func_70090_H() && !Jump.mc.field_71439_g.func_180799_ab()) {
            MovementUtils.strafe();
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

