/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.AxisAlignedBB
 */
package net.aspw.client.features.module.impl.premium;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.connection.LoginID;
import net.aspw.client.value.BoolValue;
import net.minecraft.block.Block;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;

@ModuleInfo(name="Protect", description="", category=ModuleCategory.PREMIUM)
public final class Protect
extends Module {
    private final BoolValue fire = new BoolValue("Fire", true);
    private final BoolValue cobweb = new BoolValue("Cobweb", true);
    private final BoolValue cactus = new BoolValue("Cactus", true);

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!LoginID.INSTANCE.isPremium()) {
            this.chat("You are not using NightX Premium Account!");
            this.setState(false);
            return;
        }
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent e) {
        Intrinsics.checkNotNullParameter((Object)e, (String)"e");
        EntityPlayerSP entityPlayerSP = MinecraftInstance.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        Block block = e.getBlock();
        if (block.equals(Blocks.field_150480_ab)) {
            if (!((Boolean)this.fire.get()).booleanValue()) {
                return;
            }
        } else if (block.equals(Blocks.field_150321_G)) {
            if (!((Boolean)this.cobweb.get()).booleanValue()) {
                return;
            }
        } else if (block.equals(Blocks.field_150434_aF)) {
            if (!((Boolean)this.cactus.get()).booleanValue()) {
                return;
            }
        } else {
            return;
        }
        e.setBoundingBox(new AxisAlignedBB((double)e.getX(), (double)e.getY(), (double)e.getZ(), (double)e.getX() + 1.0, (double)e.getY() + 1.0, (double)e.getZ() + 1.0));
    }
}

