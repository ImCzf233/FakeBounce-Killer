/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.Vec3
 *  net.minecraft.util.Vec3i
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;

public class MineplexGround
extends SpeedMode {
    private boolean spoofSlot;
    private float speed = 0.0f;

    public MineplexGround() {
        super("MineplexGround");
    }

    @Override
    public void onMotion() {
        if (!MovementUtils.isMoving() || !MineplexGround.mc.field_71439_g.field_70122_E || MineplexGround.mc.field_71439_g.field_71071_by.func_70448_g() == null || MineplexGround.mc.field_71439_g.func_71039_bw()) {
            return;
        }
        this.spoofSlot = false;
        for (int i = 36; i < 45; ++i) {
            ItemStack itemStack = MineplexGround.mc.field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c();
            if (itemStack != null) continue;
            mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(i - 36));
            this.spoofSlot = true;
            break;
        }
    }

    @Override
    public void onUpdate() {
        if (!MovementUtils.isMoving() || !MineplexGround.mc.field_71439_g.field_70122_E || MineplexGround.mc.field_71439_g.func_71039_bw()) {
            this.speed = 0.0f;
            return;
        }
        if (!this.spoofSlot && MineplexGround.mc.field_71439_g.field_71071_by.func_70448_g() != null) {
            return;
        }
        BlockPos blockPos = new BlockPos(MineplexGround.mc.field_71439_g.field_70165_t, MineplexGround.mc.field_71439_g.func_174813_aQ().field_72338_b - 1.0, MineplexGround.mc.field_71439_g.field_70161_v);
        Vec3 vec = new Vec3((Vec3i)blockPos).func_72441_c((double)0.4f, (double)0.4f, (double)0.4f).func_178787_e(new Vec3(EnumFacing.UP.func_176730_m()));
        MineplexGround.mc.field_71442_b.func_178890_a(MineplexGround.mc.field_71439_g, MineplexGround.mc.field_71441_e, null, blockPos, EnumFacing.UP, new Vec3(vec.field_72450_a * (double)0.4f, vec.field_72448_b * (double)0.4f, vec.field_72449_c * (double)0.4f));
        float targetSpeed = ((Float)Client.moduleManager.getModule(Speed.class).mineplexGroundSpeedValue.get()).floatValue();
        if (targetSpeed > this.speed) {
            this.speed += targetSpeed / 8.0f;
        }
        if (this.speed >= targetSpeed) {
            this.speed = targetSpeed;
        }
        MovementUtils.strafe(this.speed);
        if (!this.spoofSlot) {
            mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MineplexGround.mc.field_71439_g.field_71071_by.field_70461_c));
        }
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    @Override
    public void onDisable() {
        this.speed = 0.0f;
        mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MineplexGround.mc.field_71439_g.field_71071_by.field_70461_c));
    }
}

