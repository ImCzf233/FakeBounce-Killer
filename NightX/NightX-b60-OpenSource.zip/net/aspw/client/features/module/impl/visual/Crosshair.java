/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.visual.ColorMixer;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="Crosshair", description="", category=ModuleCategory.VISUAL)
public class Crosshair
extends Module {
    private final FloatValue saturationValue = new FloatValue("Saturation", 1.0f, 0.0f, 1.0f);
    private final FloatValue brightnessValue = new FloatValue("Brightness", 1.0f, 0.0f, 1.0f);
    private final IntegerValue mixerSecondsValue = new IntegerValue("Seconds", 2, 1, 10);
    public ListValue colorModeValue = new ListValue("Color", new String[]{"Custom", "Rainbow", "LiquidSlowly", "Sky", "Fade", "Mixer"}, "Custom");
    public IntegerValue colorRedValue = new IntegerValue("Red", 255, 0, 255);
    public IntegerValue colorGreenValue = new IntegerValue("Green", 255, 0, 255);
    public IntegerValue colorBlueValue = new IntegerValue("Blue", 255, 0, 255);
    public IntegerValue colorAlphaValue = new IntegerValue("Alpha", 255, 0, 255);
    public FloatValue widthVal = new FloatValue("Width", 0.5f, 0.25f, 10.0f);
    public FloatValue sizeVal = new FloatValue("Size/Length", 7.0f, 0.25f, 15.0f);
    public FloatValue gapVal = new FloatValue("Gap", 5.0f, 0.25f, 15.0f);

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        if (!((Boolean)Client.moduleManager.getModule(Hud.class).getNof5crossHair().get()).booleanValue() || Minecraft.func_71410_x().field_71474_y.field_74320_O == 0 && ((Boolean)Client.moduleManager.getModule(Hud.class).getNof5crossHair().get()).booleanValue()) {
            ScaledResolution scaledRes = new ScaledResolution(mc);
            float width = ((Float)this.widthVal.get()).floatValue();
            float size = ((Float)this.sizeVal.get()).floatValue();
            float gap = ((Float)this.gapVal.get()).floatValue();
            GL11.glPushMatrix();
            RenderUtils.drawBorderedRect((float)scaledRes.func_78326_a() / 2.0f - width, (float)scaledRes.func_78328_b() / 2.0f - gap - size - (float)(this.isMoving() ? 2 : 0), (float)scaledRes.func_78326_a() / 2.0f + 1.0f + width, (float)scaledRes.func_78328_b() / 2.0f - gap - (float)(this.isMoving() ? 2 : 0), 0.5f, new Color(0, 0, 0, (Integer)this.colorAlphaValue.get()).getRGB(), this.getCrosshairColor().getRGB());
            RenderUtils.drawBorderedRect((float)scaledRes.func_78326_a() / 2.0f - width, (float)scaledRes.func_78328_b() / 2.0f + gap + 1.0f + (float)(this.isMoving() ? 2 : 0) - 0.15f, (float)scaledRes.func_78326_a() / 2.0f + 1.0f + width, (float)scaledRes.func_78328_b() / 2.0f + 1.0f + gap + size + (float)(this.isMoving() ? 2 : 0) - 0.15f, 0.5f, new Color(0, 0, 0, (Integer)this.colorAlphaValue.get()).getRGB(), this.getCrosshairColor().getRGB());
            RenderUtils.drawBorderedRect((float)scaledRes.func_78326_a() / 2.0f - gap - size - (float)(this.isMoving() ? 2 : 0) + 0.15f, (float)scaledRes.func_78328_b() / 2.0f - width, (float)scaledRes.func_78326_a() / 2.0f - gap - (float)(this.isMoving() ? 2 : 0) + 0.15f, (float)(scaledRes.func_78328_b() / 2) + 1.0f + width, 0.5f, new Color(0, 0, 0, (Integer)this.colorAlphaValue.get()).getRGB(), this.getCrosshairColor().getRGB());
            RenderUtils.drawBorderedRect((float)scaledRes.func_78326_a() / 2.0f + 1.0f + gap + (float)(this.isMoving() ? 2 : 0), (float)scaledRes.func_78328_b() / 2.0f - width, (float)scaledRes.func_78326_a() / 2.0f + size + gap + 1.0f + (float)(this.isMoving() ? 2 : 0), (float)(scaledRes.func_78328_b() / 2) + 1.0f + width, 0.5f, new Color(0, 0, 0, (Integer)this.colorAlphaValue.get()).getRGB(), this.getCrosshairColor().getRGB());
            GL11.glPopMatrix();
            GlStateManager.func_179117_G();
        }
    }

    private boolean isMoving() {
        return MovementUtils.isMoving();
    }

    private Color getCrosshairColor() {
        switch ((String)this.colorModeValue.get()) {
            case "Custom": {
                return new Color((Integer)this.colorRedValue.get(), (Integer)this.colorGreenValue.get(), (Integer)this.colorBlueValue.get(), (Integer)this.colorAlphaValue.get());
            }
            case "Rainbow": {
                return new Color(RenderUtils.getRainbowOpaque((Integer)this.mixerSecondsValue.get(), ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue(), 0));
            }
            case "Sky": {
                return ColorUtils.reAlpha(RenderUtils.skyRainbow(0, ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue()), (Integer)this.colorAlphaValue.get());
            }
            case "LiquidSlowly": {
                return ColorUtils.reAlpha(ColorUtils.LiquidSlowly(System.nanoTime(), 0, ((Float)this.saturationValue.get()).floatValue(), ((Float)this.brightnessValue.get()).floatValue()), (Integer)this.colorAlphaValue.get());
            }
            case "Mixer": {
                return ColorUtils.reAlpha(ColorMixer.getMixedColor(0, (Integer)this.mixerSecondsValue.get()), (Integer)this.colorAlphaValue.get());
            }
        }
        return ColorUtils.reAlpha(ColorUtils.fade(new Color((Integer)this.colorRedValue.get(), (Integer)this.colorGreenValue.get(), (Integer)this.colorBlueValue.get()), 0, 100), (Integer)this.colorAlphaValue.get());
    }
}

