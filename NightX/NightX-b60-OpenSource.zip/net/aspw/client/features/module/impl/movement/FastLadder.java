/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockLadder
 *  net.minecraft.block.BlockVine
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.EnumFacing
 */
package net.aspw.client.features.module.impl.movement;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.BlockBBEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.features.module.impl.movement.FastLadder;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockVine;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

@ModuleInfo(name="FastLadder", spacedName="Fast Ladder", description="", category=ModuleCategory.MOVEMENT)
public final class FastLadder
extends Module {
    private final ListValue modeValue;
    private final FloatValue upSpeedValue;
    private final FloatValue downSpeedValue;
    private final FloatValue timerValue;
    private final BoolValue spartanTimerBoostValue;
    private boolean usedTimer;

    public FastLadder() {
        String[] stringArray = new String[]{"Vanilla", "Clip", "AAC3.0.0", "AAC3.0.5", "SAAC3.1.2", "AAC3.1.2", "Spartan", "Negativity", "Horizon1.4.6", "HiveMC"};
        this.modeValue = new ListValue("Mode", stringArray, "Vanilla");
        this.upSpeedValue = new FloatValue("UpSpeed", 0.3f, 0.01f, 10.0f);
        this.downSpeedValue = new FloatValue("DownSpeed", 0.15f, 0.01f, 10.0f);
        this.timerValue = new FloatValue("Timer", 1.0f, 0.1f, 10.0f, "x");
        this.spartanTimerBoostValue = new BoolValue("SpartanTimerBoost", true, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ FastLadder this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)this.this$0.getModeValue().get()), (String)"spartan", (boolean)true);
            }
        }));
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    /*
     * Enabled aggressive block sorting
     */
    @EventTarget
    public final void onMove(MoveEvent event) {
        int i;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (this.usedTimer) {
            MinecraftInstance.mc.field_71428_T.field_74278_d = 1.0f;
            this.usedTimer = false;
        }
        String mode = (String)this.modeValue.get();
        if (StringsKt.equals((String)mode, (String)"Vanilla", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(((Number)this.upSpeedValue.get()).floatValue());
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-((double)((Number)this.downSpeedValue.get()).floatValue()));
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            MinecraftInstance.mc.field_71428_T.field_74278_d = ((Number)this.timerValue.get()).floatValue();
            this.usedTimer = true;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.0.0", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70123_F) {
            double x = 0.0;
            double z = 0.0;
            EnumFacing enumFacing = MinecraftInstance.mc.field_71439_g.func_174811_aO();
            switch (enumFacing == null ? -1 : WhenMappings.$EnumSwitchMapping$0[enumFacing.ordinal()]) {
                case 1: {
                    z = -0.99;
                    break;
                }
                case 2: {
                    x = 0.99;
                    break;
                }
                case 3: {
                    z = 0.99;
                    break;
                }
                case 4: {
                    x = -0.99;
                    break;
                }
            }
            Block block = BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t + x, MinecraftInstance.mc.field_71439_g.field_70163_u, MinecraftInstance.mc.field_71439_g.field_70161_v + z));
            if (!(block instanceof BlockLadder)) {
                if (!(block instanceof BlockVine)) return;
            }
            event.setY(0.5);
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.0.5", (boolean)true) && MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d()) {
            AxisAlignedBB axisAlignedBB = MinecraftInstance.mc.field_71439_g.func_174813_aQ();
            Intrinsics.checkNotNullExpressionValue((Object)axisAlignedBB, (String)"mc.thePlayer.entityBoundingBox");
            if (BlockUtils.collideBlockIntersects(axisAlignedBB, (Function1<? super Block, Boolean>)((Function1)onMove.1.INSTANCE))) {
                event.setX(0.0);
                event.setY(0.5);
                event.setZ(0.0);
                MinecraftInstance.mc.field_71439_g.field_70159_w = 0.0;
                MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
                MinecraftInstance.mc.field_71439_g.field_70179_y = 0.0;
                return;
            }
        }
        if (StringsKt.equals((String)mode, (String)"SAAC3.1.2", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70123_F && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            event.setY(0.1649);
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"AAC3.1.2", (boolean)true) && MinecraftInstance.mc.field_71439_g.field_70123_F && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            event.setY(0.1699);
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Spartan", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(0.199);
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-1.3489);
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            if ((Boolean)this.spartanTimerBoostValue.get() == false) return;
            if (!MinecraftInstance.mc.field_71439_g.func_70617_f_()) return;
            if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 2 == 0) {
                MinecraftInstance.mc.field_71428_T.field_74278_d = 2.5f;
            }
            if (MinecraftInstance.mc.field_71439_g.field_70173_aa % 30 == 0) {
                MinecraftInstance.mc.field_71428_T.field_74278_d = 3.0f;
            }
            this.usedTimer = true;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Negativity", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(0.2299);
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-0.226);
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Twillight", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(0.16);
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-7.99);
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"Horizon1.4.6", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(0.125);
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-0.16);
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (StringsKt.equals((String)mode, (String)"HiveMC", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            if (MinecraftInstance.mc.field_71439_g.field_70123_F) {
                event.setY(0.179);
            } else if (!MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e) {
                event.setY(-0.225);
            }
            MinecraftInstance.mc.field_71439_g.field_70181_x = 0.0;
            return;
        }
        if (!StringsKt.equals((String)mode, (String)"Clip", (boolean)true)) return;
        if (!MinecraftInstance.mc.field_71439_g.func_70617_f_()) return;
        if (!MinecraftInstance.mc.field_71474_y.field_74351_w.func_151470_d()) return;
        int n = (int)MinecraftInstance.mc.field_71439_g.field_70163_u;
        int n2 = (int)MinecraftInstance.mc.field_71439_g.field_70163_u + 8;
        if (n > n2) return;
        do {
            Block block;
            if (!((block = BlockUtils.getBlock(new BlockPos(MinecraftInstance.mc.field_71439_g.field_70165_t, (double)(i = n++), MinecraftInstance.mc.field_71439_g.field_70161_v))) instanceof BlockLadder)) {
                double x = 0.0;
                double z = 0.0;
                EnumFacing enumFacing = MinecraftInstance.mc.field_71439_g.func_174811_aO();
                switch (enumFacing == null ? -1 : WhenMappings.$EnumSwitchMapping$0[enumFacing.ordinal()]) {
                    case 1: {
                        z = -1.0;
                        break;
                    }
                    case 2: {
                        x = 1.0;
                        break;
                    }
                    case 3: {
                        z = 1.0;
                        break;
                    }
                    case 4: {
                        x = -1.0;
                        break;
                    }
                }
                MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t + x, (double)i, MinecraftInstance.mc.field_71439_g.field_70161_v + z);
                return;
            }
            MinecraftInstance.mc.field_71439_g.func_70107_b(MinecraftInstance.mc.field_71439_g.field_70165_t, (double)i, MinecraftInstance.mc.field_71439_g.field_70161_v);
        } while (i != n2);
    }

    @EventTarget
    public final void onBlockBB(BlockBBEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g != null && (event.getBlock() instanceof BlockLadder || event.getBlock() instanceof BlockVine) && StringsKt.equals((String)((String)this.modeValue.get()), (String)"AAC3.0.5", (boolean)true) && MinecraftInstance.mc.field_71439_g.func_70617_f_()) {
            event.setBoundingBox(null);
        }
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    public final class WhenMappings {
        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

        static {
            int[] nArray = new int[EnumFacing.values().length];
            nArray[EnumFacing.NORTH.ordinal()] = 1;
            nArray[EnumFacing.EAST.ordinal()] = 2;
            nArray[EnumFacing.SOUTH.ordinal()] = 3;
            nArray[EnumFacing.WEST.ordinal()] = 4;
            $EnumSwitchMapping$0 = nArray;
        }
    }
}

