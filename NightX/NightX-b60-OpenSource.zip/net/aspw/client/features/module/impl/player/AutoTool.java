/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.Pair
 *  kotlin.collections.CollectionsKt
 *  kotlin.collections.IntIterator
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.ranges.IntRange
 *  net.minecraft.block.Block
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.entity.ai.attributes.AttributeModifier
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C02PacketUseEntity
 *  net.minecraft.network.play.client.C02PacketUseEntity$Action
 *  net.minecraft.network.play.client.C09PacketHeldItemChange
 *  net.minecraft.util.BlockPos
 */
package net.aspw.client.features.module.impl.player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntRange;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.ClickBlockEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.item.ItemUtils;
import net.minecraft.block.Block;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.BlockPos;

@ModuleInfo(name="AutoTool", spacedName="Auto Tool", description="", category=ModuleCategory.PLAYER)
public final class AutoTool
extends Module {
    private boolean attackEnemy;
    private int spoofedSlot;

    @EventTarget
    public final void onClick(ClickBlockEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!MinecraftInstance.mc.field_71439_g.func_71039_bw()) {
            BlockPos blockPos = event.getClickedBlock();
            if (blockPos == null) {
                return;
            }
            this.switchSlot(blockPos);
        }
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        this.attackEnemy = true;
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof C02PacketUseEntity && ((C02PacketUseEntity)event.getPacket()).func_149565_c() == C02PacketUseEntity.Action.ATTACK && this.attackEnemy) {
            Object v0;
            void $this$filterTo$iv$iv;
            Iterable $this$mapTo$iv$iv;
            this.attackEnemy = false;
            Iterable $this$map$iv = (Iterable)new IntRange(0, 8);
            boolean $i$f$map = false;
            Iterable iterable = $this$map$iv;
            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault((Iterable)$this$map$iv, (int)10));
            boolean $i$f$mapTo = false;
            Iterator iterator = $this$mapTo$iv$iv.iterator();
            while (iterator.hasNext()) {
                void it;
                int item$iv$iv;
                int n = item$iv$iv = ((IntIterator)iterator).nextInt();
                Collection collection = destination$iv$iv;
                boolean bl = false;
                collection.add(new Pair((Object)((int)it), (Object)MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a((int)it)));
            }
            Iterable $this$filter$iv = (List)destination$iv$iv;
            boolean $i$f$filter = false;
            $this$mapTo$iv$iv = $this$filter$iv;
            destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                Pair it2 = (Pair)element$iv$iv;
                boolean bl = false;
                if (!(it2.getSecond() != null && ((ItemStack)it2.getSecond()).func_77973_b() instanceof ItemSword)) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            Iterable $this$maxByOrNull$iv = (List)destination$iv$iv;
            boolean $i$f$maxByOrNull = false;
            Iterator iterator$iv = $this$maxByOrNull$iv.iterator();
            if (!iterator$iv.hasNext()) {
                v0 = null;
            } else {
                Object maxElem$iv = iterator$iv.next();
                if (!iterator$iv.hasNext()) {
                    v0 = maxElem$iv;
                } else {
                    Pair it = (Pair)maxElem$iv;
                    boolean bl = false;
                    Collection element$iv$iv = ((ItemStack)it.getSecond()).func_111283_C().get((Object)"generic.attackDamage");
                    Intrinsics.checkNotNullExpressionValue((Object)element$iv$iv, (String)"it.second.attributeModif\u2026s[\"generic.attackDamage\"]");
                    AttributeModifier it2 = (AttributeModifier)CollectionsKt.first((Iterable)element$iv$iv);
                    double maxValue$iv = (it2 == null ? 0.0 : (element$iv$iv = it2.func_111164_d())) + 1.25 * (double)ItemUtils.getEnchantment((ItemStack)it.getSecond(), Enchantment.field_180314_l);
                    do {
                        double d;
                        Object e$iv = iterator$iv.next();
                        Pair it3 = (Pair)e$iv;
                        $i$a$-maxByOrNull-AutoTool$onPacket$3 = false;
                        Collection collection = ((ItemStack)it3.getSecond()).func_111283_C().get((Object)"generic.attackDamage");
                        Intrinsics.checkNotNullExpressionValue((Object)collection, (String)"it.second.attributeModif\u2026s[\"generic.attackDamage\"]");
                        AttributeModifier attributeModifier = (AttributeModifier)CollectionsKt.first((Iterable)collection);
                        double v$iv = (attributeModifier == null ? 0.0 : (d = attributeModifier.func_111164_d())) + 1.25 * (double)ItemUtils.getEnchantment((ItemStack)it3.getSecond(), Enchantment.field_180314_l);
                        if (Double.compare(maxValue$iv, v$iv) >= 0) continue;
                        maxElem$iv = e$iv;
                        maxValue$iv = v$iv;
                    } while (iterator$iv.hasNext());
                    v0 = maxElem$iv;
                }
            }
            Pair pair = v0;
            if (pair == null) {
                return;
            }
            int slot = ((Number)pair.component1()).intValue();
            if (slot == MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c) {
                return;
            }
            MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = slot;
            MinecraftInstance.mc.field_71442_b.func_78765_e();
            MinecraftInstance.mc.func_147114_u().func_147297_a(event.getPacket());
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onUpdate(UpdateEvent update) {
        Intrinsics.checkNotNullParameter((Object)update, (String)"update");
        if (this.spoofedSlot > 0) {
            if (this.spoofedSlot == 1) {
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C09PacketHeldItemChange(MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c));
            }
            int n = this.spoofedSlot;
            this.spoofedSlot = n + -1;
        }
    }

    public final void switchSlot(BlockPos blockPos) {
        Intrinsics.checkNotNullParameter((Object)blockPos, (String)"blockPos");
        float bestSpeed = 1.0f;
        int bestSlot = -1;
        Block block = MinecraftInstance.mc.field_71441_e.func_180495_p(blockPos).func_177230_c();
        int n = 0;
        while (n < 9) {
            ItemStack item;
            float speed2;
            int i;
            if (MinecraftInstance.mc.field_71439_g.field_71071_by.func_70301_a(i = n++) == null || !((speed2 = item.func_150997_a(block)) > bestSpeed)) continue;
            bestSpeed = speed2;
            bestSlot = i;
        }
        if (bestSlot != -1) {
            MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = bestSlot;
        }
    }
}

