/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C01PacketChatMessage
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C01PacketChatMessage;

@ModuleInfo(name="ChatFilter", spacedName="Chat Filter", description="", category=ModuleCategory.OTHER)
public final class ChatFilter
extends Module {
    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getPacket() instanceof C01PacketChatMessage) {
            Packet<?> chatMessage = event.getPacket();
            String message = ((C01PacketChatMessage)chatMessage).field_149440_a;
            StringBuilder stringBuilder = new StringBuilder();
            Intrinsics.checkNotNullExpressionValue((Object)message, (String)"message");
            char[] cArray = message.toCharArray();
            Intrinsics.checkNotNullExpressionValue((Object)cArray, (String)"this as java.lang.String).toCharArray()");
            char[] cArray2 = cArray;
            int n = 0;
            int n2 = cArray2.length;
            while (n < n2) {
                char c = cArray2[n];
                ++n;
                char c2 = c;
                boolean bl = '!' <= c2 ? c2 < '\u0081' : false;
                if (bl) {
                    stringBuilder.append(Character.toChars(c + 65248));
                    continue;
                }
                stringBuilder.append(c);
            }
            ((C01PacketChatMessage)chatMessage).field_149440_a = stringBuilder.toString();
        }
    }
}

