/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.extensions.PlayerExtensionKt;
import net.aspw.client.util.render.RenderUtils;
import net.minecraft.entity.Entity;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="ESP", description="", category=ModuleCategory.VISUAL)
public final class ESP
extends Module {
    /*
     * Unable to fully structure code
     */
    @EventTarget
    public final void onRender3D(@Nullable Render3DEvent event) {
        v0 = MinecraftInstance.mc.field_71439_g;
        if (v0 == null) {
            return;
        }
        player = v0;
        var4_3 = MinecraftInstance.mc.field_71441_e.field_72996_f;
        Intrinsics.checkNotNullExpressionValue((Object)var4_3, (String)"mc.theWorld.loadedEntityList");
        $this$filter$iv = var4_3;
        $i$f$filter = false;
        var6_6 = $this$filter$iv;
        destination$iv$iv = new ArrayList<E>();
        $i$f$filterTo = false;
        for (T element$iv$iv : $this$filterTo$iv$iv) {
            entity = (Entity)element$iv$iv;
            $i$a$-filter-ESP$onRender3D$selectedEntities$1 = false;
            if (entity == null || entity == player || !EntityUtils.isSelected(entity, false)) ** GOTO lbl-1000
            v1 = MinecraftInstance.mc.field_71439_g;
            Intrinsics.checkNotNull((Object)v1);
            if ((float)PlayerExtensionKt.getDistanceToEntityBox((Entity)v1, entity) <= 42.0f) {
                v2 = true;
            } else lbl-1000:
            // 2 sources

            {
                v2 = false;
            }
            if (!v2) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        selectedEntities = (List)destination$iv$iv;
        for (Entity entity : selectedEntities) {
            RenderUtils.drawEntityBox(entity, Color.BLACK, false);
        }
    }
}

