/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.combat;

import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.value.FloatValue;

@ModuleInfo(name="Reach", description="", category=ModuleCategory.COMBAT)
public final class Reach
extends Module {
    private final FloatValue combatReachValue = new FloatValue("CombatReach", 6.0f, 3.0f, 6.0f, "m");
    private final FloatValue buildReachValue = new FloatValue("BuildReach", 6.0f, 4.5f, 6.0f, "m");

    public final FloatValue getCombatReachValue() {
        return this.combatReachValue;
    }

    public final FloatValue getBuildReachValue() {
        return this.buildReachValue;
    }

    public final float getMaxRange() {
        return Math.max(((Number)this.combatReachValue.get()).floatValue(), ((Number)this.buildReachValue.get()).floatValue());
    }
}

