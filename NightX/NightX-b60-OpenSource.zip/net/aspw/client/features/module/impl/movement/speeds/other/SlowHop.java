/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.other;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class SlowHop
extends SpeedMode {
    public SlowHop() {
        super("SlowHop");
    }

    @Override
    public void onMotion() {
        if (SlowHop.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (SlowHop.mc.field_71439_g.field_70122_E && SlowHop.mc.field_71439_g.field_70773_bE == 0) {
                SlowHop.mc.field_71439_g.func_70664_aZ();
                SlowHop.mc.field_71439_g.field_70773_bE = 10;
            } else {
                MovementUtils.strafe(MovementUtils.getSpeed() * 1.011f);
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

