/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.math.MathKt
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;

@ModuleInfo(name="ThunderNotifier", spacedName="Thunder Notifier", description="", category=ModuleCategory.OTHER)
public final class ThunderNotifier
extends Module {
    private final BoolValue chatValue = new BoolValue("Chat", true);
    private final BoolValue notifyValue = new BoolValue("Notification", false);

    public ThunderNotifier() {
        this.setState(true);
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S2CPacketSpawnGlobalEntity && ((S2CPacketSpawnGlobalEntity)packet).func_149053_g() == 1) {
            double x = (double)((S2CPacketSpawnGlobalEntity)packet).func_149051_d() / 32.0;
            double y = (double)((S2CPacketSpawnGlobalEntity)packet).func_149050_e() / 32.0;
            double z = (double)((S2CPacketSpawnGlobalEntity)packet).func_149049_f() / 32.0;
            int dist = MathKt.roundToInt((double)MinecraftInstance.mc.field_71439_g.func_70011_f(x, MinecraftInstance.mc.field_71439_g.func_174813_aQ().field_72338_b, z));
            if (((Boolean)this.chatValue.get()).booleanValue()) {
                ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7fDetected thunder at " + (int)x + ' ' + (int)y + ' ' + (int)z + " (" + dist + " blocks away)");
            }
            if (((Boolean)this.notifyValue.get()).booleanValue()) {
                Client.INSTANCE.getHud().addNotification(new Notification("Detected thunder at " + (int)x + ' ' + (int)y + ' ' + (int)z + " (" + dist + " blocks away)", Notification.Type.INFO, 3000L));
            }
        }
    }
}

