/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.module.impl.movement.speeds.verus;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public final class VerusFloat
extends SpeedMode {
    private int ticks;
    private boolean verusBypass;
    private boolean isFloating;

    public VerusFloat() {
        super("VerusFloat");
    }

    @Override
    public void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (SpeedMode.mc.field_71439_g != null && MovementUtils.isMoving()) {
            event.cancelEvent();
        }
    }

    @Override
    public void onDisable() {
    }

    @Override
    public void onTick() {
    }

    @Override
    public void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        int n = this.ticks;
        this.ticks = n + 1;
        if (SpeedMode.mc.field_71439_g.field_70122_E) {
            this.ticks = 0;
            MovementUtils.strafe(0.44f);
            SpeedMode.mc.field_71439_g.field_70181_x = 0.42;
            SpeedMode.mc.field_71428_T.field_74278_d = 2.1f;
            this.isFloating = true;
        } else if (this.isFloating) {
            if (this.ticks >= 10) {
                this.verusBypass = true;
                MovementUtils.strafe(0.2865f);
                this.isFloating = false;
            }
            if (this.verusBypass) {
                if (this.ticks <= 1) {
                    MovementUtils.strafe(0.45f);
                }
                if (this.ticks >= 2) {
                    MovementUtils.strafe(0.69f - (float)(this.ticks - 2) * 0.019f);
                }
            }
            SpeedMode.mc.field_71439_g.field_70181_x = 0.0;
            SpeedMode.mc.field_71428_T.field_74278_d = 0.9f;
            SpeedMode.mc.field_71439_g.field_70122_E = true;
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onEnable() {
        this.verusBypass = false;
    }
}

