/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.module.impl.other;

import java.util.Random;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.timer.MSTimer;
import net.aspw.client.util.timer.TimeUtils;
import net.aspw.client.value.IntegerValue;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="Spammer", description="", category=ModuleCategory.OTHER)
public final class Spammer
extends Module {
    private final IntegerValue maxDelayValue = new IntegerValue(this){
        final /* synthetic */ Spammer this$0;
        {
            this.this$0 = $receiver;
            super("MaxDelay", 1500, 0, 5000, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int minDelayValueObject = ((Number)Spammer.access$getMinDelayValue$p(this.this$0).get()).intValue();
            if (minDelayValueObject > newValue) {
                this.set(minDelayValueObject);
            }
            Spammer.access$setDelay$p(this.this$0, TimeUtils.randomDelay(((Number)Spammer.access$getMinDelayValue$p(this.this$0).get()).intValue(), ((Number)this.get()).intValue()));
        }
    };
    private final IntegerValue minDelayValue = new IntegerValue(this){
        final /* synthetic */ Spammer this$0;
        {
            this.this$0 = $receiver;
            super("MinDelay", 1500, 0, 5000, "ms");
        }

        protected void onChanged(int oldValue, int newValue) {
            int maxDelayValueObject = ((Number)Spammer.access$getMaxDelayValue$p(this.this$0).get()).intValue();
            if (maxDelayValueObject < newValue) {
                this.set(maxDelayValueObject);
            }
            Spammer.access$setDelay$p(this.this$0, TimeUtils.randomDelay(((Number)this.get()).intValue(), ((Number)Spammer.access$getMaxDelayValue$p(this.this$0).get()).intValue()));
        }
    };
    private final MSTimer msTimer = new MSTimer();
    private long delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());

    @EventTarget
    public final void onUpdate(@Nullable UpdateEvent event) {
        if (this.msTimer.hasTimePassed(this.delay)) {
            MinecraftInstance.mc.field_71439_g.func_71165_d("!NightX Client! >" + RandomUtils.randomString(5 + new Random().nextInt(5)) + '<');
            this.msTimer.reset();
            this.delay = TimeUtils.randomDelay(((Number)this.minDelayValue.get()).intValue(), ((Number)this.maxDelayValue.get()).intValue());
        }
    }

    public static final /* synthetic */ IntegerValue access$getMinDelayValue$p(Spammer $this) {
        return $this.minDelayValue;
    }

    public static final /* synthetic */ void access$setDelay$p(Spammer $this, long l) {
        $this.delay = l;
    }

    public static final /* synthetic */ IntegerValue access$getMaxDelayValue$p(Spammer $this) {
        return $this.maxDelayValue;
    }
}

