/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.entity.EntityPlayerSP
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;

public final class AACHop438
extends SpeedMode {
    public AACHop438() {
        super("AACHop4.3.8");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
        EntityPlayerSP entityPlayerSP = SpeedMode.mc.field_71439_g;
        if (entityPlayerSP == null) {
            return;
        }
        EntityPlayerSP thePlayer = entityPlayerSP;
        SpeedMode.mc.field_71428_T.field_74278_d = 1.0f;
        if (!MovementUtils.isMoving() || thePlayer.func_70090_H() || thePlayer.func_180799_ab() || thePlayer.func_70617_f_() || thePlayer.func_70115_ae()) {
            return;
        }
        if (thePlayer.field_70122_E) {
            thePlayer.func_70664_aZ();
        } else {
            SpeedMode.mc.field_71428_T.field_74278_d = (double)thePlayer.field_70143_R <= 0.1 ? 1.5f : ((double)thePlayer.field_70143_R < 1.3 ? 0.7f : 1.0f);
        }
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }

    @Override
    public void onDisable() {
    }
}

