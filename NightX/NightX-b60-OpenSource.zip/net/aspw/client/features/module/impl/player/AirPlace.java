/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.Vec3
 */
package net.aspw.client.features.module.impl.player;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

@ModuleInfo(name="AirPlace", spacedName="Air Place", description="", category=ModuleCategory.PLAYER)
public final class AirPlace
extends Module {
    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74311_E)) {
            MinecraftInstance.mc.field_71442_b.func_178890_a(MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71441_e, MinecraftInstance.mc.field_71439_g.func_70694_bm(), new BlockPos((Entity)MinecraftInstance.mc.field_71439_g).func_177979_c(1), MinecraftInstance.mc.field_71439_g.func_174811_aO(), new Vec3(0.0, 0.0, 0.0));
        } else {
            MinecraftInstance.mc.field_71474_y.field_74311_E.field_74513_e = false;
            MinecraftInstance.mc.field_71442_b.func_178890_a(MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71441_e, MinecraftInstance.mc.field_71439_g.func_70694_bm(), new BlockPos((Entity)MinecraftInstance.mc.field_71439_g).func_177979_c(2), MinecraftInstance.mc.field_71439_g.func_174811_aO(), new Vec3(0.0, 0.0, 0.0));
        }
    }
}

