/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.AxisAlignedBB
 *  net.minecraft.util.BlockPos
 *  net.minecraft.util.MovingObjectPosition
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.features.module.impl.visual;

import java.awt.Color;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.render.ColorUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.block.Block;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name="BlockOverlay", spacedName="Block Overlay", description="", category=ModuleCategory.VISUAL)
public final class BlockOverlay
extends Module {
    private final IntegerValue colorRedValue = new IntegerValue("R", 154, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 115, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 175, 0, 255);
    private final BoolValue colorRainbow = new BoolValue("Rainbow", false);
    private final BoolValue infoValue = new BoolValue("Info", false);

    public final BoolValue getInfoValue() {
        return this.infoValue;
    }

    public final BlockPos getCurrentBlock() {
        MovingObjectPosition movingObjectPosition = MinecraftInstance.mc.field_71476_x;
        Object object = movingObjectPosition == null ? null : movingObjectPosition.func_178782_a();
        if (object == null) {
            return null;
        }
        BlockPos blockPos = object;
        if (BlockUtils.canBeClicked(blockPos) && MinecraftInstance.mc.field_71441_e.func_175723_af().func_177746_a(blockPos)) {
            return blockPos;
        }
        return null;
    }

    @EventTarget
    public final void onRender3D(Render3DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        BlockPos blockPos = this.getCurrentBlock();
        if (blockPos == null) {
            return;
        }
        BlockPos blockPos2 = blockPos;
        Block block = MinecraftInstance.mc.field_71441_e.func_180495_p(blockPos2).func_177230_c();
        if (block == null) {
            return;
        }
        Block block2 = block;
        float partialTicks = event.getPartialTicks();
        Color color = (Boolean)this.colorRainbow.get() != false ? ColorUtils.rainbow(0.4f) : new Color(((Number)this.colorRedValue.get()).intValue(), ((Number)this.colorGreenValue.get()).intValue(), ((Number)this.colorBlueValue.get()).intValue(), 102);
        GlStateManager.func_179147_l();
        GlStateManager.func_179120_a((int)770, (int)771, (int)1, (int)0);
        RenderUtils.glColor(color);
        GL11.glLineWidth((float)2.0f);
        GlStateManager.func_179090_x();
        GlStateManager.func_179132_a((boolean)false);
        block2.func_180654_a((IBlockAccess)MinecraftInstance.mc.field_71441_e, blockPos2);
        double x = MinecraftInstance.mc.field_71439_g.field_70142_S + (MinecraftInstance.mc.field_71439_g.field_70165_t - MinecraftInstance.mc.field_71439_g.field_70142_S) * (double)partialTicks;
        double y = MinecraftInstance.mc.field_71439_g.field_70137_T + (MinecraftInstance.mc.field_71439_g.field_70163_u - MinecraftInstance.mc.field_71439_g.field_70137_T) * (double)partialTicks;
        double z = MinecraftInstance.mc.field_71439_g.field_70136_U + (MinecraftInstance.mc.field_71439_g.field_70161_v - MinecraftInstance.mc.field_71439_g.field_70136_U) * (double)partialTicks;
        AxisAlignedBB axisAlignedBB = block2.func_180646_a((World)MinecraftInstance.mc.field_71441_e, blockPos2).func_72314_b((double)0.002f, (double)0.002f, (double)0.002f).func_72317_d(-x, -y, -z);
        RenderUtils.drawSelectionBoundingBox(axisAlignedBB);
        RenderUtils.drawFilledBox(axisAlignedBB);
        GlStateManager.func_179132_a((boolean)true);
        GlStateManager.func_179098_w();
        GlStateManager.func_179084_k();
        GlStateManager.func_179117_G();
    }

    @EventTarget
    public final void onRender2D(Render2DEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.infoValue.get()).booleanValue()) {
            BlockPos blockPos = this.getCurrentBlock();
            if (blockPos == null) {
                return;
            }
            BlockPos blockPos2 = blockPos;
            Block block = BlockUtils.getBlock(blockPos2);
            if (block == null) {
                return;
            }
            Block block2 = block;
            String info = block2.func_149732_F() + " \u00a77ID: " + Block.func_149682_b((Block)block2);
            ScaledResolution scaledResolution = new ScaledResolution(MinecraftInstance.mc);
            GlStateManager.func_179117_G();
            Fonts.fontSFUI40.drawCenteredString(info, (float)scaledResolution.func_78326_a() / 2.0f, (float)scaledResolution.func_78328_b() / 2.0f + 6.0f, Color.WHITE.getRGB());
        }
    }
}

