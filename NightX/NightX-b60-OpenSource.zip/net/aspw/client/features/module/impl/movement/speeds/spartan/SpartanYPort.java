/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.spartan;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class SpartanYPort
extends SpeedMode {
    private int airMoves;

    public SpartanYPort() {
        super("SpartanYPort");
    }

    @Override
    public void onMotion() {
        if (!SpartanYPort.mc.field_71474_y.field_74314_A.func_151470_d() && MovementUtils.isMoving()) {
            if (SpartanYPort.mc.field_71439_g.field_70122_E) {
                SpartanYPort.mc.field_71439_g.func_70664_aZ();
                this.airMoves = 0;
            } else {
                SpartanYPort.mc.field_71428_T.field_74278_d = 1.08f;
                if (this.airMoves >= 3) {
                    SpartanYPort.mc.field_71439_g.field_70747_aH = 0.0275f;
                }
                if (this.airMoves >= 4 && (double)(this.airMoves % 2) == 0.0) {
                    SpartanYPort.mc.field_71439_g.field_70181_x = (double)-0.32f - 0.009 * Math.random();
                    SpartanYPort.mc.field_71439_g.field_70747_aH = 0.0238f;
                }
                ++this.airMoves;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

