/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C0BPacketEntityAction
 *  net.minecraft.network.play.client.C0BPacketEntityAction$Action
 */
package net.aspw.client.features.module.impl.combat;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;

@ModuleInfo(name="KeepSprint", spacedName="Keep Sprint", description="", category=ModuleCategory.COMBAT)
public final class KeepSprint
extends Module {
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof C0BPacketEntityAction && ((C0BPacketEntityAction)packet).func_180764_b() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
            event.cancelEvent();
        }
    }
}

