/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.AxisAlignedBB
 */
package net.aspw.client.features.module.impl.movement.speeds.ncp;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;

public class NCPBoost
extends SpeedMode {
    private int motionDelay;
    private float ground;

    public NCPBoost() {
        super("NCPBoost");
    }

    @Override
    public void onMotion() {
        double speed2 = 3.1981;
        double offset = 4.69;
        boolean shouldOffset = true;
        for (Object o : NCPBoost.mc.field_71441_e.func_72945_a((Entity)NCPBoost.mc.field_71439_g, NCPBoost.mc.field_71439_g.func_174813_aQ().func_72317_d(NCPBoost.mc.field_71439_g.field_70159_w / offset, 0.0, NCPBoost.mc.field_71439_g.field_70179_y / offset))) {
            if (!(o instanceof AxisAlignedBB)) continue;
            shouldOffset = false;
            break;
        }
        if (NCPBoost.mc.field_71439_g.field_70122_E && this.ground < 1.0f) {
            this.ground += 0.2f;
        }
        if (!NCPBoost.mc.field_71439_g.field_70122_E) {
            this.ground = 0.0f;
        }
        if (this.ground == 1.0f && this.shouldSpeedUp()) {
            if (!NCPBoost.mc.field_71439_g.func_70051_ag()) {
                offset += 0.8;
            }
            if (NCPBoost.mc.field_71439_g.field_70702_br != 0.0f) {
                speed2 -= 0.1;
                offset += 0.5;
            }
            if (NCPBoost.mc.field_71439_g.func_70090_H()) {
                speed2 -= 0.1;
            }
            ++this.motionDelay;
            switch (this.motionDelay) {
                case 1: {
                    NCPBoost.mc.field_71439_g.field_70159_w *= speed2;
                    NCPBoost.mc.field_71439_g.field_70179_y *= speed2;
                    break;
                }
                case 2: {
                    NCPBoost.mc.field_71439_g.field_70159_w /= 1.458;
                    NCPBoost.mc.field_71439_g.field_70179_y /= 1.458;
                    break;
                }
                case 4: {
                    if (shouldOffset) {
                        NCPBoost.mc.field_71439_g.func_70107_b(NCPBoost.mc.field_71439_g.field_70165_t + NCPBoost.mc.field_71439_g.field_70159_w / offset, NCPBoost.mc.field_71439_g.field_70163_u, NCPBoost.mc.field_71439_g.field_70161_v + NCPBoost.mc.field_71439_g.field_70179_y / offset);
                    }
                    this.motionDelay = 0;
                }
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }

    private boolean shouldSpeedUp() {
        return !NCPBoost.mc.field_71439_g.func_70090_H() && !NCPBoost.mc.field_71439_g.func_70617_f_() && !NCPBoost.mc.field_71439_g.func_70093_af() && MovementUtils.isMoving();
    }
}

