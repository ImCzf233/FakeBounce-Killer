/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.effect.EntityLightningBolt
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity
 *  net.minecraft.util.EnumParticleTypes
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.world.World
 */
package net.aspw.client.features.module.impl.other;

import java.util.Locale;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.EntityUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

@ModuleInfo(name="MoreParticles", spacedName="More Particles", description="", category=ModuleCategory.OTHER)
public final class MoreParticles
extends Module {
    private final ListValue modeValue;
    private final IntegerValue timesValue;
    private final BoolValue soundValue;
    private final int blockState;

    public MoreParticles() {
        String[] stringArray = new String[]{"Thunder", "Blood", "Fire", "Criticals", "Sharpness"};
        this.modeValue = new ListValue("Mode", stringArray, "Blood");
        this.timesValue = new IntegerValue("Multi", 1, 1, 10);
        this.soundValue = new BoolValue("Sound", false, (Function0<Boolean>)((Function0)new Function0<Boolean>(this){
            final /* synthetic */ MoreParticles this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final Boolean invoke() {
                return StringsKt.equals((String)((String)MoreParticles.access$getModeValue$p(this.this$0).get()), (String)"thunder", (boolean)true);
            }
        }));
        this.blockState = Block.func_176210_f((IBlockState)Blocks.field_150451_bX.func_176223_P());
    }

    @EventTarget
    public final void onAttack(AttackEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (EntityUtils.isSelected(event.getTargetEntity(), true)) {
            Entity entity = event.getTargetEntity();
            if (entity == null) {
                throw new NullPointerException("null cannot be cast to non-null type net.minecraft.entity.EntityLivingBase");
            }
            this.displayEffectFor((EntityLivingBase)entity);
        }
    }

    private final void displayEffectFor(EntityLivingBase entity) {
        int n = ((Number)this.timesValue.get()).intValue();
        int n2 = 0;
        while (n2 < n) {
            int n3;
            int it = n3 = n2++;
            boolean bl = false;
            String string = ((String)this.modeValue.get()).toLowerCase(Locale.ROOT);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(Locale.ROOT)");
            switch (string) {
                case "thunder": {
                    MinecraftInstance.mc.func_147114_u().func_147292_a(new S2CPacketSpawnGlobalEntity((Entity)new EntityLightningBolt((World)MinecraftInstance.mc.field_71441_e, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v)));
                    if (!((Boolean)this.soundValue.get()).booleanValue()) break;
                    MinecraftInstance.mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a((ResourceLocation)new ResourceLocation("random.explode"), (float)1.0f));
                    MinecraftInstance.mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_147674_a((ResourceLocation)new ResourceLocation("ambient.weather.thunder"), (float)1.0f));
                    break;
                }
                case "blood": {
                    int n4 = 10;
                    int n5 = 0;
                    while (n5 < n4) {
                        int n6;
                        int it2 = n6 = n5++;
                        boolean bl2 = false;
                        int[] nArray = new int[]{this.blockState};
                        MinecraftInstance.mc.field_71452_i.func_178927_a(EnumParticleTypes.BLOCK_CRACK.func_179348_c(), entity.field_70165_t, entity.field_70163_u + (double)(entity.field_70131_O / (float)2), entity.field_70161_v, entity.field_70159_w + (double)RandomUtils.nextFloat(-0.5f, 0.5f), entity.field_70181_x + (double)RandomUtils.nextFloat(-0.5f, 0.5f), entity.field_70179_y + (double)RandomUtils.nextFloat(-0.5f, 0.5f), nArray);
                    }
                    break;
                }
                case "fire": {
                    MinecraftInstance.mc.field_71452_i.func_178926_a((Entity)entity, EnumParticleTypes.LAVA);
                    break;
                }
                case "criticals": {
                    MinecraftInstance.mc.field_71452_i.func_178926_a((Entity)entity, EnumParticleTypes.CRIT);
                    break;
                }
                case "sharpness": {
                    MinecraftInstance.mc.field_71452_i.func_178926_a((Entity)entity, EnumParticleTypes.CRIT_MAGIC);
                }
            }
        }
    }

    public static final /* synthetic */ ListValue access$getModeValue$p(MoreParticles $this) {
        return $this.modeValue;
    }
}

