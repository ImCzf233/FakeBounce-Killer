/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AACYPort2
extends SpeedMode {
    public AACYPort2() {
        super("AACYPort2");
    }

    @Override
    public void onMotion() {
        if (MovementUtils.isMoving() && AACYPort2.mc.field_71439_g.field_70122_E) {
            AACYPort2.mc.field_71439_g.func_70664_aZ();
            AACYPort2.mc.field_71439_g.field_70181_x = 0.3851f;
            AACYPort2.mc.field_71439_g.field_70159_w *= 1.01;
            AACYPort2.mc.field_71439_g.field_70179_y *= 1.01;
        } else {
            AACYPort2.mc.field_71439_g.field_70181_x = -0.21;
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

