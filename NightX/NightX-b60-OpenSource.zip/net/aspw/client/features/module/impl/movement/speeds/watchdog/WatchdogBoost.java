/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.watchdog;

import net.aspw.client.Client;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class WatchdogBoost
extends SpeedMode {
    public WatchdogBoost() {
        super("WatchdogBoost");
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Speed speed2 = Client.moduleManager.getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        WatchdogBoost.mc.field_71428_T.field_74278_d = 1.0f;
        if (MovementUtils.isMoving() && !WatchdogBoost.mc.field_71439_g.func_70090_H() && !WatchdogBoost.mc.field_71439_g.func_180799_ab() && !WatchdogBoost.mc.field_71474_y.field_74314_A.func_151470_d()) {
            double moveSpeed = Math.max(MovementUtils.getBaseMoveSpeed() * (double)((Float)speed2.baseStrengthValue.get()).floatValue(), (double)MovementUtils.getSpeed());
            if (WatchdogBoost.mc.field_71439_g.field_70122_E) {
                if (((Boolean)speed2.sendJumpValue.get()).booleanValue()) {
                    WatchdogBoost.mc.field_71439_g.func_70664_aZ();
                }
                if (((Boolean)speed2.recalcValue.get()).booleanValue()) {
                    moveSpeed = Math.max(MovementUtils.getBaseMoveSpeed() * (double)((Float)speed2.baseStrengthValue.get()).floatValue(), (double)MovementUtils.getSpeed());
                }
                WatchdogBoost.mc.field_71439_g.field_70181_x = MovementUtils.getJumpBoostModifier(WatchdogBoost.mc.field_71439_g.field_70123_F ? 0.41999998688698 : (double)((Float)speed2.jumpYValue.get()).floatValue());
                event.setY(WatchdogBoost.mc.field_71439_g.field_70181_x);
                moveSpeed *= (double)((Float)speed2.moveSpeedValue.get()).floatValue();
            } else if (((Float)speed2.glideStrengthValue.get()).floatValue() > 0.0f && event.getY() < 0.0) {
                event.setY(WatchdogBoost.mc.field_71439_g.field_70181_x += (double)((Float)speed2.glideStrengthValue.get()).floatValue());
            }
            WatchdogBoost.mc.field_71428_T.field_74278_d = Math.max(((Float)speed2.baseTimerValue.get()).floatValue() + Math.abs((float)WatchdogBoost.mc.field_71439_g.field_70181_x) * ((Float)speed2.baseMTimerValue.get()).floatValue(), 1.0f);
        }
    }
}

