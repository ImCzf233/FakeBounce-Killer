/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmField
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  net.minecraft.client.Minecraft
 *  org.lwjgl.opengl.Display
 */
package net.aspw.client.features.module.impl.other;

import kotlin.jvm.JvmField;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.DefaultConstructorMarker;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

@ModuleInfo(name="FreeLook", spacedName="Free Look", description="", category=ModuleCategory.OTHER, array=false)
public final class FreeLook
extends Module {
    public static final Companion Companion = new Companion(null);
    private static final Minecraft mc = Minecraft.func_71410_x();
    @JvmField
    public static boolean perspectiveToggled;
    @JvmField
    public static float cameraYaw;
    @JvmField
    public static float cameraPitch;
    private static int previousPerspective;

    @Override
    public void onEnable() {
        perspectiveToggled = !perspectiveToggled;
        cameraYaw = FreeLook.mc.field_71439_g.field_70177_z;
        cameraPitch = FreeLook.mc.field_71439_g.field_70125_A;
        if (perspectiveToggled) {
            previousPerspective = FreeLook.mc.field_71474_y.field_74320_O;
        } else {
            FreeLook.mc.field_71474_y.field_74320_O = previousPerspective;
        }
    }

    @Override
    public void onDisable() {
        Companion.resetPerspective();
    }

    @JvmStatic
    public static final boolean overrideMouse() {
        return Companion.overrideMouse();
    }

    public static final class Companion {
        private Companion() {
        }

        @JvmStatic
        public final boolean overrideMouse() {
            if (mc.field_71415_G && Display.isActive()) {
                if (!perspectiveToggled) {
                    return true;
                }
                mc.field_71417_B.func_74374_c();
                float f1 = mc.field_71474_y.field_74341_c * 0.6f + 0.2f;
                float f2 = f1 * f1 * f1 * 8.0f;
                float f3 = (float)mc.field_71417_B.field_74377_a * f2;
                float f4 = (float)mc.field_71417_B.field_74375_b * f2;
                cameraYaw += f3 * 0.15f;
                cameraPitch -= f4 * 0.15f;
                if (cameraPitch > 90.0f) {
                    cameraPitch = 90.0f;
                }
                if (cameraPitch < -90.0f) {
                    cameraPitch = -90.0f;
                }
            }
            return false;
        }

        public final void resetPerspective() {
            perspectiveToggled = false;
            mc.field_71474_y.field_74320_O = previousPerspective;
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

