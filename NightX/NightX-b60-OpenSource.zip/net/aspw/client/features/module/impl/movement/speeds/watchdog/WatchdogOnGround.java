/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.potion.Potion
 *  net.minecraft.stats.StatList
 */
package net.aspw.client.features.module.impl.movement.speeds.watchdog;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.event.EventState;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.Speed;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;
import net.minecraft.potion.Potion;
import net.minecraft.stats.StatList;

public final class WatchdogOnGround
extends SpeedMode {
    public WatchdogOnGround() {
        super("WatchdogOnGround");
    }

    @Override
    public void onJump(JumpEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (SpeedMode.mc.field_71439_g != null && MovementUtils.isMoving()) {
            event.cancelEvent();
        }
    }

    @Override
    public void onMotion(MotionEvent eventMotion) {
        Intrinsics.checkNotNullParameter((Object)eventMotion, (String)"eventMotion");
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null || eventMotion.getEventState() != EventState.PRE || SpeedMode.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving() && SpeedMode.mc.field_71439_g.field_70122_E) {
            SpeedMode.mc.field_71439_g.field_70181_x = 0.41999998688698;
            SpeedMode.mc.field_71439_g.field_70160_al = true;
            SpeedMode.mc.field_71439_g.func_71029_a(StatList.field_75953_u);
            if (SpeedMode.mc.field_71439_g.func_70644_a(Potion.field_76424_c)) {
                MovementUtils.strafe(0.578f);
            } else {
                MovementUtils.strafe(0.428f);
            }
        }
    }

    @Override
    public void onEnable() {
        Speed speed2 = Client.INSTANCE.getModuleManager().getModule(Speed.class);
        if (speed2 == null) {
            return;
        }
        super.onEnable();
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMotion() {
    }

    @Override
    public void onMove(MoveEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
    }
}

