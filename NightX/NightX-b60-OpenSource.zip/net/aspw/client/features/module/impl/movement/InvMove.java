/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.gui.GuiIngameMenu
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.client.settings.GameSettings
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer
 *  net.minecraft.network.play.client.C16PacketClientStatus
 *  net.minecraft.network.play.client.C16PacketClientStatus$EnumState
 */
package net.aspw.client.features.module.impl.movement;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.event.ClickWindowEvent;
import net.aspw.client.event.EventState;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.MovementUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.ListValue;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C16PacketClientStatus;

@ModuleInfo(name="InvMove", spacedName="Inv Move", description="", category=ModuleCategory.MOVEMENT)
public final class InvMove
extends Module {
    private final ListValue modeValue;
    private final BoolValue noDetectableValue;
    private final BoolValue noMoveClicksValue;
    private final List<C03PacketPlayer> playerPackets;

    public InvMove() {
        String[] stringArray = new String[]{"Vanilla", "Silent", "Blink"};
        this.modeValue = new ListValue("Mode", stringArray, "Silent");
        this.noDetectableValue = new BoolValue("NoDetectable", false);
        this.noMoveClicksValue = new BoolValue("NoMoveClicks", false);
        this.playerPackets = new ArrayList();
    }

    public final ListValue getModeValue() {
        return this.modeValue;
    }

    @Override
    public String getTag() {
        return (String)this.modeValue.get();
    }

    @EventTarget
    public final void onUpdate(UpdateEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (!(MinecraftInstance.mc.field_71462_r instanceof GuiChat || MinecraftInstance.mc.field_71462_r instanceof GuiIngameMenu || ((Boolean)this.noDetectableValue.get()).booleanValue() && MinecraftInstance.mc.field_71462_r instanceof GuiContainer)) {
            MinecraftInstance.mc.field_71474_y.field_74351_w.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74351_w);
            MinecraftInstance.mc.field_71474_y.field_74368_y.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74368_y);
            MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74366_z);
            MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74370_x);
            MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A);
            MinecraftInstance.mc.field_71474_y.field_151444_V.field_74513_e = GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_151444_V);
        }
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (event.getEventState() == EventState.PRE && this.playerPackets.size() > 0 && (MinecraftInstance.mc.field_71462_r == null || MinecraftInstance.mc.field_71462_r instanceof GuiChat || MinecraftInstance.mc.field_71462_r instanceof GuiIngameMenu || ((Boolean)this.noDetectableValue.get()).booleanValue() && MinecraftInstance.mc.field_71462_r instanceof GuiContainer)) {
            Iterable $this$forEach$iv = this.playerPackets;
            boolean $i$f$forEach = false;
            for (Object element$iv : $this$forEach$iv) {
                C03PacketPlayer it = (C03PacketPlayer)element$iv;
                boolean bl = false;
                MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)it);
            }
            this.playerPackets.clear();
        }
    }

    @EventTarget
    public final void onClick(ClickWindowEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (((Boolean)this.noMoveClicksValue.get()).booleanValue() && MovementUtils.isMoving()) {
            event.cancelEvent();
        }
    }

    @EventTarget
    public final void onPacket(PacketEvent event) {
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        Packet<?> packet = event.getPacket();
        String string = (String)this.modeValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        String string3 = string2;
        if (string3.equals("silent")) {
            if (packet instanceof C16PacketClientStatus && ((C16PacketClientStatus)packet).func_149435_c() == C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT) {
                event.cancelEvent();
            }
        } else if (!(!string3.equals("blink") || MinecraftInstance.mc.field_71462_r == null || MinecraftInstance.mc.field_71462_r instanceof GuiChat || MinecraftInstance.mc.field_71462_r instanceof GuiIngameMenu || ((Boolean)this.noDetectableValue.get()).booleanValue() && MinecraftInstance.mc.field_71462_r instanceof GuiContainer || !(packet instanceof C03PacketPlayer))) {
            event.cancelEvent();
            this.playerPackets.add((C03PacketPlayer)packet);
        }
    }

    @Override
    public void onDisable() {
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74351_w) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_74351_w.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74368_y) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_74368_y.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74366_z) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_74366_z.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74370_x) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_74370_x.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_74314_A) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_74314_A.field_74513_e = false;
        }
        if (!GameSettings.func_100015_a((KeyBinding)MinecraftInstance.mc.field_71474_y.field_151444_V) || MinecraftInstance.mc.field_71462_r != null) {
            MinecraftInstance.mc.field_71474_y.field_151444_V.field_74513_e = false;
        }
    }
}

