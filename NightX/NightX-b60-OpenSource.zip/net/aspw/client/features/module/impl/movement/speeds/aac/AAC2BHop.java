/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.features.module.impl.movement.speeds.aac;

import net.aspw.client.event.MoveEvent;
import net.aspw.client.features.module.impl.movement.speeds.SpeedMode;
import net.aspw.client.util.MovementUtils;

public class AAC2BHop
extends SpeedMode {
    public AAC2BHop() {
        super("AAC2BHop");
    }

    @Override
    public void onMotion() {
        if (AAC2BHop.mc.field_71439_g.func_70090_H()) {
            return;
        }
        if (MovementUtils.isMoving()) {
            if (AAC2BHop.mc.field_71439_g.field_70122_E) {
                AAC2BHop.mc.field_71439_g.func_70664_aZ();
                AAC2BHop.mc.field_71439_g.field_70159_w *= 1.02;
                AAC2BHop.mc.field_71439_g.field_70179_y *= 1.02;
            } else if (AAC2BHop.mc.field_71439_g.field_70181_x > -0.2) {
                AAC2BHop.mc.field_71439_g.field_70747_aH = 0.08f;
                AAC2BHop.mc.field_71439_g.field_70181_x += 0.01431;
                AAC2BHop.mc.field_71439_g.field_70747_aH = 0.07f;
            }
        }
    }

    @Override
    public void onUpdate() {
    }

    @Override
    public void onMove(MoveEvent event) {
    }
}

