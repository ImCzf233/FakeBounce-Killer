/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.features.command;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.command.impl.BindCommand;
import net.aspw.client.features.command.impl.BindsCommand;
import net.aspw.client.features.command.impl.ClipCommand;
import net.aspw.client.features.command.impl.ConfigCommand;
import net.aspw.client.features.command.impl.DamageCommand;
import net.aspw.client.features.command.impl.EnchantCommand;
import net.aspw.client.features.command.impl.FriendCommand;
import net.aspw.client.features.command.impl.GiveCommand;
import net.aspw.client.features.command.impl.HelpCommand;
import net.aspw.client.features.command.impl.HideCommand;
import net.aspw.client.features.command.impl.IgnCommand;
import net.aspw.client.features.command.impl.LoginCommand;
import net.aspw.client.features.command.impl.MacroCommand;
import net.aspw.client.features.command.impl.MagicTrickCommand;
import net.aspw.client.features.command.impl.PingCommand;
import net.aspw.client.features.command.impl.PluginsCommand;
import net.aspw.client.features.command.impl.RegisterCommand;
import net.aspw.client.features.command.impl.ReloadCommand;
import net.aspw.client.features.command.impl.RemoteViewCommand;
import net.aspw.client.features.command.impl.RenameCommand;
import net.aspw.client.features.command.impl.RepeatCommand;
import net.aspw.client.features.command.impl.SayCommand;
import net.aspw.client.features.command.impl.SkinStealerCommand;
import net.aspw.client.features.command.impl.TeleportCommand;
import net.aspw.client.features.command.impl.ThemeCommand;
import net.aspw.client.features.command.impl.ToggleCommand;
import net.aspw.client.features.command.impl.VClipCommand;
import net.aspw.client.util.ClientUtils;
import org.jetbrains.annotations.Nullable;

public final class CommandManager {
    private final List<Command> commands = new ArrayList();

    public final List<Command> getCommands() {
        return this.commands;
    }

    public final void registerCommands() {
        this.registerCommand(new BindCommand());
        this.registerCommand(new VClipCommand());
        this.registerCommand(new SayCommand());
        this.registerCommand(new MacroCommand());
        this.registerCommand(new FriendCommand());
        this.registerCommand(new ConfigCommand());
        this.registerCommand(new ToggleCommand());
        this.registerCommand(new BindsCommand());
        this.registerCommand(new PingCommand());
        this.registerCommand(new ReloadCommand());
        this.registerCommand(new HideCommand());
        this.registerCommand(new TeleportCommand());
        this.registerCommand(new EnchantCommand());
        this.registerCommand(new GiveCommand());
        this.registerCommand(new DamageCommand());
        this.registerCommand(new RemoteViewCommand());
        this.registerCommand(new RenameCommand());
        this.registerCommand(new IgnCommand());
        this.registerCommand(new ThemeCommand());
        this.registerCommand(new LoginCommand());
        this.registerCommand(new ClipCommand());
        this.registerCommand(new RegisterCommand());
        this.registerCommand(new RepeatCommand());
        this.registerCommand(new MagicTrickCommand());
        this.registerCommand(new PluginsCommand());
        this.registerCommand(new SkinStealerCommand());
        this.registerCommand(new HelpCommand());
    }

    public final void executeCommands(String input) {
        Intrinsics.checkNotNullParameter((Object)input, (String)"input");
        for (Command command : this.commands) {
            String[] args;
            String[] stringArray = new String[]{" "};
            Collection $this$toTypedArray$iv = StringsKt.split$default((CharSequence)input, (String[])stringArray, (boolean)false, (int)0, (int)6, null);
            boolean $i$f$toTypedArray = false;
            Collection thisCollection$iv = $this$toTypedArray$iv;
            if (thisCollection$iv.toArray(new String[0]) == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
            }
            if (StringsKt.equals((String)args[0], (String)Intrinsics.stringPlus((String)".", (Object)command.getCommand()), (boolean)true)) {
                command.execute(args);
                return;
            }
            for (String alias : command.getAlias()) {
                if (!StringsKt.equals((String)args[0], (String)Intrinsics.stringPlus((String)".", (Object)alias), (boolean)true)) continue;
                command.execute(args);
                return;
            }
        }
        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a7cUnknown command. Try .help for a list of commands.");
    }

    public final boolean registerCommand(Command command) {
        Intrinsics.checkNotNullParameter((Object)command, (String)"command");
        return this.commands.add(command);
    }

    public final boolean unregisterCommand(@Nullable Command command) {
        return ((Collection)this.commands).remove(command);
    }
}

