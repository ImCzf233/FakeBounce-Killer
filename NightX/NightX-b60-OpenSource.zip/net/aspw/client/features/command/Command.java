/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.jetbrains.annotations.NotNull
 */
package net.aspw.client.features.command;

import java.util.Locale;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import org.jetbrains.annotations.NotNull;

public abstract class Command
extends MinecraftInstance {
    private final String command;
    private final String[] alias;

    public Command(String command, String[] alias) {
        Intrinsics.checkNotNullParameter((Object)command, (String)"command");
        Intrinsics.checkNotNullParameter((Object)alias, (String)"alias");
        this.command = command;
        this.alias = alias;
    }

    public final String getCommand() {
        return this.command;
    }

    public final String[] getAlias() {
        return this.alias;
    }

    public abstract void execute(@NotNull String[] var1);

    public final void chat(String msg) {
        Intrinsics.checkNotNullParameter((Object)msg, (String)"msg");
        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a73", (Object)msg));
    }

    protected final void chatSyntax(String syntax) {
        Intrinsics.checkNotNullParameter((Object)syntax, (String)"syntax");
        ClientUtils.displayChatMessage(Intrinsics.stringPlus((String)"\u00a7c\u00a7l>> \u00a7r\u00a7r\u00a7cSyntax: \u00a77.", (Object)syntax));
    }

    protected final void chatSyntax(String[] syntaxes) {
        Intrinsics.checkNotNullParameter((Object)syntaxes, (String)"syntaxes");
        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a73Syntax:");
        for (String syntax : syntaxes) {
            StringBuilder stringBuilder = new StringBuilder().append("\u00a78> \u00a77.").append(this.command).append(' ');
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            String string = syntax.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).toLowerCase(locale)");
            ClientUtils.displayChatMessage(stringBuilder.append(string).toString());
        }
    }

    protected final void chatSyntaxError() {
        ClientUtils.displayChatMessage("\u00a7c\u00a7l>> \u00a7r\u00a73Syntax error");
    }
}

