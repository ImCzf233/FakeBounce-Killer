/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;

public final class EnchantCommand
extends Command {
    public EnchantCommand() {
        boolean $i$f$emptyArray = false;
        super("enchant", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 2) {
            int n;
            int n2;
            if (MinecraftInstance.mc.field_71442_b.func_78762_g()) {
                this.chat("\u00a7c\u00a7lError: \u00a73You need to be in creative mode.");
                return;
            }
            ItemStack item = MinecraftInstance.mc.field_71439_g.func_70694_bm();
            if (item == null || item.func_77973_b() == null) {
                this.chat("\u00a7c\u00a7lError: \u00a73You need to hold an item.");
                return;
            }
            try {
                n2 = Integer.parseInt(args[1]);
            }
            catch (NumberFormatException e) {
                Enchantment enchantment = Enchantment.func_180305_b((String)args[1]);
                if (enchantment == null) {
                    this.chat("There is no enchantment with the name '" + args[1] + '\'');
                    return;
                }
                n2 = enchantment.field_77352_x;
            }
            int enchantID = n2;
            Enchantment enchantment = Enchantment.func_180306_c((int)enchantID);
            if (enchantment == null) {
                this.chat("There is no enchantment with the ID '" + enchantID + '\'');
                return;
            }
            try {
                n = Integer.parseInt(args[2]);
            }
            catch (NumberFormatException e) {
                this.chatSyntaxError();
                return;
            }
            int level = n;
            item.func_77966_a(enchantment, level);
            this.chat(enchantment.func_77316_c(level) + " added to " + item.func_82833_r() + '.');
            return;
        }
        this.chatSyntax("enchant <type> [level]");
    }
}

