/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.entity.Entity
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;
import net.minecraft.entity.Entity;

public final class ClipCommand
extends Command {
    public ClipCommand() {
        boolean $i$f$emptyArray = false;
        super("clip", new String[0]);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            try {
                double y = Double.parseDouble(args[1]);
                Entity entity = MinecraftInstance.mc.field_71439_g.func_70115_ae() ? MinecraftInstance.mc.field_71439_g.field_70154_o : (Entity)MinecraftInstance.mc.field_71439_g;
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                entity.func_70107_b(entity.field_70165_t, entity.field_70163_u + y, entity.field_70161_v);
                Client.INSTANCE.getHud().addNotification(new Notification("Successfully Teleported!", Notification.Type.SUCCESS));
            }
            catch (NumberFormatException ex) {
                this.chatSyntaxError();
            }
            return;
        }
        this.chatSyntax("clip <value>");
    }
}

