/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.collections.ArraysKt
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.block.Block
 */
package net.aspw.client.features.command.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.command.impl.ModuleCommand;
import net.aspw.client.features.module.Module;
import net.aspw.client.util.block.BlockUtils;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.value.BlockValue;
import net.aspw.client.value.BoolValue;
import net.aspw.client.value.FloatValue;
import net.aspw.client.value.FontValue;
import net.aspw.client.value.IntegerValue;
import net.aspw.client.value.ListValue;
import net.aspw.client.value.TextValue;
import net.aspw.client.value.Value;
import net.minecraft.block.Block;

public final class ModuleCommand
extends Command {
    private final Module module;
    private final List<Value<?>> values;

    public ModuleCommand(Module module, List<? extends Value<?>> values) {
        Intrinsics.checkNotNullParameter((Object)module, (String)"module");
        Intrinsics.checkNotNullParameter(values, (String)"values");
        String string = module.getName();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"this as java.lang.String).toLowerCase(locale)");
        boolean $i$f$emptyArray = false;
        super(string2, new String[0]);
        this.module = module;
        this.values = values;
        if (this.values.isEmpty()) {
            throw new IllegalArgumentException("Values are empty!");
        }
    }

    public /* synthetic */ ModuleCommand(Module module, List list, int n, DefaultConstructorMarker defaultConstructorMarker) {
        if ((n & 2) != 0) {
            list = module.getValues();
        }
        this(module, list);
    }

    public final Module getModule() {
        return this.module;
    }

    public final List<Value<?>> getValues() {
        return this.values;
    }

    @Override
    public void execute(String[] args) {
        Locale $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        Iterable $this$filter$iv = this.values;
        boolean $i$f$filter = false;
        Iterable iterable = $this$filter$iv;
        Object destination$iv$iv = new ArrayList();
        boolean $i$f$filterTo2 = false;
        Object object = $this$filterTo$iv$iv.iterator();
        while (object.hasNext()) {
            Object element$iv$iv = object.next();
            Value it = (Value)element$iv$iv;
            boolean bl = false;
            if (!(!(it instanceof FontValue))) continue;
            destination$iv$iv.add(element$iv$iv);
        }
        String valueNames2 = CollectionsKt.joinToString$default((Iterable)((List)destination$iv$iv), (CharSequence)"/", null, null, (int)0, null, (Function1)execute.valueNames.2.INSTANCE, (int)30, null);
        String string = this.module.getName();
        $this$filterTo$iv$iv = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue((Object)$this$filterTo$iv$iv, (String)"getDefault()");
        destination$iv$iv = string.toLowerCase($this$filterTo$iv$iv);
        Intrinsics.checkNotNullExpressionValue((Object)destination$iv$iv, (String)"this as java.lang.String).toLowerCase(locale)");
        Object moduleName = destination$iv$iv;
        if (args.length < 2) {
            this.chatSyntax(this.values.size() == 1 ? (String)moduleName + ' ' + valueNames2 + " <value>" : (String)moduleName + " <" + valueNames2 + '>');
            return;
        }
        Value<?> value = this.module.getValue(args[1]);
        if (value == null) {
            this.chatSyntax((String)moduleName + " <" + valueNames2 + '>');
            return;
        }
        if (value instanceof BoolValue) {
            boolean newValue = (Boolean)((BoolValue)value).get() == false;
            ((BoolValue)value).set(newValue);
            this.chat("\u00a77" + this.module.getName() + " \u00a78" + args[1] + "\u00a77 was toggled " + (newValue ? "\u00a78on\u00a77" : "\u00a78off\u00a77."));
        } else {
            if (args.length < 3) {
                if (value instanceof IntegerValue || value instanceof FloatValue || value instanceof TextValue) {
                    StringBuilder stringBuilder = new StringBuilder().append((String)moduleName).append(' ');
                    String string2 = args[1];
                    destination$iv$iv = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)destination$iv$iv, (String)"getDefault()");
                    String $i$f$filterTo2 = string2.toLowerCase((Locale)destination$iv$iv);
                    Intrinsics.checkNotNullExpressionValue((Object)$i$f$filterTo2, (String)"this as java.lang.String).toLowerCase(locale)");
                    this.chatSyntax(stringBuilder.append($i$f$filterTo2).append(" <value>").toString());
                } else if (value instanceof ListValue) {
                    StringBuilder stringBuilder = new StringBuilder().append((String)moduleName).append(' ');
                    String string3 = args[1];
                    destination$iv$iv = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)destination$iv$iv, (String)"getDefault()");
                    String $i$f$filterTo2 = string3.toLowerCase((Locale)destination$iv$iv);
                    Intrinsics.checkNotNullExpressionValue((Object)$i$f$filterTo2, (String)"this as java.lang.String).toLowerCase(locale)");
                    StringBuilder stringBuilder2 = stringBuilder.append($i$f$filterTo2).append(" <");
                    String string4 = ArraysKt.joinToString$default((Object[])((ListValue)value).getValues(), (CharSequence)"/", null, null, (int)0, null, null, (int)62, null);
                    destination$iv$iv = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)destination$iv$iv, (String)"getDefault()");
                    $i$f$filterTo2 = string4.toLowerCase((Locale)destination$iv$iv);
                    Intrinsics.checkNotNullExpressionValue((Object)$i$f$filterTo2, (String)"this as java.lang.String).toLowerCase(locale)");
                    this.chatSyntax(stringBuilder2.append($i$f$filterTo2).append('>').toString());
                }
                return;
            }
            try {
                Value<?> newValue = value;
                if (newValue instanceof BlockValue) {
                    int id;
                    block22: {
                        id = 0;
                        try {
                            id = Integer.parseInt(args[2]);
                        }
                        catch (NumberFormatException exception) {
                            id = Block.func_149682_b((Block)Block.func_149684_b((String)args[2]));
                            if (id > 0) break block22;
                            this.chat("\u00a77Block \u00a78" + args[2] + "\u00a77 does not exist!");
                            return;
                        }
                    }
                    ((BlockValue)value).set(id);
                    StringBuilder stringBuilder = new StringBuilder().append("\u00a77").append(this.module.getName()).append(" \u00a78");
                    String string5 = args[1];
                    object = Locale.getDefault();
                    Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getDefault()");
                    String string6 = string5.toLowerCase((Locale)object);
                    Intrinsics.checkNotNullExpressionValue((Object)string6, (String)"this as java.lang.String).toLowerCase(locale)");
                    this.chat(stringBuilder.append(string6).append("\u00a77 was set to \u00a78").append(BlockUtils.getBlockName(id)).append("\u00a77.").toString());
                    return;
                }
                if (newValue instanceof IntegerValue) {
                    ((IntegerValue)value).set(Integer.parseInt(args[2]));
                } else if (newValue instanceof FloatValue) {
                    ((FloatValue)value).set(Float.valueOf(Float.parseFloat(args[2])));
                } else if (newValue instanceof ListValue) {
                    if (!((ListValue)value).contains(args[2])) {
                        StringBuilder stringBuilder = new StringBuilder().append((String)moduleName).append(' ');
                        String string7 = args[1];
                        Locale locale = Locale.getDefault();
                        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                        object = string7.toLowerCase(locale);
                        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
                        StringBuilder stringBuilder3 = stringBuilder.append((String)object).append(" <");
                        String string8 = ArraysKt.joinToString$default((Object[])((ListValue)value).getValues(), (CharSequence)"/", null, null, (int)0, null, null, (int)62, null);
                        locale = Locale.getDefault();
                        Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                        object = string8.toLowerCase(locale);
                        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
                        this.chatSyntax(stringBuilder3.append((String)object).append('>').toString());
                        return;
                    }
                    ((ListValue)value).set(args[2]);
                } else if (newValue instanceof TextValue) {
                    TextValue textValue = (TextValue)value;
                    String string9 = StringUtils.toCompleteString(args, 2);
                    Intrinsics.checkNotNullExpressionValue((Object)string9, (String)"toCompleteString(args, 2)");
                    textValue.set(string9);
                }
                this.chat("\u00a77" + this.module.getName() + " \u00a78" + args[1] + "\u00a77 was set to \u00a78" + value.get() + "\u00a77.");
            }
            catch (NumberFormatException e) {
                this.chat("\u00a78" + args[2] + "\u00a77 cannot be converted to number!");
            }
        }
    }
}

