/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.io.FilesKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.command.impl;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.Locale;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.SettingsUtils;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;

public final class ConfigCommand
extends Command {
    public ConfigCommand() {
        String[] stringArray = new String[]{"c"};
        super("config", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 1) {
            if (StringsKt.equals((String)args[1], (String)"load", (boolean)true) || StringsKt.equals((String)args[1], (String)"l", (boolean)true)) {
                if (args.length > 2) {
                    File scriptFile = new File(Client.INSTANCE.getFileManager().settingsDir, args[2]);
                    if (scriptFile.exists()) {
                        try {
                            String settings2 = FilesKt.readText$default((File)scriptFile, null, (int)1, null);
                            SettingsUtils.INSTANCE.executeScript(settings2);
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.chat("\u00a76Config updated successfully!");
                            Client.INSTANCE.getHud().addNotification(new Notification("Config updated successfully!", Notification.Type.SUCCESS));
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                        return;
                    }
                    return;
                }
                this.chatSyntax("config load <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"save", (boolean)true) || StringsKt.equals((String)args[1], (String)"s", (boolean)true)) {
                if (args.length > 2) {
                    File scriptFile = new File(Client.INSTANCE.getFileManager().settingsDir, args[2]);
                    try {
                        boolean states2;
                        String string;
                        if (scriptFile.exists()) {
                            if (scriptFile.delete()) {
                                scriptFile.createNewFile();
                            } else {
                                return;
                            }
                        }
                        if (args.length > 3) {
                            String string2 = StringUtils.toCompleteString(args, 3);
                            Intrinsics.checkNotNullExpressionValue((Object)string2, (String)"toCompleteString(args, 3)");
                            Locale locale = Locale.getDefault();
                            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
                            String string3 = string2.toLowerCase(locale);
                            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).toLowerCase(locale)");
                            string = string3;
                        } else {
                            string = "all";
                        }
                        String option = string;
                        boolean values = option.equals("all") || option.equals("values");
                        boolean binds = option.equals("all") || option.equals("binds");
                        boolean bl = states2 = option.equals("all") || option.equals("states");
                        if (!(values || binds || states2)) {
                            return;
                        }
                        String settingsScript = SettingsUtils.INSTANCE.generateScript(values, binds, states2);
                        FilesKt.writeText$default((File)scriptFile, (String)settingsScript, null, (int)2, null);
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.chat("\u00a7aSuccessfully saved new config!");
                        Client.INSTANCE.getHud().addNotification(new Notification("Config saved successfully!", Notification.Type.SUCCESS));
                    }
                    catch (Throwable option) {
                        // empty catch block
                    }
                    return;
                }
                this.chatSyntax("config save <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"delete", (boolean)true) || StringsKt.equals((String)args[1], (String)"d", (boolean)true)) {
                if (args.length > 2) {
                    File scriptFile = new File(Client.INSTANCE.getFileManager().settingsDir, args[2]);
                    if (scriptFile.exists()) {
                        scriptFile.delete();
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.chat("\u00a76Config deleted successfully!");
                        Client.INSTANCE.getHud().addNotification(new Notification("Config deleted successfully!", Notification.Type.SUCCESS));
                        return;
                    }
                    return;
                }
                this.chatSyntax("config delete <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"fix", (boolean)true)) {
                if (args.length > 2) {
                    File scriptFile = new File(Client.INSTANCE.getFileManager().settingsDir, args[2]);
                    if (scriptFile.exists()) {
                        try {
                            String settings3 = FilesKt.readText$default((File)scriptFile, null, (int)1, null);
                            SettingsUtils.INSTANCE.executeScript(settings3);
                        }
                        catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    try {
                        boolean states;
                        String string;
                        if (scriptFile.exists()) {
                            if (scriptFile.delete()) {
                                scriptFile.createNewFile();
                            } else {
                                return;
                            }
                        }
                        if (args.length > 3) {
                            String values = StringUtils.toCompleteString(args, 3);
                            Intrinsics.checkNotNullExpressionValue((Object)values, (String)"toCompleteString(args, 3)");
                            Locale binds = Locale.getDefault();
                            Intrinsics.checkNotNullExpressionValue((Object)binds, (String)"getDefault()");
                            String states2 = values.toLowerCase(binds);
                            Intrinsics.checkNotNullExpressionValue((Object)states2, (String)"this as java.lang.String).toLowerCase(locale)");
                            string = states2;
                        } else {
                            string = "all";
                        }
                        String option = string;
                        boolean values = option.equals("all") || option.equals("values");
                        boolean binds = option.equals("all") || option.equals("binds");
                        boolean bl = states = option.equals("all") || option.equals("states");
                        if (!(values || binds || states)) {
                            return;
                        }
                        String settingsScript = SettingsUtils.INSTANCE.generateScript(values, binds, states);
                        FilesKt.writeText$default((File)scriptFile, (String)settingsScript, null, (int)2, null);
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.chat("\u00a76Config fixed successfully!");
                    }
                    catch (Throwable throwable) {
                        // empty catch block
                    }
                    return;
                }
                this.chatSyntax("config fix <name>");
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"list", (boolean)true)) {
                this.chat("\u00a7cConfigs:");
                File[] fileArray = this.getLocalSettings();
                if (fileArray == null) {
                    return;
                }
                for (File file : fileArray) {
                    this.chat(Intrinsics.stringPlus((String)"", (Object)file.getName()));
                }
                return;
            }
            if (StringsKt.equals((String)args[1], (String)"folder", (boolean)true)) {
                Desktop.getDesktop().open(Client.INSTANCE.getFileManager().settingsDir);
                this.chat("Successfully opened configs folder.");
                return;
            }
        }
        this.chatSyntax("config <load/save/list/delete/fix/folder>");
    }

    private final File[] getLocalSettings() {
        return Client.INSTANCE.getFileManager().settingsDir.listFiles();
    }
}

