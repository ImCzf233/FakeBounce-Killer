/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.misc.StringUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.hud.element.elements.Notification;

public final class RepeatCommand
extends Command {
    public RepeatCommand() {
        String[] stringArray = new String[]{"rp"};
        super("repeat", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        if (args.length > 2) {
            try {
                int amount = Integer.parseInt(args[1]);
                int n = 1;
                if (n <= amount) {
                    int cnt;
                    do {
                        cnt = n++;
                        MinecraftInstance.mc.field_71439_g.func_71165_d(StringUtils.toCompleteString(args, 2));
                    } while (cnt != amount);
                }
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                Client.INSTANCE.getHud().addNotification(new Notification("Sent Chat Successfully!", Notification.Type.SUCCESS));
                return;
            }
            catch (NumberFormatException ex) {
                this.chatSyntaxError();
                return;
            }
        }
        this.chatSyntax("repeat <amount> <message>");
    }
}

