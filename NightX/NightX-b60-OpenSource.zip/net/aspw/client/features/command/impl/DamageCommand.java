/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.C03PacketPlayer$C04PacketPlayerPosition
 */
package net.aspw.client.features.command.impl;

import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;

public final class DamageCommand
extends Command {
    public DamageCommand() {
        String[] stringArray = new String[]{"dmg"};
        super("damage", stringArray);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        int damage = 1;
        if (args.length > 1) {
            try {
                damage = Integer.parseInt(args[1]);
            }
            catch (NumberFormatException ignored) {
                this.chatSyntaxError();
                return;
            }
        }
        double x = MinecraftInstance.mc.field_71439_g.field_70165_t;
        double y = MinecraftInstance.mc.field_71439_g.field_70163_u;
        double z = MinecraftInstance.mc.field_71439_g.field_70161_v;
        int n = 0;
        int n2 = 65 * damage;
        while (n < n2) {
            int i = n++;
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.049, z, false));
            MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
        }
        MinecraftInstance.mc.func_147114_u().func_147297_a((Packet)new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, true));
        this.chat("You were damaged!");
    }
}

