/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.jagrosh.discordipc.IPCClient
 *  com.jagrosh.discordipc.IPCListener
 *  com.jagrosh.discordipc.entities.DiscordBuild
 *  com.jagrosh.discordipc.entities.RichPresence$Builder
 *  com.jagrosh.discordipc.entities.pipe.PipeStatus
 *  kotlin.Unit
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  org.jetbrains.annotations.Nullable
 *  org.json.JSONObject
 */
package net.aspw.client.features.api;

import com.jagrosh.discordipc.IPCClient;
import com.jagrosh.discordipc.IPCListener;
import com.jagrosh.discordipc.entities.DiscordBuild;
import com.jagrosh.discordipc.entities.RichPresence;
import com.jagrosh.discordipc.entities.pipe.PipeStatus;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.Unit;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.connection.CheckConnection;
import org.jetbrains.annotations.Nullable;
import org.json.JSONObject;

public final class DiscordRPC
extends MinecraftInstance {
    private boolean showRichPresenceValue = true;
    private IPCClient ipcClient;
    private long appID;
    private final Map<String, String> assets = new LinkedHashMap();
    private final OffsetDateTime timestamp = OffsetDateTime.now();
    private boolean running;

    public final boolean getShowRichPresenceValue() {
        return this.showRichPresenceValue;
    }

    public final void setShowRichPresenceValue(boolean bl) {
        this.showRichPresenceValue = bl;
    }

    public final boolean getRunning() {
        return this.running;
    }

    public final void setRunning(boolean bl) {
        this.running = bl;
    }

    public final void setup() {
        try {
            this.running = true;
            this.loadConfiguration();
            IPCClient iPCClient = this.ipcClient = new IPCClient(this.appID);
            if (iPCClient != null) {
                iPCClient.setListener(new IPCListener(this){
                    final /* synthetic */ DiscordRPC this$0;
                    {
                        this.this$0 = $receiver;
                    }

                    public void onReady(@Nullable IPCClient client) {
                        ThreadsKt.thread$default((boolean)false, (boolean)false, null, null, (int)0, (Function0)((Function0)new Function0<Unit>(this.this$0){
                            final /* synthetic */ DiscordRPC this$0;
                            {
                                this.this$0 = $receiver;
                                super(0);
                            }

                            public final void invoke() {
                                while (this.this$0.getRunning()) {
                                    this.this$0.update();
                                    try {
                                        Thread.sleep(1000L);
                                    }
                                    catch (InterruptedException interruptedException) {}
                                }
                            }
                        }), (int)31, null);
                    }

                    public void onClose(@Nullable IPCClient client, @Nullable JSONObject json) {
                        this.this$0.setRunning(false);
                    }
                });
            }
            IPCClient iPCClient2 = this.ipcClient;
            if (iPCClient2 != null) {
                iPCClient2.connect(new DiscordBuild[0]);
            }
        }
        catch (Throwable e) {
            ClientUtils.getLogger().error("Failed to setup Discord RPC.", e);
        }
    }

    public final void update() {
        RichPresence.Builder builder = new RichPresence.Builder();
        builder.setStartTimestamp(this.timestamp);
        if (this.assets.containsKey("logo")) {
            builder.setLargeImage(this.assets.get("logo"));
        }
        builder.setDetails("Build: Release B60");
        builder.setState(CheckConnection.INSTANCE.getDiscord());
        builder.setSmallImage(this.assets.get("mahiro"), "https://youtube.com/@as_pw");
        IPCClient iPCClient = this.ipcClient;
        if ((iPCClient == null ? null : iPCClient.getStatus()) == PipeStatus.CONNECTED) {
            IPCClient iPCClient2 = this.ipcClient;
            if (iPCClient2 != null) {
                iPCClient2.sendRichPresence(builder.build());
            }
        }
    }

    public final void shutdown() {
        IPCClient iPCClient = this.ipcClient;
        if ((iPCClient == null ? null : iPCClient.getStatus()) != PipeStatus.CONNECTED) {
            return;
        }
        try {
            IPCClient iPCClient2 = this.ipcClient;
            if (iPCClient2 != null) {
                iPCClient2.close();
            }
        }
        catch (Throwable e) {
            ClientUtils.getLogger().error("Failed to close Discord RPC.", e);
        }
    }

    private final void loadConfiguration() {
        this.appID = 1130780572604702821L;
        this.assets.put("logo", "logo");
        this.assets.put("mahiro", "mahiro");
    }
}

