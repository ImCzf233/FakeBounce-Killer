/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.buffer.Unpooled
 *  net.minecraft.client.Minecraft
 *  net.minecraft.network.Packet
 *  net.minecraft.network.PacketBuffer
 *  net.minecraft.network.play.INetHandlerPlayServer
 *  net.minecraft.network.play.client.C17PacketCustomPayload
 *  net.minecraftforge.fml.common.network.internal.FMLProxyPacket
 */
package net.aspw.client.features.api;

import io.netty.buffer.Unpooled;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.Listenable;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.util.MinecraftInstance;
import net.aspw.client.util.PacketUtils;
import net.aspw.client.util.misc.RandomUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.INetHandlerPlayServer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;

public class ClientSpoof
extends MinecraftInstance
implements Listenable {
    @EventTarget
    public void onPacket(PacketEvent event) {
        Packet<?> packet = event.getPacket();
        net.aspw.client.features.module.impl.other.ClientSpoof clientSpoof = Client.moduleManager.getModule(net.aspw.client.features.module.impl.other.ClientSpoof.class);
        if (!Minecraft.func_71410_x().func_71387_A()) {
            if (((Boolean)Objects.requireNonNull(clientSpoof).blockModsCheck.get()).booleanValue() && packet instanceof FMLProxyPacket) {
                event.cancelEvent();
            }
            if (packet instanceof C17PacketCustomPayload) {
                if (((C17PacketCustomPayload)event.getPacket()).func_149559_c().equalsIgnoreCase("MC|Brand")) {
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Vanilla")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("vanilla")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Forge")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("FML")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("OptiFine")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("optifine")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("LabyMod")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("LMC")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("CheatBreaker")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("CB")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("PvPLounge")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("PLC18")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Geyser")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("MC|Brand", new PacketBuffer(Unpooled.buffer()).func_180714_a("eyser")));
                    }
                    if (((String)Objects.requireNonNull(clientSpoof).modeValue.get()).equals("Lunar")) {
                        PacketUtils.sendPacketNoEvent((Packet<INetHandlerPlayServer>)new C17PacketCustomPayload("REGISTER", new PacketBuffer(Unpooled.buffer()).func_180714_a("lunarclient:" + RandomUtils.randomString(7))));
                    }
                }
                event.cancelEvent();
            }
        }
    }

    @Override
    public boolean handleEvents() {
        return true;
    }
}

