/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.features.api;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.Listenable;
import net.aspw.client.util.MinecraftInstance;

public final class MacroManager
extends MinecraftInstance
implements Listenable {
    public static final MacroManager INSTANCE = new MacroManager();
    private static final HashMap<Integer, String> macroMapping = new HashMap();

    private MacroManager() {
    }

    public final HashMap<Integer, String> getMacroMapping() {
        return macroMapping;
    }

    /*
     * WARNING - void declaration
     */
    @EventTarget
    public final void onKey(KeyEvent event) {
        void $this$filterTo$iv$iv;
        Intrinsics.checkNotNullParameter((Object)event, (String)"event");
        if (MinecraftInstance.mc.field_71439_g == null) {
            return;
        }
        Client.INSTANCE.getCommandManager();
        Map $this$filter$iv = macroMapping;
        boolean $i$f$filter = false;
        Object object = $this$filter$iv;
        Map destination$iv$iv = new LinkedHashMap();
        boolean $i$f$filterTo = false;
        Iterator iterator = $this$filterTo$iv$iv.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry element$iv$iv;
            Map.Entry it = element$iv$iv = iterator.next();
            boolean bl = false;
            if (!(((Number)it.getKey()).intValue() == event.getKey())) continue;
            destination$iv$iv.put(element$iv$iv.getKey(), element$iv$iv.getValue());
        }
        Map $this$forEach$iv = destination$iv$iv;
        boolean $i$f$forEach = false;
        object = $this$forEach$iv.entrySet().iterator();
        while (object.hasNext()) {
            Map.Entry element$iv;
            Map.Entry it = element$iv = (Map.Entry)object.next();
            boolean bl = false;
            if (StringsKt.startsWith$default((String)((String)it.getValue()), (String)".", (boolean)false, (int)2, null)) {
                Client.INSTANCE.getCommandManager().executeCommands((String)it.getValue());
                continue;
            }
            MinecraftInstance.mc.field_71439_g.func_71165_d((String)it.getValue());
        }
    }

    public final void addMacro(int keyCode, String command) {
        Intrinsics.checkNotNullParameter((Object)command, (String)"command");
        Map map = macroMapping;
        Integer n = keyCode;
        map.put(n, command);
    }

    public final void removeMacro(int keyCode) {
        macroMapping.remove(keyCode);
    }

    @Override
    public boolean handleEvents() {
        return true;
    }
}

