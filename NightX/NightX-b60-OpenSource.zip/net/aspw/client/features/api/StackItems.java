/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.features.api;

import java.util.List;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.item.ItemUtils;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public final class StackItems
extends CreativeTabs {
    public StackItems() {
        super("Stack Items");
    }

    public void func_78018_a(List<ItemStack> itemList) {
        Intrinsics.checkNotNullParameter(itemList, (String)"itemList");
        ItemStack itemStack = ItemUtils.createItem("bow 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"bow 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("arrow 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"arrow 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_sword 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_sword 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("wooden_sword 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"wooden_sword 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("stone_sword 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"stone_sword 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_sword 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_sword 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_sword 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_sword 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("leather_helmet 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"leather_helmet 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("leather_chestplate 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"leather_chestplate 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("leather_leggings 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"leather_leggings 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("leather_boots 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"leather_boots 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chainmail_helmet 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chainmail_helmet 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chainmail_chestplate 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chainmail_chestplate 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chainmail_leggings 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chainmail_leggings 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chainmail_boots 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chainmail_boots 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_helmet 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_helmet 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_chestplate 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_chestplate 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_leggings 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_leggings 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_boots 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_boots 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_helmet 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_helmet 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_chestplate 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_chestplate 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_leggings 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_leggings 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_boots 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_boots 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_helmet 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_helmet 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_chestplate 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_chestplate 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_leggings 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_leggings 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_boots 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_boots 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("fishing_rod 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"fishing_rod 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("carrot_on_a_stick 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"carrot_on_a_stick 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("water_bucket 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"water_bucket 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("lava_bucket 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"lava_bucket 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("milk_bucket 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"milk_bucket 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("snowball 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"snowball 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("ender_pearl 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"ender_pearl 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("writable_book 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"writable_book 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("written_book 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"written_book 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("iron_horse_armor 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"iron_horse_armor 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("golden_horse_armor 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"golden_horse_armor 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("diamond_horse_armor 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"diamond_horse_armor 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("clock 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"clock 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("shears 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"shears 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("saddle 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"saddle 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("boat 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"boat 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("chest_minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"chest_minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("furnace_minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"furnace_minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("tnt_minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"tnt_minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("hopper_minecart 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"hopper_minecart 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("cake 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"cake 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("mushroom_stew 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"mushroom_stew 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("rabbit_stew 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"rabbit_stew 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_13 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_13 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_cat 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_cat 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_blocks 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_blocks 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_chirp 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_chirp 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_far 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_far 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_mall 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_mall 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_mellohi 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_mellohi 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_stal 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_stal 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_strad 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_strad 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_ward 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_ward 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_11 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_11 64 0\")");
        itemList.add(itemStack);
        itemStack = ItemUtils.createItem("record_wait 64 0");
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(\"record_wait 64 0\")");
        itemList.add(itemStack);
    }

    public Item func_78016_d() {
        Item item = new ItemStack(Items.field_151048_u).func_77973_b();
        Intrinsics.checkNotNullExpressionValue((Object)item, (String)"ItemStack(Items.diamond_sword).item");
        return item;
    }

    public String func_78024_c() {
        return "Stack Items";
    }
}

