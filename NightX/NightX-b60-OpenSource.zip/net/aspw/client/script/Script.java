/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jdk.internal.dynalink.beans.StaticClass
 *  jdk.nashorn.api.scripting.JSObject
 *  jdk.nashorn.api.scripting.NashornScriptEngineFactory
 *  jdk.nashorn.api.scripting.ScriptUtils
 *  kotlin.collections.CollectionsKt
 *  kotlin.io.FilesKt
 *  kotlin.io.TextStreamsKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.Charsets
 *  kotlin.text.StringsKt
 *  net.minecraft.client.Minecraft
 */
package net.aspw.client.script;

import java.io.File;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import javax.script.ScriptEngine;
import jdk.internal.dynalink.beans.StaticClass;
import jdk.nashorn.api.scripting.JSObject;
import jdk.nashorn.api.scripting.NashornScriptEngineFactory;
import jdk.nashorn.api.scripting.ScriptUtils;
import kotlin.collections.CollectionsKt;
import kotlin.io.FilesKt;
import kotlin.io.TextStreamsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.features.command.Command;
import net.aspw.client.features.module.Module;
import net.aspw.client.script.api.ScriptCommand;
import net.aspw.client.script.api.ScriptModule;
import net.aspw.client.script.api.ScriptTab;
import net.aspw.client.script.api.global.Chat;
import net.aspw.client.script.api.global.Item;
import net.aspw.client.script.api.global.Setting;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.MinecraftInstance;
import net.minecraft.client.Minecraft;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class Script {
    private final File scriptFile;
    private final ScriptEngine scriptEngine;
    private final String scriptText;
    public String scriptName;
    public String scriptVersion;
    public String[] scriptAuthors;
    private boolean state;
    private final HashMap<String, JSObject> events;
    private final List<Module> registeredModules;
    private final List<Command> registeredCommands;

    public Script(File scriptFile) {
        String[] stringArray;
        Object object;
        String[] stringArray2;
        Intrinsics.checkNotNullParameter((Object)scriptFile, (String)"scriptFile");
        this.scriptFile = scriptFile;
        this.scriptText = FilesKt.readText$default((File)this.scriptFile, null, (int)1, null);
        this.events = new HashMap();
        this.registeredModules = new ArrayList();
        this.registeredCommands = new ArrayList();
        String string = this.getMagicComment("engine_flags");
        if (string == null) {
            stringArray2 = null;
        } else {
            String[] stringArray3 = new String[]{","};
            List list = StringsKt.split$default((CharSequence)string, (String[])stringArray3, (boolean)false, (int)0, (int)6, null);
            if (list == null) {
                stringArray2 = null;
            } else {
                Collection $this$toTypedArray$iv = list;
                boolean $i$f$toTypedArray = false;
                Collection thisCollection$iv = $this$toTypedArray$iv;
                String[] stringArray4 = thisCollection$iv.toArray(new String[0]);
                if (stringArray4 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
                }
                stringArray2 = object = stringArray4;
            }
        }
        if (object == null) {
            boolean $i$f$emptyArray = false;
            stringArray = new String[]{};
        } else {
            stringArray = object;
        }
        String[] engineFlags = stringArray;
        object = new NashornScriptEngineFactory().getScriptEngine(Arrays.copyOf(engineFlags, engineFlags.length));
        Intrinsics.checkNotNullExpressionValue((Object)object, (String)"NashornScriptEngineFacto\u2026criptEngine(*engineFlags)");
        this.scriptEngine = object;
        this.scriptEngine.put("Chat", StaticClass.forClass(Chat.class));
        this.scriptEngine.put("Setting", StaticClass.forClass(Setting.class));
        this.scriptEngine.put("Item", StaticClass.forClass(Item.class));
        this.scriptEngine.put("mc", Minecraft.func_71410_x());
        this.scriptEngine.put("moduleManager", Client.INSTANCE.getModuleManager());
        this.scriptEngine.put("commandManager", Client.INSTANCE.getCommandManager());
        this.scriptEngine.put("scriptManager", Client.INSTANCE.getScriptManager());
        this.scriptEngine.put("registerScript", new RegisterScript());
        this.supportLegacyScripts();
        this.scriptEngine.eval(this.scriptText);
        this.callEvent("load");
    }

    public final File getScriptFile() {
        return this.scriptFile;
    }

    public final String getScriptName() {
        String string = this.scriptName;
        if (string != null) {
            return string;
        }
        return null;
    }

    public final void setScriptName(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.scriptName = string;
    }

    public final String getScriptVersion() {
        String string = this.scriptVersion;
        if (string != null) {
            return string;
        }
        return null;
    }

    public final void setScriptVersion(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.scriptVersion = string;
    }

    public final String[] getScriptAuthors() {
        String[] stringArray = this.scriptAuthors;
        if (stringArray != null) {
            return stringArray;
        }
        return null;
    }

    public final void setScriptAuthors(String[] stringArray) {
        Intrinsics.checkNotNullParameter((Object)stringArray, (String)"<set-?>");
        this.scriptAuthors = stringArray;
    }

    public final void registerModule(JSObject moduleObject, JSObject callback) {
        Intrinsics.checkNotNullParameter((Object)moduleObject, (String)"moduleObject");
        Intrinsics.checkNotNullParameter((Object)callback, (String)"callback");
        ScriptModule module = new ScriptModule(moduleObject);
        Client.INSTANCE.getModuleManager().registerModule(module);
        ((Collection)this.registeredModules).add(module);
        Object[] objectArray = new Object[]{module};
        callback.call((Object)moduleObject, objectArray);
    }

    public final void registerCommand(JSObject commandObject, JSObject callback) {
        Intrinsics.checkNotNullParameter((Object)commandObject, (String)"commandObject");
        Intrinsics.checkNotNullParameter((Object)callback, (String)"callback");
        ScriptCommand command = new ScriptCommand(commandObject);
        Client.INSTANCE.getCommandManager().registerCommand(command);
        ((Collection)this.registeredCommands).add(command);
        Object[] objectArray = new Object[]{command};
        callback.call((Object)commandObject, objectArray);
    }

    public final void registerTab(JSObject tabObject) {
        Intrinsics.checkNotNullParameter((Object)tabObject, (String)"tabObject");
        new ScriptTab(tabObject);
    }

    private final String getMagicComment(String name) {
        String magicPrefix = "///";
        Iterable $this$forEach$iv = StringsKt.lines((CharSequence)this.scriptText);
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            String it = (String)element$iv;
            boolean bl = false;
            if (!StringsKt.startsWith$default((String)it, (String)magicPrefix, (boolean)false, (int)2, null)) {
                return null;
            }
            String string = it.substring(magicPrefix.length());
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).substring(startIndex)");
            String[] stringArray = new String[]{"="};
            List commentData = StringsKt.split$default((CharSequence)string, (String[])stringArray, (boolean)false, (int)2, (int)2, null);
            if (!((Object)StringsKt.trim((CharSequence)((String)CollectionsKt.first((List)commentData)))).toString().equals(name)) continue;
            return ((Object)StringsKt.trim((CharSequence)((String)CollectionsKt.last((List)commentData)))).toString();
        }
        return null;
    }

    private final void supportLegacyScripts() {
        if (!this.getMagicComment("api_version").equals("2")) {
            String string;
            ClientUtils.getLogger().info("[ScriptAPI] Running script '" + this.scriptFile.getName() + "' with legacy support.");
            URL uRL = Client.class.getResource("/assets/minecraft/client/script/api.js");
            if (uRL == null) {
                string = null;
            } else {
                URL uRL2 = uRL;
                Charset charset = Charsets.UTF_8;
                byte[] byArray = TextStreamsKt.readBytes((URL)uRL2);
                string = new String(byArray, charset);
            }
            String legacyScript = string;
            this.scriptEngine.eval(legacyScript);
        }
    }

    public final void on(String eventName, JSObject handler) {
        Intrinsics.checkNotNullParameter((Object)eventName, (String)"eventName");
        Intrinsics.checkNotNullParameter((Object)handler, (String)"handler");
        ((Map)this.events).put(eventName, handler);
    }

    public final void onEnable() {
        if (this.state) {
            return;
        }
        this.callEvent("enable");
        this.state = true;
    }

    public final void onDisable() {
        MinecraftInstance it;
        if (!this.state) {
            return;
        }
        Iterable $this$forEach$iv = this.registeredModules;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            it = (Module)element$iv;
            boolean bl = false;
            Client.INSTANCE.getModuleManager().unregisterModule((Module)it);
        }
        $this$forEach$iv = this.registeredCommands;
        $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            it = (Command)element$iv;
            boolean bl = false;
            Client.INSTANCE.getCommandManager().unregisterCommand((Command)it);
        }
        this.callEvent("disable");
        this.state = false;
    }

    public final void import(String scriptFile) {
        Intrinsics.checkNotNullParameter((Object)scriptFile, (String)"scriptFile");
        this.scriptEngine.eval(FilesKt.readText$default((File)new File(Client.INSTANCE.getScriptManager().getScriptsFolder(), scriptFile), null, (int)1, null));
    }

    private final void callEvent(String eventName) {
        try {
            JSObject jSObject = this.events.get(eventName);
            if (jSObject != null) {
                jSObject.call(null, new Object[0]);
            }
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("[ScriptAPI] Exception in script '" + this.getScriptName() + "'!", throwable);
        }
    }

    public final class RegisterScript
    implements Function<JSObject, Script> {
        public RegisterScript() {
            Intrinsics.checkNotNullParameter((Object)Script.this, (String)"this$0");
        }

        @Override
        public Script apply(JSObject scriptObject) {
            Intrinsics.checkNotNullParameter((Object)scriptObject, (String)"scriptObject");
            Object object = scriptObject.getMember("name");
            if (object == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
            }
            Script.this.setScriptName((String)object);
            Object object2 = scriptObject.getMember("version");
            if (object2 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
            }
            Script.this.setScriptVersion((String)object2);
            Object object3 = ScriptUtils.convert((Object)scriptObject.getMember("authors"), String[].class);
            if (object3 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
            }
            Script.this.setScriptAuthors((String[])object3);
            return Script.this;
        }
    }
}

