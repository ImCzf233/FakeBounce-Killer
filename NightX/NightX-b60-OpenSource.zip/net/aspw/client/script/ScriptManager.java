/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.io.FilesKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.script;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.script.Script;
import net.aspw.client.util.ClientUtils;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class ScriptManager {
    private final List<Script> scripts = new ArrayList();
    private final File scriptsFolder;
    private final String scriptFileExtension;

    public ScriptManager() {
        this.scriptsFolder = new File(Client.INSTANCE.getFileManager().dir, "scripts");
        this.scriptFileExtension = ".js";
    }

    public final List<Script> getScripts() {
        return this.scripts;
    }

    public final File getScriptsFolder() {
        return this.scriptsFolder;
    }

    public final void loadScripts() {
        if (!this.scriptsFolder.exists()) {
            this.scriptsFolder.mkdir();
        }
        File[] fileArray = this.scriptsFolder.listFiles(arg_0 -> ScriptManager.loadScripts$lambda-0(this, arg_0));
        Intrinsics.checkNotNullExpressionValue((Object)fileArray, (String)"scriptsFolder.listFiles(\u2026h(scriptFileExtension) })");
        Object[] $this$forEach$iv = fileArray;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            File it = (File)element$iv;
            boolean bl = false;
            Intrinsics.checkNotNullExpressionValue((Object)it, (String)"it");
            this.loadScript(it);
        }
    }

    public final void unloadScripts() {
        this.scripts.clear();
    }

    public final void loadScript(File scriptFile) {
        Intrinsics.checkNotNullParameter((Object)scriptFile, (String)"scriptFile");
        try {
            this.scripts.add(new Script(scriptFile));
            ClientUtils.getLogger().info("[ScriptAPI] Successfully loaded script '" + scriptFile.getName() + "'.");
        }
        catch (Throwable t) {
            ClientUtils.getLogger().error("[ScriptAPI] Failed to load script '" + scriptFile.getName() + "'.", t);
        }
    }

    public final void enableScripts() {
        Iterable $this$forEach$iv = this.scripts;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Script it = (Script)element$iv;
            boolean bl = false;
            it.onEnable();
        }
    }

    public final void disableScripts() {
        Iterable $this$forEach$iv = this.scripts;
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            Script it = (Script)element$iv;
            boolean bl = false;
            it.onDisable();
        }
    }

    public final void importScript(File file) {
        Intrinsics.checkNotNullParameter((Object)file, (String)"file");
        File scriptFile = new File(this.scriptsFolder, file.getName());
        FilesKt.copyTo$default((File)file, (File)scriptFile, (boolean)false, (int)0, (int)6, null);
        this.loadScript(scriptFile);
        ClientUtils.getLogger().info("[ScriptAPI]  Successfully imported script '" + scriptFile.getName() + "'.");
    }

    public final void deleteScript(Script script) {
        Intrinsics.checkNotNullParameter((Object)script, (String)"script");
        script.onDisable();
        this.scripts.remove(script);
        script.getScriptFile().delete();
        ClientUtils.getLogger().info("[ScriptAPI]  Successfully deleted script '" + script.getScriptFile().getName() + "'.");
    }

    public final void reloadScripts() {
        this.disableScripts();
        this.unloadScripts();
        this.loadScripts();
        this.enableScripts();
        ClientUtils.getLogger().info("[ScriptAPI]  Successfully reloaded scripts.");
    }

    private static final boolean loadScripts$lambda-0(ScriptManager this$0, File it) {
        Intrinsics.checkNotNullParameter((Object)this$0, (String)"this$0");
        String string = it.getName();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"it.name");
        return StringsKt.endsWith$default((String)string, (String)this$0.scriptFileExtension, (boolean)false, (int)2, null);
    }
}

