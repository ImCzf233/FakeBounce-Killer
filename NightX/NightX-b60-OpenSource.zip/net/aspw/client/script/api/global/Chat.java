/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.script.api.global;

import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.ClientUtils;

public final class Chat {
    public static final Chat INSTANCE = new Chat();

    private Chat() {
    }

    @JvmStatic
    public static final void print(String message) {
        Intrinsics.checkNotNullParameter((Object)message, (String)"message");
        ClientUtils.displayChatMessage(message);
    }
}

