/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.item.ItemStack
 */
package net.aspw.client.script.api.global;

import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.util.item.ItemCreator;
import net.minecraft.item.ItemStack;

public final class Item {
    public static final Item INSTANCE = new Item();

    private Item() {
    }

    @JvmStatic
    public static final ItemStack create(String itemArguments) {
        Intrinsics.checkNotNullParameter((Object)itemArguments, (String)"itemArguments");
        ItemStack itemStack = ItemCreator.createItem(itemArguments);
        Intrinsics.checkNotNullExpressionValue((Object)itemStack, (String)"createItem(itemArguments)");
        return itemStack;
    }
}

