/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jdk.nashorn.api.scripting.JSObject
 *  jdk.nashorn.api.scripting.ScriptUtils
 *  kotlin.jvm.internal.Intrinsics
 *  net.minecraft.creativetab.CreativeTabs
 *  net.minecraft.init.Items
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.script.api;

import java.util.List;
import jdk.nashorn.api.scripting.JSObject;
import jdk.nashorn.api.scripting.ScriptUtils;
import kotlin.jvm.internal.Intrinsics;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public final class ScriptTab
extends CreativeTabs {
    private final JSObject tabObject;
    private final ItemStack[] items;

    public ScriptTab(JSObject tabObject) {
        Intrinsics.checkNotNullParameter((Object)tabObject, (String)"tabObject");
        Object object = tabObject.getMember("name");
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        super((String)object);
        this.tabObject = tabObject;
        Object object2 = ScriptUtils.convert((Object)this.tabObject.getMember("items"), ItemStack[].class);
        if (object2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<net.minecraft.item.ItemStack>");
        }
        this.items = (ItemStack[])object2;
    }

    public final ItemStack[] getItems() {
        return this.items;
    }

    public Item func_78016_d() {
        Object object = this.tabObject.getMember("icon");
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        Object object2 = Items.class.getField((String)object).get(null);
        if (object2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type net.minecraft.item.Item");
        }
        return (Item)object2;
    }

    public String func_78024_c() {
        Object object = this.tabObject.getMember("name");
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        return (String)object;
    }

    public void func_78018_a(@Nullable List<ItemStack> p_78018_1_) {
        ItemStack[] $this$forEach$iv = this.items;
        boolean $i$f$forEach = false;
        for (ItemStack element$iv : $this$forEach$iv) {
            ItemStack it = element$iv;
            boolean bl = false;
            List<ItemStack> list = p_78018_1_;
            if (list == null) continue;
            list.add(it);
        }
    }
}

