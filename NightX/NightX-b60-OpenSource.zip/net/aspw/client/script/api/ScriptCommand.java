/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jdk.nashorn.api.scripting.JSObject
 *  jdk.nashorn.api.scripting.ScriptUtils
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.script.api;

import java.util.HashMap;
import java.util.Map;
import jdk.nashorn.api.scripting.JSObject;
import jdk.nashorn.api.scripting.ScriptUtils;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.features.command.Command;
import net.aspw.client.util.ClientUtils;

public final class ScriptCommand
extends Command {
    private final JSObject commandObject;
    private final HashMap<String, JSObject> events;

    public ScriptCommand(JSObject commandObject) {
        Intrinsics.checkNotNullParameter((Object)commandObject, (String)"commandObject");
        Object object = commandObject.getMember("name");
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        Object object2 = ScriptUtils.convert((Object)commandObject.getMember("aliases"), String[].class);
        if (object2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<kotlin.String>");
        }
        super((String)object, (String[])object2);
        this.commandObject = commandObject;
        this.events = new HashMap();
    }

    public final void on(String eventName, JSObject handler) {
        Intrinsics.checkNotNullParameter((Object)eventName, (String)"eventName");
        Intrinsics.checkNotNullParameter((Object)handler, (String)"handler");
        ((Map)this.events).put(eventName, handler);
    }

    @Override
    public void execute(String[] args) {
        Intrinsics.checkNotNullParameter((Object)args, (String)"args");
        try {
            JSObject jSObject = this.events.get("execute");
            if (jSObject != null) {
                Object[] objectArray = new Object[]{args};
                jSObject.call((Object)this.commandObject, objectArray);
            }
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("[ScriptAPI] Exception in command '" + this.getCommand() + "'!", throwable);
        }
    }
}

