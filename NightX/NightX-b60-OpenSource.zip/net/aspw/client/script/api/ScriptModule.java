/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  jdk.nashorn.api.scripting.JSObject
 *  kotlin.Lazy
 *  kotlin.LazyKt
 *  kotlin.collections.CollectionsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.script.api;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import jdk.nashorn.api.scripting.JSObject;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.event.AttackEvent;
import net.aspw.client.event.ClickBlockEvent;
import net.aspw.client.event.EventTarget;
import net.aspw.client.event.JumpEvent;
import net.aspw.client.event.KeyEvent;
import net.aspw.client.event.MotionEvent;
import net.aspw.client.event.MoveEvent;
import net.aspw.client.event.PacketEvent;
import net.aspw.client.event.Render2DEvent;
import net.aspw.client.event.Render3DEvent;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.event.SlowDownEvent;
import net.aspw.client.event.StepConfirmEvent;
import net.aspw.client.event.StepEvent;
import net.aspw.client.event.StrafeEvent;
import net.aspw.client.event.UpdateEvent;
import net.aspw.client.event.WorldEvent;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.ModuleInfo;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.value.Value;
import org.jetbrains.annotations.Nullable;

@ModuleInfo(name="ScriptModule", description="Empty", category=ModuleCategory.OTHER)
public final class ScriptModule
extends Module {
    private final JSObject moduleObject;
    private final HashMap<String, JSObject> events;
    private final LinkedHashMap<String, Value<?>> _values;
    private String _tag;
    private final Lazy settings$delegate;

    public ScriptModule(JSObject moduleObject) {
        Intrinsics.checkNotNullParameter((Object)moduleObject, (String)"moduleObject");
        this.moduleObject = moduleObject;
        this.events = new HashMap();
        this._values = new LinkedHashMap();
        this.settings$delegate = LazyKt.lazy((Function0)new Function0<LinkedHashMap<String, Value<?>>>(this){
            final /* synthetic */ ScriptModule this$0;
            {
                this.this$0 = $receiver;
                super(0);
            }

            public final LinkedHashMap<String, Value<?>> invoke() {
                return ScriptModule.access$get_values$p(this.this$0);
            }
        });
        Object object = this.moduleObject.getMember("name");
        if (object == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        this.setName((String)object);
        Object object2 = this.moduleObject.getMember("description");
        if (object2 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        this.setDescription((String)object2);
        if (this.moduleObject.hasMember("spacedName")) {
            Object object3 = this.moduleObject.getMember("spacedName");
            if (object3 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
            }
            this.setSpacedName((String)object3);
        } else {
            this.setSpacedName(this.getName());
        }
        Object object4 = this.moduleObject.getMember("category");
        if (object4 == null) {
            throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
        }
        String categoryString = (String)object4;
        for (ModuleCategory category : ModuleCategory.values()) {
            if (!StringsKt.equals((String)categoryString, (String)category.getDisplayName(), (boolean)true)) continue;
            this.setCategory(category);
        }
        if (this.moduleObject.hasMember("settings")) {
            Object object5 = this.moduleObject.getMember("settings");
            if (object5 == null) {
                throw new NullPointerException("null cannot be cast to non-null type jdk.nashorn.api.scripting.JSObject");
            }
            JSObject settings2 = (JSObject)object5;
            for (String settingName : settings2.keySet()) {
                Map map = this._values;
                Intrinsics.checkNotNullExpressionValue((Object)settingName, (String)"settingName");
                Object object6 = settings2.getMember(settingName);
                if (object6 == null) {
                    throw new NullPointerException("null cannot be cast to non-null type net.aspw.client.value.Value<*>");
                }
                map.put(settingName, (Value)object6);
            }
        }
        if (this.moduleObject.hasMember("tag")) {
            Object object7 = this.moduleObject.getMember("tag");
            if (object7 == null) {
                throw new NullPointerException("null cannot be cast to non-null type kotlin.String");
            }
            this._tag = (String)object7;
        }
    }

    public final LinkedHashMap<String, Value<?>> getSettings() {
        Lazy lazy = this.settings$delegate;
        return (LinkedHashMap)lazy.getValue();
    }

    @Override
    public List<Value<?>> getValues() {
        Collection<Value<?>> collection = this._values.values();
        Intrinsics.checkNotNullExpressionValue(collection, (String)"_values.values");
        return CollectionsKt.toList((Iterable)collection);
    }

    @Override
    public String getTag() {
        return this._tag;
    }

    public void setTag(@Nullable String value) {
        this._tag = value;
    }

    public final void on(String eventName, JSObject handler) {
        Intrinsics.checkNotNullParameter((Object)eventName, (String)"eventName");
        Intrinsics.checkNotNullParameter((Object)handler, (String)"handler");
        ((Map)this.events).put(eventName, handler);
    }

    @Override
    public void onEnable() {
        ScriptModule.callEvent$default(this, "enable", null, 2, null);
    }

    @Override
    public void onDisable() {
        ScriptModule.callEvent$default(this, "disable", null, 2, null);
    }

    @EventTarget
    public final void onUpdate(UpdateEvent updateEvent) {
        Intrinsics.checkNotNullParameter((Object)updateEvent, (String)"updateEvent");
        ScriptModule.callEvent$default(this, "update", null, 2, null);
    }

    @EventTarget
    public final void onMotion(MotionEvent motionEvent) {
        Intrinsics.checkNotNullParameter((Object)motionEvent, (String)"motionEvent");
        this.callEvent("motion", motionEvent);
    }

    @EventTarget
    public final void onRender2D(Render2DEvent render2DEvent) {
        Intrinsics.checkNotNullParameter((Object)render2DEvent, (String)"render2DEvent");
        this.callEvent("render2D", render2DEvent);
    }

    @EventTarget
    public final void onRender3D(Render3DEvent render3DEvent) {
        Intrinsics.checkNotNullParameter((Object)render3DEvent, (String)"render3DEvent");
        this.callEvent("render3D", render3DEvent);
    }

    @EventTarget
    public final void onPacket(PacketEvent packetEvent) {
        Intrinsics.checkNotNullParameter((Object)packetEvent, (String)"packetEvent");
        this.callEvent("packet", packetEvent);
    }

    @EventTarget
    public final void onJump(JumpEvent jumpEvent) {
        Intrinsics.checkNotNullParameter((Object)jumpEvent, (String)"jumpEvent");
        this.callEvent("jump", jumpEvent);
    }

    @EventTarget
    public final void onAttack(AttackEvent attackEvent) {
        Intrinsics.checkNotNullParameter((Object)attackEvent, (String)"attackEvent");
        this.callEvent("attack", attackEvent);
    }

    @EventTarget
    public final void onKey(KeyEvent keyEvent) {
        Intrinsics.checkNotNullParameter((Object)keyEvent, (String)"keyEvent");
        this.callEvent("key", keyEvent);
    }

    @EventTarget
    public final void onMove(MoveEvent moveEvent) {
        Intrinsics.checkNotNullParameter((Object)moveEvent, (String)"moveEvent");
        this.callEvent("move", moveEvent);
    }

    @EventTarget
    public final void onStep(StepEvent stepEvent) {
        Intrinsics.checkNotNullParameter((Object)stepEvent, (String)"stepEvent");
        this.callEvent("step", stepEvent);
    }

    @EventTarget
    public final void onStepConfirm(StepConfirmEvent stepConfirmEvent) {
        Intrinsics.checkNotNullParameter((Object)stepConfirmEvent, (String)"stepConfirmEvent");
        ScriptModule.callEvent$default(this, "stepConfirm", null, 2, null);
    }

    @EventTarget
    public final void onWorld(WorldEvent worldEvent) {
        Intrinsics.checkNotNullParameter((Object)worldEvent, (String)"worldEvent");
        this.callEvent("world", worldEvent);
    }

    @EventTarget
    public final void onSession(SessionEvent sessionEvent) {
        Intrinsics.checkNotNullParameter((Object)sessionEvent, (String)"sessionEvent");
        ScriptModule.callEvent$default(this, "session", null, 2, null);
    }

    @EventTarget
    public final void onClickBlock(ClickBlockEvent clickBlockEvent) {
        Intrinsics.checkNotNullParameter((Object)clickBlockEvent, (String)"clickBlockEvent");
        this.callEvent("clickBlock", clickBlockEvent);
    }

    @EventTarget
    public final void onStrafe(StrafeEvent strafeEvent) {
        Intrinsics.checkNotNullParameter((Object)strafeEvent, (String)"strafeEvent");
        this.callEvent("strafe", strafeEvent);
    }

    @EventTarget
    public final void onSlowDown(SlowDownEvent slowDownEvent) {
        Intrinsics.checkNotNullParameter((Object)slowDownEvent, (String)"slowDownEvent");
        this.callEvent("slowDown", slowDownEvent);
    }

    private final void callEvent(String eventName, Object payload) {
        try {
            JSObject jSObject = this.events.get(eventName);
            if (jSObject != null) {
                Object[] objectArray = new Object[]{payload};
                jSObject.call((Object)this.moduleObject, objectArray);
            }
        }
        catch (Throwable throwable) {
            ClientUtils.getLogger().error("[ScriptAPI] Exception in module '" + this.getName() + "'!", throwable);
        }
    }

    static /* synthetic */ void callEvent$default(ScriptModule scriptModule, String string, Object object, int n, Object object2) {
        if ((n & 2) != 0) {
            object = null;
        }
        scriptModule.callEvent(string, object);
    }

    public static final /* synthetic */ LinkedHashMap access$get_values$p(ScriptModule $this) {
        return $this._values;
    }
}

