/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.io.FilesKt
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.text.StringsKt
 */
package net.aspw.client.script.remapper;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import kotlin.io.FilesKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.aspw.client.Client;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.misc.HttpUtils;

public final class Remapper {
    public static final Remapper INSTANCE = new Remapper();
    private static final String srgName = "stable_22";
    private static final File srgFile = new File(Client.INSTANCE.getFileManager().dir, "mcp-stable_22.srg");
    private static final HashMap<String, HashMap<String, String>> fields = new HashMap();
    private static final HashMap<String, HashMap<String, String>> methods = new HashMap();

    private Remapper() {
    }

    public final void loadSrg() {
        if (srgFile.length() == 0L) {
            srgFile.createNewFile();
            ClientUtils.getLogger().info("[Remapper] Downloading stable_22 srg...");
            HttpUtils.download("https://nightx.skidded.host/s/6bl91v1egh", srgFile);
            ClientUtils.getLogger().info("[Remapper] Downloaded stable_22.");
        }
        ClientUtils.getLogger().info("[Remapper] Loading srg...");
        this.parseSrg();
        ClientUtils.getLogger().info("[Remapper] Loaded srg.");
    }

    private final void parseSrg() {
        Iterable $this$forEach$iv = FilesKt.readLines$default((File)srgFile, null, (int)1, null);
        boolean $i$f$forEach = false;
        for (Object element$iv : $this$forEach$iv) {
            String fieldSrg;
            String string;
            HashMap<String, String> hashMap;
            String name;
            String it = (String)element$iv;
            boolean bl = false;
            String[] stringArray = new String[]{" "};
            List args = StringsKt.split$default((CharSequence)it, (String[])stringArray, (boolean)false, (int)0, (int)6, null);
            if (StringsKt.startsWith$default((String)it, (String)"FD:", (boolean)false, (int)2, null)) {
                name = (String)args.get(1);
                String srg = (String)args.get(2);
                String string2 = name;
                int n = 0;
                int n2 = StringsKt.lastIndexOf$default((CharSequence)name, (char)'/', (int)0, (boolean)false, (int)6, null);
                String string3 = string2.substring(n, n2);
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
                String className = StringsKt.replace$default((String)string3, (char)'/', (char)'.', (boolean)false, (int)4, null);
                String string4 = name;
                n2 = StringsKt.lastIndexOf$default((CharSequence)name, (char)'/', (int)0, (boolean)false, (int)6, null) + 1;
                string3 = string4.substring(n2);
                Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"this as java.lang.String).substring(startIndex)");
                String fieldName = string3;
                hashMap = srg;
                int n3 = StringsKt.lastIndexOf$default((CharSequence)srg, (char)'/', (int)0, (boolean)false, (int)6, null) + 1;
                string = ((String)((Object)hashMap)).substring(n3);
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).substring(startIndex)");
                fieldSrg = string;
                if (!((Map)fields).containsKey(className)) {
                    hashMap = fields;
                    HashMap hashMap2 = new HashMap();
                    hashMap.put(className, (String)((Object)hashMap2));
                }
                HashMap<String, String> hashMap3 = fields.get(className);
                Intrinsics.checkNotNull(hashMap3);
                hashMap = hashMap3;
                Intrinsics.checkNotNullExpressionValue(hashMap, (String)"fields[className]!!");
                ((Map)hashMap).put(fieldSrg, fieldName);
                continue;
            }
            if (!StringsKt.startsWith$default((String)it, (String)"MD:", (boolean)false, (int)2, null)) continue;
            name = (String)args.get(1);
            String desc = (String)args.get(2);
            String srg = (String)args.get(3);
            fieldSrg = name;
            int n = 0;
            int n4 = StringsKt.lastIndexOf$default((CharSequence)name, (char)'/', (int)0, (boolean)false, (int)6, null);
            string = fieldSrg.substring(n, n4);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String\u2026ing(startIndex, endIndex)");
            String className = StringsKt.replace$default((String)string, (char)'/', (char)'.', (boolean)false, (int)4, null);
            hashMap = name;
            n4 = StringsKt.lastIndexOf$default((CharSequence)name, (char)'/', (int)0, (boolean)false, (int)6, null) + 1;
            string = ((String)((Object)hashMap)).substring(n4);
            Intrinsics.checkNotNullExpressionValue((Object)string, (String)"this as java.lang.String).substring(startIndex)");
            String methodName = string;
            Map<String, String> map = srg;
            int n5 = StringsKt.lastIndexOf$default((CharSequence)srg, (char)'/', (int)0, (boolean)false, (int)6, null) + 1;
            String string5 = ((String)((Object)map)).substring(n5);
            Intrinsics.checkNotNullExpressionValue((Object)string5, (String)"this as java.lang.String).substring(startIndex)");
            String methodSrg = string5;
            if (!((Map)methods).containsKey(className)) {
                map = methods;
                HashMap hashMap4 = new HashMap();
                map.put(className, (String)((Object)hashMap4));
            }
            HashMap<String, String> hashMap5 = methods.get(className);
            Intrinsics.checkNotNull(hashMap5);
            map = hashMap5;
            Intrinsics.checkNotNullExpressionValue(map, (String)"methods[className]!!");
            map = map;
            string = Intrinsics.stringPlus((String)methodSrg, (Object)desc);
            map.put(string, methodName);
        }
    }

    public final String remapField(Class<?> clazz, String name) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        if (!fields.containsKey(clazz.getName())) {
            return name;
        }
        HashMap<String, String> hashMap = fields.get(clazz.getName());
        Intrinsics.checkNotNull(hashMap);
        String string = hashMap.getOrDefault(name, name);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"fields[clazz.name]!!.getOrDefault(name, name)");
        return string;
    }

    public final String remapMethod(Class<?> clazz, String name, String desc) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)desc, (String)"desc");
        if (!methods.containsKey(clazz.getName())) {
            return name;
        }
        HashMap<String, String> hashMap = methods.get(clazz.getName());
        Intrinsics.checkNotNull(hashMap);
        String string = hashMap.getOrDefault(Intrinsics.stringPlus((String)name, (Object)desc), name);
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"methods[clazz.name]!!.ge\u2026efault(name + desc, name)");
        return string;
    }
}

