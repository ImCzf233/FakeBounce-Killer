/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  org.objectweb.asm.tree.AbstractInsnNode
 *  org.objectweb.asm.tree.InsnList
 */
package net.aspw.client.script.remapper.injection.utils;

import kotlin.jvm.internal.Intrinsics;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;

public final class NodeUtils {
    public static final NodeUtils INSTANCE = new NodeUtils();

    private NodeUtils() {
    }

    public final InsnList toNodes(AbstractInsnNode ... nodes) {
        Intrinsics.checkNotNullParameter((Object)nodes, (String)"nodes");
        InsnList insnList = new InsnList();
        for (AbstractInsnNode node : nodes) {
            insnList.add(node);
        }
        return insnList;
    }
}

