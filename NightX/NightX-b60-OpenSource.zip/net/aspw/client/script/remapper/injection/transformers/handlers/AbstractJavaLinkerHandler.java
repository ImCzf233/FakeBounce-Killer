/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.JvmStatic
 *  kotlin.jvm.internal.Intrinsics
 *  org.objectweb.asm.Type
 */
package net.aspw.client.script.remapper.injection.transformers.handlers;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Method;
import kotlin.jvm.JvmStatic;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.script.remapper.Remapper;
import org.objectweb.asm.Type;

public final class AbstractJavaLinkerHandler {
    public static final AbstractJavaLinkerHandler INSTANCE = new AbstractJavaLinkerHandler();

    private AbstractJavaLinkerHandler() {
    }

    @JvmStatic
    public static final String addMember(Class<?> clazz, String name, AccessibleObject accessibleObject) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter((Object)accessibleObject, (String)"accessibleObject");
        if (!(accessibleObject instanceof Method)) {
            return name;
        }
        Object currentClass = clazz;
        while (!((Class)currentClass).getName().equals("java.lang.Object")) {
            Object object = Type.getMethodDescriptor((Method)((Method)accessibleObject));
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"getMethodDescriptor(accessibleObject)");
            String remapped = Remapper.INSTANCE.remapMethod((Class<?>)currentClass, name, (String)object);
            if (!remapped.equals(name)) {
                return remapped;
            }
            if (((Class)currentClass).getSuperclass() == null) break;
            object = ((Class)currentClass).getSuperclass();
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"currentClass.superclass");
            currentClass = object;
        }
        return name;
    }

    @JvmStatic
    public static final String addMember(Class<?> clazz, String name) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Class<?> currentClass = clazz;
        while (!currentClass.getName().equals("java.lang.Object")) {
            String remapped = Remapper.INSTANCE.remapField(currentClass, name);
            if (!remapped.equals(name)) {
                return remapped;
            }
            if (currentClass.getSuperclass() == null) break;
            Class<?> clazz2 = currentClass.getSuperclass();
            Intrinsics.checkNotNullExpressionValue(clazz2, (String)"currentClass.superclass");
            currentClass = clazz2;
        }
        return name;
    }

    @JvmStatic
    public static final String setPropertyGetter(Class<?> clazz, String name) {
        Intrinsics.checkNotNullParameter(clazz, (String)"clazz");
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Class<?> currentClass = clazz;
        while (!currentClass.getName().equals("java.lang.Object")) {
            String remapped = Remapper.INSTANCE.remapField(currentClass, name);
            if (!remapped.equals(name)) {
                return remapped;
            }
            if (currentClass.getSuperclass() == null) break;
            Class<?> clazz2 = currentClass.getSuperclass();
            Intrinsics.checkNotNullExpressionValue(clazz2, (String)"currentClass.superclass");
            currentClass = clazz2;
        }
        return name;
    }
}

