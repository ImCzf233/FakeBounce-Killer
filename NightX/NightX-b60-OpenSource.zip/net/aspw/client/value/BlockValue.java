/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 */
package net.aspw.client.value;

import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import net.aspw.client.value.IntegerValue;

public final class BlockValue
extends IntegerValue {
    public BlockValue(String name, int value, Function0<Boolean> displayable) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        Intrinsics.checkNotNullParameter(displayable, (String)"displayable");
        super(name, value, 1, 197, displayable);
    }

    public BlockValue(String name, int value) {
        Intrinsics.checkNotNullParameter((Object)name, (String)"name");
        this(name, value, (Function0<Boolean>)((Function0)1.INSTANCE));
    }
}

