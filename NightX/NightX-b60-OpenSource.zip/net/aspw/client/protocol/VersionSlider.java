/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.MathHelper
 */
package net.aspw.client.protocol;

import java.util.Collections;
import java.util.List;
import net.aspw.client.protocol.Protocol;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;
import net.raphimc.vialoader.util.VersionEnum;

public class VersionSlider
extends GuiButton {
    private float dragValue = this.calculateDragValue(Protocol.targetVersion);
    private final List<VersionEnum> values = VersionEnum.SORTED_VERSIONS;
    private float sliderValue;
    public boolean dragging;

    public VersionSlider(int buttonId, int x, int y, int widthIn, int heightIn) {
        super(buttonId, x, y, Math.max(widthIn, 88), heightIn, "");
        Collections.reverse(this.values);
        this.sliderValue = this.dragValue;
        this.field_146126_j = this.getSliderVersion().getName().equals("1.20") ? "Protocol: 1.20/1" : (this.getSliderVersion().getName().equals("1.18/1.18.1") ? "Protocol: 1.18/1" : "Protocol: " + this.getSliderVersion().getName());
    }

    public float calculateDragValue(VersionEnum version) {
        int size = VersionEnum.SORTED_VERSIONS.size();
        return (size - VersionEnum.SORTED_VERSIONS.indexOf((Object)version)) / size;
    }

    public VersionEnum getSliderVersion() {
        return this.values.get((int)(this.sliderValue * (float)(this.values.size() - 1)));
    }

    public void func_146112_a(Minecraft mc, int mouseX, int mouseY) {
        super.func_146112_a(mc, mouseX, mouseY);
    }

    protected int func_146114_a(boolean mouseOver) {
        return 0;
    }

    protected void func_146119_b(Minecraft mc, int mouseX, int mouseY) {
        if (this.field_146125_m) {
            if (this.dragging) {
                this.sliderValue = (float)(mouseX - (this.field_146128_h + 4)) / (float)(this.field_146120_f - 8);
                this.dragValue = this.sliderValue = MathHelper.func_76131_a((float)this.sliderValue, (float)0.0f, (float)1.0f);
                this.field_146126_j = this.getSliderVersion().getName().equals("1.20") ? "Protocol: 1.20/1" : (this.getSliderVersion().getName().equals("1.18/1.18.1") ? "Protocol: 1.18/1" : "Protocol: " + this.getSliderVersion().getName());
                Protocol.targetVersion = this.getSliderVersion();
            }
            mc.func_110434_K().func_110577_a(field_146122_a);
            GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            this.func_73729_b(this.field_146128_h + (int)(this.sliderValue * (float)(this.field_146120_f - 8)), this.field_146129_i, 0, 66, 4, 20);
            this.func_73729_b(this.field_146128_h + (int)(this.sliderValue * (float)(this.field_146120_f - 8)) + 4, this.field_146129_i, 196, 66, 4, 20);
        }
    }

    public boolean func_146116_c(Minecraft mc, int mouseX, int mouseY) {
        if (super.func_146116_c(mc, mouseX, mouseY)) {
            this.sliderValue = (float)(mouseX - (this.field_146128_h + 4)) / (float)(this.field_146120_f - 8);
            this.dragValue = this.sliderValue = MathHelper.func_76131_a((float)this.sliderValue, (float)0.0f, (float)1.0f);
            this.field_146126_j = this.getSliderVersion().getName().equals("1.20") ? "Protocol: 1.20/1" : (this.getSliderVersion().getName().equals("1.18/1.18.1") ? "Protocol: 1.18/1" : "Protocol: " + this.getSliderVersion().getName());
            Protocol.targetVersion = this.getSliderVersion();
            this.dragging = true;
            return true;
        }
        return false;
    }

    public void func_146118_a(int mouseX, int mouseY) {
        this.dragging = false;
    }
}

