/*
 * Decompiled with CFR 0.152.
 */
package net.aspw.client.protocol;

public final class ViaPatcher {
    public static final ViaPatcher INSTANCE = new ViaPatcher();
    private static boolean ladderFix = true;
    private static boolean lilyPadFix = true;
    private static boolean livingBaseFix = true;
    private static boolean entityFix = true;

    private ViaPatcher() {
    }

    public final boolean getLadderFix() {
        return ladderFix;
    }

    public final void setLadderFix(boolean bl) {
        ladderFix = bl;
    }

    public final boolean getLilyPadFix() {
        return lilyPadFix;
    }

    public final void setLilyPadFix(boolean bl) {
        lilyPadFix = bl;
    }

    public final boolean getLivingBaseFix() {
        return livingBaseFix;
    }

    public final void setLivingBaseFix(boolean bl) {
        livingBaseFix = bl;
    }

    public final boolean getEntityFix() {
        return entityFix;
    }

    public final void setEntityFix(boolean bl) {
        entityFix = bl;
    }
}

