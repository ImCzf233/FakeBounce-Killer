/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.viaversion.viaversion.api.Via
 *  com.viaversion.viaversion.api.connection.UserConnection
 *  com.viaversion.viaversion.api.platform.providers.Provider
 *  com.viaversion.viaversion.api.protocol.version.VersionProvider
 *  com.viaversion.viaversion.protocols.base.BaseVersionProvider
 *  net.minecraft.client.Minecraft
 */
package net.aspw.client.protocol;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.connection.UserConnection;
import com.viaversion.viaversion.api.platform.providers.Provider;
import com.viaversion.viaversion.api.protocol.version.VersionProvider;
import com.viaversion.viaversion.protocols.base.BaseVersionProvider;
import net.aspw.client.protocol.VersionSlider;
import net.minecraft.client.Minecraft;
import net.raphimc.vialoader.ViaLoader;
import net.raphimc.vialoader.impl.platform.ViaBackwardsPlatformImpl;
import net.raphimc.vialoader.impl.platform.ViaRewindPlatformImpl;
import net.raphimc.vialoader.impl.viaversion.VLInjector;
import net.raphimc.vialoader.impl.viaversion.VLLoader;
import net.raphimc.vialoader.util.VersionEnum;

public class Protocol {
    public static final VersionEnum NATIVE_VERSION = VersionEnum.r1_8;
    public static VersionEnum targetVersion = VersionEnum.r1_8;
    public static VersionSlider versionSlider;

    public static void start() {
        VersionEnum.SORTED_VERSIONS.remove((Object)VersionEnum.r1_7_6tor1_7_10);
        VersionEnum.SORTED_VERSIONS.remove((Object)VersionEnum.r1_7_2tor1_7_5);
        Protocol.initAsyncSlider();
        ViaLoader.init(null, new VLLoader(){

            @Override
            public void load() {
                super.load();
                Via.getManager().getProviders().use(VersionProvider.class, (Provider)new BaseVersionProvider(){

                    public int getClosestServerProtocol(UserConnection connection) throws Exception {
                        if (connection.isClientSide() && !Minecraft.func_71410_x().func_71356_B()) {
                            return targetVersion.getVersion();
                        }
                        return super.getClosestServerProtocol(connection);
                    }
                });
            }
        }, new VLInjector(){

            @Override
            public String getDecoderName() {
                return "via-decoder";
            }

            @Override
            public String getEncoderName() {
                return "via-encoder";
            }
        }, null, ViaBackwardsPlatformImpl::new, ViaRewindPlatformImpl::new);
    }

    public static void initAsyncSlider() {
        Protocol.initAsyncSlider(5, 5, 88, 20);
    }

    public static void initAsyncSlider(int x, int y, int width, int height) {
        versionSlider = new VersionSlider(-1, x, y, Math.max(width, 88), height);
    }

    public static VersionSlider getAsyncVersionSlider() {
        return versionSlider;
    }
}

