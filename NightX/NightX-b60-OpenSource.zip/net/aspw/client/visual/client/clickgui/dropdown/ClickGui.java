/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package net.aspw.client.visual.client.clickgui.dropdown;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.aspw.client.Client;
import net.aspw.client.features.module.Module;
import net.aspw.client.features.module.ModuleCategory;
import net.aspw.client.features.module.impl.visual.Gui;
import net.aspw.client.util.render.EaseUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.visual.client.clickgui.dropdown.Panel;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ButtonElement;
import net.aspw.client.visual.client.clickgui.dropdown.elements.Element;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ModuleElement;
import net.aspw.client.visual.client.clickgui.dropdown.style.Style;
import net.aspw.client.visual.client.clickgui.dropdown.style.styles.DropDown;
import net.aspw.client.visual.font.AWTFontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ClickGui
extends GuiScreen {
    public final List<Panel> panels = new ArrayList<Panel>();
    public Style style = new DropDown();
    private Panel clickedPanel;
    private int mouseX;
    private int mouseY;
    public double slide;
    public double progress = 0.0;
    public long lastMS = System.currentTimeMillis();

    public ClickGui() {
        int width = 100;
        int height = 18;
        int xPos = 253;
        for (final ModuleCategory category : ModuleCategory.values()) {
            this.panels.add(new Panel(category.getDisplayName(), xPos, 30, 100, 18, true){

                @Override
                public void setupItems() {
                    for (Module module : Client.moduleManager.getModules()) {
                        if (module.getCategory() != category) continue;
                        this.getElements().add(new ModuleElement(module));
                    }
                }
            });
            xPos += 111;
        }
    }

    public void func_73866_w_() {
        this.progress = 0.0;
        this.slide = 0.0;
        this.lastMS = System.currentTimeMillis();
        super.func_73866_w_();
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        RenderUtils.drawGradientRect(0, 0, this.field_146294_l, this.field_146295_m, -1072689136, -804253680);
        this.progress = this.progress < 1.0 ? (double)((float)(System.currentTimeMillis() - this.lastMS) / 428.57144f) : 1.0;
        switch (((String)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).animationValue.get()).toLowerCase()) {
            case "none": {
                this.slide = 1.0;
                break;
            }
            case "zoom": {
                this.slide = EaseUtils.easeOutBack(this.progress);
            }
        }
        AWTFontRenderer.Companion.setAssumeNonVolatile(true);
        double scale = (double)((Float)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).scaleValue.get()).floatValue() - 0.1765;
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        GlStateManager.func_179118_c();
        GlStateManager.func_179141_d();
        switch (((String)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).animationValue.get()).toLowerCase()) {
            case "none": {
                GlStateManager.func_179139_a((double)scale, (double)scale, (double)scale);
                break;
            }
            case "zoom": {
                GlStateManager.func_179137_b((double)((1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)((1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)0.0);
                GlStateManager.func_179139_a((double)(scale * this.slide), (double)(scale * this.slide), (double)(scale * this.slide));
            }
        }
        RenderUtils.drawImage2(new ResourceLocation("client/images/" + (String)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).imageModeValue.getValue() + ".png"), (float)this.field_146294_l - 26.0f, (float)this.field_146295_m - 160.0f, 80, 80);
        GL11.glPushMatrix();
        GlStateManager.func_179141_d();
        GL11.glPopMatrix();
        for (Panel panel : this.panels) {
            panel.updateFade(RenderUtils.deltaTime);
            panel.drawScreen(mouseX, mouseY, partialTicks);
        }
        for (Panel panel : this.panels) {
            for (Element element : panel.getElements()) {
                if (!(element instanceof ModuleElement)) continue;
                ModuleElement moduleElement = (ModuleElement)element;
            }
        }
        GlStateManager.func_179140_f();
        RenderHelper.func_74518_a();
        if (((String)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).animationValue.get()).equalsIgnoreCase("zoom")) {
            GlStateManager.func_179137_b((double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)0.0);
        }
        GlStateManager.func_179152_a((float)1.0f, (float)1.0f, (float)1.0f);
        AWTFontRenderer.Companion.setAssumeNonVolatile(false);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    public void func_146274_d() throws IOException {
        super.func_146274_d();
        int wheel = Mouse.getEventDWheel();
        for (int i = this.panels.size() - 1; i >= 0 && !this.panels.get(i).handleScroll(this.mouseX, this.mouseY, wheel); --i) {
        }
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        double scale = (double)((Float)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).scaleValue.get()).floatValue() - 0.1765;
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        for (int i = this.panels.size() - 1; i >= 0 && !this.panels.get(i).mouseClicked(mouseX, mouseY, mouseButton); --i) {
        }
        for (Panel panel : this.panels) {
            panel.drag = false;
            if (mouseButton != 0 || !panel.isHovering(mouseX, mouseY)) continue;
            this.clickedPanel = panel;
            break;
        }
        if (this.clickedPanel != null) {
            this.clickedPanel.x2 = this.clickedPanel.x - mouseX;
            this.clickedPanel.y2 = this.clickedPanel.y - mouseY;
            this.clickedPanel.drag = true;
            this.panels.remove(this.clickedPanel);
            this.panels.add(this.clickedPanel);
            this.clickedPanel = null;
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    protected void func_146286_b(int mouseX, int mouseY, int state) {
        double scale = (double)((Float)Objects.requireNonNull(Client.moduleManager.getModule(Gui.class)).scaleValue.get()).floatValue() - 0.1765;
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        for (Panel panel : this.panels) {
            panel.mouseReleased(mouseX, mouseY, state);
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    public void func_73876_c() {
        for (Panel panel : this.panels) {
            for (Element element : panel.getElements()) {
                if (element instanceof ButtonElement) {
                    ButtonElement buttonElement = (ButtonElement)element;
                    if (buttonElement.isHovering(this.mouseX, this.mouseY)) {
                        if (buttonElement.hoverTime < 7) {
                            ++buttonElement.hoverTime;
                        }
                    } else if (buttonElement.hoverTime > 0) {
                        --buttonElement.hoverTime;
                    }
                }
                if (!(element instanceof ModuleElement)) continue;
                if (((ModuleElement)element).getModule().getState()) {
                    if (((ModuleElement)element).slowlyFade < 255) {
                        ((ModuleElement)element).slowlyFade += 100;
                    }
                } else if (((ModuleElement)element).slowlyFade > 0) {
                    ((ModuleElement)element).slowlyFade -= 100;
                }
                if (((ModuleElement)element).slowlyFade > 255) {
                    ((ModuleElement)element).slowlyFade = 255;
                }
                if (((ModuleElement)element).slowlyFade >= 0) continue;
                ((ModuleElement)element).slowlyFade = 0;
            }
        }
        super.func_73876_c();
    }

    public boolean func_73868_f() {
        return false;
    }
}

