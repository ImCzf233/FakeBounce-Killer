/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package net.aspw.client.visual.client.clickgui.dropdown.elements;

import net.aspw.client.Client;
import net.aspw.client.features.module.Module;
import net.aspw.client.visual.client.clickgui.dropdown.elements.ButtonElement;
import org.lwjgl.input.Mouse;

public class ModuleElement
extends ButtonElement {
    private final Module module;
    private boolean showSettings;
    private boolean wasPressed;
    public int slowlySettingsYPos;
    public int slowlyFade;

    public ModuleElement(Module module) {
        super(null);
        this.displayName = module.getName();
        this.module = module;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float button) {
        Client.clickGui.style.drawModuleElement(mouseX, mouseY, this);
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY) && this.isVisible()) {
            this.module.toggle();
            return true;
        }
        if (mouseButton == 1 && this.isVisible()) {
            this.showSettings = this.isHovering(mouseX, mouseY) ? !this.showSettings : false;
            return false;
        }
        return false;
    }

    public Module getModule() {
        return this.module;
    }

    public boolean isShowSettings() {
        return this.showSettings;
    }

    public boolean isntPressed() {
        return !this.wasPressed;
    }

    public void updatePressed() {
        this.wasPressed = Mouse.isButtonDown((int)0);
    }

    public float getSettingsWidth() {
        return 140.0f;
    }

    public void setSettingsWidth(float settingsWidth) {
    }
}

