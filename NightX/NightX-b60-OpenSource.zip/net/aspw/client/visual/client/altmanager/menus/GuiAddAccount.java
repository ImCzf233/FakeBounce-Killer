/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.thealtening.AltService$EnumAltService
 *  kotlin.Unit
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.internal.Intrinsics
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MinecraftAccount
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 */
package net.aspw.client.visual.client.altmanager.menus;

import com.thealtening.AltService;
import java.io.IOException;
import java.util.List;
import kotlin.Unit;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MinecraftAccount;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.client.altmanager.menus.GuiMicrosoftLogin;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public final class GuiAddAccount
extends GuiScreen {
    private final GuiAltManager prevGui;
    private GuiButton addButton;
    private GuiTextField username;
    private String status;

    public GuiAddAccount(GuiAltManager prevGui) {
        Intrinsics.checkNotNullParameter((Object)((Object)prevGui), (String)"prevGui");
        this.prevGui = prevGui;
        this.status = "\u00a77Waiting...";
    }

    /*
     * WARNING - void declaration
     */
    public void func_73866_w_() {
        void it;
        GuiButton guiButton;
        Keyboard.enableRepeatEvents((boolean)true);
        this.field_146292_n.add(new GuiButton(3, this.field_146294_l / 2 - 100, 143, "Microsoft"));
        GuiButton guiButton2 = guiButton = new GuiButton(1, this.field_146294_l / 2 - 100, this.field_146295_m - 54, 98, 20, "Add");
        List list = this.field_146292_n;
        boolean bl = false;
        this.addButton = it;
        list.add(guiButton);
        this.field_146292_n.add(new GuiButton(0, this.field_146294_l / 2 + 2, this.field_146295_m - 54, 98, 20, "Done"));
        this.username = new GuiTextField(2, this.field_146297_k.field_71466_p, this.field_146294_l / 2 - 100, 90, 200, 20);
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146195_b(false);
        GuiTextField guiTextField2 = this.username;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.func_146203_f(16);
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146278_c(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.field_146294_l, this.field_146295_m);
        RenderUtils.drawRect(30.0f, 30.0f, (float)this.field_146294_l - 30.0f, (float)this.field_146295_m - 30.0f, Integer.MIN_VALUE);
        this.func_73732_a(this.field_146297_k.field_71466_p, "Add Account", this.field_146294_l / 2, 34, 0xFFFFFF);
        this.func_73732_a(this.field_146297_k.field_71466_p, this.status, this.field_146294_l / 2, this.field_146295_m - 74, 0xFFFFFF);
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146194_f();
        GuiTextField guiTextField2 = this.username;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        String string = guiTextField2.func_146179_b();
        Intrinsics.checkNotNullExpressionValue((Object)string, (String)"username.text");
        if (((CharSequence)string).length() == 0) {
            GuiTextField guiTextField3 = this.username;
            if (guiTextField3 == null) {
                guiTextField3 = null;
            }
            if (!guiTextField3.func_146206_l()) {
                this.func_73732_a(this.field_146297_k.field_71466_p, "\u00a77Username (Cracked)", this.field_146294_l / 2 - 45, 96, 0xFFFFFF);
            }
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    protected void func_146284_a(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (!button.field_146124_l) {
            return;
        }
        switch (button.field_146127_k) {
            case 0: {
                this.field_146297_k.func_147108_a((GuiScreen)this.prevGui);
                break;
            }
            case 1: {
                GuiTextField guiTextField = this.username;
                if (guiTextField == null) {
                    guiTextField = null;
                }
                String string = guiTextField.func_146179_b();
                Intrinsics.checkNotNullExpressionValue((Object)string, (String)"username.text");
                this.checkAndAddAccount(string, new CrackedAccount());
                break;
            }
            case 3: {
                this.field_146297_k.func_147108_a((GuiScreen)new GuiMicrosoftLogin(this));
            }
        }
    }

    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == 1) {
            this.field_146297_k.func_147108_a((GuiScreen)this.prevGui);
            return;
        }
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        if (guiTextField.func_146206_l()) {
            GuiTextField guiTextField2 = this.username;
            if (guiTextField2 == null) {
                guiTextField2 = null;
            }
            guiTextField2.func_146201_a(typedChar, keyCode);
        }
        super.func_73869_a(typedChar, keyCode);
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146192_a(mouseX, mouseY, mouseButton);
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    public void func_73876_c() {
        GuiTextField guiTextField = this.username;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146178_a();
        super.func_73876_c();
    }

    public void func_146281_b() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    private final void checkAndAddAccount(String usernameText, CrackedAccount account) {
        if (((CharSequence)usernameText).length() == 0) {
            return;
        }
        account.setName(usernameText);
        if (Client.INSTANCE.getFileManager().accountsConfig.accountExists((MinecraftAccount)account)) {
            this.status = "\u00a7cThe account has already been added.";
            return;
        }
        GuiButton guiButton = this.addButton;
        if (guiButton == null) {
            guiButton = null;
        }
        guiButton.field_146124_l = false;
        ThreadsKt.thread$default((boolean)false, (boolean)false, null, (String)"Account-Checking-Task", (int)0, (Function0)((Function0)new Function0<Unit>(this, account){
            final /* synthetic */ GuiAddAccount this$0;
            final /* synthetic */ CrackedAccount $account;
            {
                this.this$0 = $receiver;
                this.$account = $account;
                super(0);
            }

            public final void invoke() {
                try {
                    AltService.EnumAltService oldService = GuiAltManager.Companion.getAltService().getCurrentService();
                    if (oldService != AltService.EnumAltService.MOJANG) {
                        GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                    }
                }
                catch (Exception e) {
                    GuiAddAccount.access$setStatus$p(this.this$0, Intrinsics.stringPlus((String)"\u00a7c", (Object)e.getMessage()));
                    GuiButton guiButton = GuiAddAccount.access$getAddButton$p(this.this$0);
                    if (guiButton == null) {
                        guiButton = null;
                    }
                    guiButton.field_146124_l = true;
                    return;
                }
                Client.INSTANCE.getFileManager().accountsConfig.addAccount((MinecraftAccount)this.$account);
                Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                GuiAddAccount.access$setStatus$p(this.this$0, "\u00a7aThe account has been added.");
                GuiAddAccount.access$getPrevGui$p(this.this$0).setStatus(GuiAddAccount.access$getStatus$p(this.this$0));
                this.this$0.field_146297_k.func_147108_a((GuiScreen)GuiAddAccount.access$getPrevGui$p(this.this$0));
            }
        }), (int)23, null);
    }

    public static final /* synthetic */ void access$setStatus$p(GuiAddAccount $this, String string) {
        $this.status = string;
    }

    public static final /* synthetic */ GuiButton access$getAddButton$p(GuiAddAccount $this) {
        return $this.addButton;
    }

    public static final /* synthetic */ GuiAltManager access$getPrevGui$p(GuiAddAccount $this) {
        return $this.prevGui;
    }

    public static final /* synthetic */ String access$getStatus$p(GuiAddAccount $this) {
        return $this.status;
    }
}

