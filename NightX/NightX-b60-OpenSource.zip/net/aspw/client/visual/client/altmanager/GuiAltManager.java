/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.Agent
 *  com.mojang.authlib.exceptions.AuthenticationException
 *  com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService
 *  com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication
 *  com.thealtening.AltService
 *  com.thealtening.AltService$EnumAltService
 *  com.thealtening.api.TheAltening
 *  com.thealtening.api.TheAltening$Asynchronous
 *  com.thealtening.api.data.AccountData
 *  kotlin.NoWhenBranchMatchedException
 *  kotlin.Unit
 *  kotlin.collections.CollectionsKt
 *  kotlin.concurrent.ThreadsKt
 *  kotlin.jvm.functions.Function0
 *  kotlin.jvm.functions.Function1
 *  kotlin.jvm.internal.DefaultConstructorMarker
 *  kotlin.jvm.internal.Intrinsics
 *  kotlin.random.Random
 *  kotlin.ranges.RangesKt
 *  kotlin.text.StringsKt
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MicrosoftAccount
 *  me.liuli.elixir.account.MinecraftAccount
 *  me.liuli.elixir.account.MojangAccount
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiSlot
 *  net.minecraft.client.gui.GuiTextField
 *  net.minecraft.util.ResourceLocation
 *  net.minecraft.util.Session
 *  org.jetbrains.annotations.Nullable
 */
package net.aspw.client.visual.client.altmanager;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import com.thealtening.AltService;
import com.thealtening.api.TheAltening;
import com.thealtening.api.data.AccountData;
import java.awt.Color;
import java.lang.invoke.LambdaMetafactory;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.concurrent.ThreadsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.random.Random;
import kotlin.ranges.RangesKt;
import kotlin.text.StringsKt;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MicrosoftAccount;
import me.liuli.elixir.account.MinecraftAccount;
import me.liuli.elixir.account.MojangAccount;
import net.aspw.client.Client;
import net.aspw.client.event.SessionEvent;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.connection.CheckConnection;
import net.aspw.client.util.connection.LoginID;
import net.aspw.client.util.login.LoginUtils;
import net.aspw.client.util.login.UserUtils;
import net.aspw.client.util.misc.RandomUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.aspw.client.visual.client.altmanager.GuiAltManager;
import net.aspw.client.visual.client.altmanager.menus.GuiAddAccount;
import net.aspw.client.visual.client.altmanager.menus.GuiTheAltening;
import net.aspw.client.visual.font.Fonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.jetbrains.annotations.Nullable;

/*
 * Illegal identifiers - consider using --renameillegalidents true
 */
public final class GuiAltManager
extends GuiScreen {
    public static final Companion Companion = new Companion(null);
    private final GuiScreen prevGui;
    private String status;
    private GuiButton loginButton;
    private GuiButton randomButton;
    private GuiButton randomCracked;
    private GuiList altsList;
    private GuiTextField searchField;
    private String lastSessionToken;
    private static final AltService altService = new AltService();
    private static final Map<String, Boolean> activeGenerators = new LinkedHashMap();

    public GuiAltManager(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
        this.status = "\u00a77Waiting...";
    }

    public final String getStatus() {
        return this.status;
    }

    public final void setStatus(String string) {
        Intrinsics.checkNotNullParameter((Object)string, (String)"<set-?>");
        this.status = string;
    }

    public final String getLastSessionToken() {
        return this.lastSessionToken;
    }

    public final void setLastSessionToken(@Nullable String string) {
        this.lastSessionToken = string;
    }

    /*
     * WARNING - void declaration
     */
    public void func_73866_w_() {
        GuiButton it;
        GuiButton guiButton;
        GuiList guiList;
        GuiList guiList2;
        int mightBeTheCurrentAccount;
        block8: {
            int n;
            void $this$indexOfFirst$iv;
            int textFieldWidth = RangesKt.coerceAtLeast((int)(this.field_146294_l / 8), (int)70);
            this.searchField = new GuiTextField(2, this.field_146297_k.field_71466_p, this.field_146294_l - textFieldWidth - 10, 10, textFieldWidth, 20);
            GuiTextField guiTextField = this.searchField;
            if (guiTextField == null) {
                guiTextField = null;
            }
            guiTextField.func_146203_f(Integer.MAX_VALUE);
            this.altsList = new GuiList(this);
            GuiList guiList3 = this.altsList;
            if (guiList3 == null) {
                guiList3 = null;
            }
            guiList3.func_148134_d(7, 8);
            List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
            Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
            boolean $i$f$indexOfFirst = false;
            int index$iv = 0;
            for (Object item$iv : $this$indexOfFirst$iv) {
                MinecraftAccount it2 = (MinecraftAccount)item$iv;
                boolean bl = false;
                if (it2.getName().equals(this.field_146297_k.field_71449_j.func_111285_a())) {
                    n = index$iv;
                    break block8;
                }
                ++index$iv;
            }
            n = mightBeTheCurrentAccount = -1;
        }
        if ((guiList2 = this.altsList) == null) {
            guiList2 = null;
        }
        guiList2.func_148144_a(mightBeTheCurrentAccount, false, 0, 0);
        GuiList guiList4 = this.altsList;
        if (guiList4 == null) {
            guiList4 = null;
        }
        if ((guiList = this.altsList) == null) {
            guiList = null;
        }
        guiList4.func_148145_f(mightBeTheCurrentAccount * guiList.func_148146_j());
        int startPositionY = 22;
        this.field_146292_n.add(new GuiButton(1, this.field_146294_l - 80, startPositionY + 24, 70, 20, "Add"));
        this.field_146292_n.add(new GuiButton(2, this.field_146294_l - 80, startPositionY + 48, 70, 20, "Delete"));
        this.field_146292_n.add(new GuiButton(0, this.field_146294_l - 80, this.field_146295_m - 65, 70, 20, "Done"));
        GuiButton index$iv = guiButton = new GuiButton(3, 5, startPositionY + 24, 90, 20, "Login");
        List list = this.field_146292_n;
        boolean bl = false;
        this.loginButton = it;
        list.add(guiButton);
        it = guiButton = new GuiButton(4, 5, startPositionY + 48, 90, 20, "Random Alt");
        list = this.field_146292_n;
        boolean bl2 = false;
        this.randomButton = it;
        list.add(guiButton);
        it = guiButton = new GuiButton(99, 5, startPositionY + 72, 90, 20, "Random Cracked");
        list = this.field_146292_n;
        boolean bl3 = false;
        this.randomCracked = it;
        list.add(guiButton);
        if (activeGenerators.getOrDefault("thealtening", true).booleanValue()) {
            this.field_146292_n.add(new GuiButton(9, 5, startPositionY + 96, 90, 20, "The Altening"));
        }
        this.field_146292_n.add(new GuiButton(13, this.field_146294_l - 80, startPositionY + 72, 70, 20, "Premium Gen"));
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        String string;
        String string2;
        this.func_146278_c(0);
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.field_146294_l, this.field_146295_m);
        GuiList guiList = this.altsList;
        if (guiList == null) {
            guiList = null;
        }
        guiList.func_148128_a(mouseX, mouseY, partialTicks);
        this.func_73732_a(this.field_146297_k.field_71466_p, "Alt Manager", this.field_146294_l / 2, 12, 0xFFFFFF);
        this.func_73732_a(this.field_146297_k.field_71466_p, Intrinsics.stringPlus((String)"\u00a77Status: \u00a7a", (Object)this.status), this.field_146294_l / 2, 25, 0xFFFFFF);
        FontRenderer fontRenderer = this.field_146297_k.field_71466_p;
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        String string3 = guiTextField.func_146179_b();
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"searchField.text");
        if (((CharSequence)string3).length() == 0) {
            string2 = Intrinsics.stringPlus((String)"\u00a77Alts: \u00a7a", (Object)Client.INSTANCE.getFileManager().accountsConfig.getAccounts().size());
        } else {
            GuiList guiList2 = this.altsList;
            if (guiList2 == null) {
                guiList2 = null;
            }
            string2 = Intrinsics.stringPlus((String)"\u00a77Search Results: \u00a7a", (Object)guiList2.getAccounts().size());
        }
        this.func_73731_b(fontRenderer, string2, 6, 26, 0xFFFFFF);
        this.func_73731_b(this.field_146297_k.field_71466_p, Intrinsics.stringPlus((String)"\u00a77Ign: \u00a7a", (Object)this.field_146297_k.func_110432_I().func_111285_a()), 6, 6, 0xFFFFFF);
        FontRenderer fontRenderer2 = this.field_146297_k.field_71466_p;
        if (altService.getCurrentService() == AltService.EnumAltService.THEALTENING) {
            string = "TheAltening";
        } else {
            string3 = this.field_146297_k.func_110432_I().func_148254_d();
            Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"mc.getSession().token");
            string = UserUtils.INSTANCE.isValidTokenOffline(string3) ? "Microsoft" : "Cracked";
        }
        this.func_73731_b(fontRenderer2, Intrinsics.stringPlus((String)"\u00a77Type: \u00a7a", (Object)string), 6, 16, 0xFFFFFF);
        GuiTextField guiTextField2 = this.searchField;
        if (guiTextField2 == null) {
            guiTextField2 = null;
        }
        guiTextField2.func_146194_f();
        GuiTextField guiTextField3 = this.searchField;
        if (guiTextField3 == null) {
            guiTextField3 = null;
        }
        string3 = guiTextField3.func_146179_b();
        Intrinsics.checkNotNullExpressionValue((Object)string3, (String)"searchField.text");
        if (((CharSequence)string3).length() == 0) {
            GuiTextField guiTextField4 = this.searchField;
            if (guiTextField4 == null) {
                guiTextField4 = null;
            }
            if (!guiTextField4.func_146206_l()) {
                FontRenderer fontRenderer3 = this.field_146297_k.field_71466_p;
                GuiTextField guiTextField5 = this.searchField;
                if (guiTextField5 == null) {
                    guiTextField5 = null;
                }
                this.func_73731_b(fontRenderer3, "\u00a77Search...", guiTextField5.field_146209_f + 3, 16, 0xFFFFFF);
            }
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    /*
     * Unable to fully structure code
     * Could not resolve type clashes
     */
    public void func_146284_a(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (!button.field_146124_l) {
            return;
        }
        switch (button.field_146127_k) {
            case 0: {
                this.field_146297_k.func_147108_a(this.prevGui);
                break;
            }
            case 1: {
                this.field_146297_k.func_147108_a((GuiScreen)new GuiAddAccount(this));
                break;
            }
            case 2: {
                v0 = this.altsList;
                if (v0 == null) {
                    v0 = null;
                }
                if (v0.getSelectedSlot() == -1) ** GOTO lbl-1000
                v1 = this.altsList;
                if (v1 == null) {
                    v1 = null;
                }
                v2 = v1.getSelectedSlot();
                v3 = this.altsList;
                if (v3 == null) {
                    v3 = null;
                }
                if (v2 < v3.func_148127_b()) {
                    v4 = Client.INSTANCE.getFileManager().accountsConfig;
                    v5 = this.altsList;
                    if (v5 == null) {
                        v5 = null;
                    }
                    v6 = v5.getAccounts();
                    v7 = this.altsList;
                    if (v7 == null) {
                        v7 = null;
                    }
                    v4.removeAccount(v6.get(v7.getSelectedSlot()));
                    Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                    v8 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v9 /* !! */  = v8 == null ? null : v8.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v9 /* !! */ );
                    if (((Boolean)v9 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v10 = "\u00a7aThe account has been deleted.";
                } else lbl-1000:
                // 2 sources

                {
                    v10 = "\u00a7cSelect an account.";
                }
                this.status = v10;
                break;
            }
            case 13: {
                if (LoginID.INSTANCE.isPremium()) {
                    altening = new TheAltening(CheckConnection.INSTANCE.getApiKey());
                    asynchronous = new TheAltening.Asynchronous(altening);
                    v11 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v12 /* !! */  = v11 == null ? null : v11.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v12 /* !! */ );
                    if (((Boolean)v12 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    asynchronous.getAccountData().thenAccept((Consumer<AccountData>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;)V, actionPerformed$lambda-4(net.aspw.client.visual.client.altmanager.GuiAltManager com.thealtening.api.data.AccountData ), (Lcom/thealtening/api/data/AccountData;)V)((GuiAltManager)this)).whenComplete((BiConsumer<Void, Throwable>)LambdaMetafactory.metafactory(null, null, null, (Ljava/lang/Object;Ljava/lang/Object;)V, actionPerformed$lambda-5(net.aspw.client.visual.client.altmanager.GuiAltManager java.lang.Void java.lang.Throwable ), (Ljava/lang/Void;Ljava/lang/Throwable;)V)((GuiAltManager)this));
                    break;
                }
                this.status = "\u00a7dPremium Gen is only for Premium NightX Users!";
                ClientUtils.getLogger().info("You are not using Premium Account!");
                break;
            }
            case 3: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.field_146297_k.field_71449_j.func_148254_d();
                }
                v13 = this;
                v14 = this.altsList;
                if (v14 == null) {
                    v14 = null;
                }
                if ((altening = v14.getSelectedAccount()) == null) {
                    v15 = "\u00a7cSelect an account.";
                } else {
                    var4_10 = altening;
                    var6_12 = v13;
                    $i$a$-let-GuiAltManager$actionPerformed$3 = false;
                    v16 = this.loginButton;
                    if (v16 == null) {
                        v16 = null;
                    }
                    v16.field_146124_l = false;
                    v17 = this.randomButton;
                    if (v17 == null) {
                        v17 = null;
                    }
                    v17.field_146124_l = false;
                    v18 = this.randomCracked;
                    if (v18 == null) {
                        v18 = null;
                    }
                    v18.field_146124_l = false;
                    GuiAltManager.Companion.login((MinecraftAccount)it, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.field_146297_k.field_71449_j.func_111285_a() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.field_146124_l = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.field_146124_l = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.field_146124_l = true;
                        }
                    }));
                    v19 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v20 /* !! */  = v19 == null ? null : v19.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v20 /* !! */ );
                    if (((Boolean)v20 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v13 = var6_12;
                    v15 = var3_7 = "\u00a7aLogging in...";
                }
                v13.status = v15;
                break;
            }
            case 4: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.field_146297_k.field_71449_j.func_148254_d();
                }
                v21 = this;
                v22 = this.altsList;
                if (v22 == null) {
                    v22 = null;
                }
                if ((altening = (MinecraftAccount)CollectionsKt.randomOrNull((Collection)v22.getAccounts(), (Random)((Random)Random.Default))) == null) {
                    v23 = "\u00a7cYou do not have any accounts.";
                } else {
                    it = altening;
                    var6_13 = v21;
                    $i$a$-let-GuiAltManager$actionPerformed$4 = false;
                    v24 = this.loginButton;
                    if (v24 == null) {
                        v24 = null;
                    }
                    v24.field_146124_l = false;
                    v25 = this.randomButton;
                    if (v25 == null) {
                        v25 = null;
                    }
                    v25.field_146124_l = false;
                    v26 = this.randomCracked;
                    if (v26 == null) {
                        v26 = null;
                    }
                    v26.field_146124_l = false;
                    GuiAltManager.Companion.login(it, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.field_146297_k.field_71449_j.func_111285_a() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.field_146124_l = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.field_146124_l = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.field_146124_l = true;
                        }
                    }));
                    v27 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    v28 /* !! */  = v27 == null ? null : v27.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)v28 /* !! */ );
                    if (((Boolean)v28 /* !! */ .get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    v21 = var6_13;
                    v23 = var3_8 = "\u00a7aLogging in...";
                }
                v21.status = v23;
                break;
            }
            case 99: {
                if (this.lastSessionToken == null) {
                    this.lastSessionToken = this.field_146297_k.field_71449_j.func_148254_d();
                }
                if ((v29 = this.loginButton) == null) {
                    v29 = null;
                }
                v29.field_146124_l = false;
                v30 = this.randomButton;
                if (v30 == null) {
                    v30 = null;
                }
                v30.field_146124_l = false;
                v31 = this.randomCracked;
                if (v31 == null) {
                    v31 = null;
                }
                v31.field_146124_l = false;
                rand = new CrackedAccount();
                var3_9 = RandomUtils.randomString(RandomUtils.nextInt(5, 16));
                Intrinsics.checkNotNullExpressionValue((Object)var3_9, (String)"randomString(RandomUtils.nextInt(5, 16))");
                rand.setName(var3_9);
                this.status = "\u00a7aGenerating...";
                GuiAltManager.Companion.login((MinecraftAccount)rand, (Function0<Unit>)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                        Intrinsics.checkNotNull((Object)boolValue);
                        if (((Boolean)boolValue.get()).booleanValue()) {
                            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                        }
                        this.this$0.setStatus("\u00a7aLogged successfully to " + this.this$0.field_146297_k.field_71449_j.func_111285_a() + '.');
                    }
                }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(1);
                    }

                    public final void invoke(Exception exception) {
                        Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                        this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                    }
                }), (Function0<Unit>)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                        if (guiButton == null) {
                            guiButton = null;
                        }
                        guiButton.field_146124_l = true;
                        GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                        if (guiButton2 == null) {
                            guiButton2 = null;
                        }
                        guiButton2.field_146124_l = true;
                        GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                        if (guiButton3 == null) {
                            guiButton3 = null;
                        }
                        guiButton3.field_146124_l = true;
                    }
                }));
                break;
            }
            case 9: {
                this.field_146297_k.func_147108_a((GuiScreen)new GuiTheAltening(this));
                break;
            }
            case 727: {
                v32 = this.loginButton;
                if (v32 == null) {
                    v32 = null;
                }
                v32.field_146124_l = false;
                v33 = this.randomButton;
                if (v33 == null) {
                    v33 = null;
                }
                v33.field_146124_l = false;
                v34 = this.randomCracked;
                if (v34 == null) {
                    v34 = null;
                }
                v34.field_146124_l = false;
                v35 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                v36 /* !! */  = v35 == null ? null : v35.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)v36 /* !! */ );
                if (((Boolean)v36 /* !! */ .get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                this.status = "\u00a7aLogging in...";
                ThreadsKt.thread$default((boolean)false, (boolean)false, null, null, (int)0, (Function0)((Function0)new Function0<Unit>(this){
                    final /* synthetic */ GuiAltManager this$0;
                    {
                        this.this$0 = $receiver;
                        super(0);
                    }

                    public final void invoke() {
                        String string;
                        String string2 = this.this$0.getLastSessionToken();
                        Intrinsics.checkNotNull((Object)string2);
                        LoginUtils.LoginResult loginResult = LoginUtils.loginSessionId(string2);
                        GuiAltManager guiAltManager = this.this$0;
                        switch (actionPerformed.WhenMappings.$EnumSwitchMapping$0[loginResult.ordinal()]) {
                            case 1: {
                                if (GuiAltManager.Companion.getAltService().getCurrentService() != AltService.EnumAltService.MOJANG) {
                                    GuiAltManager guiAltManager2 = guiAltManager;
                                    try {
                                        guiAltManager = guiAltManager2;
                                        GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                                    }
                                    catch (NoSuchFieldException e) {
                                        guiAltManager = guiAltManager2;
                                        ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                                    }
                                    catch (IllegalAccessException e) {
                                        guiAltManager = guiAltManager2;
                                        ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                                    }
                                }
                                string = "\u00a7cYour name is now \u00a7f\u00a7l" + this.this$0.field_146297_k.field_71449_j.func_111285_a() + "\u00a7c";
                                break;
                            }
                            case 2: {
                                string = "\u00a7cFailed to parse Session ID!";
                                break;
                            }
                            case 3: {
                                string = "\u00a7cInvalid Session ID!";
                                break;
                            }
                            default: {
                                throw new NoWhenBranchMatchedException();
                            }
                        }
                        guiAltManager.setStatus(string);
                        GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                        if (guiButton == null) {
                            guiButton = null;
                        }
                        guiButton.field_146124_l = true;
                        GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                        if (guiButton2 == null) {
                            guiButton2 = null;
                        }
                        guiButton2.field_146124_l = true;
                        GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                        if (guiButton3 == null) {
                            guiButton3 = null;
                        }
                        guiButton3.field_146124_l = true;
                        this.this$0.setLastSessionToken(null);
                    }
                }), (int)31, null);
            }
        }
    }

    public void func_73869_a(char typedChar, int keyCode) {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        if (guiTextField.func_146206_l()) {
            GuiTextField guiTextField2 = this.searchField;
            if (guiTextField2 == null) {
                guiTextField2 = null;
            }
            guiTextField2.func_146201_a(typedChar, keyCode);
        }
        switch (keyCode) {
            case 1: {
                this.field_146297_k.func_147108_a(this.prevGui);
                return;
            }
            case 200: {
                GuiList guiList;
                int i;
                GuiList guiList2 = this.altsList;
                if (guiList2 == null) {
                    guiList2 = null;
                }
                if ((i = guiList2.getSelectedSlot() - 1) < 0) {
                    i = 0;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList.func_148144_a(i, false, 0, 0);
                break;
            }
            case 208: {
                GuiList guiList;
                GuiList guiList3 = this.altsList;
                if (guiList3 == null) {
                    guiList3 = null;
                }
                int i = guiList3.getSelectedSlot() + 1;
                GuiList guiList4 = this.altsList;
                if (guiList4 == null) {
                    guiList4 = null;
                }
                if (i >= guiList4.func_148127_b()) {
                    GuiList guiList5 = this.altsList;
                    if (guiList5 == null) {
                        guiList5 = null;
                    }
                    i = guiList5.func_148127_b() - 1;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList.func_148144_a(i, false, 0, 0);
                break;
            }
            case 28: {
                GuiList guiList;
                GuiList guiList6 = this.altsList;
                if (guiList6 == null) {
                    guiList6 = null;
                }
                if ((guiList = this.altsList) == null) {
                    guiList = null;
                }
                guiList6.func_148144_a(guiList.getSelectedSlot(), true, 0, 0);
                break;
            }
            case 209: {
                GuiList guiList = this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                guiList.func_148145_f(this.field_146295_m - 100);
                break;
            }
            case 201: {
                GuiList guiList = this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                guiList.func_148145_f(-this.field_146295_m + 100);
                return;
            }
        }
        super.func_73869_a(typedChar, keyCode);
    }

    public void func_146274_d() {
        super.func_146274_d();
        GuiList guiList = this.altsList;
        if (guiList == null) {
            guiList = null;
        }
        guiList.func_178039_p();
    }

    public void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146192_a(mouseX, mouseY, mouseButton);
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    public void func_73876_c() {
        GuiTextField guiTextField = this.searchField;
        if (guiTextField == null) {
            guiTextField = null;
        }
        guiTextField.func_146178_a();
    }

    private static final void actionPerformed$lambda-4(GuiAltManager this$0, AccountData account) {
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
        BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
        Intrinsics.checkNotNull((Object)boolValue);
        if (((Boolean)boolValue.get()).booleanValue()) {
            Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
        }
        try {
            altService.switchService(AltService.EnumAltService.THEALTENING);
            Hud hud2 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue2 = hud2 == null ? null : hud2.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue2);
            if (((Boolean)boolValue2.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            YggdrasilUserAuthentication yggdrasilUserAuthentication = new YggdrasilUserAuthentication(new YggdrasilAuthenticationService(Proxy.NO_PROXY, ""), Agent.MINECRAFT);
            yggdrasilUserAuthentication.setUsername(account.getToken());
            yggdrasilUserAuthentication.setPassword(RandomUtils.randomString(6));
            try {
                yggdrasilUserAuthentication.logIn();
                this$0.field_146297_k.field_71449_j = new Session(yggdrasilUserAuthentication.getSelectedProfile().getName(), yggdrasilUserAuthentication.getSelectedProfile().getId().toString(), yggdrasilUserAuthentication.getAuthenticatedToken(), "mojang");
                Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
            }
            catch (AuthenticationException e) {
                altService.switchService(AltService.EnumAltService.MOJANG);
                ClientUtils.getLogger().error("Failed to login.", (Throwable)e);
                Intrinsics.stringPlus((String)"\u00a7cFailed to login: ", (Object)e.getMessage());
            }
        }
        catch (Throwable throwable) {
            Hud hud3 = Client.INSTANCE.getModuleManager().getModule(Hud.class);
            BoolValue boolValue3 = hud3 == null ? null : hud3.getFlagSoundValue();
            Intrinsics.checkNotNull((Object)boolValue3);
            if (((Boolean)boolValue3.get()).booleanValue()) {
                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
            }
            ClientUtils.getLogger().error("Failed to login.", throwable);
        }
    }

    private static final void actionPerformed$lambda-5(GuiAltManager this$0, Void $noName_0, Throwable $noName_1) {
        Intrinsics.checkNotNullParameter((Object)((Object)this$0), (String)"this$0");
        this$0.status = "\u00a7aLogged successfully to " + this$0.field_146297_k.field_71449_j.func_111285_a() + '.';
    }

    private final class GuiList
    extends GuiSlot {
        private int selectedSlot;

        public GuiList(GuiScreen prevGui) {
            Intrinsics.checkNotNullParameter((Object)((Object)GuiAltManager.this), (String)"this$0");
            Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
            super(GuiAltManager.this.field_146297_k, prevGui.field_146294_l, prevGui.field_146295_m, 40, prevGui.field_146295_m - 40, 30);
        }

        /*
         * WARNING - void declaration
         */
        public final List<MinecraftAccount> getAccounts() {
            void $this$filterTo$iv$iv;
            String search = null;
            GuiTextField guiTextField = GuiAltManager.this.searchField;
            if (guiTextField == null) {
                guiTextField = null;
            }
            if ((search = guiTextField.func_146179_b()) == null || ((CharSequence)search).length() == 0) {
                List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
                Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
                return list;
            }
            Locale locale = Locale.getDefault();
            Intrinsics.checkNotNullExpressionValue((Object)locale, (String)"getDefault()");
            Object object = search.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue((Object)object, (String)"this as java.lang.String).toLowerCase(locale)");
            search = object;
            List<MinecraftAccount> list = Client.INSTANCE.getFileManager().accountsConfig.getAccounts();
            Intrinsics.checkNotNullExpressionValue(list, (String)"fileManager.accountsConfig.accounts");
            Iterable $this$filter$iv = list;
            boolean $i$f$filter = false;
            object = $this$filter$iv;
            Collection destination$iv$iv = new ArrayList();
            boolean $i$f$filterTo = false;
            for (Object element$iv$iv : $this$filterTo$iv$iv) {
                MinecraftAccount it = (MinecraftAccount)element$iv$iv;
                boolean bl = false;
                boolean bl2 = StringsKt.contains((CharSequence)it.getName(), (CharSequence)search, (boolean)true) || it instanceof MojangAccount && StringsKt.contains((CharSequence)((MojangAccount)it).getEmail(), (CharSequence)search, (boolean)true);
                if (!bl2) continue;
                destination$iv$iv.add(element$iv$iv);
            }
            return (List)destination$iv$iv;
        }

        public final int getSelectedSlot() {
            return this.selectedSlot > this.getAccounts().size() ? -1 : this.selectedSlot;
        }

        public final void setSelectedSlot(int n) {
            this.selectedSlot = n;
        }

        public final MinecraftAccount getSelectedAccount() {
            return this.getSelectedSlot() >= 0 && this.getSelectedSlot() < this.getAccounts().size() ? this.getAccounts().get(this.getSelectedSlot()) : (MinecraftAccount)null;
        }

        protected boolean func_148131_a(int id) {
            return this.getSelectedSlot() == id;
        }

        public int func_148127_b() {
            return this.getAccounts().size();
        }

        /*
         * WARNING - void declaration
         */
        public void func_148144_a(int clickedElement, boolean doubleClick, int var3, int var4) {
            this.selectedSlot = clickedElement;
            if (doubleClick) {
                String string;
                MinecraftAccount minecraftAccount;
                GuiAltManager guiAltManager = GuiAltManager.this;
                GuiList guiList = GuiAltManager.this.altsList;
                if (guiList == null) {
                    guiList = null;
                }
                if ((minecraftAccount = guiList.getSelectedAccount()) == null) {
                    string = "\u00a7cSelect an account.";
                } else {
                    String string2;
                    void it;
                    MinecraftAccount minecraftAccount2 = minecraftAccount;
                    GuiAltManager guiAltManager2 = GuiAltManager.this;
                    MinecraftAccount minecraftAccount3 = minecraftAccount2;
                    GuiAltManager guiAltManager3 = guiAltManager;
                    boolean bl = false;
                    GuiButton guiButton = guiAltManager2.loginButton;
                    if (guiButton == null) {
                        guiButton = null;
                    }
                    guiButton.field_146124_l = false;
                    GuiButton guiButton2 = guiAltManager2.randomButton;
                    if (guiButton2 == null) {
                        guiButton2 = null;
                    }
                    guiButton2.field_146124_l = false;
                    GuiButton guiButton3 = guiAltManager2.randomCracked;
                    if (guiButton3 == null) {
                        guiButton3 = null;
                    }
                    guiButton3.field_146124_l = false;
                    Companion.login((MinecraftAccount)it, (Function0<Unit>)((Function0)new Function0<Unit>(guiAltManager2, this){
                        final /* synthetic */ GuiAltManager this$0;
                        final /* synthetic */ GuiList this$1;
                        {
                            this.this$0 = $receiver;
                            this.this$1 = $receiver2;
                            super(0);
                        }

                        public final void invoke() {
                            Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                            BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                            Intrinsics.checkNotNull((Object)boolValue);
                            if (((Boolean)boolValue.get()).booleanValue()) {
                                Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                            }
                            this.this$0.setStatus("\u00a7aLogged successfully to " + GuiList.access$getMc$p$s2037200985((GuiList)this.this$1).field_71449_j.func_111285_a() + '.');
                        }
                    }), (Function1<? super Exception, Unit>)((Function1)new Function1<Exception, Unit>(guiAltManager2){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(1);
                        }

                        public final void invoke(Exception exception) {
                            Intrinsics.checkNotNullParameter((Object)exception, (String)"exception");
                            this.this$0.setStatus("\u00a7cLogin failed to '" + exception.getMessage() + "'.");
                        }
                    }), (Function0<Unit>)((Function0)new Function0<Unit>(guiAltManager2){
                        final /* synthetic */ GuiAltManager this$0;
                        {
                            this.this$0 = $receiver;
                            super(0);
                        }

                        public final void invoke() {
                            GuiButton guiButton = GuiAltManager.access$getLoginButton$p(this.this$0);
                            if (guiButton == null) {
                                guiButton = null;
                            }
                            guiButton.field_146124_l = true;
                            GuiButton guiButton2 = GuiAltManager.access$getRandomButton$p(this.this$0);
                            if (guiButton2 == null) {
                                guiButton2 = null;
                            }
                            guiButton2.field_146124_l = true;
                            GuiButton guiButton3 = GuiAltManager.access$getRandomCracked$p(this.this$0);
                            if (guiButton3 == null) {
                                guiButton3 = null;
                            }
                            guiButton3.field_146124_l = true;
                        }
                    }));
                    Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                    BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                    Intrinsics.checkNotNull((Object)boolValue);
                    if (((Boolean)boolValue.get()).booleanValue()) {
                        Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                    }
                    guiAltManager = guiAltManager3;
                    string = string2 = "\u00a7aLogging in...";
                }
                guiAltManager.setStatus(string);
            }
        }

        protected void func_180791_a(int id, int x, int y, int var4, int var5, int var6) {
            MinecraftAccount minecraftAccount = this.getAccounts().get(id);
            String accountName = minecraftAccount instanceof MojangAccount && ((CharSequence)((MojangAccount)minecraftAccount).getName()).length() == 0 ? ((MojangAccount)minecraftAccount).getEmail() : minecraftAccount.getName();
            Fonts.minecraftFont.func_175063_a(accountName, (float)this.field_148155_a / 2.0f - (float)40, (float)y + 2.0f, Color.WHITE.getRGB());
            Fonts.minecraftFont.func_175063_a(minecraftAccount instanceof CrackedAccount ? "Cracked" : (minecraftAccount instanceof MicrosoftAccount ? "Microsoft" : (minecraftAccount instanceof MojangAccount ? "Mojang" : "Something else")), (float)this.field_148155_a / 2.0f - (float)40, (float)y + 15.0f, minecraftAccount instanceof CrackedAccount ? Color.GRAY.getRGB() : new Color(118, 255, 95).getRGB());
        }

        protected void func_148123_a() {
        }

        public static final /* synthetic */ Minecraft access$getMc$p$s2037200985(GuiList $this) {
            return $this.field_148161_k;
        }
    }

    public static final class Companion {
        private Companion() {
        }

        public final AltService getAltService() {
            return altService;
        }

        public final Thread login(MinecraftAccount minecraftAccount, Function0<Unit> success, Function1<? super Exception, Unit> error, Function0<Unit> done) {
            Intrinsics.checkNotNullParameter((Object)minecraftAccount, (String)"minecraftAccount");
            Intrinsics.checkNotNullParameter(success, (String)"success");
            Intrinsics.checkNotNullParameter(error, (String)"error");
            Intrinsics.checkNotNullParameter(done, (String)"done");
            return ThreadsKt.thread$default((boolean)false, (boolean)false, null, (String)"LoginTask", (int)0, (Function0)((Function0)new Function0<Unit>(error, minecraftAccount, success, done){
                final /* synthetic */ Function1<Exception, Unit> $error;
                final /* synthetic */ MinecraftAccount $minecraftAccount;
                final /* synthetic */ Function0<Unit> $success;
                final /* synthetic */ Function0<Unit> $done;
                {
                    this.$error = $error;
                    this.$minecraftAccount = $minecraftAccount;
                    this.$success = $success;
                    this.$done = $done;
                    super(0);
                }

                public final void invoke() {
                    if (GuiAltManager.Companion.getAltService().getCurrentService() != AltService.EnumAltService.MOJANG) {
                        try {
                            GuiAltManager.Companion.getAltService().switchService(AltService.EnumAltService.MOJANG);
                        }
                        catch (NoSuchFieldException e) {
                            this.$error.invoke((Object)e);
                            ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                        }
                        catch (IllegalAccessException e) {
                            this.$error.invoke((Object)e);
                            ClientUtils.getLogger().error("Something went wrong while trying to switch alt service.", (Throwable)e);
                        }
                    }
                    try {
                        this.$minecraftAccount.update();
                        Minecraft.func_71410_x().field_71449_j = new Session(this.$minecraftAccount.getSession().getUsername(), this.$minecraftAccount.getSession().getUuid(), this.$minecraftAccount.getSession().getToken(), "mojang");
                        Client.INSTANCE.getEventManager().callEvent(new SessionEvent());
                        this.$success.invoke();
                    }
                    catch (Exception exception) {
                        this.$error.invoke((Object)exception);
                    }
                    this.$done.invoke();
                }
            }), (int)23, null);
        }

        public /* synthetic */ Companion(DefaultConstructorMarker $constructor_marker) {
            this();
        }
    }
}

