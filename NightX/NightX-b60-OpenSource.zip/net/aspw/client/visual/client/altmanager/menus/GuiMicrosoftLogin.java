/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  kotlin.jvm.internal.Intrinsics
 *  me.liuli.elixir.account.MicrosoftAccount
 *  me.liuli.elixir.account.MicrosoftAccount$Companion
 *  me.liuli.elixir.account.MicrosoftAccount$OAuthHandler
 *  me.liuli.elixir.account.MinecraftAccount
 *  me.liuli.elixir.compat.OAuthServer
 *  net.minecraft.client.gui.GuiButton
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.util.ResourceLocation
 */
package net.aspw.client.visual.client.altmanager.menus;

import kotlin.jvm.internal.Intrinsics;
import me.liuli.elixir.account.MicrosoftAccount;
import me.liuli.elixir.account.MinecraftAccount;
import me.liuli.elixir.compat.OAuthServer;
import net.aspw.client.Client;
import net.aspw.client.features.module.impl.visual.Hud;
import net.aspw.client.util.ClientUtils;
import net.aspw.client.util.misc.MiscUtils;
import net.aspw.client.util.render.RenderUtils;
import net.aspw.client.value.BoolValue;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

public final class GuiMicrosoftLogin
extends GuiScreen {
    private final GuiScreen prevGui;
    private String stage;
    private OAuthServer server;

    public GuiMicrosoftLogin(GuiScreen prevGui) {
        Intrinsics.checkNotNullParameter((Object)prevGui, (String)"prevGui");
        this.prevGui = prevGui;
        this.stage = "Initializing...";
    }

    public void func_73866_w_() {
        this.server = MicrosoftAccount.Companion.buildFromOpenBrowser$default((MicrosoftAccount.Companion)MicrosoftAccount.Companion, (MicrosoftAccount.OAuthHandler)new MicrosoftAccount.OAuthHandler(this){
            final /* synthetic */ GuiMicrosoftLogin this$0;
            {
                this.this$0 = $receiver;
            }

            public void openUrl(String url) {
                Intrinsics.checkNotNullParameter((Object)url, (String)"url");
                GuiMicrosoftLogin.access$setStage$p(this.this$0, "Logging in...");
                ClientUtils.getLogger().info(Intrinsics.stringPlus((String)"Opening URL: ", (Object)url));
                MiscUtils.showURL(url);
            }

            public void authError(String error) {
                Intrinsics.checkNotNullParameter((Object)error, (String)"error");
                GuiMicrosoftLogin.access$setStage$p(this.this$0, Intrinsics.stringPlus((String)"Error: ", (Object)error));
            }

            public void authResult(MicrosoftAccount account) {
                Intrinsics.checkNotNullParameter((Object)account, (String)"account");
                if (Client.INSTANCE.getFileManager().accountsConfig.accountExists((MinecraftAccount)account)) {
                    GuiMicrosoftLogin.access$setStage$p(this.this$0, "\u00a7cThe account has already been added.");
                    return;
                }
                Client.INSTANCE.getFileManager().accountsConfig.addAccount((MinecraftAccount)account);
                Client.INSTANCE.getFileManager().saveConfig(Client.INSTANCE.getFileManager().accountsConfig);
                Hud hud = Client.INSTANCE.getModuleManager().getModule(Hud.class);
                BoolValue boolValue = hud == null ? null : hud.getFlagSoundValue();
                Intrinsics.checkNotNull((Object)boolValue);
                if (((Boolean)boolValue.get()).booleanValue()) {
                    Client.INSTANCE.getTipSoundManager().getPopSound().asyncPlay(Client.INSTANCE.getModuleManager().getPopSoundPower());
                }
                GuiMicrosoftLogin.access$setStage$p(this.this$0, "\u00a7aThe account has been added.");
                this.this$0.field_146297_k.func_147108_a(GuiMicrosoftLogin.access$getPrevGui$p(this.this$0));
            }
        }, null, (int)2, null);
        this.field_146292_n.add(new GuiButton(0, this.field_146294_l / 2 - 100, this.field_146295_m / 4 + 120 + 12, "Cancel"));
    }

    protected void func_146284_a(GuiButton button) {
        Intrinsics.checkNotNullParameter((Object)button, (String)"button");
        if (button.field_146127_k == 0) {
            OAuthServer oAuthServer = this.server;
            if (oAuthServer == null) {
                oAuthServer = null;
            }
            oAuthServer.stop(true);
            this.field_146297_k.func_147108_a(this.prevGui);
        }
    }

    public void func_73869_a(char typedChar, int keyCode) {
        if (keyCode == 1) {
            this.field_146297_k.func_147108_a(this.prevGui);
            OAuthServer oAuthServer = this.server;
            if (oAuthServer == null) {
                oAuthServer = null;
            }
            oAuthServer.stop(true);
            return;
        }
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        this.func_146276_q_();
        RenderUtils.drawImage(new ResourceLocation("client/background/portal.png"), 0, 0, this.field_146294_l, this.field_146295_m);
        this.func_73732_a(this.field_146297_k.field_71466_p, this.stage, this.field_146294_l / 2, this.field_146295_m / 2 - 50, 0xFFFFFF);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    public static final /* synthetic */ void access$setStage$p(GuiMicrosoftLogin $this, String string) {
        $this.stage = string;
    }

    public static final /* synthetic */ GuiScreen access$getPrevGui$p(GuiMicrosoftLogin $this) {
        return $this.prevGui;
    }
}

