/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.google.gson.JsonSyntaxException
 *  me.liuli.elixir.account.CrackedAccount
 *  me.liuli.elixir.account.MinecraftAccount
 *  me.liuli.elixir.account.MojangAccount
 *  me.liuli.elixir.manage.AccountSerializer
 */
package net.aspw.client.config.configs;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import me.liuli.elixir.account.CrackedAccount;
import me.liuli.elixir.account.MinecraftAccount;
import me.liuli.elixir.account.MojangAccount;
import me.liuli.elixir.manage.AccountSerializer;
import net.aspw.client.config.FileConfig;
import net.aspw.client.config.FileManager;

public class AccountsConfig
extends FileConfig {
    private final List<MinecraftAccount> accounts = new ArrayList<MinecraftAccount>();

    public AccountsConfig(File file) {
        super(file);
    }

    @Override
    protected void loadConfig() throws IOException {
        this.clearAccounts();
        JsonElement jsonElement = new JsonParser().parse((Reader)new BufferedReader(new FileReader(this.getFile())));
        if (jsonElement instanceof JsonNull) {
            return;
        }
        for (JsonElement accountElement : jsonElement.getAsJsonArray()) {
            JsonObject accountObject = accountElement.getAsJsonObject();
            try {
                this.accounts.add(AccountSerializer.INSTANCE.fromJson(accountElement.getAsJsonObject()));
            }
            catch (JsonSyntaxException | IllegalStateException e) {
                JsonElement name = accountObject.get("name");
                JsonElement password = accountObject.get("password");
                JsonElement inGameName = accountObject.get("inGameName");
                if (inGameName.isJsonNull() && password.isJsonNull()) {
                    MojangAccount mojangAccount = new MojangAccount();
                    mojangAccount.setEmail(name.getAsString());
                    mojangAccount.setName(inGameName.getAsString());
                    mojangAccount.setPassword(password.getAsString());
                    this.accounts.add((MinecraftAccount)mojangAccount);
                    continue;
                }
                CrackedAccount crackedAccount = new CrackedAccount();
                crackedAccount.setName(name.getAsString());
                this.accounts.add((MinecraftAccount)crackedAccount);
            }
        }
    }

    @Override
    protected void saveConfig() throws IOException {
        JsonArray jsonArray = new JsonArray();
        for (MinecraftAccount minecraftAccount : this.accounts) {
            jsonArray.add((JsonElement)AccountSerializer.INSTANCE.toJson(minecraftAccount));
        }
        PrintWriter printWriter = new PrintWriter(new FileWriter(this.getFile()));
        printWriter.println(FileManager.PRETTY_GSON.toJson((JsonElement)jsonArray));
        printWriter.close();
    }

    public void addCrackedAccount(String name) {
        CrackedAccount crackedAccount = new CrackedAccount();
        crackedAccount.setName(name);
        if (this.accountExists((MinecraftAccount)crackedAccount)) {
            return;
        }
        this.accounts.add((MinecraftAccount)crackedAccount);
    }

    public void addMojangAccount(String name, String password) {
        MojangAccount mojangAccount = new MojangAccount();
        mojangAccount.setName(name);
        mojangAccount.setPassword(password);
        if (this.accountExists((MinecraftAccount)mojangAccount)) {
            return;
        }
        this.accounts.add((MinecraftAccount)mojangAccount);
    }

    public void addAccount(MinecraftAccount account) {
        this.accounts.add(account);
    }

    public void removeAccount(int selectedSlot) {
        this.accounts.remove(selectedSlot);
    }

    public void removeAccount(MinecraftAccount account) {
        this.accounts.remove(account);
    }

    public boolean accountExists(MinecraftAccount newAccount) {
        for (MinecraftAccount minecraftAccount : this.accounts) {
            if (!minecraftAccount.getClass().getName().equals(newAccount.getClass().getName()) || !minecraftAccount.getName().equals(newAccount.getName())) continue;
            return true;
        }
        return false;
    }

    public void clearAccounts() {
        this.accounts.clear();
    }

    public List<MinecraftAccount> getAccounts() {
        return this.accounts;
    }
}

