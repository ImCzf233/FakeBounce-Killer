/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 */
package net.aspw.client.config.configs;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Map;
import net.aspw.client.Client;
import net.aspw.client.config.FileConfig;
import net.aspw.client.config.FileManager;
import net.aspw.client.features.api.MacroManager;
import net.aspw.client.features.module.Module;
import net.aspw.client.value.Value;
import net.aspw.client.visual.client.altmanager.menus.GuiTheAltening;

public class ValuesConfig
extends FileConfig {
    public ValuesConfig(File file) {
        super(file);
    }

    @Override
    protected void loadConfig() throws IOException {
        JsonElement jsonElement = new JsonParser().parse((Reader)new BufferedReader(new FileReader(this.getFile())));
        if (jsonElement instanceof JsonNull) {
            return;
        }
        JsonObject jsonObject = (JsonObject)jsonElement;
        for (Map.Entry entry : jsonObject.entrySet()) {
            JsonArray jsonValue;
            if (((String)entry.getKey()).equalsIgnoreCase("macros")) {
                jsonValue = ((JsonElement)entry.getValue()).getAsJsonArray();
                for (JsonElement macroElement : jsonValue) {
                    JsonObject macroObject = macroElement.getAsJsonObject();
                    JsonElement keyValue = macroObject.get("key");
                    JsonElement commandValue = macroObject.get("command");
                    MacroManager.INSTANCE.addMacro(keyValue.getAsInt(), commandValue.getAsString());
                }
                continue;
            }
            if (((String)entry.getKey()).equalsIgnoreCase("features")) continue;
            if (((String)entry.getKey()).equalsIgnoreCase("thealtening")) {
                jsonValue = (JsonObject)entry.getValue();
                if (!jsonValue.has("API-Key")) continue;
                GuiTheAltening.Companion.setApiKey(jsonValue.get("API-Key").getAsString());
                continue;
            }
            Module module = Client.moduleManager.getModule((String)entry.getKey());
            if (module == null) continue;
            JsonObject jsonModule = (JsonObject)entry.getValue();
            for (Value<?> moduleValue : module.getValues()) {
                JsonElement element = jsonModule.get(moduleValue.getName());
                if (element == null) continue;
                moduleValue.fromJson(element);
            }
        }
    }

    @Override
    protected void saveConfig() throws IOException {
        JsonObject jsonObject = new JsonObject();
        JsonArray jsonMacros = new JsonArray();
        MacroManager.INSTANCE.getMacroMapping().forEach((k, v) -> {
            JsonObject jsonMacro = new JsonObject();
            jsonMacro.addProperty("key", (Number)k);
            jsonMacro.addProperty("command", v);
            jsonMacros.add((JsonElement)jsonMacro);
        });
        jsonObject.add("macros", (JsonElement)jsonMacros);
        JsonObject jsonFeatures = new JsonObject();
        jsonObject.add("features", (JsonElement)jsonFeatures);
        JsonObject theAlteningObject = new JsonObject();
        theAlteningObject.addProperty("API-Key", GuiTheAltening.Companion.getApiKey());
        jsonObject.add("thealtening", (JsonElement)theAlteningObject);
        Client.moduleManager.getModules().stream().filter(module -> !module.getValues().isEmpty()).forEach(module -> {
            JsonObject jsonModule = new JsonObject();
            module.getValues().forEach(value -> jsonModule.add(value.getName(), value.toJson()));
            jsonObject.add(module.getName(), (JsonElement)jsonModule);
        });
        PrintWriter printWriter = new PrintWriter(new FileWriter(this.getFile()));
        printWriter.println(FileManager.PRETTY_GSON.toJson((JsonElement)jsonObject));
        printWriter.close();
    }
}

