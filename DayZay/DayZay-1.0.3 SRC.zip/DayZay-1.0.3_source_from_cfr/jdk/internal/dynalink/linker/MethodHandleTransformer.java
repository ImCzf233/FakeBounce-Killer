/*
 * Decompiled with CFR 0.150.
 */
package jdk.internal.dynalink.linker;

import java.lang.invoke.MethodHandle;

public interface MethodHandleTransformer {
    public MethodHandle transform(MethodHandle var1);
}

