/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir;

import java.util.List;
import jdk.nashorn.internal.codegen.Label;

public interface Labels {
    public List<Label> getLabels();
}

