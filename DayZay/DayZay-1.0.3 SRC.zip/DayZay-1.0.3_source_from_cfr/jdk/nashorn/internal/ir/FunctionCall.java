/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir;

public interface FunctionCall {
    public boolean isFunction();
}

