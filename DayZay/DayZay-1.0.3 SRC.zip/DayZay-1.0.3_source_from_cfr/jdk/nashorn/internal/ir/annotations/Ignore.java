/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(value=RetentionPolicy.RUNTIME)
public @interface Ignore {
}

