/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir.annotations;

public @interface Immutable {
}

