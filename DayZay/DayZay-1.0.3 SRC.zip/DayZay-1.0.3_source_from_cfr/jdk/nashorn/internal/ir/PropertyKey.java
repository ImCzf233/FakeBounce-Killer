/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir;

public interface PropertyKey {
    public String getPropertyName();
}

