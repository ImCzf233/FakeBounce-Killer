/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.ir;

import jdk.nashorn.internal.codegen.CompileUnit;

public interface CompileUnitHolder {
    public CompileUnit getCompileUnit();
}

