/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.arrays;

public interface AnyElements {
    public int getElementWeight();
}

