/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.arrays;

import jdk.nashorn.internal.runtime.arrays.AnyElements;

public interface NumericElements
extends AnyElements {
}

