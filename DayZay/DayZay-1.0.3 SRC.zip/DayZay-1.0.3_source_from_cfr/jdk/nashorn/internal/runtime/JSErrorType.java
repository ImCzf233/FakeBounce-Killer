/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime;

public enum JSErrorType {
    ERROR,
    EVAL_ERROR,
    RANGE_ERROR,
    REFERENCE_ERROR,
    SYNTAX_ERROR,
    TYPE_ERROR,
    URI_ERROR;

}

