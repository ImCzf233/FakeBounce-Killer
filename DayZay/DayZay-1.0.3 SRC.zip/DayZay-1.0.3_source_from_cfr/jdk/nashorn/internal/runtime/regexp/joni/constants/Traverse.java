/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public interface Traverse {
    public static final int TRAVERSE_CALLBACK_AT_FIRST = 1;
    public static final int TRAVERSE_CALLBACK_AT_LAST = 2;
    public static final int TRAVERSE_CALLBACK_AT_BOTH = 3;
}

