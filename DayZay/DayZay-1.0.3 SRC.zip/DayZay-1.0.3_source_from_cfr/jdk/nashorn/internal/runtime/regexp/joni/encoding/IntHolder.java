/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.encoding;

public class IntHolder {
    public int value;
}

