/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public interface Arguments {
    public static final int SPECIAL = -1;
    public static final int NON = 0;
    public static final int RELADDR = 1;
    public static final int ABSADDR = 2;
    public static final int LENGTH = 3;
    public static final int MEMNUM = 4;
    public static final int OPTION = 5;
    public static final int STATE_CHECK = 6;
}

