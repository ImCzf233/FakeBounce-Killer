/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.ast;

import jdk.nashorn.internal.runtime.regexp.joni.ast.Node;

public final class AnyCharNode
extends Node {
    @Override
    public int getType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Any Char";
    }

    @Override
    public String toString(int level) {
        String value = "";
        return "";
    }
}

