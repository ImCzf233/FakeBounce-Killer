/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public interface AsmConstants {
    public static final int THIS = 0;
    public static final int RANGE = 1;
    public static final int SSTART = 2;
    public static final int SPREV = 3;
    public static final int S = 4;
    public static final int BYTES = 5;
    public static final int LAST_INDEX = 6;
    public static final String STR = "str";
    public static final String END = "end";
    public static final String MSA_START = "msaStart";
    public static final String MSA_OPTONS = "msaOptions";
    public static final String MSA_BEST_LEN = "msaBestLen";
    public static final String MSA_BEST_S = "msaBestS";
    public static final String MSA_BEGIN = "msaBegin";
    public static final String MSA_END = "msaEnd";
    public static final String BITSET = "bitset";
    public static final String CODERANGE = "range";
    public static final String TEMPLATE = "template";
}

