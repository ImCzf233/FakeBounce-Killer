/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public enum CCSTATE {
    VALUE,
    RANGE,
    COMPLETE,
    START;

}

