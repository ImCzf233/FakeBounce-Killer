/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public enum CCVALTYPE {
    SB,
    CODE_POINT,
    CLASS;

}

