/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public interface TargetInfo {
    public static final int ISNOT_EMPTY = 0;
    public static final int IS_EMPTY = 1;
    public static final int IS_EMPTY_MEM = 2;
}

