/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.exception;

import jdk.nashorn.internal.runtime.regexp.joni.exception.JOniException;

public class SyntaxException
extends JOniException {
    private static final long serialVersionUID = 7862720128961874288L;

    public SyntaxException(String message) {
        super(message);
    }
}

