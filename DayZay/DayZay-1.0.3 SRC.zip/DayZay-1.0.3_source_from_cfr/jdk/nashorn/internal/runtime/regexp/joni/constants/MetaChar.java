/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.runtime.regexp.joni.constants;

public interface MetaChar {
    public static final int ESCAPE = 0;
    public static final int ANYCHAR = 1;
    public static final int ANYTIME = 2;
    public static final int ZERO_OR_ONE_TIME = 3;
    public static final int ONE_OR_MORE_TIME = 4;
    public static final int ANYCHAR_ANYTIME = 5;
    public static final int INEFFECTIVE_META_CHAR = 0;
}

