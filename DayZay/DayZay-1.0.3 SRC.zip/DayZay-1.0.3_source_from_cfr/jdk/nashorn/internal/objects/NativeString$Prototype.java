/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.PrototypeObject;

final class NativeString$Prototype
extends PrototypeObject {
    private Object toString;
    private Object valueOf;
    private Object charAt;
    private Object charCodeAt;
    private Object concat;
    private Object indexOf;
    private Object lastIndexOf;
    private Object localeCompare;
    private Object match;
    private Object replace;
    private Object search;
    private Object slice;
    private Object split;
    private Object substr;
    private Object substring;
    private Object toLowerCase;
    private Object toLocaleLowerCase;
    private Object toUpperCase;
    private Object toLocaleUpperCase;
    private Object trim;
    private Object trimLeft;
    private Object trimRight;
    private static final PropertyMap $nasgenmap$;

    public Object G$toString() {
        return this.toString;
    }

    public void S$toString(Object object) {
        this.toString = object;
    }

    public Object G$valueOf() {
        return this.valueOf;
    }

    public void S$valueOf(Object object) {
        this.valueOf = object;
    }

    public Object G$charAt() {
        return this.charAt;
    }

    public void S$charAt(Object object) {
        this.charAt = object;
    }

    public Object G$charCodeAt() {
        return this.charCodeAt;
    }

    public void S$charCodeAt(Object object) {
        this.charCodeAt = object;
    }

    public Object G$concat() {
        return this.concat;
    }

    public void S$concat(Object object) {
        this.concat = object;
    }

    public Object G$indexOf() {
        return this.indexOf;
    }

    public void S$indexOf(Object object) {
        this.indexOf = object;
    }

    public Object G$lastIndexOf() {
        return this.lastIndexOf;
    }

    public void S$lastIndexOf(Object object) {
        this.lastIndexOf = object;
    }

    public Object G$localeCompare() {
        return this.localeCompare;
    }

    public void S$localeCompare(Object object) {
        this.localeCompare = object;
    }

    public Object G$match() {
        return this.match;
    }

    public void S$match(Object object) {
        this.match = object;
    }

    public Object G$replace() {
        return this.replace;
    }

    public void S$replace(Object object) {
        this.replace = object;
    }

    public Object G$search() {
        return this.search;
    }

    public void S$search(Object object) {
        this.search = object;
    }

    public Object G$slice() {
        return this.slice;
    }

    public void S$slice(Object object) {
        this.slice = object;
    }

    public Object G$split() {
        return this.split;
    }

    public void S$split(Object object) {
        this.split = object;
    }

    public Object G$substr() {
        return this.substr;
    }

    public void S$substr(Object object) {
        this.substr = object;
    }

    public Object G$substring() {
        return this.substring;
    }

    public void S$substring(Object object) {
        this.substring = object;
    }

    public Object G$toLowerCase() {
        return this.toLowerCase;
    }

    public void S$toLowerCase(Object object) {
        this.toLowerCase = object;
    }

    public Object G$toLocaleLowerCase() {
        return this.toLocaleLowerCase;
    }

    public void S$toLocaleLowerCase(Object object) {
        this.toLocaleLowerCase = object;
    }

    public Object G$toUpperCase() {
        return this.toUpperCase;
    }

    public void S$toUpperCase(Object object) {
        this.toUpperCase = object;
    }

    public Object G$toLocaleUpperCase() {
        return this.toLocaleUpperCase;
    }

    public void S$toLocaleUpperCase(Object object) {
        this.toLocaleUpperCase = object;
    }

    public Object G$trim() {
        return this.trim;
    }

    public void S$trim(Object object) {
        this.trim = object;
    }

    public Object G$trimLeft() {
        return this.trimLeft;
    }

    public void S$trimLeft(Object object) {
        this.trimLeft = object;
    }

    public Object G$trimRight() {
        return this.trimRight;
    }

    public void S$trimRight(Object object) {
        this.trimRight = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeString$Prototype() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDCW.getStackDelta(OperationFactoryLDCW.java:17)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "String";
    }
}

