/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.objects.NativeMath;
import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.ScriptObject;

final class NativeMath$Constructor
extends ScriptObject {
    private Object abs;
    private Object acos;
    private Object asin;
    private Object atan;
    private Object atan2;
    private Object ceil;
    private Object cos;
    private Object exp;
    private Object floor;
    private Object log;
    private Object max;
    private Object min;
    private Object pow;
    private Object random;
    private Object round;
    private Object sin;
    private Object sqrt;
    private Object tan;
    private static final PropertyMap $nasgenmap$;

    public double G$E() {
        return NativeMath.E;
    }

    public double G$LN10() {
        return NativeMath.LN10;
    }

    public double G$LN2() {
        return NativeMath.LN2;
    }

    public double G$LOG2E() {
        return NativeMath.LOG2E;
    }

    public double G$LOG10E() {
        return NativeMath.LOG10E;
    }

    public double G$PI() {
        return NativeMath.PI;
    }

    public double G$SQRT1_2() {
        return NativeMath.SQRT1_2;
    }

    public double G$SQRT2() {
        return NativeMath.SQRT2;
    }

    public Object G$abs() {
        return this.abs;
    }

    public void S$abs(Object object) {
        this.abs = object;
    }

    public Object G$acos() {
        return this.acos;
    }

    public void S$acos(Object object) {
        this.acos = object;
    }

    public Object G$asin() {
        return this.asin;
    }

    public void S$asin(Object object) {
        this.asin = object;
    }

    public Object G$atan() {
        return this.atan;
    }

    public void S$atan(Object object) {
        this.atan = object;
    }

    public Object G$atan2() {
        return this.atan2;
    }

    public void S$atan2(Object object) {
        this.atan2 = object;
    }

    public Object G$ceil() {
        return this.ceil;
    }

    public void S$ceil(Object object) {
        this.ceil = object;
    }

    public Object G$cos() {
        return this.cos;
    }

    public void S$cos(Object object) {
        this.cos = object;
    }

    public Object G$exp() {
        return this.exp;
    }

    public void S$exp(Object object) {
        this.exp = object;
    }

    public Object G$floor() {
        return this.floor;
    }

    public void S$floor(Object object) {
        this.floor = object;
    }

    public Object G$log() {
        return this.log;
    }

    public void S$log(Object object) {
        this.log = object;
    }

    public Object G$max() {
        return this.max;
    }

    public void S$max(Object object) {
        this.max = object;
    }

    public Object G$min() {
        return this.min;
    }

    public void S$min(Object object) {
        this.min = object;
    }

    public Object G$pow() {
        return this.pow;
    }

    public void S$pow(Object object) {
        this.pow = object;
    }

    public Object G$random() {
        return this.random;
    }

    public void S$random(Object object) {
        this.random = object;
    }

    public Object G$round() {
        return this.round;
    }

    public void S$round(Object object) {
        this.round = object;
    }

    public Object G$sin() {
        return this.sin;
    }

    public void S$sin(Object object) {
        this.sin = object;
    }

    public Object G$sqrt() {
        return this.sqrt;
    }

    public void S$sqrt(Object object) {
        this.sqrt = object;
    }

    public Object G$tan() {
        return this.tan;
    }

    public void S$tan(Object object) {
        this.tan = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeMath$Constructor() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDCW.getStackDelta(OperationFactoryLDCW.java:17)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "Math";
    }
}

