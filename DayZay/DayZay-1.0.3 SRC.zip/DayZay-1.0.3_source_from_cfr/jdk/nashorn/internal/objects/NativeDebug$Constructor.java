/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.ScriptObject;

final class NativeDebug$Constructor
extends ScriptObject {
    private Object getArrayDataClass;
    private Object getArrayData;
    private Object getContext;
    private Object map;
    private Object identical;
    private Object equalWithoutType;
    private Object diffPropertyMaps;
    private Object getClass;
    private Object equals;
    private Object toJavaString;
    private Object toIdentString;
    private Object getListenerCount;
    private Object dumpCounters;
    private Object getEventQueueCapacity;
    private Object setEventQueueCapacity;
    private Object addRuntimeEvent;
    private Object expandEventQueueCapacity;
    private Object clearRuntimeEvents;
    private Object removeRuntimeEvent;
    private Object getRuntimeEvents;
    private Object getLastRuntimeEvent;
    private static final PropertyMap $nasgenmap$;

    public Object G$getArrayDataClass() {
        return this.getArrayDataClass;
    }

    public void S$getArrayDataClass(Object object) {
        this.getArrayDataClass = object;
    }

    public Object G$getArrayData() {
        return this.getArrayData;
    }

    public void S$getArrayData(Object object) {
        this.getArrayData = object;
    }

    public Object G$getContext() {
        return this.getContext;
    }

    public void S$getContext(Object object) {
        this.getContext = object;
    }

    public Object G$map() {
        return this.map;
    }

    public void S$map(Object object) {
        this.map = object;
    }

    public Object G$identical() {
        return this.identical;
    }

    public void S$identical(Object object) {
        this.identical = object;
    }

    public Object G$equalWithoutType() {
        return this.equalWithoutType;
    }

    public void S$equalWithoutType(Object object) {
        this.equalWithoutType = object;
    }

    public Object G$diffPropertyMaps() {
        return this.diffPropertyMaps;
    }

    public void S$diffPropertyMaps(Object object) {
        this.diffPropertyMaps = object;
    }

    public Object G$getClass() {
        return this.getClass;
    }

    public void S$getClass(Object object) {
        this.getClass = object;
    }

    public Object G$equals() {
        return this.equals;
    }

    public void S$equals(Object object) {
        this.equals = object;
    }

    public Object G$toJavaString() {
        return this.toJavaString;
    }

    public void S$toJavaString(Object object) {
        this.toJavaString = object;
    }

    public Object G$toIdentString() {
        return this.toIdentString;
    }

    public void S$toIdentString(Object object) {
        this.toIdentString = object;
    }

    public Object G$getListenerCount() {
        return this.getListenerCount;
    }

    public void S$getListenerCount(Object object) {
        this.getListenerCount = object;
    }

    public Object G$dumpCounters() {
        return this.dumpCounters;
    }

    public void S$dumpCounters(Object object) {
        this.dumpCounters = object;
    }

    public Object G$getEventQueueCapacity() {
        return this.getEventQueueCapacity;
    }

    public void S$getEventQueueCapacity(Object object) {
        this.getEventQueueCapacity = object;
    }

    public Object G$setEventQueueCapacity() {
        return this.setEventQueueCapacity;
    }

    public void S$setEventQueueCapacity(Object object) {
        this.setEventQueueCapacity = object;
    }

    public Object G$addRuntimeEvent() {
        return this.addRuntimeEvent;
    }

    public void S$addRuntimeEvent(Object object) {
        this.addRuntimeEvent = object;
    }

    public Object G$expandEventQueueCapacity() {
        return this.expandEventQueueCapacity;
    }

    public void S$expandEventQueueCapacity(Object object) {
        this.expandEventQueueCapacity = object;
    }

    public Object G$clearRuntimeEvents() {
        return this.clearRuntimeEvents;
    }

    public void S$clearRuntimeEvents(Object object) {
        this.clearRuntimeEvents = object;
    }

    public Object G$removeRuntimeEvent() {
        return this.removeRuntimeEvent;
    }

    public void S$removeRuntimeEvent(Object object) {
        this.removeRuntimeEvent = object;
    }

    public Object G$getRuntimeEvents() {
        return this.getRuntimeEvents;
    }

    public void S$getRuntimeEvents(Object object) {
        this.getRuntimeEvents = object;
    }

    public Object G$getLastRuntimeEvent() {
        return this.getLastRuntimeEvent;
    }

    public void S$getLastRuntimeEvent(Object object) {
        this.getLastRuntimeEvent = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeDebug$Constructor() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDCW.getStackDelta(OperationFactoryLDCW.java:17)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "Debug";
    }
}

