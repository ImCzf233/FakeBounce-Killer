/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.ScriptFunction;

final class NativeObject$Constructor
extends ScriptFunction {
    private Object setIndexedPropertiesToExternalArrayData;
    private Object getPrototypeOf;
    private Object setPrototypeOf;
    private Object getOwnPropertyDescriptor;
    private Object getOwnPropertyNames;
    private Object create;
    private Object defineProperty;
    private Object defineProperties;
    private Object seal;
    private Object freeze;
    private Object preventExtensions;
    private Object isSealed;
    private Object isFrozen;
    private Object isExtensible;
    private Object keys;
    private Object bindProperties;
    private static final PropertyMap $nasgenmap$;

    public Object G$setIndexedPropertiesToExternalArrayData() {
        return this.setIndexedPropertiesToExternalArrayData;
    }

    public void S$setIndexedPropertiesToExternalArrayData(Object object) {
        this.setIndexedPropertiesToExternalArrayData = object;
    }

    public Object G$getPrototypeOf() {
        return this.getPrototypeOf;
    }

    public void S$getPrototypeOf(Object object) {
        this.getPrototypeOf = object;
    }

    public Object G$setPrototypeOf() {
        return this.setPrototypeOf;
    }

    public void S$setPrototypeOf(Object object) {
        this.setPrototypeOf = object;
    }

    public Object G$getOwnPropertyDescriptor() {
        return this.getOwnPropertyDescriptor;
    }

    public void S$getOwnPropertyDescriptor(Object object) {
        this.getOwnPropertyDescriptor = object;
    }

    public Object G$getOwnPropertyNames() {
        return this.getOwnPropertyNames;
    }

    public void S$getOwnPropertyNames(Object object) {
        this.getOwnPropertyNames = object;
    }

    public Object G$create() {
        return this.create;
    }

    public void S$create(Object object) {
        this.create = object;
    }

    public Object G$defineProperty() {
        return this.defineProperty;
    }

    public void S$defineProperty(Object object) {
        this.defineProperty = object;
    }

    public Object G$defineProperties() {
        return this.defineProperties;
    }

    public void S$defineProperties(Object object) {
        this.defineProperties = object;
    }

    public Object G$seal() {
        return this.seal;
    }

    public void S$seal(Object object) {
        this.seal = object;
    }

    public Object G$freeze() {
        return this.freeze;
    }

    public void S$freeze(Object object) {
        this.freeze = object;
    }

    public Object G$preventExtensions() {
        return this.preventExtensions;
    }

    public void S$preventExtensions(Object object) {
        this.preventExtensions = object;
    }

    public Object G$isSealed() {
        return this.isSealed;
    }

    public void S$isSealed(Object object) {
        this.isSealed = object;
    }

    public Object G$isFrozen() {
        return this.isFrozen;
    }

    public void S$isFrozen(Object object) {
        this.isFrozen = object;
    }

    public Object G$isExtensible() {
        return this.isExtensible;
    }

    public void S$isExtensible(Object object) {
        this.isExtensible = object;
    }

    public Object G$keys() {
        return this.keys;
    }

    public void S$keys(Object object) {
        this.keys = object;
    }

    public Object G$bindProperties() {
        return this.bindProperties;
    }

    public void S$bindProperties(Object object) {
        this.bindProperties = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeObject$Constructor() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }
}

