/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PrototypeObject;

final class NativeJSAdapter$Prototype
extends PrototypeObject {
    NativeJSAdapter$Prototype() {
    }

    @Override
    public String getClassName() {
        return "JSAdapter";
    }
}

