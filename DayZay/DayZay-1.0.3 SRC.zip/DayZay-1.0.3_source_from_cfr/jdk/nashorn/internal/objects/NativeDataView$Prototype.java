/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.PrototypeObject;

final class NativeDataView$Prototype
extends PrototypeObject {
    private Object getInt8;
    private Object getUint8;
    private Object getInt16;
    private Object getUint16;
    private Object getInt32;
    private Object getUint32;
    private Object getFloat32;
    private Object getFloat64;
    private Object setInt8;
    private Object setUint8;
    private Object setInt16;
    private Object setUint16;
    private Object setInt32;
    private Object setUint32;
    private Object setFloat32;
    private Object setFloat64;
    private static final PropertyMap $nasgenmap$;

    public Object G$getInt8() {
        return this.getInt8;
    }

    public void S$getInt8(Object object) {
        this.getInt8 = object;
    }

    public Object G$getUint8() {
        return this.getUint8;
    }

    public void S$getUint8(Object object) {
        this.getUint8 = object;
    }

    public Object G$getInt16() {
        return this.getInt16;
    }

    public void S$getInt16(Object object) {
        this.getInt16 = object;
    }

    public Object G$getUint16() {
        return this.getUint16;
    }

    public void S$getUint16(Object object) {
        this.getUint16 = object;
    }

    public Object G$getInt32() {
        return this.getInt32;
    }

    public void S$getInt32(Object object) {
        this.getInt32 = object;
    }

    public Object G$getUint32() {
        return this.getUint32;
    }

    public void S$getUint32(Object object) {
        this.getUint32 = object;
    }

    public Object G$getFloat32() {
        return this.getFloat32;
    }

    public void S$getFloat32(Object object) {
        this.getFloat32 = object;
    }

    public Object G$getFloat64() {
        return this.getFloat64;
    }

    public void S$getFloat64(Object object) {
        this.getFloat64 = object;
    }

    public Object G$setInt8() {
        return this.setInt8;
    }

    public void S$setInt8(Object object) {
        this.setInt8 = object;
    }

    public Object G$setUint8() {
        return this.setUint8;
    }

    public void S$setUint8(Object object) {
        this.setUint8 = object;
    }

    public Object G$setInt16() {
        return this.setInt16;
    }

    public void S$setInt16(Object object) {
        this.setInt16 = object;
    }

    public Object G$setUint16() {
        return this.setUint16;
    }

    public void S$setUint16(Object object) {
        this.setUint16 = object;
    }

    public Object G$setInt32() {
        return this.setInt32;
    }

    public void S$setInt32(Object object) {
        this.setInt32 = object;
    }

    public Object G$setUint32() {
        return this.setUint32;
    }

    public void S$setUint32(Object object) {
        this.setUint32 = object;
    }

    public Object G$setFloat32() {
        return this.setFloat32;
    }

    public void S$setFloat32(Object object) {
        this.setFloat32 = object;
    }

    public Object G$setFloat64() {
        return this.setFloat64;
    }

    public void S$setFloat64(Object object) {
        this.setFloat64 = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeDataView$Prototype() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "DataView";
    }
}

