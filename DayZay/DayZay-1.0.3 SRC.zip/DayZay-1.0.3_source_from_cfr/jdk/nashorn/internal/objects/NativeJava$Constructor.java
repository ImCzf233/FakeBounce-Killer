/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.ScriptObject;

final class NativeJava$Constructor
extends ScriptObject {
    private Object isType;
    private Object synchronizedFunc;
    private Object isJavaMethod;
    private Object isJavaFunction;
    private Object isJavaObject;
    private Object isScriptObject;
    private Object isScriptFunction;
    private Object type;
    private Object typeName;
    private Object to;
    private Object from;
    private Object extend;
    private Object _super;
    private Object asJSONCompatible;
    private static final PropertyMap $nasgenmap$;

    public Object G$isType() {
        return this.isType;
    }

    public void S$isType(Object object) {
        this.isType = object;
    }

    public Object G$synchronizedFunc() {
        return this.synchronizedFunc;
    }

    public void S$synchronizedFunc(Object object) {
        this.synchronizedFunc = object;
    }

    public Object G$isJavaMethod() {
        return this.isJavaMethod;
    }

    public void S$isJavaMethod(Object object) {
        this.isJavaMethod = object;
    }

    public Object G$isJavaFunction() {
        return this.isJavaFunction;
    }

    public void S$isJavaFunction(Object object) {
        this.isJavaFunction = object;
    }

    public Object G$isJavaObject() {
        return this.isJavaObject;
    }

    public void S$isJavaObject(Object object) {
        this.isJavaObject = object;
    }

    public Object G$isScriptObject() {
        return this.isScriptObject;
    }

    public void S$isScriptObject(Object object) {
        this.isScriptObject = object;
    }

    public Object G$isScriptFunction() {
        return this.isScriptFunction;
    }

    public void S$isScriptFunction(Object object) {
        this.isScriptFunction = object;
    }

    public Object G$type() {
        return this.type;
    }

    public void S$type(Object object) {
        this.type = object;
    }

    public Object G$typeName() {
        return this.typeName;
    }

    public void S$typeName(Object object) {
        this.typeName = object;
    }

    public Object G$to() {
        return this.to;
    }

    public void S$to(Object object) {
        this.to = object;
    }

    public Object G$from() {
        return this.from;
    }

    public void S$from(Object object) {
        this.from = object;
    }

    public Object G$extend() {
        return this.extend;
    }

    public void S$extend(Object object) {
        this.extend = object;
    }

    public Object G$_super() {
        return this._super;
    }

    public void S$_super(Object object) {
        this._super = object;
    }

    public Object G$asJSONCompatible() {
        return this.asJSONCompatible;
    }

    public void S$asJSONCompatible(Object object) {
        this.asJSONCompatible = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeJava$Constructor() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "Java";
    }
}

