/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PrototypeObject;

final class NativeMath$Prototype
extends PrototypeObject {
    NativeMath$Prototype() {
    }

    @Override
    public String getClassName() {
        return "Math";
    }
}

