/*
 * Decompiled with CFR 0.150.
 */
package jdk.nashorn.internal.objects;

import jdk.nashorn.internal.runtime.PropertyMap;
import jdk.nashorn.internal.runtime.PrototypeObject;

final class NativeDate$Prototype
extends PrototypeObject {
    private Object toString;
    private Object toDateString;
    private Object toTimeString;
    private Object toLocaleString;
    private Object toLocaleDateString;
    private Object toLocaleTimeString;
    private Object valueOf;
    private Object getTime;
    private Object getFullYear;
    private Object getUTCFullYear;
    private Object getYear;
    private Object getMonth;
    private Object getUTCMonth;
    private Object getDate;
    private Object getUTCDate;
    private Object getDay;
    private Object getUTCDay;
    private Object getHours;
    private Object getUTCHours;
    private Object getMinutes;
    private Object getUTCMinutes;
    private Object getSeconds;
    private Object getUTCSeconds;
    private Object getMilliseconds;
    private Object getUTCMilliseconds;
    private Object getTimezoneOffset;
    private Object setTime;
    private Object setMilliseconds;
    private Object setUTCMilliseconds;
    private Object setSeconds;
    private Object setUTCSeconds;
    private Object setMinutes;
    private Object setUTCMinutes;
    private Object setHours;
    private Object setUTCHours;
    private Object setDate;
    private Object setUTCDate;
    private Object setMonth;
    private Object setUTCMonth;
    private Object setFullYear;
    private Object setUTCFullYear;
    private Object setYear;
    private Object toUTCString;
    private Object toGMTString;
    private Object toISOString;
    private Object toJSON;
    private static final PropertyMap $nasgenmap$;

    public Object G$toString() {
        return this.toString;
    }

    public void S$toString(Object object) {
        this.toString = object;
    }

    public Object G$toDateString() {
        return this.toDateString;
    }

    public void S$toDateString(Object object) {
        this.toDateString = object;
    }

    public Object G$toTimeString() {
        return this.toTimeString;
    }

    public void S$toTimeString(Object object) {
        this.toTimeString = object;
    }

    public Object G$toLocaleString() {
        return this.toLocaleString;
    }

    public void S$toLocaleString(Object object) {
        this.toLocaleString = object;
    }

    public Object G$toLocaleDateString() {
        return this.toLocaleDateString;
    }

    public void S$toLocaleDateString(Object object) {
        this.toLocaleDateString = object;
    }

    public Object G$toLocaleTimeString() {
        return this.toLocaleTimeString;
    }

    public void S$toLocaleTimeString(Object object) {
        this.toLocaleTimeString = object;
    }

    public Object G$valueOf() {
        return this.valueOf;
    }

    public void S$valueOf(Object object) {
        this.valueOf = object;
    }

    public Object G$getTime() {
        return this.getTime;
    }

    public void S$getTime(Object object) {
        this.getTime = object;
    }

    public Object G$getFullYear() {
        return this.getFullYear;
    }

    public void S$getFullYear(Object object) {
        this.getFullYear = object;
    }

    public Object G$getUTCFullYear() {
        return this.getUTCFullYear;
    }

    public void S$getUTCFullYear(Object object) {
        this.getUTCFullYear = object;
    }

    public Object G$getYear() {
        return this.getYear;
    }

    public void S$getYear(Object object) {
        this.getYear = object;
    }

    public Object G$getMonth() {
        return this.getMonth;
    }

    public void S$getMonth(Object object) {
        this.getMonth = object;
    }

    public Object G$getUTCMonth() {
        return this.getUTCMonth;
    }

    public void S$getUTCMonth(Object object) {
        this.getUTCMonth = object;
    }

    public Object G$getDate() {
        return this.getDate;
    }

    public void S$getDate(Object object) {
        this.getDate = object;
    }

    public Object G$getUTCDate() {
        return this.getUTCDate;
    }

    public void S$getUTCDate(Object object) {
        this.getUTCDate = object;
    }

    public Object G$getDay() {
        return this.getDay;
    }

    public void S$getDay(Object object) {
        this.getDay = object;
    }

    public Object G$getUTCDay() {
        return this.getUTCDay;
    }

    public void S$getUTCDay(Object object) {
        this.getUTCDay = object;
    }

    public Object G$getHours() {
        return this.getHours;
    }

    public void S$getHours(Object object) {
        this.getHours = object;
    }

    public Object G$getUTCHours() {
        return this.getUTCHours;
    }

    public void S$getUTCHours(Object object) {
        this.getUTCHours = object;
    }

    public Object G$getMinutes() {
        return this.getMinutes;
    }

    public void S$getMinutes(Object object) {
        this.getMinutes = object;
    }

    public Object G$getUTCMinutes() {
        return this.getUTCMinutes;
    }

    public void S$getUTCMinutes(Object object) {
        this.getUTCMinutes = object;
    }

    public Object G$getSeconds() {
        return this.getSeconds;
    }

    public void S$getSeconds(Object object) {
        this.getSeconds = object;
    }

    public Object G$getUTCSeconds() {
        return this.getUTCSeconds;
    }

    public void S$getUTCSeconds(Object object) {
        this.getUTCSeconds = object;
    }

    public Object G$getMilliseconds() {
        return this.getMilliseconds;
    }

    public void S$getMilliseconds(Object object) {
        this.getMilliseconds = object;
    }

    public Object G$getUTCMilliseconds() {
        return this.getUTCMilliseconds;
    }

    public void S$getUTCMilliseconds(Object object) {
        this.getUTCMilliseconds = object;
    }

    public Object G$getTimezoneOffset() {
        return this.getTimezoneOffset;
    }

    public void S$getTimezoneOffset(Object object) {
        this.getTimezoneOffset = object;
    }

    public Object G$setTime() {
        return this.setTime;
    }

    public void S$setTime(Object object) {
        this.setTime = object;
    }

    public Object G$setMilliseconds() {
        return this.setMilliseconds;
    }

    public void S$setMilliseconds(Object object) {
        this.setMilliseconds = object;
    }

    public Object G$setUTCMilliseconds() {
        return this.setUTCMilliseconds;
    }

    public void S$setUTCMilliseconds(Object object) {
        this.setUTCMilliseconds = object;
    }

    public Object G$setSeconds() {
        return this.setSeconds;
    }

    public void S$setSeconds(Object object) {
        this.setSeconds = object;
    }

    public Object G$setUTCSeconds() {
        return this.setUTCSeconds;
    }

    public void S$setUTCSeconds(Object object) {
        this.setUTCSeconds = object;
    }

    public Object G$setMinutes() {
        return this.setMinutes;
    }

    public void S$setMinutes(Object object) {
        this.setMinutes = object;
    }

    public Object G$setUTCMinutes() {
        return this.setUTCMinutes;
    }

    public void S$setUTCMinutes(Object object) {
        this.setUTCMinutes = object;
    }

    public Object G$setHours() {
        return this.setHours;
    }

    public void S$setHours(Object object) {
        this.setHours = object;
    }

    public Object G$setUTCHours() {
        return this.setUTCHours;
    }

    public void S$setUTCHours(Object object) {
        this.setUTCHours = object;
    }

    public Object G$setDate() {
        return this.setDate;
    }

    public void S$setDate(Object object) {
        this.setDate = object;
    }

    public Object G$setUTCDate() {
        return this.setUTCDate;
    }

    public void S$setUTCDate(Object object) {
        this.setUTCDate = object;
    }

    public Object G$setMonth() {
        return this.setMonth;
    }

    public void S$setMonth(Object object) {
        this.setMonth = object;
    }

    public Object G$setUTCMonth() {
        return this.setUTCMonth;
    }

    public void S$setUTCMonth(Object object) {
        this.setUTCMonth = object;
    }

    public Object G$setFullYear() {
        return this.setFullYear;
    }

    public void S$setFullYear(Object object) {
        this.setFullYear = object;
    }

    public Object G$setUTCFullYear() {
        return this.setUTCFullYear;
    }

    public void S$setUTCFullYear(Object object) {
        this.setUTCFullYear = object;
    }

    public Object G$setYear() {
        return this.setYear;
    }

    public void S$setYear(Object object) {
        this.setYear = object;
    }

    public Object G$toUTCString() {
        return this.toUTCString;
    }

    public void S$toUTCString(Object object) {
        this.toUTCString = object;
    }

    public Object G$toGMTString() {
        return this.toGMTString;
    }

    public void S$toGMTString(Object object) {
        this.toGMTString = object;
    }

    public Object G$toISOString() {
        return this.toISOString;
    }

    public void S$toISOString(Object object) {
        this.toISOString = object;
    }

    public Object G$toJSON() {
        return this.toJSON;
    }

    public void S$toJSON(Object object) {
        this.toJSON = object;
    }

    /*
     * Exception decompiling
     */
    public static {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackDelta(OperationFactoryLDC.java:18)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    /*
     * Exception decompiling
     */
    NativeDate$Prototype() {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * org.benf.cfr.reader.util.ConfusedCFRException: Expecting a ConstantPoolEntryLiteral or ConstantPoolEntryDynamicInfo
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDC.getStackType(OperationFactoryLDC.java:37)
         * org.benf.cfr.reader.bytecode.opcode.OperationFactoryLDCW.getStackDelta(OperationFactoryLDCW.java:17)
         * org.benf.cfr.reader.bytecode.opcode.JVMInstr.getStackDelta(JVMInstr.java:315)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:195)
         * org.benf.cfr.reader.bytecode.analysis.opgraph.Op02WithProcessedDataAndRefs.populateStackInfo(Op02WithProcessedDataAndRefs.java:1542)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:400)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:258)
         * org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:192)
         * org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         * org.benf.cfr.reader.entities.Method.analyse(Method.java:521)
         * org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1035)
         * org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:922)
         * org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:253)
         * org.benf.cfr.reader.Driver.doJar(Driver.java:135)
         * org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:65)
         * org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException(Decompilation failed);
    }

    @Override
    public String getClassName() {
        return "Date";
    }
}

