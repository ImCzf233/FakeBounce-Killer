var scriptName = "AutoDisabler";
var scriptAuthor = "Cat";
var scriptVersion = 1.1;

//本JS来自[猫柒团队]-CatBounce
//Dev.猫染 qq:3414576738
//Dev.瑾小七 qq:1209921041
//外部群：553849936
//欲商业使用请联系Dev

var a = 0
var c = 0
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils');
function KillAuraDisabler() {

    this.killAuraModule = moduleManager.getModule("AuraPlus");
    this.tntflyModule = moduleManager.getModule("GrimFLY");
    this.killAura2Module = moduleManager.getModule("KillAura2");
    this.killAura3Module = moduleManager.getModule("KillAura3");
    this.NoC03Module = moduleManager.getModule("NoC03");
    this.NoC0BModule = moduleManager.getModule("NoC0B");
    this.NoC03fModule = moduleManager.getModule("NoC03Fix");
    this.NoC03f2Module = moduleManager.getModule("noc03fix2");
    this.NoC0FModule = moduleManager.getModule("NoC0F");
    this.Velocity2Module = moduleManager.getModule("Velocity2");
    this.VelocityModule = moduleManager.getModule("Velocity");
    this.Velocity3Module = moduleManager.getModule("Velocity3");
    this.GrimVelocityModule = moduleManager.getModule("GrimVelocity");
    this.StopMoveModule = moduleManager.getModule("StopMove");
    this.MultiActionsModule = moduleManager.getModule("MultiActions");
    this.AutoWeaponModule = moduleManager.getModule("AutoWeapon");
    this.NoSlowModule = moduleManager.getModule("NoSlow");
    this.NoSlowdownModule = moduleManager.getModule("NoSlowdown");
    this.ScaffoldModule = moduleManager.getModule("Scaffold");
    this.Scaffold2Module = moduleManager.getModule("Scaffold2");
    this.ScaffoldlbModule = moduleManager.getModule("ScaffoldLB");
    this.eagleModule = moduleManager.getModule("eagle");
    this.PingspoofModule = moduleManager.getModule("Pingspoof");
    this.InvmoveModule = moduleManager.getModule("invmove");
    this.aModule = moduleManager.getModule("反击退瞬移修复");
    this.bModule = moduleManager.getModule("GrimVel");
    this.FastplaceModule = moduleManager.getModule("Fastplace");
    this.GNoslowModule = moduleManager.getModule("GrimNoslow");
    this.NoslowModule = moduleManager.getModule("Noslow");
    this.NoslowplusModule = moduleManager.getModule("NoslowPlus");
    this.timerModule = moduleManager.getModule("timer");
    this.tModule = moduleManager.getModule("targetstrafe");
    this.ScaffoldnewModule=moduleManager.getModule('Scaffoldnew');
    this.ScaffoldhelpModule=moduleManager.getModule('Scahelpernew');
    this.nobadpacketModule=moduleManager.getModule('nobadpacket');
    this.autotoolModule=moduleManager.getModule('autotool');
    this.nomovetimerModule=moduleManager.getModule('nomovetimer');
    this.safemodeModule=moduleManager.getModule('safeauramode');
    this.hytautoblockModule=moduleManager.getModule('hytautoblock');
    this.nolagbanModule=moduleManager.getModule('nolagban');
    this.eagleModule=moduleManager.getModule('eagle');
    this.speedModule=moduleManager.getModule('speed');
    this.timer2Module=moduleManager.getModule('timer2');
    this.antifireballModule=moduleManager.getModule('antifireball');
    this.espModule=moduleManager.getModule('esp');
    this.esp2Module=moduleManager.getModule('esp2');
    this.nametageModule=moduleManager.getModule('NameTags');
    this.StealerPlusModule=moduleManager.getModule('StealerPlus');
    this.AutoArmorModule=moduleManager.getModule('AutoArmor');
    this.InventoryCleanerModule=moduleManager.getModule('InventoryCleaner');
    


    this.getName = function () {
        return "AutoDisabler";
    }
    this.getcn = function () {
        return "自动关闭";
    }
    this.getCategory = function () {
        return "Misc";
    }

    this.getDescription = function () {
        return "Automatically disables something after dying.";
    }

 this.onJump = function () {
            this.Scaffold2Module.getState(false)
}

    this.onUpdate = function () {
        if(this.killAura2Module.getState(true)){
        mc.gameSettings.keyBindForward.pressed = false
        mc.gameSettings.keyBindLeft.pressed = false
        mc.gameSettings.keyBindBack.pressed = false
        mc.gameSettings.keyBindRight.pressed = false
        }

        if(this.killAuraModule.getState(true) || this.ScaffoldModule.getState(true) ){
         this.nobadpacketModule.getValue("c09fix").set(true);

        }else{         this.nobadpacketModule.getValue("c09fix").set(false)
}

		if(!mc.thePlayer.onGround) {    
                 this.InvmoveModule.getValue("nomoveclicks").set(true);
		} else {
            this.InvmoveModule.getValue("nomoveclicks").set(false);
} 


        if(this.killAuraModule.getState(true)){
this.AutoWeaponModule.setState(true);
        }else{
this.AutoWeaponModule.setState(false);
}
        if(this.ScaffoldlbModule.getState(true)){
this.killAuraModule.setState(false);
        }

        if(this.bModule.getState(true)){
this.Velocity2Module.setState(false);
        }else{
this.Velocity2Module.setState(true);
}

        if(this.ScaffoldModule.getState(true)){
            this.eagleModule.setState(true);
            this.Scaffold2Module.setState(true);
        }else{this.eagleModule.setState(false);
            this.Scaffold2Module.setState(false)
        }

        if(this.tntflyModule.getState(true)){
            this.antifireballModule.setState(false);
        }else{
            this.antifireballModule.setState(true);
        }

            if(this.espModule.getState(true)){
                this.esp2Module.setState(false);
                this.nametageModule.setState(false);
            }else{
                this.esp2Module.setState(true);
                this.nametageModule.setState(true);
            }

        if(this.StealerPlusModule.getState(true)){
            this.AutoArmorModule.setState(true);
            this.InventoryCleanerModule.setState(true);
        }else{
            this.AutoArmorModule.setState(false);
            this.InventoryCleanerModule.setState(false);
        }

        if (mc.thePlayer.isDead || mc.thePlayer.getHealth() <= 0) {
            this.tModule.setState(false);
            this.NoC0BModule.setState(false);
            this.killAuraModule.setState(false);
            this.aModule.setState(false);
            this.bModule.setState(false);
            this.killAura3Module.setState(false);
            this.PingspoofModule.setState(false);
            this.killAura2Module.setState(false);
            this.NoC03Module.setState(false);
            this.NoC03fModule.setState(false);
            this.NoC03f2Module.setState(false);
            this.StopMoveModule.setState(false);
            this.MultiActionsModule.setState(false);
            this.CriticalsModule.setState(false);
            this.TargetstrafeModule.setState(false);
            this.NoC0FModule.setState(false);
        }
    }
}

var KillAuraDisabler = new KillAuraDisabler();
var KillAuraDisablerClient;

function onEnable() {
    KillAuraDisablerClient = moduleManager.registerModule(KillAuraDisabler);
}

function onDisable() {
    moduleManager.unregisterModule(KillAuraDisablerClient);
}