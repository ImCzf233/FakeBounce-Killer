/// api_version=2
// 第一行三个斜杠的注释不要动，是脚本版本2的固定标识
// 下面是固定写法
var script = registerScript({
    name: "鸡你太美",
    version: "1.0.0",
    authors: ["My Name"]
})
// 玩家在游戏内发送消息
// mc.thePlayer.sendChatMessage()
// 让文本显示在游戏聊天框里（不会发送聊天消息）
// 支持原版颜色符号§，不支持&
// Chat.print()

script.registerModule(
    {
        name: "CXK",//模块名称
        category: "Fun", //分类 Movement, Misc, Combat, Fun, Player, Exploit, World, Render
        description: "An example module created with LiquidBounce's script API."//描述
    },
    function (module) {
        module.on(
            "enable",
            function () {
                Chat.print("鸡你太美歌词模块开启")//模块已启用
            }
        )
        module.on(
            "disable",
            function () {
                Chat.print("鸡你太美歌词模块关闭")//模块已禁用
            }
        )
        module.on(
            "update",
            function () {
                //Minecraft游戏每秒有20 tick
                //此function每一个tick就运行一次
                //所以每秒执行20次
                //不要在这里写for、while循环，否则Windows电脑的内存会立刻升高，
                //而且会把虚拟内存也占满，电脑马上就会蓝屏，写循环要去script.registerModule的外面写，也就是和script.registerModule并列。
                sendMessage()
            }
        )
    })
// 如果要定义变量名，直接写，前面好像只能加var
// js代码会被编译成java字节码，所以如果是从网上复制的js代码，需要把let,const这些去掉
// 不然的话，游戏里不会出现你写的功能
// 如果js代码在浏览器上正常运行，不代表在这里能运行，多用Chat.print()，一步一测试
ticks = 0
function sendMessage() {
    if (ticks % 60 == 0) {
        myMessage = jntmlrc()
        mc.thePlayer.sendChatMessage(myMessage)
    }
    ticks++
}
jntmLyrics = ["@购买猫染Client+①②零酒⑨②①零④衣，仅需25r，工艺群⑤雾③⑧私酒⑨③留，接下来播放《鸡你太美》：鸡你太美 baby 鸡你太美 baby", "@鸡你实在是太美 baby 鸡你太美 baby", "@迎面走来的你让我如此蠢蠢欲动", "@这种感觉我从未有", "@Cause I got a crush on you who you", "@你是我的我是你的谁", "@再多一眼看一眼就会爆炸", "@再近一点靠近点快被融化", "@想要把你占为己有baby bae", "@不管走到哪里都会想起的人是你 you you", "@我应该拿你怎样", "@uh 所有人都在看着你", "@我的心总是不安", "@oh 我现在已病入膏肓", "@eh eh 难道真的因为你而疯狂吗", "@我本来不是这种人", "@因你变成奇怪的人", "@第一次呀变成这样的我", "@不管我怎么去否认", "@鸡你太美 baby 鸡你太美 baby", "@鸡你实在是太美 baby 鸡你太美 baby", "@oh eh oh 现在确认地告诉我", "@oh eh oh 你到底属于谁", "@oh eh oh 现在确认地告诉我", "@oh eh oh 你到底属于谁 就是现在告诉我", "@跟着这节奏 缓缓 make wave", "@甜蜜的奶油 it\'s your birthday cake", "@男人们的 game call me 你恋人", "@别被欺骗愉快的 I wanna play", "@我的脑海每分每秒只为你一人沉醉", "@最迷人让我神魂颠倒是你身上香水", "@oh right baby I\'m fall in love with you", "@我的一切你都拿走只要有你就已足够", "@我到底应该怎样", "uh 我心里一直很不安", "@其他男人们的视线", "@Oh 全都只看向你的脸", "@Eh eh 难道真的因为你而疯狂吗", "@我本来不是这种人", "@因你变成奇怪的人", "@第一次呀变成这样的我", "@不管我怎么去否认", "@鸡你太美 baby 鸡你太美 baby", "@鸡你实在是太美 baby 鸡你太美 baby", "@我愿意把我的全部都给你", "@我每天在梦里都梦见你还有我闭着眼睛也能看到你", "@现在开始我只准你看我", "@I don\'t wanna wake up in dream 我只想看你这是真心话", "@鸡你太美 baby 鸡你太美 baby", "@鸡你实在是太美 baby 鸡你太美 baby", "oh eh oh 现在确认的告诉我", "@oh eh oh 你到底属于谁", "@oh eh oh 现在确认的告诉我", "@oh eh oh 你到底属于谁就是现在告诉我"]
jntmItemCount = 0
function jntmlrc() {
    tempstr = jntmLyrics[jntmItemCount]
    jntmItemCount++
    if (jntmItemCount == jntmLyrics.length) {
        jntmItemCount = 0
    }
    return tempstr
}