var scriptName = "CatbounceScaffoldHelper";
var scriptAuthor = "Cat";
var scriptVersion = 1.1;

var ScaffoldModule=moduleManager.getModule('Scaffold');
var EagleModule=moduleManager.getModule('Eagle');
var TimerModule=moduleManager.getModule('Timer');

function ScaffoldHelper() {
    this.getName = function () {
        return "CatbounceScaffold";
    }
    this.getCategory = function () {
        return "Misc";
    }
    this.getDescription = function () {
        return "官方QQ群553849936";
    }
    this.onEnable = function() {
        EagleModule.setState(true);
    }
    this.onDisable = function() {
        EagleModule.setState(false);
    }
    this.onUpdate = function () {
        if(mc.thePlayer.motionZ > 0.15 && mc.thePlayer.motionX < 0.15 && mc.thePlayer.motionX > -0.15){
            mc.thePlayer.rotationYaw = 0
        }
    if(mc.thePlayer.motionZ > 0.15 && mc.thePlayer.motionX > 0.15){
            mc.thePlayer.rotationYaw = -45
        }
    if(mc.thePlayer.motionZ < -0.15 && mc.thePlayer.motionX > 0.15){
            mc.thePlayer.rotationYaw = -135
        }
    if(mc.thePlayer.motionZ < -0.15 && mc.thePlayer.motionX < -0.15){
            mc.thePlayer.rotationYaw = 135
        }
    if(mc.thePlayer.motionZ > 0.15 && mc.thePlayer.motionX < -0.15){
            mc.thePlayer.rotationYaw = 45
        }
        if(mc.thePlayer.motionZ < -0.15 && mc.thePlayer.motionX < 0.15 && mc.thePlayer.motionX > -0.15){
            mc.thePlayer.rotationYaw = -180
        }
        if(mc.thePlayer.motionX > 0.15 && mc.thePlayer.motionZ < 0.15 && mc.thePlayer.motionZ > -0.15){
            mc.thePlayer.rotationYaw = -90
        }
        if(mc.thePlayer.motionX < -0.15 && mc.thePlayer.motionZ < 0.15 && mc.thePlayer.motionZ > -0.15){
            mc.thePlayer.rotationYaw = 90
        }
    }
}

var ScaffoldHelper = new ScaffoldHelper();
var ScaffoldHelper;

function onEnable() {
    ScaffoldHelperClient = moduleManager.registerModule(ScaffoldHelper);
}

function onDisable() {
    moduleManager.unregisterModule(ScaffoldHelperClient);
}