var scriptName = "noc03fix2";
var scriptAuthor = "Cat";
var scriptVersion = 1.1;

//本JS来自[猫柒团队]-CatBounce
//Dev.猫染 qq:3414576738
//Dev.瑾小七 qq:1209921041
//外部群：553849936
//欲商业使用请联系Dev


var a = 0;
function KillAuraDisabler() {

    this.noc03Module = moduleManager.getModule("noc03");
    this.killAuraModule = moduleManager.getModule("killAura2");
    this.criticals3Module = moduleManager.getModule("criticals3");
    this.velocityModule = moduleManager.getModule("velocity");

    this.getName = function () {
        return "noc03fix2";
    }
    this.getCategory = function () {
        return "Misc";
    }

    this.getDescription = function () {
        return "Jumpfix for Killaura";
    }

    this.getTag = function() {
        return "CatBounce";
    }

 this.onEnable = function () {
     this.killAuraModule.setState(true);
     this.noc03Module.setState(true);
     this.velocityModule.setState(true);
}

    this.onDisable = function() {
  this.killAuraModule.setState(false);
  this.noc03Module.setState(false);
            this.velocityModule.setState(false);
  chat.print("§c[CatBounce] " + "§b已关闭NoC03，请在接下来的3s内不要移动 ");
mc.thePlayer.jump();
    }

}

var KillAuraDisabler = new KillAuraDisabler();
var KillAuraDisablerClient;

function onEnable() {
    KillAuraDisablerClient = moduleManager.registerModule(KillAuraDisabler);
}

function onDisable() {
    moduleManager.unregisterModule(KillAuraDisablerClient);
}