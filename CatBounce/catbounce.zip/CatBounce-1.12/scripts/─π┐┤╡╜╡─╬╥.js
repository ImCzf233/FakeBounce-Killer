/// api_version=2
// 第一行三个斜杠的注释不要动，是脚本版本2的固定标识
// 下面是固定写法
var script = registerScript({
    name: "你看到的我",
    version: "1.0.0",
    authors: ["My Name"]
})
// 玩家在游戏内发送消息
// mc.thePlayer.sendChatMessage()
// 让文本显示在游戏聊天框里（不会发送聊天消息）
// 支持原版颜色符号§，不支持&
// Chat.print()

script.registerModule(
    {
        name: "你看到的我",//模块名称
        category: "Fun", //分类 Movement, Misc, Combat, Fun, Player, Exploit, World, Render
        description: "An example module created with LiquidBounce's script API."//描述
    },
    function (module) {
        module.on(
            "enable",
            function () {
                Chat.print("歌词模块开启")//模块已启用
            }
        )
        module.on(
            "disable",
            function () {
                Chat.print("歌词模块关闭")//模块已禁用
            }
        )
        module.on(
            "update",
            function () {
                //Minecraft游戏每秒有20 tick
                //此function每一个tick就运行一次
                //所以每秒执行20次
                //不要在这里写for、while循环，否则Windows电脑的内存会立刻升高，
                //而且会把虚拟内存也占满，电脑马上就会蓝屏，写循环要去script.registerModule的外面写，也就是和script.registerModule并列。
                sendMessage()
            }
        )
    })
// 如果要定义变量名，直接写，前面好像只能加var
// js代码会被编译成java字节码，所以如果是从网上复制的js代码，需要把let,const这些去掉
// 不然的话，游戏里不会出现你写的功能
// 如果js代码在浏览器上正常运行，不代表在这里能运行，多用Chat.print()，一步一测试
ticks = 0
function sendMessage() {
    if (ticks % 60 == 0) {
        myMessage = jntmlrc()
        mc.thePlayer.sendChatMessage(myMessage)
    }
    ticks++
}
jntmLyrics = 
[
,"@购买猫染Client+①②零酒⑨②①零④衣，仅需25r，工艺群⑤雾③⑧私酒⑨③留，接下来播放《你看到的我》"
,"@背起了行囊"
,"@离开家的那一刻"
,"@我知道现实生活"
,"@有太多特别的特"
,"@假如你看到了我"
,"@也不要太过冷漠"
,"@我多愁善感"
,"@但也热情奔放洒脱"
,"@匆忙的世界"
,"@来不及问为什么"
,"@我知道漂泊的人"
,"@心中都有一团火"
,"@假如你又看到我"
,"@请给我一个拥抱"
,"@我偶尔沉默"
,"@但也勇敢执着"
,"@你看到的我 你看到的我"
,"@是哪一种颜色"
,"@悲伤或快乐"
,"@也许老了一点"
,"@眼神变得不再那么清澈"
,"@热血依然沸腾着我的脉搏"
,"@你看到的我 你看到的我"
,"@是哪一种性格"
,"@开朗或慢热"
,"@像勇敢的雄鹰"
,"@不怕风雨不怕困难挫折"
,"@如果要fly就fly出天空海阔"
,"@我就是我"
,"@匆忙的世界"
,"@来不及问为什么"
,"@我知道漂泊的人"
,"@心中都有一团火"
,"@假如你又看到我"
,"@请给我一个拥抱"
,"@我偶尔沉默"
,"@但也勇敢执着"
,"@你看到的我 你看到的我"
,"@是哪一种颜色"
,"@悲伤或快乐"
,"@也许老了一点"
,"@眼神变得不再那么清澈"
,"@热血依然沸腾着我的脉搏"
,"@你看到的我 你看到的我"
,"@是哪一种性格"
,"@开朗或慢热"
,"@像勇敢的雄鹰"
,"@不怕风雨不怕困难挫折"
,"@如果要fly就fly出天空海阔"
,"@我就是我"
,"@你看到的我 你看到的我"
,"@是哪一种颜色"
,"@悲伤或快乐"
,"@也许老了一点"
,"@眼神变得不再那么清澈"
,"@热血依然沸腾着我的脉搏"
,"@你看到的我 你看到的我"
,"@是哪一种性格"
,"@开朗或慢热"
,"@像勇敢的雄鹰"
,"@不怕风雨不怕困难挫折"
,"@如果要fly就fly出天空海阔"
,"@我就是我"
]
jntmItemCount = 0
function jntmlrc() {
    tempstr = jntmLyrics[jntmItemCount]
    jntmItemCount++
    if (jntmItemCount == jntmLyrics.length) {
        jntmItemCount = 0
    }
    return tempstr
}