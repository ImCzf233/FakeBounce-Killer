/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.injection.access;

public interface IItemStack {
    public long getItemDelay();
}

