/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.injection.access;

public interface IMixinWorldAccess {
    public void markBlockForUpdate(int var1, int var2, int var3);

    public void notifyLightSet(int var1, int var2, int var3);
}

