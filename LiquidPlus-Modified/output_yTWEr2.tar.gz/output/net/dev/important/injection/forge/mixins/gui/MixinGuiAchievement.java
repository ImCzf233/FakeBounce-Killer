/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.achievement.GuiAchievement
 */
package net.dev.important.injection.forge.mixins.gui;

import net.minecraft.client.gui.achievement.GuiAchievement;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={GuiAchievement.class})
public class MixinGuiAchievement {
}

