/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  org.lwjgl.input.Keyboard
 */
package net.dev.important.injection.forge.mixins.bugfixes;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={Minecraft.class})
public class MinecraftMixin_ForeignKeyboards {
    @Redirect(method={"dispatchKeypresses"}, at=@At(value="INVOKE", target="Lorg/lwjgl/input/Keyboard;getEventCharacter()C", remap=false))
    private char patcher$resolveForeignKeyboards() {
        return (char)(Keyboard.getEventCharacter() + 256);
    }
}

