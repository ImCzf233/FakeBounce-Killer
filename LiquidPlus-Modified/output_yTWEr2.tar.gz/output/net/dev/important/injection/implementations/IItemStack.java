/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.injection.implementations;

public interface IItemStack {
    public long getItemDelay();
}

