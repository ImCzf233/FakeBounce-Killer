/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.modules.module.modules.render;

import kotlin.Metadata;
import net.dev.important.modules.module.Category;
import net.dev.important.modules.module.Info;
import net.dev.important.modules.module.Module;

@Info(name="NoHurtCam", spacedName="No Hurt Cam", description="Disables hurt cam effect when getting hurt.", category=Category.RENDER, cnName="\u65e0\u53d7\u4f24\u6447\u6643")
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lnet/dev/important/modules/module/modules/render/NoHurtCam;", "Lnet/dev/important/modules/module/Module;", "()V", "LiquidBounce"})
public final class NoHurtCam
extends Module {
}

