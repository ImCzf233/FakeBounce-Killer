/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.modules.module.modules.misc;

import kotlin.Metadata;
import net.dev.important.modules.module.Category;
import net.dev.important.modules.module.Info;
import net.dev.important.modules.module.Module;

@Info(name="AntiDesync", spacedName="Anti Desync", description="Fix Minecraft's bug with active movement.", category=Category.MISC, cnName="\u4fee\u590d\u79fb\u52a8\u6570\u636e\u5305")
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lnet/dev/important/modules/module/modules/misc/AntiDesync;", "Lnet/dev/important/modules/module/Module;", "()V", "LiquidBounce"})
public final class AntiDesync
extends Module {
}

