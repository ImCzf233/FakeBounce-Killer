/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.modules.module.modules.combat;

import kotlin.Metadata;
import net.dev.important.modules.module.Category;
import net.dev.important.modules.module.Info;
import net.dev.important.modules.module.Module;

@Info(name="NoFriends", spacedName="No Friends", description="Allows you to attack friends.", category=Category.COMBAT, cnName="\u6ca1\u6709\u767d\u540d\u5355")
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lnet/dev/important/modules/module/modules/combat/NoFriends;", "Lnet/dev/important/modules/module/Module;", "()V", "LiquidBounce"})
public final class NoFriends
extends Module {
}

