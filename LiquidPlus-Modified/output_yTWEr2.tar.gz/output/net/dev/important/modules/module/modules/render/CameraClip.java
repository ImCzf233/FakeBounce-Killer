/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.modules.module.modules.render;

import kotlin.Metadata;
import net.dev.important.modules.module.Category;
import net.dev.important.modules.module.Info;
import net.dev.important.modules.module.Module;

@Info(name="CameraClip", spacedName="Camera Clip", description="Allows you to see through walls in third person view.", category=Category.RENDER, cnName="\u76f8\u673a\u89c6\u89d2")
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lnet/dev/important/modules/module/modules/render/CameraClip;", "Lnet/dev/important/modules/module/Module;", "()V", "LiquidBounce"})
public final class CameraClip
extends Module {
}

