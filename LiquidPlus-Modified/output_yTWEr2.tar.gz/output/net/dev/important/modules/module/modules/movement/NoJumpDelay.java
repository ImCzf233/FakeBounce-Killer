/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.modules.module.modules.movement;

import kotlin.Metadata;
import net.dev.important.modules.module.Category;
import net.dev.important.modules.module.Info;
import net.dev.important.modules.module.Module;

@Info(name="NoJumpDelay", spacedName="No Jump Delay", description="Removes delay between jumps.", category=Category.MOVEMENT, cnName="\u65e0\u8df3\u8dc3\u5ef6\u8fdf")
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0005\u00a2\u0006\u0002\u0010\u0002\u00a8\u0006\u0003"}, d2={"Lnet/dev/important/modules/module/modules/movement/NoJumpDelay;", "Lnet/dev/important/modules/module/Module;", "()V", "LiquidBounce"})
public final class NoJumpDelay
extends Module {
}

