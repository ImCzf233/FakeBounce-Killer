/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.patcher.ducks;

import net.dev.important.patcher.hooks.font.FontRendererHook;

public interface FontRendererExt {
    public FontRendererHook patcher$getFontRendererHook();
}

