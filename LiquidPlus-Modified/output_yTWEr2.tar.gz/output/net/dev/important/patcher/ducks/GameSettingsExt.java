/*
 * Decompiled with CFR 0.152.
 */
package net.dev.important.patcher.ducks;

public interface GameSettingsExt {
    public void patcher$onSettingsGuiClosed();
}

